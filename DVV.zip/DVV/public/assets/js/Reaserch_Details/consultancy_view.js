//Name of the Project
  function validateProjectName() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('projectname').value;
    var error = document.getElementById("projectnameError");
  
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
  
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
  
    var finalprojectname = capitalizedWords.join(" ");
    document.getElementById('projectname').value = finalprojectname;
  
    if (finalprojectname.length === 0 || regName.test(finalprojectname)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
  }
  
  // Attach event listener using JavaScript
  document.getElementById('projectname').addEventListener('input', validateProjectName);
  



//Consulting/Sponsoring agency 
  function validateAgency() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('agency').value;
    var error = document.getElementById("agencyError");
  
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
  
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
  
    var finalagency = capitalizedWords.join(" ");
    document.getElementById('agency').value = finalagency;
  
    if (finalagency.length === 0 || regName.test(finalagency)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
  }
  
  // Attach event listener using JavaScript
  document.getElementById('agency').addEventListener('input', validateAgency);
  

//Validation for Revenue Generated
function validateRevenue(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field
  
    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));
  
    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("revenueError").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("revenueError").style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("revenueError").style.display = "none";
        inputElement.setCustomValidity("");
    }
  }
  
  // Add an event listener to the input field
  document.getElementById("revenue").addEventListener("input", function () {
    validateRevenue(this);
  });
  

//No. of Trainings
function validateTraining(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field
  
    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));
  
    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("trainingError").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("trainingError").style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("trainingError").style.display = "none";
        inputElement.setCustomValidity("");
    }
  }
  
  // Add an event listener to the input field
  document.getElementById("training").addEventListener("input", function () {
    validateTraining(this);
  });


//Upload Letter of Beneficiary
function validateBeneficiary(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('beneficiaryError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}