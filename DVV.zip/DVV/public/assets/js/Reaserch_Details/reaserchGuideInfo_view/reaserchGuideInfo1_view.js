//For Ph.D. Guide
function showTextBox() {
    document.getElementById("text-input1").style.display = "block";
    document.getElementById("text-input2").style.display = "block";
    document.getElementById("text-input3").style.display = "block";
    document.getElementById("year1").style.display = "block";
    document.getElementById("Co-Guide").style.display ="none";

    //Add form, remove form, submit displaying
    document.getElementById("myTemplate").style.display = "block";


}

function hideTextBox() {
    document.getElementById("text-input1").style.display = "none";
    document.getElementById("text-input2").style.display = "none";
    document.getElementById("text-input3").style.display = "none";
    document.getElementById("year1").style.display = "none";
    document.getElementById("Co-Guide").style.display ="none";

    document.getElementById("myTemplate").style.display = "none";
    //Add form, remove form, submit hiding
}
function display(){
    document.getElementById("Co-Guide").style.display ="block";
}


//For Ph.D.Co-Guide
function showTextBox1() {
    document.getElementById("text-input1").style.display = "block";
    document.getElementById("text-input2").style.display = "block";
    document.getElementById("text-input3").style.display = "block";
    document.getElementById("year1").style.display = "block";

    //Add form, remove form, submit displaying
    document.getElementById("myTemplate").style.display = "block";

}

function hideTextBox1() {
    document.getElementById("text-input1").style.display = "none";
    document.getElementById("text-input2").style.display = "none";
    document.getElementById("text-input3").style.display = "none";
    document.getElementById("year1").style.display = "none";

    //Add form, remove form, submit hiding
    document.getElementById("myTemplate").style.display = "none";

}
//validation for Subject Name
function validateSubName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('subject').value;
    var error = document.getElementById("subjectnameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalSubName = capitalizedWords.join(" ");
    
    document.getElementById('subject').value = finalSubName;
  
    if (finalSubName.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalSubName)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

  //validation for Center Name
  function validateCenterName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('center').value;
    var error = document.getElementById("centernameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalCenterName = capitalizedWords.join(" ");
    
    document.getElementById('center').value = finalCenterName;
  
    if (finalCenterName.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalCenterName)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }



  //validation for University Name
  function validateUniversity() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('university').value;
    var error = document.getElementById("universityError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalUniName = capitalizedWords.join(" ");
    
    document.getElementById('university').value = finalUniName;
  
    if (finalUniName.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalUniName)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

//Upload Recognition Letter
function validateRecognitionLetter(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('rletterError');
    if (!file.type.match('pdf')) {
    errorElement.textContent = 'File is not a PDF.';
    event.target.value = ''; // Clear the file input
    return;
    }
    if (file.size > 500 * 1024) {
    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
    event.target.value = ''; // Clear the file input
    return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
    }