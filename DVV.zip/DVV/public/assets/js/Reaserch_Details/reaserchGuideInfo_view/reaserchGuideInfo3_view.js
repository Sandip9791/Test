// //Validation for the Date
function setupDateValidation() {
    //Validation for the Date
    const dobDateInput = document.getElementById('dob');

    // Set the minimum date allowed (2018-01-01 in this case)
    const minDate = new Date('2018-01-01');

    // Function to set the maximum date allowed to the current date
    function setMaxDate() {
        const today = new Date();
        const maxDate = today.toISOString().split('T')[0]; // Format as "YYYY-MM-DD"
        dobDateInput.max = maxDate;
    }

    // Call the setMaxDate function to set the maximum date initially
    setMaxDate();

    // Attach an event listener to the input element to dynamically update the maximum date
    dobDateInput.addEventListener('input', setMaxDate);

    // Function to validate the selected date on form submission
    function validateRegDate() {
        const selectedDate = new Date(dobDateInput.value);
        if (selectedDate < minDate) {
            alert('Please select a date on or after 2018-01-01.');
            return false;
        }
        return true;
    }

    // Attach an event listener to the form to validate the date on form submission
    const form = document.querySelector('form');
    form.addEventListener('submit', validateRegDate);
}

// Call the setupDateValidation function to set up the date validation
setupDateValidation();

//Name of Research Title 
function validateResearchTitleName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('researchtitlename').value;
    var error = document.getElementById("researchtitlenameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalresearchtitle = capitalizedWords.join(" ");
    
    document.getElementById('researchtitlename').value = finalresearchtitle;
  
    if (finalresearchtitle.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalresearchtitle)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }




//Name of Researcher 
function validateResearcherName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('researchername').value;
    var error = document.getElementById("researchernameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalresearchername = capitalizedWords.join(" ");
    
    document.getElementById('researchername').value = finalresearchername;
  
    if (finalresearchername.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalresearchername)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }



// RR Letter
function validateRRLetter(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('rrletterError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


