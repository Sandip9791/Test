//Name of Research Title 
function validateResearchTitleName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('researchtitlename').value;
    var error = document.getElementById("researchtitlenameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalresearchtitle = capitalizedWords.join(" ");
    
    document.getElementById('researchtitlename').value = finalresearchtitle;
  
    if (finalresearchtitle.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalresearchtitle)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

//Name of Researcher 
function validateResearcherName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('researchername').value;
    var error = document.getElementById("researchernameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalresearchername = capitalizedWords.join(" ");
    
    document.getElementById('researchername').value = finalresearchername;
  
    if (finalresearchername.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalresearchername)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }


//Provisional/Degree Certificate
function validateCertificate(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('certificateError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

