///////////////////////////////////////////////////////////     Name of the Organisation/Industry/Institute   ////////////////////////////////////
function validateOrgname() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('orgname').value;
    var error = document.getElementById("orgnameError");

    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });

    var finalorgname = capitalizedWords.join(" ");
    document.getElementById('orgname').value = finalorgname;

    if (finalorgname.length === 0 || regName.test(finalorgname)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
}

// Attach event listener using JavaScript
document.getElementById('orgname').addEventListener('input', validateOrgname);



///////////////////////////////////////////////////////////////////////////////////    To show the Text Box for Other       ///////////////////////////////////////////////////////////////////////////////

function showOther() {
    var type = document.getElementById("Colaboration");
        if (type.value == "Other") 
        {
            document.getElementById("other").style.display="block";
        }
        else 
        {
            document.getElementById("other").style.display="none";
        } 
    }

////////////////////////////////////////////////////////////////////////////////    Validation for Other field        /////////////////////////////////////////////////////////////////////////////
function validateOther() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('otherJournal').value;
    var error = document.getElementById("otherErrror");

    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });

    var finalotherJournal = capitalizedWords.join(" ");
    document.getElementById('otherJournal').value = finalotherJournal;

    if (finalotherJournal.length === 0 || regName.test(finalotherJournal)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
}

// Attach event listener using JavaScript
document.getElementById('otherJournal').addEventListener('input', validateOther);


////////////////////////////////////////////////////////////////////////////////    Validtion for the date    ///////////////////////////////////////////////////////////////////////////////////////
document.addEventListener("DOMContentLoaded", function() {
    var currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0); // Set current time to midnight (00:00:00)

    var fromdateInput = document.getElementById("fromdate");
    var todateInput = document.getElementById("todate");

    // Set the maximum date for the Joining Date
    fromdateInput.setAttribute("max", formatDate(currentDate));

    // Attach input event listener to the Joining Date input
    fromdateInput.addEventListener("input", function() {
        var jDate = new Date(fromdateInput.value);

        // Set the minimum date for the Leaving Date based on the Joining Date
        todateInput.setAttribute("min", formatDate(jDate));

        // Set the maximum date for the Leaving Date as today's date
        var maxDate = new Date();
        maxDate.setHours(0, 0, 0, 0); // Set current time to midnight (00:00:00)
        todateInput.setAttribute("max", formatDate(maxDate));

        // Reset the Leaving Date field if it is earlier than the Joining Date or not set
        if (todateInput.value < fromdateInput.value) {
            todateInput.value = "";
        }
    });

    function formatDate(date) {
        var dd = String(date.getDate()).padStart(2, "0");
        var mm = String(date.getMonth() + 1).padStart(2, "0"); // January is 0!
        var yyyy = date.getFullYear();
        return yyyy + "-" + mm + "-" + dd;
    }
});

// // // // //Script for hiding the date // // // // 
function enableToDate() {
    var fromDateInput = document.getElementById('fromdate');
    var toDateInput = document.getElementById('todate');

    if (fromDateInput.value !== '') {
        toDateInput.removeAttribute('disabled');
    } else {
        toDateInput.setAttribute('disabled', 'disabled');
    }
}



///////////////////////////////////////////////////////////////////////////////////////////    Document of Activity   /////////////////////////////////////////////////////////////////////
function validateAcitvityDoc(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('activitydocError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


///////////////////////////////////////////////////////////////////////     Validation for the Upload the Document Disabled and Unables modes      ///////////////////////////////////
function updateUploadFields(num) {
    for (let i = 0; i < 5; i++) {
        const uploadField = document.getElementById(`Udocument${i}`);
        uploadField.disabled = true; // Disable all fields by default
    }
    for (let i = 0; i < num; i++) {
        const uploadField = document.getElementById(`Udocument${i}`);
        uploadField.disabled = false; // Enable the specified number of fields
    }
}

function validateBeneficiary(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("beneficiaryError").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
        updateUploadFields(0); // Disable all upload fields
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("beneficiaryError").style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("beneficiaryError").style.display = "none";
        inputElement.setCustomValidity("");
        updateUploadFields(enteredValue);
    }
}

// Add an event listener to the input field
document.getElementById("beneficiary").addEventListener("input", function () {
    validateBeneficiary(this);
});

////////////////////////////////////////////////////////////////////////////////    Upload the Document   1   ////////////////////////////////////////////////////////////////////////////////////////////
function validateUdocument(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('UdocumentError0');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


//////////////////////////////////////////////////////////////////////////      Upload the Document   2    ///////////////////////////////////////////////////////////////////////////////////////////////
function validateUdocument1(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('UdocumentError1');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

//////////////////////////////////////////////////////////////////////////     Upload the Document   3    ////////////////////////////////////////////////////////////////////////////////
function validateUdocument2(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('UdocumentError2');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

//////////////////////////////////////////////////////////////////////////     Upload the Document   4    /////////////////////////////////////////////////////////////////////////////////////
function validateUdocument3(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('UdocumentError3');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

/////////////////////////////////////////////////////////////////////////      Upload the Document   5     ///////////////////////////////////////////////////////////////////////////////////////////////
function validateUdocument4(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('UdocumentError4');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}
