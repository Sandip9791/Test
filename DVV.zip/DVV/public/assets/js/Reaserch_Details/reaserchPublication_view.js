//Title of the Paper
function validateTPaper() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('titlepaper').value;
    var error = document.getElementById("titlepaperErrror");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finaltitlepaper = capitalizedWords.join(" ");
    
    document.getElementById('titlepaper').value = finaltitlepaper;
  
    if (finaltitlepaper.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finaltitlepaper)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }


//Name of the Journal
function validateJournalName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('journalname').value;
    var error = document.getElementById("journalNameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finaljournalname = capitalizedWords.join(" ");
    
    document.getElementById('journalname').value = finaljournalname;
  
    if (finaljournalname.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finaljournalname)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }



//Show box for selecting the Yes ans No button
function showTextBox() {
    document.getElementById("text-input1").style.display = "block";
    document.getElementById("text-input2").style.display = "none";

}

function hideTextBox() {
    document.getElementById("text-input2").style.display = "block";
    document.getElementById("text-input1").style.display = "none";
}



// Journal Approved by "Other"
function validateOther() {
    var regName = /^[a-zA-Z ]+$/;
    var inputElement = document.getElementById('otherJournal');
    var name = inputElement.value;
    var error = document.getElementById("otherError");

    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalOther = capitalizedWords.join(" ");
    
    inputElement.value = finalOther;

    if (finalOther.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalOther)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}


//Validation for link
function validateLink() {
    var linkInput = document.getElementById('enterLink');
    var linkValidationError = document.getElementById('linkValidationError');
    var linkRegex = /^(ftp|http|https):\/\/[^ "]+$/;

    if (linkInput.value.trim() === '') {
        // Empty input, hide error message
        linkValidationError.style.display = 'none';
    } else if (!linkRegex.test(linkInput.value)) {
        // Invalid link format, show error message
        linkValidationError.style.display = 'block';
    } else {
        // Valid link format, hide error message
        linkValidationError.style.display = 'none';
    }
}

// Attach event listener to validate link on keyup
document.getElementById('enterLink').addEventListener('keyup', validateLink);


//Validation for Screen Shot
function validateScreenShot(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('screenshotError');
    const allowedFormats = ['image/jpeg', 'image/jpg', 'image/png'];

    if (!allowedFormats.includes(file.type)) {
        errorElement.textContent = 'Invalid file format. Please select only .jpg, .jpeg, .png images.';
        event.target.value = ''; // Clear the file input
        return;
    }

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

