//Have you received travel grant // Yes or No
function showTextBox() {
    document.getElementById("text-input").style.display = "block";
}

function hideTextBox() {
    document.getElementById("text-input").style.display = "none";
}


////////////////////////////////////////////////////////////////////////////////  Awarding Agency  ///////////////////////////////////////////////////////////////////
function validateAgency() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('AwardingAgency').value;
    var error = document.getElementById("AwardingAgencyError");

    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });

    var finalAwardingAgency = capitalizedWords.join(" ");
    document.getElementById('AwardingAgency').value = finalAwardingAgency;

    if (finalAwardingAgency.length === 0 || regName.test(finalAwardingAgency)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
}

// Attach event listener using JavaScript
document.getElementById('AwardingAgency').addEventListener('input', validateAgency);




/////////////////////////////////////////////////////////////////////////   Validation for Select the Year of Award  /////////////////////////////////////////////////////
$(document).ready(function () {
    var currentYear = new Date().getFullYear();
    var minYear = 1992;

    function validateYear(year) {
        return year >= minYear && year <= currentYear;
    }

    function showError() {
        $("#error-message").show();
    }

    function hideError() {
        $("#error-message").hide();
    }

    $("#datepicker").datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        startDate: new Date(minYear, 0, 1), // January 1st of 1983
        endDate: new Date(currentYear, 0, 1), // January 1st of the current year
        autoclose: true
    });

    $("#datepicker").on("keyup change", function () {
        var enteredYear = parseInt($(this).val());
        if (!$(this).val() || isNaN(enteredYear) || !validateYear(enteredYear)) {
            showError();
        } else {
            hideError();
        }
    });

    $("#datepicker").on("blur", function () {
        // Hide the error message when the input field loses focus (blurred) and it's empty
        if ($(this).val().trim() === '') {
            hideError();
        }
    });
});


/////////////////////////////////////////////////////////////////////////   Name of Award/Fellowship   ////////////////////////////////////////////////////////
function validateAwardName() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('Awardname').value;
    var error = document.getElementById("AwardNameError");

    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });

    var finalAwardname = capitalizedWords.join(" ");
    document.getElementById('Awardname').value = finalAwardname;

    if (finalAwardname.length === 0 || regName.test(finalAwardname)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
}

// Attach event listener using JavaScript
document.getElementById('Awardname').addEventListener('input', validateAwardName);


//////////////////////////////////////////////////////////////////////////////////   Other  //////////////////////////////////////////////////////////////////////////////
function validateOther() {
    var regName = /^[a-zA-Z ]+$/;
    var name = document.getElementById('otherJournal').value;
    var error = document.getElementById("AwardingAgencyError");

    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });

    var finalotherJournal = capitalizedWords.join(" ");
    document.getElementById('otherJournal').value = finalotherJournal;

    if (finalotherJournal.length === 0 || regName.test(finalotherJournal)) {
        error.style.display = "none";
    } else {
        error.style.display = "block";
    }
}

// Attach event listener using JavaScript
document.getElementById('otherJournal').addEventListener('input', validateOther);


//////////////////////////////////////////////////////////////////////////////////  Upload Sanction Letter  //////////////////////////////////////////////////////////
function validateSanction(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('sanctiondocumentError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


//Validation for Funds received travel gran in INR
function validateTravelGrant(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("error-message2").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("error-message2").style.display = "block";
        document.getElementById("error-message2").textContent = "Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("error-message2").style.display = "none";
        inputElement.setCustomValidity("");
    }
}

// Add an event listener to the input field
var fundsInput = document.getElementById("funds-id");
fundsInput.addEventListener("input", function () {
    validateTravelGrant(this);
});

// Call the validation function once to handle the initial state
validateTravelGrant(fundsInput);