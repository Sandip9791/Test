//Name of the Project
function validateProjectName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('projectname').value;
    var error = document.getElementById("projectnameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalprojectname = capitalizedWords.join(" ");
    
    document.getElementById('projectname').value = finalprojectname;
  
    if (finalprojectname.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalprojectname)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

//Name of Funding Agency
function validateFundingName() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('fundingname').value;
    var error = document.getElementById("fundingnameError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalfundingname = capitalizedWords.join(" ");
    
    document.getElementById('fundingname').value = finalfundingname;
  
    if (finalfundingname.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalfundingname)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

  

//Validation for the Fund Provided in INR
function validateFund(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, '');
    inputElement.value = sanitizedValue;

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    var errorSpan = document.getElementById("FundError");

    if (sanitizedValue.length === 0) {
        errorSpan.style.display = "none";
        inputElement.setCustomValidity("");
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        errorSpan.textContent = "Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".";
        errorSpan.style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        errorSpan.style.display = "none";
        inputElement.setCustomValidity("");
    }
}

document.getElementById("funds-id").addEventListener("input", function () {
    validateFund(this);
});


//Validation for Duration of Project
function validateDuration(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, '');
    inputElement.value = sanitizedValue;

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    var errorSpan = document.querySelector(".durationError");

    if (sanitizedValue.length === 0) {
        errorSpan.style.display = "none";
        inputElement.setCustomValidity("");
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        var errorMessage = "Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".";
        errorSpan.textContent = errorMessage;
        errorSpan.style.display = "block";
        inputElement.setCustomValidity(errorMessage);
    } else {
        errorSpan.style.display = "none";
        inputElement.setCustomValidity("");
    }
}

document.getElementById("duration-id").addEventListener("input", function () {
    validateDuration(this);
});



//Upload Sanction Letter
function validateSanction(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('sanctiondocumentError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}