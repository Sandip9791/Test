function setupDateValidation() {
    // Validation for the Date
    const dobDateInput = document.getElementById('awarddate');

    // Set the minimum date allowed (2022-01-01 in this case)
    const minDate = new Date('2022-01-01');

    // Function to set the maximum date allowed to the current date
    function setMaxDate() {
        const today = new Date();
        const maxDate = today.toISOString().split('T')[0]; // Format as "YYYY-MM-DD"
        dobDateInput.max = maxDate;
    }

    // Call the setMaxDate1 function to set the maximum date initially
    setMaxDate();

    // Attach an event listener to the input element to dynamically update the maximum date
    dobDateInput.addEventListener('input', setMaxDate);

    // Function to validate the selected date on form submission
    function validateRegDate() {
        const selectedDate = new Date(dobDateInput.value);
        if (selectedDate < minDate) {
            alert('Please select a date on or after 2022-01-01.');
            return false;
        }
        return true;
    }

    // Attach an event listener to the form to validate the date on form submission
    const form = document.querySelector('form');
    form.addEventListener('submit', validateRegDate);
}

// Call the setupDateValidation function to set up the validation for this specific element
setupDateValidation();





//Validation for Yes or No and Hide or Unhide
function showTextBox() {
    document.getElementById("text-input1").style.display = "block";

}

function hideTextBox() {
    document.getElementById("text-input1").style.display = "none";
  
}


//Title of Research Project
function validateRPName() {
  var regName = /^[a-zA-Z ]+$/;
  var name = document.getElementById('researchname').value;
  var error = document.getElementById("researchError");

  var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

  var words = sanitizedName.split(" ");
  var capitalizedWords = words.map(function(word) {
      return word.charAt(0).toUpperCase() + word.slice(1);
  });

  var finalresearchname = capitalizedWords.join(" ");
  document.getElementById('researchname').value = finalresearchname;

  if (finalresearchname.length === 0 || regName.test(finalresearchname)) {
      error.style.display = "none";
  } else {
      error.style.display = "block";
  }
}

// Attach event listener using JavaScript
document.getElementById('researchname').addEventListener('input', validateRPName);



//Duration
function validateDuration(inputElement) {
  var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
  inputElement.value = sanitizedValue; // Set sanitized value back into the input field

  var enteredValue = parseInt(sanitizedValue);
  var minLimit = parseInt(inputElement.getAttribute("min"));
  var maxLimit = parseInt(inputElement.getAttribute("max"));

  // Check if the entered value is within the specified limits
  if (sanitizedValue.length === 0) {
      document.getElementById("durationError").style.display = "none"; // Hide the error message
      inputElement.setCustomValidity(""); // Clear custom validity
  } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
      document.getElementById("durationError").style.display = "block";
      inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
  } else {
      document.getElementById("durationError").style.display = "none";
      inputElement.setCustomValidity("");
  }
}

// Add an event listener to the input field
document.getElementById("duration").addEventListener("input", function () {
  validateDuration(this);
});







//Upload Sanction Letter
function validateSanction(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('sanctiondocumentError');
    if (!file.type.match('pdf')) {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

//Validation for Amount
function validateAmount(inputElement) {
  var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
  inputElement.value = sanitizedValue; // Set sanitized value back into the input field

  var enteredValue = parseInt(sanitizedValue);
  var minLimit = parseInt(inputElement.getAttribute("min"));
  var maxLimit = parseInt(inputElement.getAttribute("max"));

  // Check if the entered value is within the specified limits
  if (sanitizedValue.length === 0) {
      document.getElementById("amountError").style.display = "none"; // Hide the error message
      inputElement.setCustomValidity(""); // Clear custom validity
  } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
      document.getElementById("amountError").style.display = "block";
      inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
  } else {
      document.getElementById("amountError").style.display = "none";
      inputElement.setCustomValidity("");
  }
}

// Add an event listener to the input field
document.getElementById("amount").addEventListener("input", function () {
  validateAmount(this);
});
