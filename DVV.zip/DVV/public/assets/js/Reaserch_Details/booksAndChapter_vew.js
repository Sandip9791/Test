//Title of the Book Published
  function validatebookPub() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('bookPub').value;
    var error = document.getElementById("bookPubError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalbookPub = capitalizedWords.join(" ");
    
    document.getElementById('bookPub').value = finalbookPub;
  
    if (finalbookPub.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalbookPub)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }


//Title of the Chapter
function validateTchapter() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('Tchapter').value;
    var error = document.getElementById("TchapterError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalTchapter = capitalizedWords.join(" ");
    
    document.getElementById('Tchapter').value = finalTchapter;
  
    if (finalTchapter.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalTchapter)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }



//Validation for ISBN number
document.addEventListener('DOMContentLoaded', function() {
    var isbnInput = document.getElementById('isbnnumber');
    var errorElement = document.getElementById('isbnError');
    
    isbnInput.addEventListener('input', function(event) {
        var inputValue = event.target.value;
        var digitsOnly = inputValue.replace(/\D/g, ''); // Remove non-digit characters
        event.target.value = digitsOnly; // Update the input value
        
        validateISBN();
    });
    
    function validateISBN() {
        var isbnPattern = /^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$/;
        var isbnInputValue = isbnInput.value;

        if (isbnInputValue.length === 0) {
            errorElement.textContent = 'Please enter a valid ISBN number.';
            errorElement.style.display = 'none';
        } else if (isbnPattern.test(isbnInputValue)) {
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        } else {
            errorElement.textContent = 'Please enter a valid ISBN number.';
            errorElement.style.display = 'block';
        }
    }
});

// Add event listeners to the input field to trigger the validation
var isbnInput = document.getElementById('isbnnumber');
isbnInput.addEventListener('input', validateISBN);
isbnInput.addEventListener('keydown', function(event) {
    var key = event.key;
    if (!/^\d$/.test(key) && key !== 'Backspace' && key !== 'Delete') {
        event.preventDefault();
    }
});



//Name of the Publisher
function validatenpublisher() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('npublisher').value;
    var error = document.getElementById("npublisherError");
  
    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalnpublisher= capitalizedWords.join(" ");
    
    document.getElementById('npublisher').value = finalnpublisher;
  
    if (finalnpublisher.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalnpublisher)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }

////Validation for Uploade Images////

//Validation for Cover Page
function validateCoverDoc(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('coverdocError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}



//Validation for Content Page
function validateContentDoc(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('contentdocError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


//Validation for First Page
function validateFirstDoc(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('firstdocError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}
