function validateFirstName() {
    var regName = /[a-zA-Z]$/;
    var name = document.getElementById('firstname').value;
    var error = document.getElementById("firstnameError");
  
    if (name.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(name)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
  }
  
    function validateLastName(){
      var regName = /[a-zA-Z]$/;
      var name = document.getElementById('lastname').value;
      var error = document.getElementById("lastnameError");
  
      if(name.length === 0){
        error.style.display = "none"
      } else if(!regName.test(name)){
        error.style.display = "block";
      } else {
        error.style.display = "none";
      }
    }
  
    function validateMiddleName(){
      var regName = /[a-zA-Z]$/;
      var name = document.getElementById('middlename').value;
      var error = document.getElementById("midnameError");
      
      if(name.length === 0){
        error.style.display = "none"
      } else
      if(!regName.test(name)){
        error.style.display = "block";
      }else{
        error.style.display = "none";
      }
    }
  
  function validateEmail() {
  var email = document.getElementById('email').value;
  var validRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var error = document.getElementById("TEmailError");
  
  if(email.length === 0){
    error.style.display = "none"
  } else
    if (!validRegex.test(email)) {
      error.style.display = "block";
  
      }else{
        error.style.display = "none";
      }
  
  }

//validation for date
    $(document).ready(function() {
        var currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0); // Set current time to midnight (00:00:00)

        // Set the maximum date for the Joining Date
        $('#validationDefault05').prop('max', formatDate(currentDate));

        // Attach change event handler to the Joining Date input
        $('#validationDefault05').on('change', function() {
            var jDate = new Date($('#validationDefault05').val());

            // Set the minimum date for the Leaving Date based on the Joining Date
            $('#validationDefault06').prop('min', formatDate(jDate));

            // Set the maximum date for the Leaving Date as today's date
            var maxDate = new Date();
            maxDate.setHours(0, 0, 0, 0); // Set current time to midnight (00:00:00)
            $('#validationDefault06').prop('max', formatDate(maxDate));

            // Reset the Leaving Date field if it is earlier than the Joining Date or not set
            if ($('#validationDefault06').val() < $('#validationDefault05').val()) {
                $('#validationDefault06').val('');
            }
        });

        function formatDate(date) {
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0'); // January is 0!
            var yyyy = date.getFullYear();
            return yyyy + '-' + mm + '-' + dd;
        }
    });
    
  
  //Is There Any Earlier Experiance Yes or No validation
        function showTextBox() {
          document.getElementById("instituteNameDiv").style.display = "block";
          document.getElementById("experienceDiv").style.display = "block";
          document.getElementById("experienceDocDiv").style.display = "block";
      }

      function hideTextBox() {
          document.getElementById("instituteNameDiv").style.display = "none";
          document.getElementById("experienceDiv").style.display = "none";
          document.getElementById("experienceDocDiv").style.display = "none";
      }
  
  
//Institute Name
    function validateInstiName() {
      var regName = /^[a-zA-Z\s]+$/;
      var name = document.getElementById('institute-name').value;
      var error = document.getElementById("instinameError");

      if (name.length === 0) {
          error.style.display = "none";
      } else if (!regName.test(name)) {
          error.style.display = "block";
      } else {
          error.style.display = "none";
      }
  }

//Experiance
  function validateExperience() {
      var experienceInput = document.getElementById('experience-years').value;
      var errorMessage = document.getElementById('experienceError');

      // Trim any leading or trailing white spaces before checking for empty input
      experienceInput = experienceInput.trim();

      if (experienceInput === '') {
          errorMessage.style.display = 'none';
      } else {
          // Convert the trimmed input to an integer
          var experienceValue = parseInt(experienceInput);

          if (isNaN(experienceValue) || experienceValue < 0 || experienceValue > 30) {
              errorMessage.style.display = 'block';
          } else {
              errorMessage.style.display = 'none';
          }
      }
  }

  //Experiance Document
  function validateExperienceDoc(event) {
      const file = event.target.files[0];
      const errorElement = document.getElementById('experiencedocError');
      if (!file.type.match('pdf')) {
          errorElement.textContent = 'File is not a PDF.';
          event.target.value = ''; // Clear the file input
          return;
      }
      if (file.size > 500 * 1024) {
          errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
          event.target.value = ''; // Clear the file input
          return;
      }
      // If the file is valid, clear the error message
      errorElement.textContent = '';
  }

