//Subject Name 
function validateSubjectName() {
  var regName = /[a-zA-Z ]$/;
  var name = document.getElementById('subject').value;
  var error = document.getElementById("subjectnameError");

  // Remove any non-alphabetical characters from the input
  var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
  
  // Split the input into words and capitalize the first letter of each word
  var words = sanitizedName.split(" ");
  var capitalizedWords = words.map(function(word) {
      return word.charAt(0).toUpperCase() + word.slice(1);
  });
  
  // Join the capitalized words back together
  var finalSubName = capitalizedWords.join(" ");
  
  document.getElementById('subject').value = finalSubName;

  if (finalSubName.length === 0) {
      error.style.display = "none";
  } else if (!regName.test(finalSubName)) {
      error.style.display = "block";
  } else {
      error.style.display = "none";
  }
}



//Upload Teaching Plan Document
function validateTeaPlan(event) 
{
    const file = event.target.files[0];
    const errorElement = document.getElementById('teaPlanError');
    if (!file.type.match('pdf')) 
    {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) 
    {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}    