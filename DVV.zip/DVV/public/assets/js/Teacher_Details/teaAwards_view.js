//Name of National Award/Recongnition Name
function validateNationalAward() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('national').value;
    var error = document.getElementById("nationalError");

    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalName = capitalizedWords.join(" ");
    
    document.getElementById('national').value = finalName;

    if (finalName.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalName)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}




//Name of International Award/Recongnition Name
function validateInternationalAward() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('international').value;
    var error = document.getElementById("internationalError");

    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalName = capitalizedWords.join(" ");
    
    document.getElementById('international').value = finalName;

    if (finalName.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalName)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}




//Validation for Yes or No after selecting the radio button Yes or No
document.getElementById('form1').style.display='none';
document.getElementById('form2').style.display='none';

function showForm1()
{
    // Get references to the checkboxes and forms
    const form1Checkbox = document.getElementById('form1Checkbox');
    const form1Div = document.getElementById('form1');

    form1Checkbox.addEventListener('change', () => 
    {
        form1Div.style.display = form1Checkbox.checked ? 'block' : 'none';
    });
}

function showForm2()
{
    // Get references to the checkboxes and forms
    const form2Checkbox = document.getElementById('form2Checkbox');
    const form2Div = document.getElementById('form2');

    form2Checkbox.addEventListener('change', () => 
    {
        form2Div.style.display = form2Checkbox.checked ? 'block' : 'none';
    });  
}


//National Award Document
function validatenationalDoc() 
{
    const file = event.target.files[0];
    const errorElement = document.getElementById('nationaldocError');
    if (!file.type.match('pdf')) 
    {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) 
    {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


//International Award Document
function validateinternationalDoc() 
{
    const file = event.target.files[0];
    const errorElement = document.getElementById('internationaldocError');
    if (!file.type.match('pdf')) 
    {
        errorElement.textContent = 'File is not a PDF.';
        event.target.value = ''; // Clear the file input
        return;
    }
    if (file.size > 500 * 1024) 
    {
        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
        event.target.value = ''; // Clear the file input
        return;
    }
    // If the file is valid, clear the error message
    errorElement.textContent = '';
}     