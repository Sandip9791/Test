//First Name
function validateFirstName() {
  var name = document.getElementById('firstname').value;
  var error = document.getElementById("firstnameError");
  
  // Remove any non-alphabetical characters from the input
  var sanitizedName = name.replace(/[^a-zA-Z]/g, '');
  document.getElementById('firstname').value = sanitizedName;
  
  if (sanitizedName.length === 0) {
      error.style.display = "none";
  } else {
      error.style.display = "none";
      
      // Check if the input contains only one word
      if (sanitizedName.split(" ").length === 1) {
          var capitalizedValue = sanitizedName.charAt(0).toUpperCase() + sanitizedName.slice(1);
          document.getElementById('firstname').value = capitalizedValue;
      }
  }
}


//Last Name
function validateLastName() {
  var name = document.getElementById('lastname').value;
  var error = document.getElementById("lastnameError");

  var sanitizedName = name.replace(/[^a-zA-Z]/g, '');
  document.getElementById('lastname').value = sanitizedName;

  if (sanitizedName.length === 0) {
      error.style.display = "none";
  } else {
      error.style.display = "none";
      
      // Check if the input contains only one word
      if (sanitizedName.split(" ").length === 1) {
          var capitalizedValue = sanitizedName.charAt(0).toUpperCase() + sanitizedName.slice(1);
          document.getElementById('lastname').value = capitalizedValue;
      }
  }
}


//Middle Name
function validateMiddleName() {
  var name = document.getElementById('middlename').value;
  var error = document.getElementById("midnameError");

  var sanitizedName = name.replace(/[^a-zA-Z]/g, '');
  document.getElementById('middlename').value = sanitizedName;

  if (sanitizedName.length === 0) {
      error.style.display = "none";
  } else {
      error.style.display = "none";
      
      // Check if the input contains only one word
      if (sanitizedName.split(" ").length === 1) {
          var capitalizedValue = sanitizedName.charAt(0).toUpperCase() + sanitizedName.slice(1);
          document.getElementById('middlename').value = capitalizedValue;
      }
  }
}

//Validation for Birth Date
function setMaxDate() {
  // Get the current date
  var currentDate = new Date();

  // Calculate the maximum date by subtracting 23 years from the current date
  var maxDate = new Date(currentDate);
  maxDate.setFullYear(maxDate.getFullYear() - 23);

  // Format the maximum date as yyyy-mm-dd
  var formattedMaxDate = maxDate.toISOString().split('T')[0];

  // Set the max attribute of the date input element
  var dobInput = document.querySelector('input[name="dob"]');
  dobInput.setAttribute('max', formattedMaxDate);
}

// Call the function to set the max date when the page loads
setMaxDate();

//Mobile Number  
function validateMobile(inputElement) {
  var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
  inputElement.value = sanitizedValue; // Set sanitized value back into the input field

  var enteredValue = parseInt(sanitizedValue);
  var minLimit = parseInt(inputElement.getAttribute("min"));
  var maxLimit = parseInt(inputElement.getAttribute("max"));

  // Check if the entered value is within the specified limits
  if (sanitizedValue.length === 0) {
      document.getElementById("mobileError").style.display = "none"; // Hide the error message
      inputElement.setCustomValidity(""); // Clear custom validity
  } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
      document.getElementById("mobileError").style.display = "block";
      inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
  } else {
      document.getElementById("mobileError").style.display = "none";
      inputElement.setCustomValidity("");
  }
}

// Add an event listener to the input field
document.getElementById("mobilenumber").addEventListener("input", function () {
  validateMobile(this);
});


//Validate Function for Aadhar Number
function validateAadhar(inputElement) {
  var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
  inputElement.value = sanitizedValue; // Set sanitized value back into the input field

  var enteredValue = parseInt(sanitizedValue);
  var minLimit = parseInt(inputElement.getAttribute("min"));
  var maxLimit = parseInt(inputElement.getAttribute("max"));

  // Check if the entered value is within the specified limits
  if (sanitizedValue.length === 0) {
      document.getElementById("aadharError").style.display = "none"; // Hide the error message
      inputElement.setCustomValidity(""); // Clear custom validity
  } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
      document.getElementById("aadharError").style.display = "block";
      inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
  } else {
      document.getElementById("aadharError").style.display = "none";
      inputElement.setCustomValidity("");
  }
}

// Add an event listener to the input field
document.getElementById("aadhar").addEventListener("input", function () {
  validateAadhar(this);
});


//Pan Card Number
function handlePanInput(inputElement) {
  var inputValue = inputElement.value;
  var uppercaseValue = inputValue.toUpperCase();
  
  // Only update the input value if the case has changed
  if (inputValue !== uppercaseValue) {
    inputElement.value = uppercaseValue;
  }
  
  validatePan(); // Perform validation
}

function validatePan() {
  var pan = document.getElementById("pan").value;
  var regPan = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
  var error = document.getElementById("panError");

  if (pan.length === 0) {
    error.style.display = "none";
  } else if (!regPan.test(pan)) {
    error.style.display = "block";
  } else {
    error.style.display = "none";
  }
}


// Function for Email verification
function validateEmail() {
  var email = document.getElementById('email').value;
  var validRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var validDomains = ["gmail.com", "yahoo.com", "outlook.com"]; // List of valid domains
  var error = document.getElementById("emailError");

  if (email.length === 0) {
      error.style.display = "none";
  } else if (!validRegex.test(email)) {
      error.style.display = "block";
  } else {
      var domain = email.split('@')[1]; // Extract domain after '@'

      if (validDomains.includes(domain)) {
          error.style.display = "none";
      } else {
          error.style.display = "block";
      }
  }
}


//Function for Residental Address verification
function validateResidentialAddress(){
  var regName = /^[a-zA-Z0-9, /-]+$/;
  var name = document.getElementById('residential').value;
  var error = document.getElementById("residentialError");

  if (name.length === 0) {
    error.style.display = "none";
} else if(!regName.test(name)){
    error.style.display = "block";
  }else{
    error.style.display = "none";
  }
}


//Upload Aadhar Document
function validateAadharDoc(event) {
  const file = event.target.files[0];
  const errorElement = document.getElementById('aadhardocError');
  if (!file.type.match('pdf')) {
      errorElement.textContent = 'File is not a PDF.';
      event.target.value = ''; // Clear the file input
      return;
  }
  if (file.size > 500 * 1024) {
      errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
      event.target.value = ''; // Clear the file input
      return;
  }
  // If the file is valid, clear the error message
  errorElement.textContent = '';
}

//Upload Pan Document
function validatePanDoc(event) {
  const file = event.target.files[0];
  const errorElement = document.getElementById('pandocError');
  if (!file.type.match('pdf')) {
      errorElement.textContent = 'File is not a PDF.';
      event.target.value = ''; // Clear the file input
      return;
  }
  if (file.size > 500 * 1024) {
      errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
      event.target.value = ''; // Clear the file input
      return;
  }
  // If the file is valid, clear the error message
  errorElement.textContent = '';
}


function validateCurrentPhoto(event) {
  const file = event.target.files[0];
  const errorElement = document.getElementById('currentphotoError');
  const allowedFormats = ['image/jpeg', 'image/jpg', 'image/png'];

  if (!allowedFormats.includes(file.type)) {
      errorElement.textContent = 'Invalid file format. Please select only .jpg, .jpeg, .png images.';
      event.target.value = ''; // Clear the file input
      return;
  }

  const maxSizeKB = 500; // Maximum file size in KB
  if (file.size > maxSizeKB * 1024) {
      errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
      event.target.value = ''; // Clear the file input
      return;
  }

  // If the file is valid, clear the error message
  errorElement.textContent = '';
}