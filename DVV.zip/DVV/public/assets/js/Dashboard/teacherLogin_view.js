function validateUsername() {
    var username = document.getElementById("username").value;
    var regUser = /^[a-z]+[A-Z]\d{4}$/;
    var error = document.getElementById("userError");                       
  
    if (username.length === 0) {
        error.style.display = "none";
    } else if (!regUser.test(username)) {
      error.style.display = "block";
  
    }else{
      error.style.display = "none";
    }
  }
   
  
  
  function validatePassword() {
    var password = document.getElementById("password").value;
    var upperRegex = /[A-Z]/;
    var lowerRegex = /[a-z]/;
    var symbolRegex = /[@]/;
    var digitRegex = /\d{2}/;
    var error = document.getElementById("passError");

    if (password.length === 0) {
        error.style.display = "none";   
    } else if (!upperRegex.test(password)) {
        error.style.display = "block";
    } else if (!lowerRegex.test(password)) {
        error.style.display = "block";
    } else if (!symbolRegex.test(password)) {
        error.style.display = "block";
    } else if (!digitRegex.test(password)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}
