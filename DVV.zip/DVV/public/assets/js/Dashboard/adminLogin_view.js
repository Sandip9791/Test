//Validation for Admin Username and Password...


function validateUsername() {
    var username = document.getElementsByName("username")[0].value;
    var regUser = /([a-z]{5})_([a-z]{5})$/;
    var error = document.getElementById("userError");
    if (username.length === 0) {
        error.style.display = "none";
    } else if (!regUser.test(username)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}

function validatePassword() {
    var password = document.getElementsByName("password")[0].value;
    var lowerRegex = /[a-z]/;
    var symbolRegex = /@/;
    var digitRegex = /\d{2}$/;
    var error = document.getElementById("passError");
    if (password.length === 0) {
        error.style.display = "none";
    } else if (!lowerRegex.test(password) || !symbolRegex.test(password) || !digitRegex.test(password)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}