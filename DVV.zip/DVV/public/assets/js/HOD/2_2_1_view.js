// Function to enforce the word limit on the textarea******************************************Word Limit******************************************************8
function enforceWordLimit(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement = document.getElementById('wordLimitedTextarea');
textareaElement.addEventListener('input', enforceWordLimit);


//Validation for the Bridge course attendance***********************************************Bridge course attendance********************************************************************
function validateattendace(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('attendaceError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}



//Validation for the Bridge Course Notice************************************************Bridge Course Notice****************************************************************
function validatenotice(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('noticeError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}




//Validation for the Report of Diagnostic Test*****************************************Report of Diagnostic Test*****************************************************************
function validatereport(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('reportError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}



//Validation for the Attendance of Diagnostic Test **************************************Attendance of Diagnostic Test****************************************************************
function validateAttDign(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('attDignError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}



//Validation for the 1. Number of Students*************************************************************  1. Number of Students*******************************************************
function validatestudBridge(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("studBridgeError").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("studBridgeError").style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("studBridgeError").style.display = "none";
        inputElement.setCustomValidity("");
    }
}

// Add an event listener to the input field
document.getElementById("studBridge").addEventListener("input", function () {
    validatestudBridge(this);
});




//Validation for the 2. Number of Students*************************************************************  2. Number of Students*******************************************************
function validatestudDign(inputElement) {
    var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
    inputElement.value = sanitizedValue; // Set sanitized value back into the input field

    var enteredValue = parseInt(sanitizedValue);
    var minLimit = parseInt(inputElement.getAttribute("min"));
    var maxLimit = parseInt(inputElement.getAttribute("max"));

    // Check if the entered value is within the specified limits
    if (sanitizedValue.length === 0) {
        document.getElementById("studDignError").style.display = "none"; // Hide the error message
        inputElement.setCustomValidity(""); // Clear custom validity
    } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
        document.getElementById("studDignError").style.display = "block";
        inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
    } else {
        document.getElementById("studDignError").style.display = "none";
        inputElement.setCustomValidity("");
    }
}

// Add an event listener to the input field
document.getElementById("studDign").addEventListener("input", function () {
    validatestudDign(this);
});