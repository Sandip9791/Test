// Function to enforce the word limit on the textarea//////////////************Employability**************/////////////

function enforceWordLimit1(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords1').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement1 = document.getElementById('wordLimitedTextarea1');
textareaElement1.addEventListener('input', enforceWordLimit1);




// Function to enforce the word limit on the textarea////////////////*************Entreprenurship*************////////////////////////////
function enforceWordLimit2(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords2').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement2 = document.getElementById('wordLimitedTextarea2');
textareaElement2.addEventListener('input', enforceWordLimit2);



// Function to enforce the word limit on the textarea/////////////////**************Skill Development******************////////////////
function enforceWordLimit3(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords3').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement3 = document.getElementById('wordLimitedTextarea3');
textareaElement3.addEventListener('input', enforceWordLimit3);




//Validation for the Upload Course Syllabi
function validatesyllabi(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('uploadPOsError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}