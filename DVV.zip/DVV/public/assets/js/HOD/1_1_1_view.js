// Function to enforce the word limit on the textarea
function enforceWordLimit(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement = document.getElementById('wordLimitedTextarea');
textareaElement.addEventListener('input', enforceWordLimit);


//Validation for the Upload POs:
function validateuploadPOs(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('uploadPOsError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}


//Validation for the Upload COs:
function validateuploadCOs(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('uploadCOsError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

