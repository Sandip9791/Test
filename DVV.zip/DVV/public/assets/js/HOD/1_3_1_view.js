// Function to enforce the word limit on the textarea*******************************************Professional Ethics**************************************************8

function enforceWordLimit1(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords1').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement1 = document.getElementById('wordLimitedTextarea1');
textareaElement1.addEventListener('input', enforceWordLimit1);



// Function to enforce the word limit on the textarea**************************************Gender********************************************************
function enforceWordLimit2(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords2').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement2 = document.getElementById('wordLimitedTextarea2');
textareaElement2.addEventListener('input', enforceWordLimit2);




// Function to enforce the word limit on the textarea**********************************************Human Values**************************************************
function enforceWordLimit3(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords3').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement3 = document.getElementById('wordLimitedTextarea3');
textareaElement3.addEventListener('input', enforceWordLimit3);




// Function to enforce the word limit on the textarea*****************************************Environment and Sustainability*******************************************************
function enforceWordLimit4(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords4').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement4 = document.getElementById('wordLimitedTextarea4');
textareaElement4.addEventListener('input', enforceWordLimit4);



// Function to enforce the word limit on the textarea*******************************************************Others****************************************
function enforceWordLimit5(event) {
    const wordLimit =  200; // Set your desired word limit here
    const textarea = event.target;
    const words = textarea.value.trim().split(/\s+/);
    const remainingWords = wordLimit - words.length;

    if (remainingWords < 0) {
        // If the user exceeds the word limit, prevent further input
        event.preventDefault();
        textarea.value = words.slice(0, wordLimit).join(' ');
    }

    // Update the remaining words count
    document.getElementById('remainingWords5').textContent = remainingWords;
}

// Attach the event listener to the textarea
const textareaElement5 = document.getElementById('wordLimitedTextarea5');
textareaElement5.addEventListener('input', enforceWordLimit5);



//Valiation for the Upload Course syllabi 
function validatesyllabi(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('syllabiError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}