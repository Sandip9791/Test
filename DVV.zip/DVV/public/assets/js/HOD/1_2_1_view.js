//Validation for the Name of the Course
function validatecourse_name() {
    var regName = /[a-zA-Z ]$/;
    var name = document.getElementById('course_name').value;
    var error = document.getElementById("course_nameError");

    // Remove any non-alphabetical characters from the input
    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
    
    // Split the input into words and capitalize the first letter of each word
    var words = sanitizedName.split(" ");
    var capitalizedWords = words.map(function(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    });
    
    // Join the capitalized words back together
    var finalcourse_name= capitalizedWords.join(" ");
    
    document.getElementById('course_name').value = finalcourse_name;

    if (finalcourse_name.length === 0) {
        error.style.display = "none";
    } else if (!regName.test(finalcourse_name)) {
        error.style.display = "block";
    } else {
        error.style.display = "none";
    }
}


//Upload Minutes of Board of Studies meeting clearly specifying the syllabus approval of new courses * (.pdf only)
function validatesyllabus(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('syllabusError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}

//Upload Subsequent Academic Council meeting extracts endorsing the decision of BOS * (.pdf only)
function validatebos(event) {
    const file = event.target.files[0];
    const errorElement = document.getElementById('bosError');

    const maxSizeKB = 500; // Maximum file size in KB
    if (file.size > maxSizeKB * 1024) {
        errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
        event.target.value = ''; // Clear the file input
        return;
    }

    // If the file is valid, clear the error message
    errorElement.textContent = '';
}