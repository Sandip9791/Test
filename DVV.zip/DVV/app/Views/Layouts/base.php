<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modern College Ganeshkhind Pune </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/> 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
   
</head>

<body>

    <div class="img-fluid" style="width:100%;background-color: #034568;">
        <img  src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
    </div>

    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?= base_url('teaProf');?>">Dashboard</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Profile
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= base_url('teaForm')?>" >Teacher's Details</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('teaAwards')?>" >Teacher's Awards</a></li>

                            <!-- <li><hr class="dropdown-divider"></li> -->
                            <li><a class="dropdown-item" href="<?= base_url('teaLearning')?>">Teaching Learning</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('fdp')?>">Faculty Development Program (FDP)</a></li>

                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Research
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= base_url('reaserchGuideInfo1')?>" >Research Guide</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('reaserchProjectInfo')?>" >Research Project</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('reaserchPublication')?>">Research Publications</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('booksAndChapter')?>" >Books and Chapter</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('reaserchProjectMoney')?>">Seed Money</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('consultancy')?>">Consultancy</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('mou_Linkage')?>">MOU/Linkages</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('reaserchProjectFollowship')?>">Fellowship/Financial Support</a></li>
                           <!-- <li><hr class="dropdown-divider"></li> -->
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Teaching Learning Evaluation
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= base_url('experientialLearning')?>">Experiential Learning</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('studentcentric')?>">Student Centric Methods</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('effectiveMentee')?>">Mentor-Mentee Scheme</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('studyTour')?>" >Study Tour/Field Visits</a></li>
                           <!-- <li><hr class="dropdown-divider"></li> -->
                        </ul>
                    </li>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Extension & Outreach Program
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= base_url('activitiesOfForum')?>">Activities of Forum</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('financialSupport')?>">Financial Support</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('alumniEngagement')?>">Alumni Engagement</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('sensitization')?>" >Sensitization of Students</a></li>
                           <!-- <li><hr class="dropdown-divider"></li> -->
                        </ul>
                    </li>
                </ul>

                <!-- <form class="d-flex" method="Post" action="
                <?= base_url('teaLogout')?>">
                <label  class="btn btn-info rounded-pill mx-4"  title="Login Profile">Username: 
                    <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('loged_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-danger">
               </form> -->

           
          <img src="<?= base_url('assets/images/profile/profile.png');?>" width="36" height="36" alt="user image" class="rounded-circle" /></a>
               <form class="btn btn-info rounded-pill mx-2 d-flex" method="Post" action="<?= base_url('teaLogout')?>">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <label  class=""  title="Login Profile">Username : <?php  $session = \Config\Services::session(); $myusername= $session->get('loged_user'); echo $myusername ;?></label></a>
                        <ul class="dropdown-menu">
                            <!-- <li><a class="dropdown-item fa-solid fa-user" href="#">&nbsp;&nbsp;Profile</a></li>
                            <li><a class="dropdown-item fa-solid fa-gear">&nbsp;&nbsp;Settings</a> -->
                            <div class="dropdown-divider"></div>
                            <li>
                            &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-right-from-bracket">
                            <input type="submit" value="Logout"></i>
                            </li>

                          
                            <!-- &nbsp;&nbsp;<i class="fa-solid fa-arrow-right-from-bracket"></i>&nbsp;<input type="submit" value="Logout"> -->
                        </ul>
                    </div>
                </form>
            </div>
        </div>
    </nav>


      
    <?= $this->renderSection("Content");?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>

</html>