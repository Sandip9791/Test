<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modern College Ganeshkhind Pune </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/> 
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
    <style>
        .navbar-nav .nav-link {
  color: white;
}
.dropend .dropdown-toggle:hover {
  color: white;
  margin-left: 1em;
}
.dropdown-item:hover {
  background-color: blue;
  color: #fff;
}
.dropdown .dropdown-menu {
  display: none;
}
.dropdown:hover > .dropdown-menu,
.dropend:hover > .dropdown-menu {
  display: block;
  margin-top: 0.125em;
  margin-left: 0.125em;
}
@media screen and (min-width: 769px) {
  .dropend:hover > .dropdown-menu {
    position: absolute;
    top: 0;
    left: 100%;
  }
  .dropend .dropdown-toggle {
    margin-left: 0.5em;
  }
}

    </style>
</head>
<body>

<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img  src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>

<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
 <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?= base_url('iqacProf');?>">Dashboard</a>
            </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Criterion II
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
               2.3 Teaching - Learning Process (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('iqac_2_3_3')?>">2.3.3</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion IV 
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              4.1 Physical Facilities (30)
              </a>
              <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?= base_url('iqac_4_1_1')?>">4.1.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              4.4 Maintenance of Campus Infrastructure (20)
              </a>
              <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?= base_url('iqac_4_4_2')?>">4.4.2</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
     


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion VI 
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              6.1 Institutional Vision and Leadership (15)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_1_1')?>">6.1.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              6.2 Strategy Development and Deployment (10)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_2_1')?>">6.2.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_2_2')?>">6.2.2</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              6.3 Faculty Empowerment Strategies (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_3_1')?>">6.3.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_3_2')?>">6.3.2</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              6.4 Financial Management and Resourse Mobilization (15)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_4_1')?>">6.4.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('iqac_6_4_3')?>">6.4.3</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              6.5 Internal Quality Assurance System (IQAS) (35)
              </a>
              <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?= base_url('iqac_6_5_1')?>">6.5.1</a></li>
                  <li><a class="dropdown-item" href="<?= base_url('iqac_6_5_2')?>">6.5.2</a></li>
                  <li><a class="dropdown-item" href="<?= base_url('iqac_6_5_3')?>">6.5.3</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
 


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion VII 
          <!-- - Student Support and Progression (100) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              7.1 Institutional Values and Social Responsibilities (50)
              </a>
              <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?= base_url('iqac_7_1_1')?>">7.1.1</a></li>
                  <li><a class="dropdown-item" href="<?= base_url('iqac_7_1_6')?>">7.1.6</a></li>
                  <li><a class="dropdown-item" href="<?= base_url('iqac_7_1_10')?>">7.1.10</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              7.3 Best Practices (30)
              </a>
              <ul class="dropdown-menu">
                 <li><a class="dropdown-item" href="<?= base_url('iqac_7_3_1')?>">7.3.1</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>


<div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                </ul>

                
                <form class="d-flex" method="Post" action="<?= base_url('iqacLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('iqac_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
            </div>
        </div>
</nav>

    <?= $this->renderSection("Content");?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    </body>
</html>