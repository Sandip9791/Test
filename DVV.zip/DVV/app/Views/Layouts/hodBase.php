<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modern College Ganeshkhind Pune </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/> 
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
    <style>
        .navbar-nav .nav-link {
  color: white;
}
.dropend .dropdown-toggle:hover {
  color: white;
  margin-left: 1em;
}
.dropdown-item:hover {
  background-color: blue;
  color: #fff;
}
.dropdown .dropdown-menu {
  display: none;
}
.dropdown:hover > .dropdown-menu,
.dropend:hover > .dropdown-menu {
  display: block;
  margin-top: 0.125em;
  margin-left: 0.125em;
}
@media screen and (min-width: 769px) {
  .dropend:hover > .dropdown-menu {
    position: absolute;
    top: 0;
    left: 100%;
  }
  .dropend .dropdown-toggle {
    margin-left: 0.5em;
  }
}

    </style>
</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img  src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?= base_url('hodProf');?>">Dashboard</a>
            </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion I 
          <!-- - Curricular Aspects (150) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              1.1 Curriculum Design and Development (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_1_1_1')?>">1.1.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('hod_1_1_2')?>">1.1.2</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              1.2 Academic Flexibility (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_1_2_1')?>">1.2.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              1.3 Curriculum Enrichment (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_1_3_1')?>">1.3.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('hod_1_3_2')?>">1.3.2</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion II 
          <!-- - Teaching-Learning and Evaluation (300) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              2.2 Catering to Student Diversity (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_2_2_1')?>">2.2.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              2.3 Teaching - Learning Process (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_2_3_3')?>">2.3.3</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              2.6 Student Performance and Learning Outcomes (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_2_6_1')?>">2.6.1</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
     


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion III 
          <!-- - Research, Innovations and Extension (150) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              3.1 Promotion of Research and Facilities (20)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_3_1_1')?>">3.1.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              3.3 Innovation Ecosystem (10)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_3_3_1')?>">3.3.1</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              3.6 Extension Activities (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_3_6_1')?>">3.6.1</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
 


      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion V 
          <!-- - Student Support and Progression (100) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              5.1 Student Support (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_5_1_2')?>">5.1.2</a></li>
                <li><a class="dropdown-item"  href="<?= base_url('hod_5_1_3')?>">5.1.3</a></li>

              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              5.2 Student Progression (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_5_2_1')?>">5.2.1,5.2.2</a></li>
                <li><a class="dropdown-item" href="<?= base_url('hod_5_2_3')?>">5.2.3</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>




      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Criterion VII 
          <!-- - Institutional Values and Best Practices (100) -->
          </a>
          <ul class="dropdown-menu">
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              7.1 Institutional Values and Social Responsibilities (50)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_7_1_1')?>">7.1.1</a></li>
                <li><a class="dropdown-item" href="<?= base_url('hod_7_1_8')?>">7.1.8</a></li>
              </ul>
            </li>
            <li class="nav-item dropend">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              7.2 Best Practices (30)
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= base_url('hod_7_2_1')?>">7.2.1</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>


            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                </ul>

                
                <form class="d-flex" method="Post" action="<?= base_url('teaLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('loged_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
            </div>
        </div>
</nav>

    <?= $this->renderSection("Content");?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    </body>
</html>