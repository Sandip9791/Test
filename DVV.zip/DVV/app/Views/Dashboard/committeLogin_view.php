<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Committee Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
       
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
      <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css'); ?>"/>
       
</head>

<body>
    <div class="image-container border-bottom">
    <img src="<?php echo base_url('assets/images/ModernCollageLogo.png'); ?>"/>
    </div>

    
    <div class="conatiner-fluid">
        <div class="row position-relative  border border-light-subtle mx-4 my-4">
            <div class="col my-4">
            <!-- <center><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-bank bd-placeholder-img rounded-circle" viewBox="0 0 16 16">
                    <path d="m8 0 6.61 3h.89a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5H15v7a.5.5 0 0 1 .485.38l.5 2a.498.498 0 0 1-.485.62H.5a.498.498 0 0 1-.485-.62l.5-2A.501.501 0 0 1 1 13V6H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 3h.89L8 0ZM3.777 3h8.447L8 1 3.777 3ZM2 6v7h1V6H2Zm2 0v7h2.5V6H4Zm3.5 0v7h1V6h-1Zm2 0v7H12V6H9.5ZM13 6v7h1V6h-1Zm2-1V4H1v1h14Zm-.39 9H1.39l-.25 1h13.72l-.25-1Z"/>
                  </svg></center> -->
                  <a href="<?= base_url('ALogin');?>" style="text-decoration: none;color: black;">
                  <center><i class="fa-solid fa-building-columns fa-5x" ></i></center>
                </a> 
                  <br>
                <h2 class="fw-normal text-center">
                <a href="<?= base_url('ALogin');?>" style="text-decoration: none;color: black;">Admin</a></h2>
                <!-- <p>And lastly this, the third column of representative placeholder content.</p> -->
            </div>
    
            <!-- /.col-lg-4 -->
            <div class="col my-4">
            <a href="<?= base_url();?>" style="text-decoration: none;color: black;">
            <center><i class="fa-solid fa-users fa-5x"></i></center>  
                 </a>
            
            <br>
            <h2 class="fw-normal text-center">
            <a href="<?= base_url();?>" style="text-decoration: none;color: black;">Teachers</a></h2>
                <!-- <p>And lastly this, the third column of representative placeholder content.</p> -->
            </div>
    

          
            <!-- /.col-lg-4 -->
            <div class="col my-4">
            <a href="<?= base_url('PLogin');?>" style="text-decoration: none;color: black;">
            <center><i class="fa-sharp fa-solid fa-graduation-cap fa-5x"></i></center>

                 </a>
            <br>
            <h2 class="fw-normal text-center">
            <a href="<?= base_url('PLogin')?>" style="text-decoration: none;color: black;">Principal </a></h2>
                <!-- <p>And lastly this, the third column of representative placeholder content.</p> -->
            </div>
            
             <!-- /.col-lg-4 -->
             <div class="col my-4">
                <a href="<?= base_url('ILogin');?>" style="text-decoration: none;color: black;">
                <center><i class="fa-solid fa-book-open-reader  fa-5x" ></i></center></a>
                <br>
                <h2 class="fw-normal text-center">
                <a href="<?= base_url('ILogin')?>" style="text-decoration: none;color: black;">IQAC</a></h2>
                    <!-- <p>And lastly this, the third column of representative placeholder content.</p> -->
            </div>

            <div class="col my-4">
                <a href="<?= base_url('CLogin');?>" style="text-decoration: none;color: black;">
                <center><i class="fa-solid fa-users-between-lines fa-5x fa-beat"></i></center>
                
                     </a>
                <br>
                <h2 class="fw-normal text-center">
                <a href="<?= base_url('CLogin')?>" style="text-decoration: none;color: black;">Committees</a></h2>
                    <!-- <p>And lastly this, the third column of representative placeholder content.</p> -->
            </div>
        </div>
    </div>
    </div>
    </div>
    <div class="container-fluid">
        <div class="row" style="margin-left:130px; padding:auto;" >
            <div class="col-lg-6 my-4" >
                <div id="Maininfo_College">
                    <div class="login_main_inner">
                        <h5>For Admin</h5>
                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com">moderncollege16@gmail.com</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;: (020) 25634021 / (020) 25650191<br> -->
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('ALogin');?>">Admin Login</a><br>

                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;
                        <a href="<?= base_url('ALogin');?>">MIRROR</a>


                            <hr style="width:45%;text-align:left;margin-left:0">
                        <h5>For Teachers</h5>
                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com"> moderncollege16@gmail.com</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;: (020) 25634021 / (020) 25650191<br> -->
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url();?>">Teacher Login</a><br>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('forgotPassword');?>">Teacher Forgot Password?</a>

                            <hr style="width:45%;text-align:left;margin-left:0">
                        <h5>For Principal | Vice Principal</h5>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('PLogin');?>">Principal | Vice Principal</a>
                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com"> moderncollege16@gmail.com</a> -->
                    </div>
                
                </div>
                    
            </div>
            <div class="col-lg-6 my-4">
                <div class="login-box">
                    <h2>Committee Login</h2>
                    <form method="POST" action="<?= base_url('committeeLogin');?>">
                      <div class="user-box">
                        <input type="text" name="username" required="" autocomplete="off">
                        <label>Username</label>
                      </div>
                      <div class="user-box">
                        <input type="password" name="password" required="" autocomplete="off">
                        <label>Password</label>
                      </div>
                      <div class="forgot">
                        <a href="<?= base_url('forgotPassword');?>" style="color:black">Forgot Password ?</a>
                    </div>
                      <b>
                      <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                          <input type="submit" value="Login" >
                      </b>
                    </form>
                </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N"
        crossorigin="anonymous"></script>
        
</body>

</html>