<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
       
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>

        <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css'); ?>"/>
        <style>
          .passwordMessage{
            color: #ff1a1a;
            display:none;
          }
        </style>
</head>

<body>
    <div class="image-container border-bottom">
    <img src="<?php echo base_url('assets/images/ModernCollageLogo.png'); ?>"/>
    </div>

    <div class="container-fluid">
        <div class="row" style="margin-left:130px; padding:auto;" >
            <div class="col-lg-6 my-4" >
                <div id="Maininfo_College">
                    <div class="login_main_inner">
                        <h5>For Admin</h5>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('ALogin');?>">Admin Login</a>

                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com">moderncollege16@gmail.com</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;: (020) 25634021 / (020) 25650191<br> -->
                        

                        <hr style="width:45%;text-align:left;margin-left:0">
                        <h5>For Teachers</h5>

                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url();?>">Teacher Login</a><br>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('forgotPassword');?>">Teacher Forgot Password?</a>

                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com"> moderncollege16@gmail.com</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;: (020) 25634021 / (020) 25650191<br> -->
                       

                            <hr style="width:45%;text-align:left;margin-left:0">
                        <h5>For Principal | Vice Principal</h5>

                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="<?= base_url('PLogin');?>">Principal | Vice Principal</a>

                        <!-- <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto: moderncollege16@gmail.com"> moderncollege16@gmail.com</a> -->
                    </div>
                
                </div>
                    
            </div>
            <div class="col-lg-6 my-4">
            <div class="login-box">
                    <h2>Forgot Password ?</h2>
                    <p style="text-align:center; color:#fff ;" >We have sent you an OTP at your registered email.</p>
                    <form method="POST" action="<?= base_url('confirmPassword');?>">
                      <div class="user-box">
                        <input type="password" name="otp" required="">
                        <label>OTP</label>
                      </div>
                      <div class="user-box">
                        <input class="password" type="password" name="password" required="" onkeyup="checkPassword()">
                        <label>Enter A New Password</label>
                      </div>
                      <div class="user-box">
                        <input class="confirmPassword" type="password" name="confirmPassword" required="" onkeyup="checkPassword()">
                        <label>Confirm Password</label>
                        <h5 class="passwordMessage">The passwords aren't matching, please re-check</h5>
                      </div>
                      <b>
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                          <input type="submit" value="Save" >
                      </b>
                      <b>
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                          <a href="<?= base_url()?>" style="text-decoration:none">Cancel</a>
                      </b>
                    </form>
                </div>
        </div>
    </div>
                
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N"
        crossorigin="anonymous"></script>

    <script>
      // document.querySelector(".resetButton").addEventListener("click",function(e){
      //   e.preventDefault();
      // });
      function checkPassword(){
        let password=document.querySelector(".password").value;
        let confirmPassword=document.querySelector(".confirmPassword").value;
        
        if( password !== confirmPassword ){
          document.querySelector(".passwordMessage").style.display="block";

        }
        else{
          document.querySelector(".passwordMessage").style.display="none";
        }
      }
    </script> 
        
</body>

</html>