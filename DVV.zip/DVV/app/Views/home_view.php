<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url(); ?>">Home</a>
                </li>
                <li class="nav-item">
                <li> <a class="btn btn-outline-danger mx-4" data-bs-toggle="modal" data-bs-target="#exampleModal1">Admin </a></li>
                </li>
                <li class="nav-item">
                <li> <a class="btn btn-outline-info mx-2" data-bs-toggle="modal" data-bs-target="#exampleModa2">Teachers</a></li>
                </li> 
            </ul>
        </div>
    </div>
</nav>


<!-- Admin Login Modal -->
<form method="POST" action="<?= base_url();?>/adminLogin">
    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Login Form</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!--Email-->
                    <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Username</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
                    <!--password-->
                    <div class="mb-3 row" id="check">
                        <label for="inputPassword" class="col-sm-2 col-form-label text-dark">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="password" name="password" maxlength="12"
                                onkeyup="validatePassword()" required>
                            <span id="passError" style="display:none;color:red;">Please enter valid Password.</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                    Forgot
                </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Login" class="btn btn-outline-primary">
                </div>
            </div>
        </div>
    </div>
</form>


<!-- Teacher Login Modal -->
<form method="POST" action="<?= base_url();?>/teaLogin ">
    <div class="modal fade" id="exampleModa2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Login Form</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!--Email-->
                    <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Username</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
                    <!--password-->
                    <div class="mb-3 row" id="check">
                        <label for="inputPassword" class="col-sm-2 col-form-label text-dark">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="password" name="password" maxlength="12"
                                onkeyup="validatePassword()" required>
                            <span id="passError" style="display:none;color:red;">Please enter valid Password.</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                    Forgot
                </button>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Login" class="btn btn-outline-primary">
                </div>
            </div>
        </div>
    </div>
</form>


<!-- Forgot Model For Teacher Login -->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Recover Your Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <!--Email-->
          <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Username</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
            
              <!--Email-->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Register Email ID</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

              <!--Email-->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">OTP</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

              <!--Email-->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Password</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

                  <!--Email-->
                  <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Confirm Password</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-outline-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<!-- Forgot Model For Admin Login -->
<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Recover Your Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <!-- Username -->
          <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Username</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
            
              <!--Register Email ID -->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Register Email ID</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

              <!-- OTP -->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">OTP</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

              <!-- Password -->
              <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Password</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>

                  <!--Confirm Password-->
                  <div class="mb-3 row " id="check">
                        <label for="staticEmail" class="col-sm-2 col-form-label text-dark">Confirm Password</label>
                        <div class="col-sm-10">
                            <input id="username" type="text" class="form-control" name="username" maxlength="50"
                                onkeyup="validateUsername()" required>
                            <span id="userError" style="display:none;color:red;">Please enter valid Username.</span>

                        </div>
                    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-outline-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<script>

    function validateUsername() {
        var username = document.getElementById("username").value;
        var regUser = /[A-Za-z][0-9]{4}$/;
        var error = document.getElementById("userError");

        if (!regUser.test(username)) {
            error.style.display = "block";

        } else {
            error.style.display = "none";
        }
    }


    function validatePassword() {
        var password = document.getElementById("password").value;
        var upperRegex = /[A-Z]/;
        var lowerRegex = /[a-z]/;
        var symbolRegex = /[!@#$%^&*()_+]/;
        var digitRegex = /\d/;
        var error = document.getElementById("passError");

        if (!upperRegex.test(password)) {
            error.style.display = "block";
        }
        else if (!lowerRegex.test(password)) {
            error.style.display = "block";
        }
        else if (!symbolRegex.test(password)) {
            error.style.display = "block";
        }
        else if (!digitRegex.test(password)) {
            error.style.display = "block";
        }
        else {
            error.style.display = "none";
        }
    }


</script>

<?= $this->endSection();?>