<!DOCTYPE html>
<html>
<head>
	<title> IQAC Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

    <link rel="stylesheet" href="<?= base_url('assets/css/hodDashboard.css')?>">
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        }) 
    </script>

</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
      
    
    
    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html"></a>
                    </li>
                    <li class="nav-item dropdown">
                    </li>
                </ul>
                

                <form class="d-flex" method="Post" action="<?= base_url('iqacLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('iqac_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
           </div>
       </div>
   </nav>
   
    <h1 style="margin-top:10px; margin-bottom:10px; text-align:center;">IQAC Dashboard</h1>
    <div class="container">
    <div class="section1">
			<div class="section1a mt-1">
                <h3>&nbsp; Profile</h3>
            </div>

                <?php if(isset($documents)):
                    foreach($documents as $doc):
                      
                        $title=$doc->Title;
                        $fname=$doc->First_Name;
                        $lname=$doc->Last_Name;
                        $mname=$doc->Midd_Name;
                
                        $Name = $title." ".$fname." ".$mname." ".$lname;
                        
                ?>
			<div class="section1b">
                <img src="<?= base_url("assets\images\profile\pro.png");?>" alt="profile" class="profilr_pic"><br>
                <h6><b>Name :&nbsp;</b><?= $Name?></h6>
                <h6><b>Designation :&nbsp;</b><?= $doc->Designation?></h6>
                <h6><b>Teacher Type :&nbsp;</b><?= $doc->Teacher_Type?></h6>
                <h6><b>Email :&nbsp;</b><?= $doc->Email?></h6>
                <h6><b>Department :&nbsp;</b><?= $doc->Department?></h6>
                </h6>
                <h6><b>Name of the College / Institute : </b>
                    Progressive Education Society's
                    Modern College Of Arts, Science & Commerce
                    Ganeshkhind,Pune-16.
                </h6>
            </div>
		</div>

		<div class="section2">
			<div class="section2a  pt-3">
                <h3>&nbsp; Important links:</h3>
            </div>
			<br>
            <div class="section2b"><u>
                    <ol id="criteria">
                        
                        <li onclick="toggleSublist(6)" class="mx-3" style="color:green;"><b>&nbsp;Criterion II - Teaching-Learning and Evaluation (300)&nbsp;</b></li>
                            <ul class="criterium6" id="sublist6" style="display: none;">
                                
                                <li onclick="toggleSublist(9)">2.3 Teaching - Learning Process (50)</li>
                                    <ul class="sub-criterium9" id="sublist9" style="display: none;">
                                        <li><a href="<?= base_url('iqac_2_3_3')?>">2.3.3</a></li>
                                    </ul>
                            </ul>
                            <hr>
                            <br>
                        <li onclick="toggleSublist(14)" class="mx-3" style="color:green;"><b>&nbsp;Criterion IV – Infrastructure and Learning Resources (100)&nbsp;</b></li>
                            <ul class="criterium14" id="sublist14" style="display: none;">
                                <li onclick="toggleSublist(15)">4.1 Physical Facilities (30)</li>
                                    <ul class="sub-criterium15" id="sublist15" style="display: none;">
                                        <li><a href="<?= base_url('iqac_4_1_1')?>">4.1.1</a></li>
                                    </ul>
                                <li onclick="toggleSublist(17)">4.4 Maintenance of Campus Infrastructure (20)</li>
                                    <ul class="sub-criterium17" id="sublist17" style="display: none;">
                                        <li><a href="<?= base_url('iqac_4_4_2')?>">4.4.2</a></li>
                                    </ul>  
                            </ul>
                            <hr>
                            <br>
                        <li onclick="toggleSublist(27)" class="mx-3" style="color:green;"><b>&nbsp;Criterion VI – Governance, Leadership and Management (100)&nbsp;</b></li>
                            <ul class="criterium27" id="sublist27" style="display: none;">
                                <li onclick="toggleSublist(28)">6.1 Institutional Vision and Leadership (15)</li>
                                    <ul class="sub-criterium28" id="sublist28" style="display: none;">
                                        <li><a href="<?= base_url('iqac_6_1_1')?>">6.1.1</a></li>
                                    </ul>
                                <li onclick="toggleSublist(29)">6.2 Strategy Development and Deployment (10)</li>
                                    <ul class="sub-criterium29" id="sublist29" style="display: none;">
                                        <li><a href="<?= base_url('iqac_6_2_1')?>">6.2.1</a></li>
                                        <li><a href="<?= base_url('iqac_6_2_2')?>">6.2.2</a></li>

                                    </ul>
                                <li onclick="toggleSublist(30)">6.3 Faculty Empowerment Strategies (30)</li>
                                    <ul class="sub-criterium30" id="sublist30" style="display: none;">
                                        <li><a href="<?= base_url('iqac_6_3_1')?>">6.3.1</a></li>
                                        <li><a href="<?= base_url('iqac_6_3_2')?>">6.3.2</a></li>
                                    </ul>
                                <li onclick="toggleSublist(31)">6.4 Financial Management and Resourse Mobilization (15)</li>
                                    <ul class="sub-criterium31" id="sublist31" style="display: none;">
                                        <li><a href="<?= base_url('iqac_6_4_1')?>">6.4.1</a></li>
                                        <li><a href="<?= base_url('iqac_6_4_3')?>">6.4.3</a></li>
                                    </ul>
                                <li onclick="toggleSublist(32)">6.5 Internal Quality Assurance System (IQAS) (35)</li>
                                    <ul class="sub-criterium32" id="sublist32" style="display: none;">
                                        <li><a href="<?= base_url('iqac_6_5_1')?>">6.5.1</a></li>
                                        <li><a href="<?= base_url('iqac_6_5_2')?>">6.5.2</a></li>
                                        <li><a href="<?= base_url('iqac_6_5_3')?>">6.5.3</a></li>
                                    </ul>
                            </ul>
                            <hr>
                            <br>

                        <li onclick="toggleSublist(38)" class="mx-3" style="color:green;"><b>&nbsp;Criterion VII – Institutional Values and Best Practices (100)&nbsp;</b></li>
                            <ul class="criterium38" id="sublist38" style="display: none;">
                                <li onclick="toggleSublist(39)">7.1 Institutional Values and Social Responsibilities (50)</li>
                                    <ul class="sub-criterium39" id="sublist39" style="display: none;">
                                        <li><a href="<?= base_url('iqac_7_1_1')?>">7.1.1</a></li>
                                        <li><a href="<?= base_url('iqac_7_1_6')?>">7.1.6</a></li>
                                        <li><a href="<?= base_url('iqac_7_1_10')?>">7.1.10</a></li>
                                       
                                    </ul>
                                <li onclick="toggleSublist(40)">7.3 Best Practices (30) </li>
                                    <ul class="sub-criterium40" id="sublist40" style="display: none;">
                                        <li><a href="<?= base_url('iqac_7_3_1')?>">7.3.1</a></li>
                                    </ul>
                            </ul>
                    </ol></u>
                    <script>
                        function toggleSublist(listNum) 
                        {
                        var sublist = document.getElementById("sublist" + listNum);
                        sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                        }
                    </script>
            </div>
            
		</div>
	</div>
<?php endforeach;?>
<?php endif;?>
</body>
</html>