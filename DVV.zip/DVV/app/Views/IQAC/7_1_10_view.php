<?= $this->extend('Layouts/iqacBase');?>
<?= $this->section("Content");?>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>The Institution has a prescribed code of conduct for students, teachers, administrators and other staff and conducts periodic programmes in this regard (7.1.10):</h1>
            <form class="row g-4 my-4" method="post" action="<?= base_url('save_IQAC_7_1_10')?>" enctype="multipart/form-data"> 
            <div  id="form-container" >

                <div class="form-fields">
                    
                    <div class="row mx-2 pt-3 pb-3 border border-2">
                <!-- <div class="col-md-12">
                    <label >Describe the gender equity & sensitization in curricular and co-curricular activities, facilities for women on campus etc. : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="Describe" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement = document.getElementById('wordLimitedTextarea');
                        textareaElement.addEventListener('input', enforceWordLimit);
                    </script>
                </div> -->
                 <div class="col-md-6 my-2" >
                    <label for="">Upload Policy document on code of ethics : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="policyEdoc" name="policyEdoc" onchange="validatePolicyEDoc()" accept=".pdf">
                    <span id="policyEdocError" style="color:red;"></span>
                    </div>
                    
                    <br>
                 <div class="col-md-6 my-2">
                    <label for="">Upload Constitution and proceedings of the monitoring committee : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="cpmcdoc" name="cpmcdoc" onchange="validateCPMCDoc()" accept=".pdf">
                    <span id="cpmcdocError" style="color:red;"></span>
                    </div>
                    <br>
                 <div class="col-md-6 my-2">
                    <label for="">Upload Circulars of Code of Conduct for students, teachers, governing body and administration and other staff : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="cocdoc" name="cocdoc" onchange="validateCOCDoc()" accept=".pdf">
                    <span id="cocdocError" style="color:red;"></span>
                    </div>
                    <br>
                 <div class="col-md-6 my-2">
                    <label for="">Upload Programs on Professional ethics for students, teachers, administrators and other staff : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="popedoc" name="popedoc" onchange="validatePOPEDoc()" accept=".pdf">
                    <span id="popedocError" style="color:red;"></span>
                    </div>
                    <br>
                 <div class="col-md-6 my-2">
                    <label for="">Upload Handbooks, manuals and brochures on human values and professional ethics : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="ethicsdoc" name="ethicsdoc" onchange="validateEthicsDoc()" accept=".pdf">
                    <span id="ethicsdocError" style="color:red;"></span>
                    </div>
                    <br> 
                 <div class="col-md-6 my-2">
                    <label for="">Upload Report on the student attributes facilitated by the Institution : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="reportdoc" name="reportdoc" onchange="validateReportDoc()" accept=".pdf">
                    <span id="reportdocError" style="color:red;"></span>
                    </div>
                    <br>                                        
                 <div class="col-md-7 my-3">
                    <label for="">Upload Relevant Document : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="Relaventdoc" name="Relaventdoc" onchange="validateRelaventDoc()" accept=".pdf">
                    <span id="RelaventdocError" style="color:red;"></span>
                </div>
                <br>
               
                 <div class="col-md-6 my-3">
                    <label class="form-label">Upload Geotag Photo  : <label style="color: red;">* (.jpg ,.jpeg ,.png)</label></label>
                    <input type="file" class="form-control" name="photo1" onchange="validateGeoP()" accept=".jpg, .jpeg, .png" />
                    <span id="GeoPError" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo2" onchange="validateGeoP1()" accept=".jpg, .jpeg, .png" />
                    <span id="GeoP1Error" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo3" onchange="validateGeoP2()" accept=".jpg, .jpeg, .png" />
                    <span id="GeoP2Error" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo4" onchange="validateGeoP3()" accept=".jpg, .jpeg, .png" />
                    <span id="GeoP3Error" style="color: red;"></span>
                </div>
                 <br>
                 
                 <div class="col-md-6 my-3">
                    <label class="form-label">Upload Non-Geotag Photo  : <label style="color: red;">* (.jpg ,.jpeg ,.png)</label></label><br>
                    <input type="file" class="form-control" name="photo5" onchange="validateNGeoP()" accept=".jpg, .jpeg, .png" />
                    <span id="NGeoPError" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo6" onchange="validateNGeoP1()" accept=".jpg, .jpeg, .png" />
                    <span id="NGeoP1Error" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo7" onchange="validateNGeoP2()" accept=".jpg, .jpeg, .png" />
                    <span id="NGeoP2Error" style="color: red;"></span>
                    <br>
                    <input type="file" class="form-control" name="photo8" onchange="validateNGeoP3()" accept=".jpg, .jpeg, .png" />
                    <span id="NGeoP3Error" style="color: red;"></span>
                </div>
                 <br>
                
            <script>
                    function validatePolicyEDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('policyEdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateGAuditDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('GAuditdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateCPMCDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('cpmcdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateCOCDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('cocdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validatePOPEDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('popedocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateEthicsDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('ethicsdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateReportDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('reportdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }

                    function validateRelaventDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('RelaventdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }
                
                function validateGeoP() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('GeoPError');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }
            
              function validateGeoP2() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('GeoP1Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }


                 function validateGeoP2() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('GeoP2Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }
            
              function validateGeoP3() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('GeoP3Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }

              function validateNGeoP() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('NGeoPError');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }

              function validateNGeoP1() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('NGeoP1Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }

                            
                function validateNGeoP2() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('NGeoP2Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }

              function validateNGeoP3() {
                    const file = event.target.files[0];
                    const errorElement = document.getElementById('NGeoP3Error');
                    const allowedExtensions = ["jpg", "jpeg", "png"];
                        if (!file) {
                        errorElement.textContent = 'No file selected.';
                        return;
                    }
                    const fileExtension = getFileExtension(file.name);
                    if (!allowedExtensions.includes(fileExtension)) {
                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    if (file.size > 10240 * 1024) {
                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                        event.target.value = ''; // Clear the file input
                        return;
                    }
                    // If the file is valid, clear the error message
                    errorElement.textContent = '';
                    }
                    function getFileExtension(filename) {
                    return filename.split('.').pop().toLowerCase();
              }
                </script>
                </div>
                </div>
                </div>
                
                 <div class="col-12 text-center">
                   <input type="submit" class="btn btn-outline-primary">
                 </div>
            </form>
	</div>



    <div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):

            foreach($documents as $doc):
                $book=  $doc->Reaserch_Project_Info;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Sanction_Latter;
            ?>
            <tr >
                <th scope="row">
                    <form action="<?= base_url('deleteProjectInfo')?>" method="post">
                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->RInfo_id?>"></th>
                <td class="text-center"><?= $chapter->Name_Of_Project?> </td>
                <td class="text-center"><?= $chapter->Investigator_Type?> </td>
                <td class="text-center"> <?= $chapter->Name_Of_Funding_Agency?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Award?> </td>
                <td class="text-center"> <?= $chapter->Type_Funding_Aggency?> </td>
                <td class="text-center"> <?= $chapter->Satus?> </td>
                <td class="text-center"> <?= $chapter->Funds_Provided?> </td>
                <td class="text-center"> <?= $chapter->Duration_Of_Project?> </td>
                <td class="text-center"> <?= $cover->Name?> </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><input class="btn btn-danger" type="submit" value="Delete"></td> 
                      </form>
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RInfo_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RInfo_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Book And Chapter</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateBookAndChapter')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <!-- <div class="col-md-12">
                                    <label >Describe the gender equity & sensitization in curricular and co-curricular activities, facilities for women on campus etc. : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                    <textarea name="Describe" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                    <script>
                                        // Function to enforce the word limit on the textarea
                                        function enforceWordLimit(event) {
                                            const wordLimit =  200; // Set your desired word limit here
                                            const textarea = event.target;
                                            const words = textarea.value.trim().split(/\s+/);
                                            const remainingWords = wordLimit - words.length;
                                
                                            if (remainingWords < 0) {
                                                // If the user exceeds the word limit, prevent further input
                                                event.preventDefault();
                                                textarea.value = words.slice(0, wordLimit).join(' ');
                                            }
                                
                                            // Update the remaining words count
                                            document.getElementById('remainingWords').textContent = remainingWords;
                                        }
                                
                                        // Attach the event listener to the textarea
                                        const textareaElement = document.getElementById('wordLimitedTextarea');
                                        textareaElement.addEventListener('input', enforceWordLimit);
                                    </script>
                                </div> -->
                                <br>
                                <div class="col-md-6">
                                    <label for="">Upload Policy document on code of ethics (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="policyEdoc" name="policyEdoc" onchange="validatePolicyEDoc()" accept=".pdf">
                                    <span id="policyEdocError" style="color:red;"></span>
                                    </div>
                                    
                                    <br>
                                <div class="col-md-6">
                                    <label for="">Upload Constitution and proceedings of the monitoring committee (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="cpmcdoc" name="cpmcdoc" onchange="validateCPMCDoc()" accept=".pdf">
                                    <span id="cpmcdocError" style="color:red;"></span>
                                    </div>
                                    <br>
                                <div class="col-md-6">
                                    <label for="">Upload Circulars of Code of Conduct for students, teachers, governing body and administration and other staff (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="cocdoc" name="cocdoc" onchange="validateCOCDoc()" accept=".pdf">
                                    <span id="cocdocError" style="color:red;"></span>
                                    </div>
                                    <br>
                                <div class="col-md-6">
                                    <label for="">Upload Programs on Professional ethics for students, teachers, administrators and other staff (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="popedoc" name="popedoc" onchange="validatePOPEDoc()" accept=".pdf">
                                    <span id="popedocError" style="color:red;"></span>
                                    </div>
                                    <br>
                                <div class="col-md-6">
                                    <label for="">Upload Handbooks, manuals and brochures on human values and professional ethics (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="ethicsdoc" name="ethicsdoc" onchange="validateEthicsDoc()" accept=".pdf">
                                    <span id="ethicsdocError" style="color:red;"></span>
                                    </div>
                                    <br>
                                <div class="col-md-6">
                                    <label for="">Upload Report on the student attributes facilitated by the Institution (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="reportdoc" name="reportdoc" onchange="validateReportDoc()" accept=".pdf">
                                    <span id="reportdocError" style="color:red;"></span>
                                    </div>
                                    <br>                                        
                                <div class="col-md-7">
                                    <label for="">Upload Relevant Document (.pdf Only) :</label>
                                    <input type="file" class="form-control" id="Relaventdoc" name="Relaventdoc" onchange="validateRelaventDoc()" accept=".pdf">
                                    <span id="RelaventdocError" style="color:red;"></span>
                                </div>
                            
                                <div class="col-md-6">
                                    <label class="form-label">Upload Geotag Photo  :<label style="color: red;">* (.jpg ,.jpeg ,.png)</label></label>
                                    <input type="file" class="form-control" name="photo1" onchange="validateGeoP()" accept=".jpg, .jpeg, .png" />
                                    <span id="GeoPError" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo2" onchange="validateGeoP1()" accept=".jpg, .jpeg, .png" />
                                    <span id="GeoP1Error" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo3" onchange="validateGeoP2()" accept=".jpg, .jpeg, .png" />
                                    <span id="GeoP2Error" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo4" onchange="validateGeoP3()" accept=".jpg, .jpeg, .png" />
                                    <span id="GeoP3Error" style="color: red;"></span>
                                </div>
                                <br>
                                
                                <div class="col-md-6">
                                    <label class="form-label">Upload Non-Geotag Photo  :<label style="color: red;">* (.jpg ,.jpeg ,.png)</label></label><br>
                                    <input type="file" class="form-control" name="photo5" onchange="validateNGeoP()" accept=".jpg, .jpeg, .png" />
                                    <span id="NGeoPError" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo6" onchange="validateNGeoP1()" accept=".jpg, .jpeg, .png" />
                                    <span id="NGeoP1Error" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo7" onchange="validateNGeoP2()" accept=".jpg, .jpeg, .png" />
                                    <span id="NGeoP2Error" style="color: red;"></span>
                                    <br>
                                    <input type="file" class="form-control" name="photo8" onchange="validateNGeoP3()" accept=".jpg, .jpeg, .png" />
                                    <span id="NGeoP3Error" style="color: red;"></span>
                                </div>
                                <br>
                                
                            <script>
                                    function validatePolicyEDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('policyEdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateGAuditDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('GAuditdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateCPMCDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('cpmcdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateCOCDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('cocdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validatePOPEDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('popedocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateEthicsDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('ethicsdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateReportDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('reportdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                    function validateRelaventDoc() {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('RelaventdocError');
                                        if (!file.type.match('pdf')) {
                                            errorElement.textContent = 'File is not a PDF.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        if (file.size > 500 * 1024) {
                                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }
                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }
                                
                                function validateGeoP() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('GeoPError');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }
                            
                            function validateGeoP2() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('GeoP1Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }


                                function validateGeoP2() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('GeoP2Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }
                            
                            function validateGeoP3() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('GeoP3Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }

                            function validateNGeoP() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('NGeoPError');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }

                            function validateNGeoP1() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('NGeoP1Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }

                                            
                                function validateNGeoP2() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('NGeoP2Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }

                            function validateNGeoP3() {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('NGeoP3Error');
                                    const allowedExtensions = ["jpg", "jpeg", "png"];
                                        if (!file) {
                                        errorElement.textContent = 'No file selected.';
                                        return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                        errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 10240 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 10 MB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }
                                    function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                            }
                                </script>





                                        
                                        </div>
                                    </div>
                                
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                    <button  class="btn btn-outline-warning">Update</button>
                                </div>
                                </form>
                                </div>
                            </div>
                            </div>
                    </td>
                    </tr>
                    <?php endforeach;?>
                </tbody>
                <?php endforeach;?>
                <?php endif;?>
            </table>
            </div>

    <?= $this->endSection();?>



