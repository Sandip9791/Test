<?= $this->extend('Layouts/iqacBase');?>
<?= $this->section("Content");?>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>Internal Quality Assurance Cell (IQAC)/ Internal Quality Assurance System (IQAS) has contributed significantly for institutionalizing the quality assurance strategies and processes, by constantly reviewing the teaching-learning process, structures & methodologies of operations and learning outcomes, at periodic intervals (6.5.1):</h1>
        <br>
        <h4>Internal Quality Assurance Cell (IQAC) has contributed significantly for institutionalizing the quality assurance strategies and processes visible in terms of – </h4>
        
        <h5>    •	Incremental improvements made for the preceding five years with regard to quality and post accreditation quality initiatives (second and subsequent cycles)</h5>
        <div class="row g-3 my-3">
            <form method="post" action="<?= base_url('save_IQAC_6_5_1')?>" enctype="multipart/form-data"> 
                
                <div  id="form-container" >

<div class="form-fields">
    
    <div class="row mx-2 pt-3 pb-3 border border-2">
    <div class="col-md-12">
                    <label >Describe two practices institutionalized as a result of IQAC initiatives : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="Describe" class="form-control my-2" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement = document.getElementById('wordLimitedTextarea');
                        textareaElement.addEventListener('input', enforceWordLimit);
                    </script>
                </div>
                 <br>
                 <div class="col-md-6">
                    <label for="">Upload Relevant Document : <label style="color: red;">* (.pdf Only)</label> </label>
                    <input type="file" class="form-control my-2" id="Relaventdoc" name="Relaventdoc" onchange="validateRelaventDoc()" accept=".pdf">
                    <span id="RelaventdocError" style="color:red;"></span>
                </div>
                
                <script>
                    function validateRelaventDoc() {
                        const file = event.target.files[0];
                        const errorElement = document.getElementById('RelaventdocError');
                        if (!file.type.match('pdf')) {
                            errorElement.textContent = 'File is not a PDF.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        if (file.size > 500 * 1024) {
                            errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                            event.target.value = ''; // Clear the file input
                            return;
                        }
                        // If the file is valid, clear the error message
                        errorElement.textContent = '';
                    }
                </script>
                </div>
                </div>
                </div>
                </div>
                <br>
                
                 <div class="col-12 text-center">
                   <input type="submit" class="btn btn-outline-primary">
                 </div>
                 <br>
            </form>
        </div> 
	


    <div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):

            foreach($documents as $doc):
                $book=  $doc->Reaserch_Project_Info;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Sanction_Latter;
            ?>
            <tr >
                <th scope="row">
                    <form action="<?= base_url('deleteProjectInfo')?>" method="post">
                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->RInfo_id?>"></th>
                <td class="text-center"><?= $chapter->Name_Of_Project?> </td>
                <td class="text-center"><?= $chapter->Investigator_Type?> </td>
                <td class="text-center"> <?= $chapter->Name_Of_Funding_Agency?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Award?> </td>
                <td class="text-center"> <?= $chapter->Type_Funding_Aggency?> </td>
                <td class="text-center"> <?= $chapter->Satus?> </td>
                <td class="text-center"> <?= $chapter->Funds_Provided?> </td>
                <td class="text-center"> <?= $chapter->Duration_Of_Project?> </td>
                <td class="text-center"> <?= $cover->Name?> </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><input class="btn btn-danger" type="submit" value="Delete"></td> 
                      </form>
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RInfo_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RInfo_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Book And Chapter</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateBookAndChapter')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                             
                                            <label >Describe two practices institutionalized as a result of IQAC initiatives : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                            <textarea name="Describe" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                            <script>
                                                // Function to enforce the word limit on the textarea
                                                function enforceWordLimit(event) {
                                                    const wordLimit =  200; // Set your desired word limit here
                                                    const textarea = event.target;
                                                    const words = textarea.value.trim().split(/\s+/);
                                                    const remainingWords = wordLimit - words.length;
                                        
                                                    if (remainingWords < 0) {
                                                        // If the user exceeds the word limit, prevent further input
                                                        event.preventDefault();
                                                        textarea.value = words.slice(0, wordLimit).join(' ');
                                                    }
                                        
                                                    // Update the remaining words count
                                                    document.getElementById('remainingWords').textContent = remainingWords;
                                                }
                                        
                                                // Attach the event listener to the textarea
                                                const textareaElement = document.getElementById('wordLimitedTextarea');
                                                textareaElement.addEventListener('input', enforceWordLimit);
                                            </script>
                                        </div>
                                        <br>
                                        <div class="col-md-4">
                                            <label for="">Upload Relevant Document (.pdf Only) :</label>
                                            <input type="file" class="form-control" id="Relaventdoc" name="Relaventdoc" onchange="validateRelaventDoc()" accept=".pdf">
                                            <span id="RelaventdocError" style="color:red;"></span>
                                        </div>
                                        
                                        <script>
                                            function validateRelaventDoc() {
                                                const file = event.target.files[0];
                                                const errorElement = document.getElementById('RelaventdocError');
                                                if (!file.type.match('pdf')) {
                                                    errorElement.textContent = 'File is not a PDF.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                if (file.size > 500 * 1024) {
                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                // If the file is valid, clear the error message
                                                errorElement.textContent = '';
                                            }
                                        </script>





                                
                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
     </div>
    <?= $this->endSection();?>



