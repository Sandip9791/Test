<?= $this->extend('Layouts/iqacBase');?>
<?= $this->section("Content");?>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>Institution implements e-governance in its operations (6.2.2) :</h1>

            <form  class="row g-3 my-3"> 
                <div class="col-md-12">
                    <label >Description : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="Description" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement = document.getElementById('wordLimitedTextarea');
                        textareaElement.addEventListener('input', enforceWordLimit);
                    </script>
                </div>
                 <br>
                 <div class="col-md-5">
                    <label class="col-form-label pt-0">e-governance is implemented covering the following areas of operations : <label
                        style="color: red;">*</label></label>
                    <div class="container px-4">
                      <div class="row gx-5">
            
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="DST-FIST" name="Administration" id="checkbox1"
                            onclick="show()">
                          <label class="form-check-label">
                            1.	Administration including complaint management
                          </label>
                        </div>
            
            
                        <div class="form-check mt-3">
                          <input class="form-check-input" type="checkbox" name="flexRadioDefault2" id="checkbox2" onclick="show()">
                          <label class="form-check-label" for="flexRadioDefault2">
                            2.	Finance and Accounts
                          </label>
                        </div>
            
                        <div class="form-check mt-3">
                          <input class="form-check-input" type="checkbox" name="flexRadioDefault3" id="checkbox3" onclick="show()">
                          <label class="form-check-label" for="flexRadioDefault3">
                            3.	Student Admission and Support
                          </label>
                        </div>
            
                        <div class="form-check mt-3">
                          <input class="form-check-input" type="checkbox" name="flexRadioDefault4" id="checkbox4" onclick="show()">
                          <label class="form-check-label" for="flexRadioDefault4">
                            4.	Examinations
                          </label>
                        </div>
                      </div>
                    </div>
                 </div>

                        <div class="col-md-5">
                            <div class="container px-4">
                              <div class="row gx-5">
                    
                                <div class="col">
                                  <label class="form-label">Screenshots of user interface : <label style="color: red;">* (.jpg ,.jpeg ,.png)</label></label>
                                  <input type="file" class="form-control" name="Administration_photo" onchange="validateSSUI1()" accept=".jpg, .jpeg, .png" id="upload1" style="display:none;">
                                  <span id="SSUIError1" style="color: red;"></span>

                                  <input type="file" class="form-control" name="Finance_photo" onchange="validateSSUI2()" accept=".jpg, .jpeg, .png" id="upload2" style="display:none;">
                                  <span id="SSUIError2" style="color: red;"></span>

                                  <input type="file" class="form-control" name="Student_photo" onchange="validateSSUI3()" accept=".jpg, .jpeg, .png" id="upload3" style="display:none;">
                                  <span id="SSUIError3" style="color: red;"></span>

                                  <input type="file" class="form-control" name="Examinations_photo" onchange="validateSSUI4()" accept=".jpg, .jpeg, .png" id="upload4" style="display:none;">
                                  <span id="SSUIError4" style="color: red;"></span>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                        <script>
                            function show() {
                              var checkBox1 = document.getElementById("checkbox1");
                              var checkBox2 = document.getElementById("checkbox2");
                              var checkBox3 = document.getElementById("checkbox3");
                              var checkBox4 = document.getElementById("checkbox4");
                    
                              var file1 = document.getElementById("upload1");
                              var file2 = document.getElementById("upload2");
                              var file3 = document.getElementById("upload3");
                              var file4 = document.getElementById("upload4");
                    
                              if (checkBox1.checked == true) {
                                file1.style.display = "block"
                              } else {
                                file1.style.display = "none";
                              }
                    
                              if (checkBox2.checked == true) {
                                file2.style.display = "block"
                              } else {
                                file2.style.display = "none";
                              }
                    
                              if (checkBox3.checked == true) {
                                file3.style.display = "block"
                              } else {
                                file3.style.display = "none";
                              }

                              if (checkBox4.checked == true) {
                                file4.style.display = "block"
                              } else {
                                file4.style.display = "none";
                              }
                    
                    
                            }
                          </script>
                          <script>
                                function validateSSUI1() {
                                  const file = event.target.files[0];
                                  const errorElement = document.getElementById('SSUIError1');
                                  const allowedExtensions = ["jpg", "jpeg", "png"];
                                  if (!file) {
                                    errorElement.textContent = 'No file selected.';
                                    return;
                                  }
                                  const fileExtension = getFileExtension(file.name);
                                  if (!allowedExtensions.includes(fileExtension)) {
                                    errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                    event.target.value = ''; // Clear the file input
                                    return;
                                  }
                                  if (file.size > 500 * 1024) {
                                    errorElement.textContent = `File is too big. Maximum size is 500 KB.`;
                                    event.target.value = ''; // Clear the file input
                                    return;
                                  }
                                  // If the file is valid, clear the error message
                                  errorElement.textContent = '';
                                }
                                function getFileExtension(filename) {
                                return filename.split('.').pop().toLowerCase();
                                }
                          </script>
                          <script>
                              function validateSSUI2() {
                                 const file = event.target.files[0];
                                 const errorElement = document.getElementById('SSUIError2');
                                 const allowedExtensions = ["jpg", "jpeg", "png"];
                                    if (!file) {
                                      errorElement.textContent = 'No file selected.';
                                      return;
                                    }
                                    const fileExtension = getFileExtension(file.name);
                                    if (!allowedExtensions.includes(fileExtension)) {
                                       errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                       event.target.value = ''; // Clear the file input
                                       return;
                                    }
                                    if (file.size > 500 * 1024) {
                                        errorElement.textContent = `File is too big. Maximum size is 500 KB.`;
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                              }
                                function getFileExtension(filename) {
                                    return filename.split('.').pop().toLowerCase();
                                }
                           </script>
                          <script>
                            function validateSSUI3() {
                              const file = event.target.files[0];
                              const errorElement = document.getElementById('SSUIError3');
                              const allowedExtensions = ["jpg", "jpeg", "png"];
                              if (!file) {
                                errorElement.textContent = 'No file selected.';
                                return;
                              }
                              const fileExtension = getFileExtension(file.name);
                              if (!allowedExtensions.includes(fileExtension)) {
                                errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                event.target.value = ''; // Clear the file input
                                return;
                              }
                              if (file.size > 500 * 1024) {
                                errorElement.textContent = `File is too big. Maximum size is 500 KB.`;
                                event.target.value = ''; // Clear the file input
                                return;
                              }
                              // If the file is valid, clear the error message
                              errorElement.textContent = '';
                            }
                            function getFileExtension(filename) {
                            return filename.split('.').pop().toLowerCase();
                            }
                      </script>
                          <script>
                            function validateSSUI4() {
                              const file = event.target.files[0];
                              const errorElement = document.getElementById('SSUIError4');
                              const allowedExtensions = ["jpg", "jpeg", "png"];
                              if (!file) {
                                errorElement.textContent = 'No file selected.';
                                return;
                              }
                              const fileExtension = getFileExtension(file.name);
                              if (!allowedExtensions.includes(fileExtension)) {
                                errorElement.textContent = 'File is not a .jpg, .jpeg, or .png.';
                                event.target.value = ''; // Clear the file input
                                return;
                              }
                              if (file.size > 500 * 1024) {
                                errorElement.textContent = `File is too big. Maximum size is 500 KB.`;
                                event.target.value = ''; // Clear the file input
                                return;
                              }
                              // If the file is valid, clear the error message
                              errorElement.textContent = '';
                            }
                            function getFileExtension(filename) {
                            return filename.split('.').pop().toLowerCase();
                            }
                      </script>
              

                    <div class="col-md-4">
                        <label class="form-label">Upload:- </label>
                        <p style="color: red;"><b>Note:- Only .pdf </b></p> 
                        <div>
                            <label class="form-label">ERP contract document : <label style="color: red;">*</label></label>
                            <input type="file" class="form-control" name="ERPdoc" onchange="validateERPDoc()" accept=".pdf">
                            <span id="ERPdocError" style="color:red;"></span>

                            <label class="form-label">Annual e-governance report by Governing Council : <label style="color: red;">*</label></label>
                            <input type="file" class="form-control" name="ARepdoc" onchange="validateARepDoc()"  accept=".pdf">
                            <span id="ARepdocError" style="color:red;"></span>

                            <label class="form-label">Institutional expenditure statement for e-governance : <label style="color: red;">*</label></label>
                            <input type="file" class="form-control" name="IESdoc" onchange="validateIESDoc()" accept=".pdf">
                            <span id="IESdocError" style="color:red;"></span>

                            <label class="form-label">ERP developed Inhouse : <label style="color: red;">*</label></label>
                            <input type="file" class="form-control" name="ERPIdoc" onchange="validateERPIDoc()" accept=".pdf">
                            <span id="ERPIdocError" style="color:red;"></span>
                        </div>
    
                 <div class="col-12 text-center">
                   <input type="submit" class="btn btn-outline-primary">
                 </div>

                 <script>
                    function validateERPDoc() {
                      const file = event.target.files[0];
                      const errorElement = document.getElementById('ERPdocError');
                      if (!file.type.match('pdf')) {
                        errorElement.textContent = 'File is not a PDF.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      if (file.size > 500 * 1024) {
                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      // If the file is valid, clear the error message
                      errorElement.textContent = '';
                    }
                    function validateARepDoc() {
                      const file = event.target.files[0];
                      const errorElement = document.getElementById('ARepdocError');
                      if (!file.type.match('pdf')) {
                        errorElement.textContent = 'File is not a PDF.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      if (file.size > 500 * 1024) {
                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      // If the file is valid, clear the error message
                      errorElement.textContent = '';
                    }
                    function validateIESDoc() {
                      const file = event.target.files[0];
                      const errorElement = document.getElementById('IESdocError');
                      if (!file.type.match('pdf')) {
                        errorElement.textContent = 'File is not a PDF.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      if (file.size > 500 * 1024) {
                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      // If the file is valid, clear the error message
                      errorElement.textContent = '';
                    }
                    function validateERPIDoc() {
                      const file = event.target.files[0];
                      const errorElement = document.getElementById('ERPIdocError');
                      if (!file.type.match('pdf')) {
                        errorElement.textContent = 'File is not a PDF.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      if (file.size > 500 * 1024) {
                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                        event.target.value = ''; // Clear the file input
                        return;
                      }
                      // If the file is valid, clear the error message
                      errorElement.textContent = '';
                    }

                 </script>
                 
            </form>
            <?= $this->endSection();?>


