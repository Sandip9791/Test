<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#datepicker").datepicker({
           format: "yyyy",
           viewMode: "years", 
           minViewMode: "years",
           autoclose:true
        });   
      })
  </script>
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Student complaints/grievances about evaluation (2.5.2):</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_exam_2_5_2')?>" enctype="multipart/form-data">


            <div class="col-md-6">
              <label class="form-label">Number of complaints about Evaluation : <label style="color: red;">*</label></label>
              <input id="" type="number" class="form-control" name="Number_of_complaints" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Number of Students appeared in examination : <label style="color: red;">*</label></label>
              <input id="" type="number" class="form-control" name="Number_of_Students" required>
            </div>

            
            <div class="col-md-6">
                <label class="form-label"><b><h5>Document :- </h5> </b></label>
                <p style="color: red;"><b>Note:- Only .pdf </b></p> 
                <div>
                    <label class="form-label">Minutes of Grievance cell certified by Principal/COE : </label>
                    <input type="file" class="form-control" name="Minutes_of_Grievance"  accept=".pdf" required>
                </div>
            </div>
            <br>

            <div class="col-12">
                <input  type="button" class="btn-primary" value="Add More">
              </div>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="Submit">
              </div>
    </form>
  </div>
</body>
</html>