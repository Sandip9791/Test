<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
	
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>IT integration and Reforms in examination (2.5.3):</h1>
		<form class="row" method="post" action="<?= base_url('save_exam_2_5_3')?>" enctype="multipart/form-data">
        
            <div class="row-3">
                <label><b>Examination Procedure : </b><label style="color: red;">*</label></label>
                <br>
                <textarea  rows="3" cols="100" maxlength="200" name="Examination_Procedure"></textarea></b> <label style="color: red;">Limit : 200 words</label>
            </div>
           

            <div class="row-3">
                <label><b>Process Integrating IT : </b><label style="color: red;">*</label></label>
                <br>
                <textarea  rows="3" cols="100" maxlength="200" name="Process_Integrating_IT"></textarea> <label style="color: red;">Limit : 200 words</label>
            </div>


            <div class="row-3">
                <label><b>Continuous Internal Assessment System : </b><label style="color: red;">*</label></label>
                <br>
                <textarea  rows="3" cols="100" maxlength="200" name="Continuous_Internal"></textarea> <label style="color: red;">Limit : 200 words</label>
            </div>


            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="submit">
              </div>
    </form>
  </div>
</body>
</html>