<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

	
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Pass percentage of Student (Excluding Backlog) (2.6.2) :</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_exam_2_6_2')?>" enctype="multipart/form-data">

            <div class="col-md-4">
              <label class="form-label"><b>Program Code : </b><label style="color: red;">*</label></label>
              <input id="" type="number" class="form-control" name="Program_Code" required>
              </div>

            <div class="col-md-4">
                <label class="form-label"><b>Program Name : </b><label style="color: red;">*</label></label>
                <input id="" type="text" class="form-control" name="Program_Name"  required>
            </div>

            <div class="col-md-4">
              <label class="form-label"><b>Fresh Student appeared in Final Year : </b><label style="color: red;">*</label></label>
              <input id="" type="number" class="form-control" name="Fresh_Student_appeared"  required>
          </div>
  
          <div class="col-md-4">
            <label class="form-label"><b>Passed in Final Year : </b><label style="color: red;">*</label></label>
            <input id="" type="number" class="form-control" name="Passed_in_Final"  required>
        </div>

        <div class="col-md-4">
            <label class="form-label"><b>Percentage(%) of Passing : </b><label style="color: red;">*</label></label>
            <input id="" type="number" class="form-control" name="Percentage_of_Passing"  required>
        </div>

            <div class="col-md-6">
                <label class="form-label"><b><h5>Upload:-</h5> </b></label>
                <p style="color: red;"><b>Note:- .pdf </b></p> 
                <div>
                    <label class="form-label"><b>Annual report of COE highligting passed % of Final year Student : </b></label>
                    <input type="file" class="form-control" name="Annual_report"  accept=".pdf">
                    <label class="form-label"><b>Certified report from COE : </b> </label>
                    <input type="file" class="form-control" name="Certified_report"  accept=".pdf">
    
                </div>
                
            </div>
            <br>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="submit">
              </div>
    </form>
  </div>
</body>
</html>