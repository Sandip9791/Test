<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#datepicker").datepicker({
           format: "yyyy",
           viewMode: "years", 
           minViewMode: "years",
           autoclose:true
        });   
      })
  </script>
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Average number of days from the date of last semester-end/ year- end examination till the last date of declaration of results (2.5.1) :</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_exam_2_5_1')?>" enctype="multipart/form-data">

          <div class="col-md-4">
            <label for="year-of-award">Year : <label style="color: red;">*</label></label>
            <input type="number" class="form-control" name="year" id="datepicker" placeholder="yyyy" required>
          </div>

            <div class="col-md-4">
                <label class="form-label">Semester : <label style="color: red;">*</label></label>
                <input id="" type="text" class="form-control" name="semester"  required>
            </div>

            <div class="col-md-4">
              <label class="form-label">Program Name : <label style="color: red;">*</label></label>
              <input id="" type="text" class="form-control" name="program_name"  required>
          </div>
  
          <div class="col-md-4">
            <label class="form-label">Program Code : <label style="color: red;">*</label></label>
            <input id="" type="number" class="form-control" name="program_code"  required>
        </div>

            <div class="col-md-4">
              <label for="validationDefault05" class="form-label">Last Date of the semester end : <label style="color: red;">*</label></label>
              <input type="date" class="form-control" id="validationDefault05" name="last_date_sem_end" placeholder="dd-mm-yyyy" required>
          </div>

          <div class="col-md-4">
            <label for="validationDefault05" class="form-label">Date of declaration of result : <label style="color: red;">*</label></label>
            <input type="date" class="form-control" id="validationDefault05" name="date_of_dec" placeholder="dd-mm-yyyy" required>
        </div>

            <div class="col-md-6">
                <label class="form-label">Examination Time Table : </label>
                <input type="file" class="form-control" name="examination_tt"  accept=".pdf">
            </div>
                    <div class="col-md-6">
                    <label class="form-label">Result-Sheet : </label>
                    <input type="file" class="form-control" name="result_sheet"  accept=".pdf">
                    </div>

                    <div class="col-md-6">
                    <label class="form-label">Policy document on declaration of result : </label>
                    <input type="file" class="form-control" name="policy_document"  accept=".pdf">
                    </div>

                    <div class="col-md-6">
                    <label class="form-label">Report from COE mentioning name of program, end date of examination and date of annoucement of result along with number of days elapsed, for all programs  : </label>
                    <input type="file" class="form-control" name="report_from_COE"  accept=".pdf">
                </div>
                <br>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="submit">
              </div>
    </form>
  </div>
</body>
</html>