<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#datepicker").datepicker({
           format: "yyyy",
           viewMode: "years", 
           minViewMode: "years",
           autoclose:true
        });   
      })
  </script>
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Enrolment (2.1.1) :</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_office_2_1_1')?>" enctype="multipart/form-data">

            <div class="col-md-4">
              <label class="form-label"><b>Program Name : </b><label style="color: red;">*</label></label>
              <input id="" type="text" class="form-control" name="Program_Name" >
              <span style="display:none;color:red;">Please enter a valid name.</span>
            </div>

            <div class="col-md-4">
                <label class="form-label"><b>Program Code : </b><label style="color: red;">*</label></label>
                <input id="" type="text" class="form-control" name="Program_Code" >
                <span style="display:none;color:red;">Please enter a valid code.</span>
            </div>
  
            <div class="col-md-4">
                <label for="year-of-award"><b>Academic Year : </b><label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Academic_Year" id="datepicker" placeholder="yyyy">
            </div>

            <div class="col-md-4">
                <label for="year-of-award"><b>Number of Seats Sanctioned: </b><label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Seats_Sanctioned" id="" >
            </div>

            <div class="col-md-4">
              <label for="year-of-award"><b>Number of Students Admitted: </b><label style="color: red;">*</label></label>
              <input type="number" class="form-control" name="Students_Admitted" id="" >
          </div>
  
            <div class="col-md-6">
                <label class="form-label"><b><h5>Document :- </h5> </b></label>
                <p style="color: red;"><b>Note:- Only .pdf </b></p> 
                <div>
                    <label class="form-label"><b>Approval of Saction of Intake:</b></label>
                    <input type="file" class="form-control" name="Approval_of_Sanction"  accept=".pdf">
                    <label class="form-label"><b>Final Addmission List:</b> </label>
                    <input type="file" class="form-control" name="Final_Admission"  accept=".pdf">
    
                </div>
                
            </div><br>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="Submit">
              </div>
    </form>
  </div>
</body>
</html>