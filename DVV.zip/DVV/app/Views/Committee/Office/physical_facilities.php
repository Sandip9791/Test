<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Particulars</th>
      <th scope="col">Number</th>
      <th scope="col">Upload Document/Photo</th>
      <th scope="col">Upload Document/Photo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>No. of Classrooms</td>
      <td><input type="number" class="form-control"></td>
      <td><input type="file" class="form-control"></td>
      <td><input type="file" class="form-control"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>No. of Laborataries</td>
      <td><input type="number" class="form-control"></td>
      <td><input type="file" class="form-control"></td>
      <td><input type="file" class="form-control"></td>
    </tr>
    <tr>
        <th scope="row">3</th>
        <td>No. of Computers</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
      </tr>
    <tr>
        <th scope="row">4</th>
        <td>No. of Laptops</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
      </tr>
    <tr>
        <th scope="row">5</th>
        <td>No. of Printers</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
      </tr>
    <tr>
        <th scope="row">6</th>
        <td>No. of Server</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
      </tr>
    <tr>
        <th scope="row">7</th>
        <td>No. of WIFI</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">8</th>
        <td>No. of Scanners</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">9</th>
        <td>No. of Smart boards</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">10</th>
        <td>No. of Smart Classrooms</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">11</th>
        <td>No. of Projectors</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">12</th>
        <td>No. of Washrooms</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">13</th>
        <td>No. of LR</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">14</th>
        <td>Green Room</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">15</th>
        <td>Auditorium</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">16</th>
        <td>Open Theater</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">17</th>
        <td>Record Romm</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">18</th>
        <td>Yoga & Meditation Hall</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">19</th>
        <td>Gym</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">20</th>
        <td>Open Gym</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">21</th>
        <td>Fire Extinguisher </td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">22</th>
        <td>Generator</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><label>Bill Details :</label><input type="file" class="form-control" name="bill"></td>
        <td><label>AMC Details :</label><input type="file" class="form-control"></td>
      </tr>
    <tr>
        <th scope="row">23</th>
        <td>Filter Cooler</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">24</th>
        <td>Ramps</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <tr>
        <th scope="row">25</th>
        <td>Lift</td>
        <td><input type="number" class="form-control" style="display: none;"></td>
        <td><input type="file" class="form-control" ></td>
        <td><input type="file" class="form-control" style="display: none;"></td>
      </tr>
    <!-- <tr>
        <th scope="row">25</th>
        <td>No. of LR</td>
        <td><input type="number" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
        <td><input type="file" class="form-control"></td>
      </tr> -->
  </tbody>
</table>
</body>
</html>