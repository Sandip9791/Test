<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Percentage of Seats filled against reserved category for first year (2.1.2) :</h1>
	
        <form class="row g-3  my-3" method="post" action="<?= base_url('save_office_2_1_2')?>" enctype="multipart/form-data">

            <div class="col-md-12">
                <label><b>Academic Year: </b><label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Academic_Year" id="datepicker" placeholder="yyyy" required>
            </div>

            <div class="col-md-6">
                <label class="form-label"><b>Number of seats emarked for reserved category as per GOI/State Government rule :</b></label>
                <div class="input-group">
                    <label class="input-group-text" for="">SC</label>
                    <input type="number" class="form-control" id="" name="SC_emarked">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">ST</label>
                    <input type="number" class="form-control" id="" name="ST_emarked">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">OBC</label>
                    <input type="number" class="form-control" id="" name="OBC_emarked">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">GENERAL</label>
                    <input type="number" class="form-control" id="" name="GENERAL_emarked">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">Divyanjan</label>
                    <input type="number" class="form-control" id="" name="Divyanjan_emarked">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">Other</label>
                    <input type="number" class="form-control" id="" name="Other_emarked">
                </div>

            </div>
  


            <div class="col-md-6">
                <label class="form-label"><b>Number of seats admitted from the reserved category : <br></b></label>
                <div class="input-group">
                    <label class="input-group-text" for="">SC</label>
                    <input type="number" class="form-control" id="" name="SC_admitted">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">ST</label>
                    <input type="number" class="form-control" id="" name="ST_admitted">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">OBC</label>
                    <input type="number" class="form-control" id="" name="OBC_admitted">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">GENERAL</label>
                    <input type="number" class="form-control" id="" name="GENERAL_admitted">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">Divyanjan</label>
                    <input type="number" class="form-control" id="" name="Divyanjan_admitted">
                </div>

                <div class="input-group">
                    <label class="input-group-text" for="">Other</label>
                    <input type="number" class="form-control" id="" name="Other_admitted">
                </div>

            </div>


            <div class="col-md-6">
                <label class="form-label"><b><h5>Upload:-</h5> </b></label>
                <p style="color: red;"><b>Note:- .jpg </b></p> 
                <div>
                    <label class="form-label"><b>Letter issued by Government for reservation : </b></label>
                    <input type="file" class="form-control" name="Letter_issued_by_Government"  accept=".pdf">
                    <label class="form-label"><b>Final Admission List : </b> </label>
                    <input type="file" class="form-control" name="Final_Admission_List"  accept=".pdf">
    
                </div>
                
            </div><br>

           
            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="submit">
              </div>
            </form>
  </div>
</body>
</html>