<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#datepicker").datepicker({
           format: "yyyy",
           viewMode: "years", 
           minViewMode: "years",
           autoclose:true
        });   
      })
  </script>
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>(6.4.2) :</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_office_6_4_2')?>" enctype="multipart/form-data">

            <div class="col-md-4">
                <label>Academic Year :<label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Academic_Year" id="datepicker" placeholder="yyyy">
            </div>

            <div class="col-md-4">
				<label for="faculty-select">Type : <label style="color: red;">*</label></label>
				<select class="form-control" id="" name="Type" required >
					<option>--Select--</option>
					<option>Government Bodies</option>
					<option>Non-Government Bodies</option>
					<option>Non-Government Bodies</option>
				</select>
			</div>

            <!-- <div class="col-md-6 ">
                <label for="yes-no">Type :</label><br>
                <br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">Government Bodies</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">Non-Government Bodies</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" >
                    <label class="form-check-label" for="inlineRadio3">don't known</label>
                  </div>
              </div> -->

            <div class="col-md-4">
              <label>Name of government body : <label style="color: red;">*</label></label>
              <input id="" type="text" class="form-control" name="Government_body" >
              <span style="display:none;color:red;">Please enter a valid name.</span>
            </div>

            <div class="col-md-4">
                <label>Purpose of grant : <label style="color: red;">*</label></label>
                <input id="" type="text" class="form-control" name="Purpose_of_grant" >
                <span style="display:none;color:red;">Please enter a valid code.</span>
            </div>
  
            

            <div class="col-md-4">
                <label>Grants in Rs. : <label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Grants_in_Rs" id="" >
            </div>

            <div class="col-md-4">
              <label>Link to Audited Statment of Accounts reflecting receipts : <label style="color: red;">*</label></label>
              <input type="text" class="form-control" name="Link_to_Audited_Statment" id="" >
          </div>

          <br>

          <div class="col-12">
            <input type="button" value="Add More">
          </div>
  
            <br>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="Submit">
              </div>
    </form>
  </div>
</body>
</html>