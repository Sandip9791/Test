<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#datepicker").datepicker({
           format: "yyyy",
           viewMode: "years", 
           minViewMode: "years",
           autoclose:true
        });   
      })
  </script>
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>2.1 , 2.2 :</h1>
		<form class="row g-3 my-3" method="post" action="<?= base_url('save_office_2_1__2_2')?>" enctype="multipart/form-data">
 
            <label><h4>2.1) Number of full time teachers presently working in the institution : </h4></label>
            <div class="col-md-4">
              <label>Name : <label style="color: red;">*</label></label>
              <input id="" type="text" class="form-control" name="Name_p" >
              <span style="display:none;color:red;">Please enter a valid name.</span>
            </div>

            <div class="col-md-4">
                <label>ID number : <label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="ID_number_p" id="" >
            </div>

            <div class="col-md-4">
                <label>Email : <label style="color: red;">*</label></label>
                <input type="text" class="form-control" name="Email_p" >
                <span style="display:none;color:red;">Please enter a valid code.</span>
            </div>
            
            <div class="col-md-4">
                <label>Designation : <label style="color: red;">*</label></label>
                <input type="text" class="form-control" name="Designation_p" id="" >
            </div>

            <div class="col-md-4">
                <label>Date of joining:<label style="color: red;">*</label></label>
                <input type="date" class="form-control" name="Date_of_joining_p" placeholder="">
            </div>

            <br><br>

            <div class="col-12">
              <input type="button" value="Add More">
            </div>
            
            <label><h4>2.2) Number of full time teachers who left the institution during the last five years : </h4></label>
            <div class="col-md-4">
                <label>Name : <label style="color: red;">*</label></label>
                <input id="" type="text" class="form-control" name="Name_l" >
                <span style="display:none;color:red;">Please enter a valid name.</span>
              </div>
  
              <div class="col-md-4">
                  <label>ID number : <label style="color: red;">*</label></label>
                  <input type="number" class="form-control" name="ID_number_l" id="" >
              </div>
  
              <div class="col-md-4">
                  <label>Email : <label style="color: red;">*</label></label>
                  <input type="text" class="form-control" name="Email_l" >
                  <span style="display:none;color:red;">Please enter a valid code.</span>
              </div>
              
              <div class="col-md-4">
				<label for="faculty-select">Gender : <label style="color: red;">*</label></label>
				<select class="form-control" id="Gender_l" required>
					<option>--Select--</option>
					<option>Male</option>
					<option>Female</option>
				</select>
			</div>

              <div class="col-md-4">
                  <label>Designation : <label style="color: red;">*</label></label>
                  <input type="text" class="form-control" name="Designation_l" id="" >
              </div>
  
              <div class="col-md-4">
                  <label>Date of joining:<label style="color: red;">*</label></label>
                  <input type="date" class="form-control" name="Date_of_joining_l" placeholder="">
              </div>

              <div class="col-md-4">
                  <label>Date of leaving:<label style="color: red;">*</label></label>
                  <input type="date" class="form-control" name="Date_of_leaving_l" placeholder="">
              </div>
          <br>

          <div class="col-12">
            <input type="button" value="Add More">
          </div>
  
            <br>

            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="Submit">
              </div>
    </form>
  </div>
</body>
</html>