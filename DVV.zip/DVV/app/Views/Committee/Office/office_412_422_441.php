<!DOCTYPE html>
<html>
<head>
    <br>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>
  <div class="container-fluid border border-info-subtle my-4">
		<h1>Expenditure incurred on Infrastructure, Books & Physical Facilites (4.1.2) (4.2.2) (4.4.1) :</h1>
		<form class=" g-3 my-3" method="post" action="<?= base_url('save_office_412_422_441')?>" enctype="multipart/form-data">

            <div class="mx-1 row border">
                <h4>1) Infrastructure :</h4>
                <div class="col-md-4">
                    <label>Year : <label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Year_Infrastructure" id="datepicker" placeholder="yyyy" required>
                </div>
        
                <div class="col-md-6">
                    <label>Amount of Expenditure Infrastructure developement & augmentation :<label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Expenditure_Infrastructure" id="" >
                </div>

                <div class="col-md-4">
                    <label>Total Expenditure Excluding Salary : <label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Total_Expenditure" id="" >
                </div>

                <div class="col-md-4">
                    <label>Percentage : <label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Percentage_Infrastructure" id="" >
                </div>

                <div class="col-md-4">
                    <label>Upload Audited income Expenditure statement  : <label style="color: red;">*</label></label>
                    <input type="file" class="form-control" name="Audited_Infrastructure" id="" accept=".pdf">
                    <label style="color: red;"><small>Note - Signed by CA & Counter Signed by competent authority.</small></label></label>
                </div>
            </div>
                
            <br>

            <div class="mx-1 row border">
                <h4>2) Books :</h4>
            
                <div class="col-md-6">
                    <label>Amount of Expenditure Infrastructure developement & augmentation :<label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Expenditure_Books" id="" >
                </div>
    
                <div class="col-md-4">
                    <label>Percentage : <label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Percentage_Books" id="" >
                </div>
    
                <div class="col-md-4">
                    <label>Upload Audited Expenditure statement  : <label style="color: red;">*</label></label>
                    <input type="file" class="form-control" name="Audited_Books" id="" accept=".pdf">
                    <label style="color: red;"><small>Note - Signed by CA & Counter Signed by competent authority.</small></label></label>
                </div>

           </div>

        <br>
        
            <div class="mx-1 row border">
                <h4>3) Physical Facilites :</h4>

                <div class="col-md-6">
                    <label>Expenditure on maintenance of physical facilities (excluding salary for human resources) :<label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Expenditure_physical_facilities" id="" >
                </div>

                <div class="col-md-6">
                    <label>Expenditure on maintenace of academic facilities (excluding salary for human resources)  :<label style="color: red;">*</label></label>
                    <input type="number" class="form-control" name="Expenditure_academic_facilities" id="" >
                </div>

                <div class="col-md-4">
                    <label>Upload Audited Expenditure statement  : <label style="color: red;">*</label></label>
                    <input type="file" class="form-control" name="Audited_Physical_Facilites" id="" accept=".pdf">
                    <label style="color: red;"><small>Note - Signed by CA & Counter Signed by competent authority.</small></label></label>
                </div>

            </div>


            <br>
            <div class="col-12">
                <input  type="submit" class="btn btn-outline-warning" value="submit">
            </div>
        </form>
  </div>
</body>
</html>