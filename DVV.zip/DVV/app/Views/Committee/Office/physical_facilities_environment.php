<!DOCTYPE html>
<html>

<head>
  <br>
  <title></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css"
    rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
  <script
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#datepicker").datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        autoclose: true
      });
    })
  </script>

</head>

<body>
<form method="post" action="<?= base_url('save_physical_facilities_environment')?>" enctype="multipart/form-data">

  <table class="table ">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Particulars</th>
        <th scope="col">Select</th>
        <th scope="col">Upload Document/Photo</th>
        <th scope="col">Upload Document/Photo</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Solar Energy</td>
        <td>
          <input class="form-check-input" type="radio" name="Solar_Energy" id="inlineRadio1" value="Yes"
            onclick="showSolar()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Solar_Energy" id="inlineRadio1" value="No"
            onclick="hideSolar()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="Solar1" class="form-control" name="Solar1" disabled="true"></td>
        <td><input type="file" id="Solar2" class="form-control" name="Solar2" disabled="true"></td>

        <script>
          var Solar1 = document.getElementById("Solar1")
          var Solar2 = document.getElementById("Solar2")

          function showSolar() {
            Solar1.removeAttribute("disabled");
            Solar2.removeAttribute("disabled");
          }

          function hideSolar() {
            Solar1.disabled = "true";
            Solar2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Bio gas</td>
        <td><input class="form-check-input" type="radio" name="Bio_gas" id="inlineRadio1" value="Yes"
            onclick="showBio()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Bio_gas" id="inlineRadio1" value="No"
            onclick="hideBio()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="Bio1" name="Bio1" class="form-control" disabled="true"></td>
        <td><input type="file" id="Bio2" name="Bio2" class="form-control" disabled="true"></td>
        <script>
          var Bio1 = document.getElementById("Bio1")
          var Bio2 = document.getElementById("Bio2")

          function showBio() {
            Bio1.removeAttribute("disabled");
            Bio2.removeAttribute("disabled");

          }

          function hideBio() {
            Bio1.disabled = "true";
            Bio2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Wheeling to the grid</td>
        <td><input class="form-check-input" type="radio" name="Wheeling_to_the_grid" id="inlineRadio1" value="Yes"
            onclick="showWheeling()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Wheeling_to_the_grid" id="inlineRadio1" value="No"
            onclick="hideWheeling()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="Wheeling1" name="Wheeling1" class="form-control" disabled="true"></td>
        <td><input type="file" id="Wheeling2" name="Wheeling2" class="form-control" disabled="true"></td>
        <script>
          var Wheeling1 = document.getElementById("Wheeling1")
          var Wheeling2 = document.getElementById("Wheeling2")

          function showWheeling() {
            Wheeling1.removeAttribute("disabled");
            Wheeling2.removeAttribute("disabled");

          }

          function hideWheeling() {
            Wheeling1.disabled = "true";
            Wheeling2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Sensor based energy conservation</td>
        <td><input class="form-check-input" type="radio" name="Sensor_based_energy_conservation" id="inlineRadio1" value="Yes"
            onclick="showSensor()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Sensor_based_energy_conservation" id="inlineRadio1" value="No"
            onclick="hideSensor()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="Sensor1" name="Sensor1" class="form-control" disabled="true"></td>
        <td><input type="file" id="Sensor2" name="Sensor2" class="form-control" disabled="true"></td>
        <script>
          var Sensor1 = document.getElementById("Sensor1")
          var Sensor2 = document.getElementById("Sensor2")

          function showSensor() {
            Sensor1.removeAttribute("disabled");
            Sensor2.removeAttribute("disabled");

          }

          function hideSensor() {
            Sensor1.disabled = "true";
            Sensor2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Use of LED bulbs/power efficient equipment</td>
        <td><input class="form-check-input" type="radio" name="Use_of_LED_bulbs" id="inlineRadio1" value="Yes"
            onclick="showLED()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Use_of_LED_bulbs" id="inlineRadio1" value="No"
            onclick="hideLED()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="LED1" name="LED1" class="form-control" disabled="true"></td>
        <td><input type="file" id="LED2" name="LED2" class="form-control" disabled="true"></td>
        <script>
          var LED1 = document.getElementById("LED1")
          var LED2 = document.getElementById("LED2")

          function showLED() {
            LED1.removeAttribute("disabled");
            LED2.removeAttribute("disabled");

          }

          function hideLED() {
            LED1.disabled = "true";
            LED2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Wind mill</td>
        <td><input class="form-check-input" type="radio" name="Wind_mill" id="inlineRadio1" value="Yes"
            onclick="showWind()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Wind_mill" id="inlineRadio1" value="No"
            onclick="hideWind()">
          <label class="form-check-label" for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="Wind1" name="Wind1" class="form-control" disabled="true"></td>
        <td><input type="file" id="Wind2" name="Wind2" class="form-control" disabled="true"></td>
        <script>
          var Wind1 = document.getElementById("Wind1")
          var Wind2 = document.getElementById("Wind2")

          function showWind() {
            Wind1.removeAttribute("disabled");
            Wind2.removeAttribute("disabled");

          }

          function hideWind() {
            Wind1.disabled = "true";
            Wind2.disabled = "true";
          }
        </script>
      </tr>
      <tr>
        <th scope="row">1</th>
        <td>Any other clean green energy</td>
        <td><input class="form-check-input" type="radio" name="Any_other" id="inlineRadio1" value="option1"
            onclick="showOther()">
          <label class="form-check-label" for="inlineRadio1">Yes</label><br>
          <input class="form-check-input" type="radio" name="Any_other" id="inlineRadio1" value="option1"
            onclick="hideOther()">
          <label class="form-check-label " for="inlineRadio1">No</label>
        </td>
        <td><input type="file" id="other1" name="other1" class="form-control" disabled="true"></td>
        <td><input type="file" id="other2" name="other2" class="form-control" disabled="true"></td>
        <script>
          var other1 = document.getElementById("other1")
          var other2 = document.getElementById("other2")

          function showOther() {
            other1.removeAttribute("disabled");
            other2.removeAttribute("disabled");

          }

          function hideOther() {
            other1.disabled = "true";
            other2.disabled = "true";
          }
        </script>
      </tr>
    </tbody>
  </table>

  <div>
      <input type="submit" class="btn btn-outline-warning" value="submit" cente>
  </div>
</form>
</body>

</html>