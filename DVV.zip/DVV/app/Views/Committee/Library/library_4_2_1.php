<!DOCTYPE html>
<html>
<head>
    <br>
	<title>4.2.1</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>
<div class="img-fluid">
        <img src="p1.png" style="width:100%;background-color: #034568;">
</div>

<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                  
                 
                </ul>

                <form class="d-flex" method="Post" action="logout.php">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  session_start(); 
                   $myusername=$_SESSION['committee_user']; echo $myusername ;?></label>
                    <input type="submit" value="Logout" class="btn btn-outline-danger">
                </form>
            </div>
        </div>
    </nav>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>Library is automated with digital facilities using Integrated Library Management System (ILMS), adequate subscriptions to e-resources and journals are made.  The library is optimally used by the faculty and students (4.2.1) :</h1>
        <div class="row g-3 my-3">
            <form method="post" action="<?= base_url('save_library_4_2_1')?>" enctype="multipart/form-data"> 
                <div class="col-md-12">
                    <label >Describe : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="Describe" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement1 = document.getElementById('wordLimitedTextarea');
                        textareaElement1.addEventListener('input', enforceWordLimit);
                    </script>
                </div>
                 <br>

                <div class="col-md-6">
                    <label class="form-label"><b><h5>Upload :-</h5> </b></label>
                    <p style="color: red;"><b>Note:- .pdf </b></p> 
                      <div>
                        <label class="form-label">Library is automated with digital facilities using Integrated Library Management System (ILMS) : </label>
                        <input type="file" class="form-control" name="Automated_with_digital"  accept=".pdf">
                      </div>
                    <br>
                    
                      <div>
                        <label class="form-label">Library is having adequate subscriptions to e-resources and journals : </label>
                        <input type="file" class="form-control" name="Adequate_subscriptions"  accept=".pdf">
                      </div>
                    <br>
            
                      <div >
                        <label class="form-label">Library is optimally used by the faculty and students : </label>
                        <div >
                            <label for="">Footfall of Teachers :</label>
                            <input type="file" class="form-control" name="Footfall_of_Teachers">
                         </div>
                         <div>
                            <label for="">Footfall of Students :</label>
                            <input type="file" class="form-control" name="Footfall_of_Students">
                         </div>
                      </div>
                
            
                    </div>
                    <br>
                    <div class="col-12 text-center">
                        <input type="submit" class="btn btn-outline-primary">
                      </div>
            </form>
        </div> 
	</div>
</body>
</html>



