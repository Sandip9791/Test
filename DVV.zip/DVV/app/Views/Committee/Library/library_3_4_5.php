<!DOCTYPE html>
<html>
<head>
    <br>
	<title>3.4.5</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>Bibliometrics of the publications based on average Citation index in Scopus/ Web of Science (3.4.5) :</h1>
        <form class="row g-3 my-3" method="post" action="<?= base_url('save_library_3_4_5')?>" enctype="multipart/form-data">

          <div class="col-md-4">
            <label for="year-of-award">Year : <label style="color: red;">*</label></label>
            <input type="number" class="form-control" name="Year" id="datepicker" placeholder="yyyy" required>
          </div>


      <div class="col-md-12">
          <div class="row gx-1">


            <div class="col">
              <label class="form-label">Total no. of Citations in Scopus : <label style="color: red;">*</label></label>
              <input type="number" class="form-control" name="Citations_in_Scopus"  id="" >
            </div>

            <div class="col">
                <label class="form-label">Total no. of Citations in Web of Science :<label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Citations_in_Web_of_Science"  id="" >
            </div>

            <div class="col">
                <label class="form-label">Total no. of Publications in Scopus :<label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Publications_in_Scopus"  id="" >
            </div>


            <div class="col">
                <label class="form-label">Total no. of Publications in Web of Science:<label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Publications_in_Web_of_Science"  id="" >
            </div>            
            
        </div>
      </div>

      <div class="col-md-5">
        <label for="">Average Citation index in Scopus/ Web of Science : </label><br/>
        <input type="text" class="form-control" name="Average_Citation_index">
      </div>


      <div class="col-md-3">
        <label for="validationTooltipUsername" class="form-label">Email ID : </label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="validationTooltipUsernamePrepend">@</span>
          <input type="text" name="Email_ID" class="form-control" id="validationTooltipUsername" aria-describedby="validationTooltipUsernamePrepend" required>
          <div class="invalid-tooltip">
            Please choose a unique and valid username.
          </div>
        </div>
      </div>
      
      <br>

      <div class="col-12">
        <input type="submit" class="btn btn-outline-warning" value="Submit">
      </div>
      
        </form>
    </div>
</body>
</html>
