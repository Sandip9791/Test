<!DOCTYPE html>
<html>
<head>
    <br>
	<title>3.4.6</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
	
</head>
<body>

    <div class="container-fluid border border-info-subtle my-4">
        <h1>Bibliometrics of the publications based on Scopus/ Web of Science – h-index of the Institution (3.4.6) :</h1>
        <form class="row g-3 my-3" method="post" action="<?= base_url('save_library_3_4_6')?>" enctype="multipart/form-data">

              <div class="col-md-4">
                <label for="year-of-award">Year : <label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="Year" id="datepicker" placeholder="yyyy" required>
              </div>
    

            <div class="col-md-4">
              <label class="form-label">h-index scopus : <label style="color: red;">*</label></label>
              <input type="number" class="form-control" name="h_index_scopus" id="" >
            </div>

            <div class="col-md-4">
                <label class="form-label">h-index Web of Science :<label style="color: red;">*</label></label>
                <input type="number" class="form-control" name="h_index_Web_of_Science"  id="" >
            </div>

            <div class="col-md-4">
              <label for="">Calculate : </label><br/>
              <input type="text" class="form-control" name="Calculate">
            </div>
            <br>

      <div class="col-12">
        <input type="submit" class="btn btn-outline-warning" value="Submit">
      </div>
      
        </form>
    </div>
</body>
</html>
