<!DOCTYPE html>
<html>
<head>
	<title> IQAC Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

    <link rel="stylesheet" href="<?= base_url('assets/css/hodDashboard.css')?>">
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        }) 
    </script>

</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
      
    
    
    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html"></a>
                    </li>
                    <li class="nav-item dropdown">
                    </li>
                </ul>
                

                <form class="d-flex" method="Post" action="<?= base_url('iqacLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('committee_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
           </div>
       </div>
   </nav>
   
    <h1 style="margin-top:10px; margin-bottom:10px; text-align:center;">Committee Dashboard</h1>
    <div class="container">
    <div class="section1">
			<div class="section1a mt-1">
                <h3>&nbsp; Profile</h3>
            </div>

                <?php if(isset($documents)):
                    foreach($documents as $doc):
                      
                        $title=$doc->Title;
                        $fname=$doc->First_Name;
                        $lname=$doc->Last_Name;
                        $mname=$doc->Midd_Name;
                
                        $Name = $title." ".$fname." ".$mname." ".$lname;
                        
                ?>
			<div class="section1b">
                <img src="<?= base_url("assets\images\profile\pro.png");?>" alt="profile" class="profilr_pic"><br>
                <h6><b>Name :&nbsp;</b><?= $Name?></h6>
                <h6><b>Designation :&nbsp;</b><?= $doc->Designation?></h6>
                <h6><b>Teacher Type :&nbsp;</b><?= $doc->Teacher_Type?></h6>
                <h6><b>Email :&nbsp;</b><?= $doc->Email?></h6>
                <h6><b>Department :&nbsp;</b><?= $doc->Department?></h6>
                </h6>
                <h6><b>Name of the College / Institute : </b>
                    Progressive Education Society's
                    Modern College Of Arts, Science & Commerce
                    Ganeshkhind,Pune-16.
                </h6>
            </div>
		</div>

		<div class="section2">
			<div class="section2a  pt-3">
                <h3>&nbsp; Important links:</h3>
            </div>
			<br>
        </div>
	</div>
<?php endforeach;?>
<?php endif;?>
</body>
</html>