<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>


<h1 class="text-center my-3">Books and Chapter </h1>
    <div class="container-fluid border border-primary my-4" style="display:none;" id="bookAndChapter">
        <form class="row g-3 my-3" id="dynamic-form" action="<?= base_url('saveBookAndChapter')?>" method="post"
            enctype="multipart/form-data">
            <div  id="form-container" >

                <div class="form-fields">
                    
                    <div class="row mx-2 pt-3 pb-3 border border-2">
                    <div class="col-md-4 my-3">
                            <label class="form-label">Title of the Book Published : <label style="color: red;">*</label></label>
                            <input id="bookPub" type="text" class="form-control" name="bookPub" autocomplete="off" oninput="validatebookPub()" required>
                            <span id="bookPubError" style="display:none;color:red;">Please enter a valid title.</span>
                        </div>
    
                        <div class="col-md-4 my-3">
                            <label class="form-label">Title of the Chapter : <label style="color: red;">*</label></label>
                            <input id="Tchapter" type="text" class="form-control" name="Tchapter" autocomplete="off" oninput="validateTchapter()" required>
                            <span id="TchapterError" style="display:none;color:red;">Please enter a valid name.</span>
                        </div>
    
                        <div class="col-md-4 my-3">
                            <label class="form-label" for="year-of-award">Year of Publication : <label style="color: red;">*</label></label>
                            <input type="year" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" maxlength="4" autocomplete="off" required>
                            <span id="error-message" style="color: red; display: none;"></span>
                        </div>
                        <script>
                        $(document).ready(function() {
                            var currentYear = new Date().getFullYear(); // Get the current year

                            $("#datepicker").datepicker({
                                format: "yyyy",
                                viewMode: "years",
                                minViewMode: "years",
                                startDate: "2020",
                                endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                autoclose: true
                            });

                            // Add an input event handler to validate numeric input
                            $("#datepicker").on("input", function() {
                                var inputValue = $(this).val();
                                var numericValue = parseInt(inputValue);
                                
                                if (isNaN(numericValue)) {
                                    $(this).val(""); // Clear the input
                                }
                            });
                        });
                    </script>
     
                        <div class="col-md-4 my-3">
                            <label class="form-label" for="year-of-award">ISBN Number : <label style="color: red;">*</label></label>
                            <input id="isbnnumber" type="text" class="form-control" name="ISBN" minlength="10" maxlength="13" autocomplete="off" required>
                            <span id="isbnError" style="display:none;color:red;">Please enter a valid ISBN number.</span>
                        </div>
    
                        <div class="col-md-4 my-3">
                            <label class="form-label">Name of the Publisher : <label style="color: red;">*</label></label>
                            <input id="npublisher" type="text" class="form-control" name="npublisher" autocomplete="off" oninput="validatenpublisher()" required>
                            <span id="npublisherError" style="display:none;color:red;">Please enter a valid name.</span>
                        </div>
                        
                        <div class="col-md-4 my-3">
                            <label class="form-label" for="reason">Whether at the time of Publication affiliating Institute was same : <label style="color: red;">*</label></label>
                            <select id="reason" name="Institute"  class="form-control">
                                <option disabled selected hidden>--- Select one ---</option>
                                <option  value="Yes" >Yes</option>
                                <option  value="No" >No</option>
                            </select>
                        </div>
                        
 
                        <p class="my-3"style="color: red;"><strong>Note:- ISBN no. and year should be visible. (Select only .jpg, .jpeg .png under 500kb) </strong></p>

                        <div class="col-md-4 my-3">
                            <label class="form-label">Cover Page: <label style="color: red;"> *</label></label>
                            <input id="Cover_document" type="file" class="form-control" name="Cover_document" accept=".jpg,.jpeg,.png" oninput="validateCoverDoc(event)">
                            <span id="coverdocError" style="color:red;"></span>
                        </div>

                        <div class="col-md-4 my-3">
                            <label class="form-label">Content Page: <label style="color: red;"> *</label></label>
                            <input id="Content_document" type="file" class="form-control" name="Content_document" accept=".jpg,.jpeg,.png" oninput="validateContentDoc(event)">
                            <span id="contentdocError" style="color:red;"></span>
                        </div>

                        <div class="col-md-4 my-3">
                            <label class="form-label">First Page: <label style="color: red;"> *</label></label>
                            <input id="First_document" type="file" class="form-control" name="First_document" accept=".jpg,.jpeg,.png" oninput="validateFirstDoc(event)">
                            <span id="firstdocError" style="color:red;"></span>
                        </div>
                        <div class="col-md-4 my-3">
                            <label class="form-label">Back Page: <label style="color: red;"> *</label></label>
                            <input id="Back_document" type="file" class="form-control" name="Back_document" accept=".jpg,.jpeg,.png" oninput="validateFirstDoc(event)">
                            <span id="backdocError" style="color:red;"></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
        </form>

    </div>
 </div>

 <div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>


 <div class="container-fluid pt-1 pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Title of the Book Published</th>
                <th scope="col">Title of the Chapter</th>
                <th scope="col">Year Of Publication</th>
                <th scope="col">ISBN Number</th>
                <th scope="col">Name of the Publisher</th>
                <th scope="col">Publication affiliating Institute was same</th>
                <th scope="col">Cover page</th>
                <th scope="col">Content page</th>
                <th scope="col">First page</th>
                <th scope="col">Back page</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->BookAndChapter;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Cover_Page;
                $content = $chapter->Content_Page;
                $firstPage= $chapter->First_Page;
                $backPage = $chapter->Back_Page;
            ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++;?></th>
                <td class="text-center"><?= $chapter->Book_Published?></td>
                <td class="text-center"><?= $chapter->Title_Of_The_Chapter?></td>
                <td class="text-center"><?= $chapter->Year_Of_Publication?></td>
                <td class="text-center"><?= $chapter->ISBN_Number?></td>
                <td class="text-center"><?= $chapter->Name_Of_The_Publisher?></td>
                <td class="text-center"><?= $chapter->Time_Of_Publication?></td>
                <td class="text-center">
                     <?php if(!empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center">
                    <?php if(!empty($content)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$content;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center">
                    <?php if(!empty($firstPage)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$firstPage;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
                <td class="text-center">
                    <?php if(!empty($backPage)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$backPage;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" >
                     <form action="<?= base_url('deleteBookChapter')?>" method="post">
                        <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->BookAndChapter_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                 <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->BookAndChapter_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->BookAndChapter_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Book And Chapter</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateBookAndChapter')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                <div class="md-4" style="display:none;">
                                        <label class="form-label">Book And Chapter id : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->BookAndChapter_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>
                                    
                                    <div class="md-4 my-3">
                                        <label class="form-label">Title of the Book Published : <label style="color: red;">*</label></label>
                                        <input id="bookPub1<?= $chapter->BookAndChapter_id?>" type="text" class="form-control" name="bookPub" value="<?= $chapter->Book_Published?>" autocomplete="off" oninput="validatebookPub1<?= $chapter->BookAndChapter_id?>()" >
                                        <span id="bookPubError1<?= $chapter->BookAndChapter_id?>" style="display:none;color:red;">Please enter a valid title.</span>
                                    </div><br>

                                    <script>
                                        function validatebookPub1<?= $chapter->BookAndChapter_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('bookPub1<?= $chapter->BookAndChapter_id?>').value;
                                            var error = document.getElementById("bookPubError1<?= $chapter->BookAndChapter_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalbookPub1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('bookPub1<?= $chapter->BookAndChapter_id?>').value = finalbookPub1;
                                        
                                            if (finalbookPub1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalbookPub1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>
                
                                    <div class="md-4 my-3">
                                        <label class="form-label">Title of the Chapter : <label style="color: red;">*</label></label>
                                        <input id="Tchapter1<?= $chapter->BookAndChapter_id?>" type="text" class="form-control" name="Tchapter" value="<?= $chapter->Title_Of_The_Chapter?>" autocomplete="off" oninput="validateTchapter1<?= $chapter->BookAndChapter_id?>()" >
                                        <span id="TchapterError1<?= $chapter->BookAndChapter_id?>" style="display:none;color:red;">Please enter a valid name.</span>
                                    </div><br>

                                    <script>
                                        function validateTchapter1<?= $chapter->BookAndChapter_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('Tchapter1<?= $chapter->BookAndChapter_id?>').value;
                                            var error = document.getElementById("TchapterError1<?= $chapter->BookAndChapter_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalTchapter1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('Tchapter1<?= $chapter->BookAndChapter_id?>').value = finalTchapter1;
                                        
                                            if (finalTchapter1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalTchapter1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                    <div class="md-4 my-3">
                                        <label class="form-label" for="year-of-award">Year of Publication : <label style="color: red;">*</label></label>
                                        <input  type="text" class="form-control " name="datepicker" id="datepicker1<?= $chapter->BookAndChapter_id?>" value="<?= $chapter->Year_Of_Publication?>" maxlength="4" autocomplete="off"  placeholder="yyyy">
                                        <span id="error-message1<?= $chapter->BookAndChapter_id?>" style="color: red; display: none;"></span>
                                    </div><br>

                                    <script>
                                        $(document).ready(function() {
                                            var currentYear = new Date().getFullYear(); // Get the current year

                                            $("#datepicker1<?= $chapter->BookAndChapter_id?>").datepicker({
                                                format: "yyyy",
                                                viewMode: "years",
                                                minViewMode: "years",
                                                startDate: "2020",
                                                endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                                autoclose: true
                                            });

                                            // Add an input event handler to validate numeric input
                                            $("#datepicker1<?= $chapter->BookAndChapter_id?>").on("input", function() {
                                                var inputValue = $(this).val();
                                                var numericValue = parseInt(inputValue);
                                                
                                                if (isNaN(numericValue)) {
                                                    $(this).val(""); // Clear the input
                                                }
                                            });
                                        });
                                    </script>

                                    <div class="md-4 my-3">
                                        <label class="form-label" for="year-of-award">ISBN Number : <label style="color: red;">*</label></label>
                                        <input id="isbnnumber1<?= $chapter->BookAndChapter_id?>" type="text" class="form-control" name="ISBN" value="<?= $chapter->ISBN_Number?>" minlength="10" maxlength="13" autocomplete="off" >
                                        <span id="isbnError1<?= $chapter->BookAndChapter_id?>" style="display:none;color:red;">Please enter a valid ISBN number.</span>
                                    </div>

                                    <script>
                                        document.addEventListener('DOMContentLoaded', function() {
                                            var isbnInput = document.getElementById('isbnnumber1<?= $chapter->BookAndChapter_id?>');
                                            var errorElement = document.getElementById('isbnError1<?= $chapter->BookAndChapter_id?>');

                                            isbnInput.addEventListener('input', function(event) {
                                                var inputValue = event.target.value;
                                                var digitsOnly = inputValue.replace(/\D/g, ''); // Remove non-digit characters
                                                event.target.value = digitsOnly; // Update the input value

                                                validateISBN();
                                            });

                                            function validateISBN() {
                                                var isbnPattern = /^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$/;
                                                var isbnInputValue = isbnInput.value;

                                                if (isbnPattern.test(isbnInputValue)) {
                                                    errorElement.textContent = '';
                                                    errorElement.style.display = 'none';
                                                } else {
                                                    errorElement.textContent = 'Please enter a valid ISBN number.';
                                                    errorElement.style.display = 'block';
                                                }
                                            }
                                        });
                                    </script>


                                    <div class="md-4 my-3">
                                        <label class="form-label">Name of the Publisher : <label style="color: red;">*</label></label>
                                        <input id="npublisher1<?= $chapter->BookAndChapter_id?>" type="text" class="form-control" name="npublisher" value="<?= $chapter->Name_Of_The_Publisher?>" autocomplete="off" oninput="validatenpublisher1<?= $chapter->BookAndChapter_id?>()" >
                                        <span id="npublisherError1<?= $chapter->BookAndChapter_id?>" style="display:none;color:red;">Please enter a valid name.</span>
                                    </div> 

                                    <script>
                                        function validatenpublisher1<?= $chapter->BookAndChapter_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('npublisher1<?= $chapter->BookAndChapter_id?>').value;
                                            var error = document.getElementById("npublisherError1<?= $chapter->BookAndChapter_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalnpublisher1= capitalizedWords.join(" ");
                                            
                                            document.getElementById('npublisher1<?= $chapter->BookAndChapter_id?>').value = finalnpublisher1;
                                        
                                            if (finalnpublisher1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalnpublisher1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                    <div class="md-4 my-3">
                                        <label class="form-label" for="reason">Whether at the time of Publication affiliating Institute was same : <label style="color: red;">*</label></label>
                                        <select id="reason<?= $chapter->BookAndChapter_id?>" name="Institute"  class="form-control">
                                            <option value="<?= $chapter->Time_Of_Publication?>" ><?= $chapter->Time_Of_Publication?></option>
                                            <option  value="Yes" >Yes</option>
                                            <option  value="No" >No</option>
                                        </select>
                                    </div>

                                    <p class="my-3" style="color: red;"><strong>Note:- ISBN no. and year should be visible. (Select only .jpg, .jpeg .png under 500kb) </strong></p>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Cover Page: <label style="color: red;"> *</label></label>
                                        <input id="Cover_document1<?= $chapter->BookAndChapter_id?>" type="file" class="form-control"  name="Cover_document" accept=".jpg,.jpeg,.png" oninput="validateCoverDoc1<?= $chapter->BookAndChapter_id?>(event)">
                                        <span id="coverdocError1<?= $chapter->BookAndChapter_id?>" style="color:red;"></span>
                                    </div><br>

                                    <script>
                                        function validateCoverDoc1<?= $chapter->BookAndChapter_id?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('coverdocError1<?= $chapter->BookAndChapter_id?>');

                                            const maxSizeKB = 500; // Maximum file size in KB
                                            if (file.size > maxSizeKB * 1024) {
                                                errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }

                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }
                                    </script>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Content Page: <label style="color: red;"> *</label></label>
                                        <input id="Content_document1<?= $chapter->BookAndChapter_id?>" type="file" class="form-control" name="Content_document" accept=".jpg,.jpeg,.png" oninput="validateContentDoc1<?= $chapter->BookAndChapter_id?>(event)">
                                        <span id="contentdocError1<?= $chapter->BookAndChapter_id?>" style="color:red;"></span>
                                    </div><br>

                                    <script>
                                        function validateContentDoc1<?= $chapter->BookAndChapter_id?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('contentdocError1<?= $chapter->BookAndChapter_id?>');

                                            const maxSizeKB = 500; // Maximum file size in KB
                                            if (file.size > maxSizeKB * 1024) {
                                                errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }

                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }
                                    </script>

                                    <div class="md-4 my-3">
                                        <label class="form-label">First Page: <label style="color: red;"> *</label></label>
                                        <input id="First_document1<?= $chapter->BookAndChapter_id?>" type="file" class="form-control" name="First_document" accept=".jpg,.jpeg,.png" oninput="validateFirstDoc1<?= $chapter->BookAndChapter_id?>(event)">
                                        <span id="firstdocError1<?= $chapter->BookAndChapter_id?>" style="color:red;"></span>
                                    </div><br>
                                    
                                    <script>
                                        function validateFirstDoc1<?= $chapter->BookAndChapter_id?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('firstdocError1<?= $chapter->BookAndChapter_id?>');

                                            const maxSizeKB = 500; // Maximum file size in KB
                                            if (file.size > maxSizeKB * 1024) {
                                                errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }

                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }
                                    </script>

                                </div>
                                <div class="md-4 my-3">
                                    <label class="form-label">Back Page: <label style="color: red;"> *</label></label>
                                    <input id="Back_document" type="file" class="form-control" name="Back_document" accept=".jpg,.jpeg,.png" oninput="validateFirstDoc(event)">
                                    <span id="backdocError" style="color:red;"></span>
                                </div>
                                <script>
                                        function validateFirstDoc1<?= $chapter->BookAndChapter_id?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('backdocError1<?= $chapter->BookAndChapter_id?>');

                                            const maxSizeKB = 500; // Maximum file size in KB
                                            if (file.size > maxSizeKB * 1024) {
                                                errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }

                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }
                                    </script>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('bookAndChapter');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>
   
<script src="<?php echo base_url('assets/js/Reaserch_Details/booksAndChapter_vew.js'); ?>"></script>
      
<?= $this->endSection();?>