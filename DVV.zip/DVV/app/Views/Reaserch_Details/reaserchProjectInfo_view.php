<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center">Research Project Information  </h1>
    <div class="container-fluid border border-primary my-4" style="display:none" id="reaserchProjectInfo">
        <form class="row g-3 my-3" action="<?= base_url('saveProjectInfo')?>" method="post" enctype="multipart/form-data">
      
                    
        <div class="row mx-2 pt-3 pb-3 border border-2" >
        <div class="col-md-4">
                    <label class="form-label">Name of Project : <label style="color: red;">*</label></label>
                    <input type="text" class="form-control" id="projectname" name="pname" placeholder="Enter Project name" autocomplete="off" oninput="validateProjectName()" required>
                    <span id="projectnameError" style="display:none;color:red;">Please Enter Valid Project Name.</span>
            </div>

            <div class="col-md-4">
                <label class="form-label" for="reason">Investigator Type : <label style="color: red;">*</label></label>
                <select id="reason" name="IT" class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option value="Principal Investigator">Principal Investigator</option>
                    <option value="Co-Investigator">  Co-Investigator</option>
                </select>
            </div>

        
            <div class="col-md-4">
                <label class="form-label">Name of Funding Agency : <label style="color: red;">*</label></label>
                <input type="text" class="form-control" id="fundingname" name="agency1" placeholder="Enter Agency name" autocomplete="off" oninput="validateFundingName()" required>
                <span id="fundingnameError" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
            </div>
            
            <br><br><br><br>

            <div class="col-md-4" id="year1" style="display:block;">
                <label class="form-label">Year of Award : <label style="color: red;">* (Sanction Year of the Project)</label></label>
                <input type="text" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" autocomplete="off" maxlength="4" required>
                <span id="error-message" style="color: red; display: none;">Please enter a valid Year.</span>
            </div>
            <script>
                $(document).ready(function() {
                    var currentYear = new Date().getFullYear(); // Get the current year

                    $("#datepicker").datepicker({
                        format: "yyyy",
                        viewMode: "years",
                        minViewMode: "years",
                        startDate: "1992",
                        endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                        autoclose: true
                    });

                    // Add an input event handler to validate numeric input
                    $("#datepicker").on("input", function() {
                        var inputValue = $(this).val();
                        var numericValue = parseInt(inputValue);
                        
                        if (isNaN(numericValue)) {
                            $(this).val(""); // Clear the input
                        }
                    });
                });
            </script>
             
            
            <div class="col-md-4">
                <label class="form-label" for="reason">Type of Funding Agency :  <label style="color: red;">*</label></label>
                <select id="Funding" onclick="showOther()" name="typeAgency" class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option value="Government">Government</option>
                    <option value="Non-Government">Non-Government</option>
                    <option value="International Bodies"> International Bodies</option>
                    <option value="Other">Other</option>
                </select>

                <script>
                    function showOther() {
                        var type = document.getElementById("Funding");
                            if (type.value == "Other") 
                            {
                                document.getElementById("other").style.display="block";
                            }
                            else 
                            {
                                document.getElementById("other").style.display="none";
                            } 
                        }
                </script>
            </div>
            <div class="col-md-4" id="other" style="display:none;">
                    <label class="form-label">Other : <label style="color: red;">*</label></label>
                    <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOther()">
                    <span id="otherErrror" style="display:none;color:red;"></span>
                </div>
            
            <div class="col-md-4">
                <label class="form-label" for="reason">Status :  <label style="color: red;">*</label></label>
                <select id="reason" name="status" class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Complete">Complete</option>
                </select>
            </div>

            <br><br><br><br>

            <div class="col-md-4">
                <label class="form-label">Funds Provided in INR : <span style="color: red;">* (Total amount in Lakhs)</span></label>
                <input type="text" class="form-control" id="funds-id" name="funds" placeholder="Enter Funds" min="100000" max="10000000" autocomplete="off" maxlength="7" required>
                <span id="FundError" style="color: red;"></span>
            </div>
            
            <div class="col-md-4">
            <label class="form-label">Duration of Project : <label style="color: red;">* (in Years Only)</label></label>
                <input type="text" class="form-control" id="duration-id" name="DP" value="" placeholder="Enter Duration" min="1" max="5" autocomplete="off" maxlength="1" required>
                <span class="durationError" style="color: red; display: none;">Please enter a valid year between 1 and 5.</span>
            </div>

            <div class="col-md-4">
                <label class="form-label" for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
                <input id="sanctiondocument" type="file" class="form-control" name="sletter" accept=".pdf" onchange="validateSanction(event)" required>
                <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
            </div>     
          </div>

            <div class="col-12 text-center">
                        <input type="submit" class="btn btn-outline-primary" value="Submit">
            </div>
        </form>
    </div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Name of Project</th>
                <th scope="col">Investigator Type</th>
                <th scope="col">Name of Funding Agency</th>
                <th scope="col">Year of Award</th>
                <th scope="col">Type of Funding Agency</th>
                <th scope="col">Status</th>
                <th scope="col">Funds Provided in INR</th>
                <th scope="col">Duration of Project</th>
                <th scope="col">Sanction Letter</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->Reaserch_Project_Info;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Sanction_Latter;
            ?>
            <tr >
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Name_Of_Project?> </td>
                <td class="text-center"><?= $chapter->Investigator_Type?> </td>
                <td class="text-center"> <?= $chapter->Name_Of_Funding_Agency?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Award?> </td>
                <td class="text-center"> <?= $chapter->Type_Funding_Aggency?> </td>
                <td class="text-center"> <?= $chapter->Satus?> </td>
                <td class="text-center"> <?= $chapter->Funds_Provided?> </td>
                <td class="text-center"> <?= $chapter->Duration_Of_Project?> </td>
                <td class="text-center"> 
                    <?php if( !empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" >
                   <form action="<?= base_url('deleteProjectInfo')?>" method="post">
                        <input type="text"  style="display:none;" name="srnumber" readonly value="<?= $chapter->RInfo_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                   </form>
                </td> 
                      
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RInfo_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RInfo_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateProjectInfo')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">RInfo id <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RInfo_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div><br>

                                    <div class="md-4">
                                        <label class="form-label">Name of Project : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" id="projectname1<?= $chapter->RInfo_id?>" name="pname" value="<?= $chapter->Name_Of_Project?>" placeholder="Enter Project name" autocomplete="off" oninput="validateProjectName1<?= $chapter->RInfo_id?>()" >
                                        <span id="projectnameError1<?= $chapter->RInfo_id?>" style="display:none;color:red;">Please Enter Valid Project Name.</span>
                                    </div>
                                    <script>
                                       function validateProjectName1<?= $chapter->RInfo_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('projectname1<?= $chapter->RInfo_id?>').value;
                                            var error = document.getElementById("projectnameError1<?= $chapter->RInfo_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalprojectname = capitalizedWords.join(" ");
                                            
                                            document.getElementById('projectname1<?= $chapter->RInfo_id?>').value = finalprojectname;
                                        
                                            if (finalprojectname.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalprojectname)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }

                                    </script>

                                    <div class="md-4">
                                        <label class="form-label" for="reason">Investigator Type : <label style="color: red;">*</label></label>
                                        <select id="reason" name="IT" class="form-control">
                                            <option value="<?= $chapter->Investigator_Type?>"><?= $chapter->Investigator_Type?></option>
                                            <option value="Principal Investigator">Principal Investigator</option>
                                            <option value="Co-Investigator">  Co-Investigator</option>
                                        </select>
                                    </div><br>
                            

                                <div class="md-4">
                                    <label class="form-label">Name of Funding Agency : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" id="fundingname1<?= $chapter->RInfo_id?>" name="agency1" value="<?= $chapter->Name_Of_Funding_Agency?>" placeholder="Enter Agency name" autocomplete="off" oninput="validateFundingName1<?= $chapter->RInfo_id?>()" >
                                    <span id="fundingnameError1<?= $chapter->RInfo_id?>" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
                                </div><br>
                                <script>
                                    function validateFundingName1<?= $chapter->RInfo_id?>() {
                                        var regName = /[a-zA-Z ]$/;
                                        var name = document.getElementById('fundingname1<?= $chapter->RInfo_id?>').value;
                                        var error = document.getElementById("fundingnameError1<?= $chapter->RInfo_id?>");
                                    
                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finalfundingname = capitalizedWords.join(" ");
                                        
                                        document.getElementById('fundingname1<?= $chapter->RInfo_id?>').value = finalfundingname;
                                    
                                        if (finalfundingname.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finalfundingname)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>

                                <div class="md-4" id="year1" style="display:block;">
                                    <label class="form-label">Year of Award : <label style="color: red;">* (Sanction Year of the Project)</label></label>
                                    <input type="text" class="form-control" name="datepicker" value="<?= $chapter->Year_Of_Award?>" id="datepicker1<?= $chapter->RInfo_id?>" placeholder="yyyy" autocomplete="off" maxlength="4" >
                                    <span id="error-message1<?= $chapter->RInfo_id?>" style="color: red; display: none;">Please enter a valid Year.</span>
                                </div>
                                <script>
                                    $(document).ready(function() {
                                        var currentYear = new Date().getFullYear(); // Get the current year

                                        $("#datepicker1<?= $chapter->RInfo_id?>").datepicker({
                                            format: "yyyy",
                                            viewMode: "years",
                                            minViewMode: "years",
                                            startDate: "1992",
                                            endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                            autoclose: true
                                        });

                                        // Add an input event handler to validate numeric input
                                        $("#datepicker1<?= $chapter->RInfo_id?>").on("input", function() {
                                            var inputValue = $(this).val();
                                            var numericValue = parseInt(inputValue);
                                            
                                            if (isNaN(numericValue)) {
                                                $(this).val(""); // Clear the input
                                            }
                                        });
                                    });
                                </script>
                                 
                                 <div class="md-4">
                                    <label class="form-label" for="reason">Type of Funding Agency :  <label style="color: red;">*</label></label>
                                    <select id="Funding<?= $chapter->RInfo_id?>" onclick="showOther<?= $chapter->RInfo_id?>()" name="typeAgency" class="form-control">
                                        <option  selected hidden value="<?= $chapter->Type_Funding_Aggency?>"><?= $chapter->Type_Funding_Aggency?></option>
                                        <option value="Government">Government</option>
                                        <option value="Non-Government">Non-Government</option>
                                        <option value="International Bodies"> International Bodies</option>
                                        <option value="Other">Other</option>
                                    </select>

                                    <div class="md-4" id="other<?= $chapter->RInfo_id?>" style="display:none;">
                                        <label class="form-label">Other: <label style="color: red;">*</label></label>
                                        <input id="otherJournal" type="text" class="form-control"  name="other" value="<?= $chapter->Type_Funding_Aggency?>"  autocomplete="off" oninput="validateOther()">
                                        <span id="otherErrror" style="display:none;color:red;"></span>
                                    </div>

                                    <script>
                                        function showOther<?= $chapter->RInfo_id?>() {
                                            var type = document.getElementById("Funding<?= $chapter->RInfo_id?>");
                                                if (type.value == "Other") 
                                                {
                                                    document.getElementById("other<?= $chapter->RInfo_id?>").style.display="block";
                                                }
                                                else 
                                                {
                                                    document.getElementById("other<?= $chapter->RInfo_id?>").style.display="none";
                                                } 
                                            }
                                    </script>
                                </div><br>
                                
                                <div class="md-4">
                                    <label class="form-label" for="reason">Status :  <label style="color: red;">*</label></label>
                                    <select id="reason" name="status" class="form-control">
                                        <option value="<?= $chapter->Satus?>"><?= $chapter->Satus?></option>
                                        <option value="Ongoing">Ongoing</option>
                                        <option value="Complete">Complete</option>
                                    </select>
                                </div><br>

                                <div class="md-4">
                                    <label class="form-label">Funds Provided in INR : <span style="color: red;">* (Total amount in Lakhs)</span></label>
                                    <input type="text" class="form-control" id="funds-id1<?= $chapter->RInfo_id?>" name="funds" value="<?= $chapter->Funds_Provided?>" placeholder="Enter Funds" min="100000" max="10000000" autocomplete="off" maxlength="7" >
                                    <span id="FundError1<?= $chapter->RInfo_id?>" style="color: red;"></span>
                                </div><br>

                                <script>
                                    function validateFund1<?= $chapter->RInfo_id?>(inputElement) {
                                        var sanitizedValue = inputElement.value.replace(/\D/g, '');
                                        inputElement.value = sanitizedValue;

                                        var enteredValue = parseInt(sanitizedValue);
                                        var minLimit = parseInt(inputElement.getAttribute("min"));
                                        var maxLimit = parseInt(inputElement.getAttribute("max"));

                                        var errorSpan = document.getElementById("FundError1<?= $chapter->RInfo_id?>");

                                        if (sanitizedValue.length === 0) {
                                            errorSpan.style.display = "none";
                                            inputElement.setCustomValidity("");
                                        } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                            errorSpan.textContent = "Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".";
                                            errorSpan.style.display = "block";
                                            inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                        } else {
                                            errorSpan.style.display = "none";
                                            inputElement.setCustomValidity("");
                                        }
                                    }

                                    document.getElementById("funds-id1<?= $chapter->RInfo_id?>").addEventListener("input", function () {
                                        validateFund1<?= $chapter->RInfo_id?>(this);
                                    });
                                </script>                                
                                
                                <div class="md-4">
                                    <label class="form-label">Duration of Project : <label style="color: red;">* (in Years Only)</label></label>
                                    <input type="text" class="form-control" id="duration-id1<?= $chapter->RInfo_id?>" name="DP" value="<?= $chapter->Duration_Of_Project?>" value="" placeholder="Enter Duration" min="1" max="5" autocomplete="off" maxlength="1" >
                                    <span class="durationError1<?= $chapter->RInfo_id?>" style="color: red; display: none;">Please enter a valid year between 1 and 5.</span>
                                </div><br>

                                <script>
                                    function validateDuration1<?= $chapter->RInfo_id?>(inputElement) {
                                        var sanitizedValue = inputElement.value.replace(/\D/g, '');
                                        inputElement.value = sanitizedValue;

                                        var enteredValue = parseInt(sanitizedValue);
                                        var minLimit = parseInt(inputElement.getAttribute("min"));
                                        var maxLimit = parseInt(inputElement.getAttribute("max"));

                                        var errorSpan = document.querySelector(".durationError1<?= $chapter->RInfo_id?>");

                                        if (sanitizedValue.length === 0) {
                                            errorSpan.style.display = "none";
                                            inputElement.setCustomValidity("");
                                        } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                            var errorMessage = "Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".";
                                            errorSpan.textContent = errorMessage;
                                            errorSpan.style.display = "block";
                                            inputElement.setCustomValidity(errorMessage);
                                        } else {
                                            errorSpan.style.display = "none";
                                            inputElement.setCustomValidity("");
                                        }
                                    }

                                    document.getElementById("duration-id1<?= $chapter->RInfo_id?>").addEventListener("input", function () {
                                        validateDuration1<?= $chapter->RInfo_id?>(this);
                                    });
                                </script>

                                <div class="md-4">
                                    <label class="form-label" for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
                                    <input id="sanctiondocument1<?= $chapter->RInfo_id?>" type="file" class="form-control" name="sletter" accept=".pdf" onchange="validateSanction1<?= $chapter->RInfo_id?>(event)" >
                                    <span id="sanctiondocumentError1<?= $chapter->RInfo_id?>" name="sanctiondocument" style="color:red;"></span>
                                </div><br>  

                                <script>
                                    function validateSanction1<?= $chapter->RInfo_id?>(event) {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('sanctiondocumentError1<?= $chapter->RInfo_id?>');
                                    if (!file.type.match('pdf')) {
                                        errorElement.textContent = 'File is not a PDF.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 500 * 1024) {
                                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                }
                                </script>

                            </div>
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('reaserchProjectInfo');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/Reaserch_Details/reaserchProjectInfo_view.js'); ?>"></script>


<?= $this->endSection();?>