<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Consultancy & Corporate Training Program </h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="consultancy">
    <form class="row g-3 my-3" method="post" action="<?= base_url('saveConsultancy')?>" enctype="multipart/form-data">
        <div id="form-container">
            <div class="form-fields">

                <div class="row mx-2 pt-3 pb-3 border border-2">
                    <div class="col-md-4 my-3">
                        <label class="form-label" for="reason">Type: <label style="color: red;">*</label></label>
                        <select id="reason" name="Place" class="form-control">
                            <option disabled selected hidden>--- Select one ---</option>
                            <option value="Consultancy">Consultancy</option>
                            <option value="Corporate Training Program">Corporate Training Program</option>
                        </select>
                    </div>
                

                <div class="col-md-4 my-3">
                    <label class="form-label" for="teacher-name">Name of the Project : <label style="color: red;">*</label></label>
                    <input id="projectname" type="text" class="form-control" name="projectname" autocomplete="off" oninput="validateProjectName()" required>
                    <span id="projectnameError" style="display:none;color:red;">Please Enter a Valid Name of the Project.</span>
                </div>

                <div class="col-md-4 my-3">
                    <label class="form-label" for="teacher-name">Consulting/Sponsoring agency : <label style="color: red;">*</label></label>
                    <input id="agency" type="text" class="form-control" name="agency" placeholder="" autocomplete="off" oninput="validateAgency()" required>
                    <span id="agencyError" style="display:none;color:red;">Please Enter a Valid Name of the Project.</span>
                </div>

 
                <div class="col-md-4 my-3">
                    <label class="form-label" for="teacher-id">Revenue Generated : <label style="color: red;">*</label></label>
                    <input id="revenue" type="tel" class="form-control" name="revenue" placeholder="" autocomplete="off" min="20000" max="600000" autocomplete="off" maxlength="6" required>
                    <span id="revenueError" style="color:red; display:none;">Please enter a valid amount between 20000 and 600000.</span>
                </div>

                <div class="col-md-4 my-3">
                    <label class="form-label">Number of Trainings : </label>
                    <input id="training" type="tel" class="form-control" name="training" min="1" max="5" maxlength="1" autocomplete="off" >
                    <span id = "trainingError" style="display:none;color:red;">Please Enter a Valid Duration of Project between 1 to 5.</span>
                </div>

                <div class="col-md-4 my-3">
                    <label class="form-label">Upload Letter of Beneficiary : <label style="color: red;">* PDF file should be less than 500kb.</label></label>
                    <input id="beneficiary" type="file" class="form-control" name="beneficiary" accept=".pdf" onchange="validateBeneficiary(event)" required>
                    <span id="beneficiaryError" name="beneficiary" style="color:red;"></span>
                </div>
            </div> 
            
            <div class="col-12 text-center my-3">
            <input type="submit" class="btn btn-outline-primary"></input>
        </div>

        </div>
        
        
    </form>
</div>
</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>


<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Place</th>
                <th scope="col">Name of the Project</th>
                <th scope="col">Consulting/Sponsoring agency</th>
                <th scope="col">Revenue Generated</th>
                <th scope="col">Number of Trainings</th>
                <th scope="col">Upload Letter of Beneficiary</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->Consultancy;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Letter_Of_Beneficiary;
            ?>
            <tr >
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Place?> </td>
                <td class="text-center"> <?= $chapter->Name_Project?> </td>
                <td class="text-center"> <?= $chapter->Sponsoring_Agency?> </td>
                <td class="text-center"> <?= $chapter->Revenue_Generate?> </td>
                <td class="text-center"> <?= $chapter->No_Trainings?> </td>
                <td class="text-center"> 
                    <?php if(!empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
               </td>

                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>
                    <form action="<?= base_url('deleteConsultancy')?>" method="post">
                        <input type="text"  style="display:none;" name="srnumber" readonly value="<?= $chapter->Consultancy_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Consultancy_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Consultancy_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Consultancy & Corporate Training Program </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateConsultancy')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">

                                <div class="md-4" style="display:none;">
                                        <label class="form-label">Consultancy id : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->Consultancy_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                </div>
                                
                                <div class="md-4 my-3">
                                    <label class="form-label" for="reason">Type: <label style="color: red;">*</label></label>
                                    <select id="reason" name="Place"  class="form-control">
                                        <option value="<?= $chapter->Place?>"><?= $chapter->Place?></option>
                                        <option  value="Consultancy" >Consultancy</option>
                                        <option  value="Corporate Training Program" >Corporate Training Program</option>
                                    </select>
                                </div><br>
										
                                <div class="md-4 my-3">
                                    <label class="form-label"  for="teacher-name">Name of the Project : <label style="color: red;">*</label></label>
                                    <input id="projectname1<?= $chapter->Consultancy_id?>" type="text" class="form-control" name="projectname" value="<?= $chapter->Name_Project?>" autocomplete="off" oninput="validateProjectName1<?= $chapter->Consultancy_id?>()" >
                                    <span id="projectnameError1<?= $chapter->Consultancy_id?>" style="display:none;color:red;">Please Enter a Valid Name of the Project.</span>
                                </div><br>

                                <script>
                                      function validateProjectName1<?= $chapter->Consultancy_id?>() {
                                        var regName = /^[a-zA-Z ]+$/;
                                        var name = document.getElementById('projectname1<?= $chapter->Consultancy_id?>').value;
                                        var error = document.getElementById("projectnameError1<?= $chapter->Consultancy_id?>");
                                    
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                    
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                    
                                        var finalprojectname = capitalizedWords.join(" ");
                                        document.getElementById('projectname1<?= $chapter->Consultancy_id?>').value = finalprojectname;
                                    
                                        if (finalprojectname.length === 0 || regName.test(finalprojectname)) {
                                            error.style.display = "none";
                                        } else {
                                            error.style.display = "block";
                                        }
                                    }
                                    
                                    // Attach event listener using JavaScript
                                    document.getElementById('projectname1<?= $chapter->Consultancy_id?>').addEventListener('input', validateProjectName1<?= $chapter->Consultancy_id?>);
  
                                </script>

                                <div class="md-4 my-3">
                                    <label class="form-label"  for="teacher-name">Consulting/Sponsoring agency : <label style="color: red;">*</label></label>
                                    <input id="agency1<?= $chapter->Consultancy_id?>" type="text" class="form-control" name="agency" value="<?= $chapter->Sponsoring_Agency?>" placeholder="" autocomplete="off" oninput="validateAgency1<?= $chapter->Consultancy_id?>()" >
                                    <span id="agencyError1<?= $chapter->Consultancy_id?>" style="display:none;color:red;">Please Enter a Valid Name of the Project.</span>
                                </div><br>

                                <script>
                                    function validateAgency1<?= $chapter->Consultancy_id?>() {
                                        var regName = /^[a-zA-Z ]+$/;
                                        var name = document.getElementById('agency1<?= $chapter->Consultancy_id?>').value;
                                        var error = document.getElementById("agencyError1<?= $chapter->Consultancy_id?>");
                                    
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                    
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                    
                                        var finalagency = capitalizedWords.join(" ");
                                        document.getElementById('agency1<?= $chapter->Consultancy_id?>').value = finalagency;
                                    
                                        if (finalagency.length === 0 || regName.test(finalagency)) {
                                            error.style.display = "none";
                                        } else {
                                            error.style.display = "block";
                                        }
                                    }
                                    
                                    // Attach event listener using JavaScript
                                    document.getElementById('agency1<?= $chapter->Consultancy_id?>').addEventListener('input', validateAgency1<?= $chapter->Consultancy_id?>);
  
                                </script>

                                <div class="md-4 my-3">
                                    <label class="form-label"  for="teacher-id">Revenue Generated : <label style="color: red;">*</label></label>
                                    <input id="revenue1<?= $chapter->Consultancy_id?>" type="tel" class="form-control" name="revenue" value="<?= $chapter->Revenue_Generate?>" placeholder="" autocomplete="off" min="20000" max="599999" autocomplete="off" maxlength="6" >
                                    <span id="revenueError1<?= $chapter->Consultancy_id?>" style="color:red; display:none;">Please enter a valid amount between 20000 and 599999.</span>
                                </div><br>

                                <script>
                                    function validateRevenue1<?= $chapter->Consultancy_id?>(inputElement) {
                                        var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
                                        inputElement.value = sanitizedValue; // Set sanitized value back into the input field
                                    
                                        var enteredValue = parseInt(sanitizedValue);
                                        var minLimit = parseInt(inputElement.getAttribute("min"));
                                        var maxLimit = parseInt(inputElement.getAttribute("max"));
                                    
                                        // Check if the entered value is within the specified limits
                                        if (sanitizedValue.length === 0) {
                                            document.getElementById("revenueError1<?= $chapter->Consultancy_id?>").style.display = "none"; // Hide the error message
                                            inputElement.setCustomValidity(""); // Clear custom validity
                                        } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                            document.getElementById("revenueError1<?= $chapter->Consultancy_id?>").style.display = "block";
                                            inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                        } else {
                                            document.getElementById("revenueError1<?= $chapter->Consultancy_id?>").style.display = "none";
                                            inputElement.setCustomValidity("");
                                        }
                                    }
                                    
                                    // Add an event listener to the input field
                                    document.getElementById("revenue1<?= $chapter->Consultancy_id?>").addEventListener("input", function () {
                                        validateRevenue1<?= $chapter->Consultancy_id?>(this);
                                    });
                                </script>

                                <div class="md-4 my-3">
                                    <label class="form-label">No. of Trainings :</label>
                                    <input id="training1<?= $chapter->Consultancy_id?>" type="tel" class="form-control" name="training" value="<?= $chapter->No_Trainings?>" min="1" max="5" maxlength="1" autocomplete="off" >
                                    <span id = "trainingError1<?= $chapter->Consultancy_id?>" style="display:none;color:red;">Please Enter a Valid Duration of Project between 1 to 5.</span>
                                </div><br>

                                <script>
                                    function validateTraining1<?= $chapter->Consultancy_id?>(inputElement) {
                                        var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
                                        inputElement.value = sanitizedValue; // Set sanitized value back into the input field
                                    
                                        var enteredValue = parseInt(sanitizedValue);
                                        var minLimit = parseInt(inputElement.getAttribute("min"));
                                        var maxLimit = parseInt(inputElement.getAttribute("max"));
                                    
                                        // Check if the entered value is within the specified limits
                                        if (sanitizedValue.length === 0) {
                                            document.getElementById("trainingError1<?= $chapter->Consultancy_id?>").style.display = "none"; // Hide the error message
                                            inputElement.setCustomValidity(""); // Clear custom validity
                                        } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                            document.getElementById("trainingError1<?= $chapter->Consultancy_id?>").style.display = "block";
                                            inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                        } else {
                                            document.getElementById("trainingError1<?= $chapter->Consultancy_id?>").style.display = "none";
                                            inputElement.setCustomValidity("");
                                        }
                                    }
                                    
                                    // Add an event listener to the input field
                                    document.getElementById("training1<?= $chapter->Consultancy_id?>").addEventListener("input", function () {
                                        validateTraining1<?= $chapter->Consultancy_id?>(this);
                                    });
                                </script>

                                <div class="md-4 my-3">
                                    <label class="form-label">Upload Letter of Beneficiary : <label style="color: red;">* PDF file should be less than 500kb.</label></label>
                                    <input id="beneficiary1<?= $chapter->Consultancy_id?>" type="file" class="form-control" name="beneficiary"   accept=".pdf" onchange="validateBeneficiary1<?= $chapter->Consultancy_id?>(event)" >
                                    <span id="beneficiaryError1<?= $chapter->Consultancy_id?>" name="beneficiary" style="color:red;"></span>
                                </div>

                                <script>
                                    function validateBeneficiary1<?= $chapter->Consultancy_id?>(event) {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('beneficiaryError1<?= $chapter->Consultancy_id?>');
                                    if (!file.type.match('pdf')) {
                                        errorElement.textContent = 'File is not a PDF.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    if (file.size > 500 * 1024) {
                                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                        event.target.value = ''; // Clear the file input
                                        return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                }
                                </script>

                            </div>
                        </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('consultancy');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>

<script src="<?php echo base_url('assets/js/Reaserch_Details/consultancy_view.js'); ?>"></script>

<?= $this->endSection();?>