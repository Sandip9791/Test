<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

    <h1 class="text-center my-3">Research Guide Details</h1>
    <div class="container-fluid border border-info  my-3">
        <form class=" g-2 my-3" id="myForm" method="post" action="<?= base_url('saveReaserchGuideInfo1')?>" enctype="multipart/form-data">

            <div class="row mx-2 pt-3 pb-3 ">

                <div class="col-md-4 pb-3">
                    <label class="form-label" for="reason">Are you a Ph.D.Guide ? <label
                            style="color: red;">*</label></label>
                    <select id="Ph.D.Guide" name="yesno" onclick="show()" class="form-control">
                        <option disabled selected hidden>--- Select one ---</option>
                        <option  value="Yes" >Yes</option>
                        <option  value="No" >No</option>
                    </select>
                </div>

                <script>
                    function show() {
                        var type = document.getElementById("Ph.D.Guide");
                        if (type.value == "Yes") {
                            document.getElementById("myTemplate").style.display="block";
                        }
                        else 
                        {
                            document.getElementById("myTemplate").style.display="none";
                        }

                        if (type.value == "No") {
                            document.getElementById("Ph.D.Co-Guide").style.display="block";
                        }
                        else {
                            document.getElementById("Ph.D.Co-Guide").style.display="none";
                        }  
                    }
                </script>

                <div class="col-md-4" id="Ph.D.Co-Guide" style="display:none;">
                    <label class="form-label" for="reason">Are you a Ph.D.Co-Guide ? <label
                            style="color: red;">*</label></label>
                    <select id="reason" name="yesno1" onclick="show1()" class="form-control">
                        <option disabled selected hidden>--- Select one ---</option>
                        <option  value="Yes" >Yes</option>
                        <option  value="No" >No</option>
                    </select>
                </div>

                <script>
                    function show1() {
                        var type = document.getElementById("reason");
                        if (type.value == "Yes") {
                            document.getElementById("myTemplate").style.display="block";
                        }
                        else 
                        {
                            document.getElementById("myTemplate").style.display="none";
                        }
    
                    }
                </script>

                 <div class=" mx-2 pt-3 pb-3 border border-2" id="myTemplate" style="display:none">
                     <div class="row">
                        <div class="col-md-4 my-4">
                            <label class="form-label">Subject Name : <label style="color: red;">*(Subject name from recognition letter.)</label></label>
                            <input type="text" class="form-control" id="subject" id="text-input1" name="subject" placeholder="Enter Subject" autocomplete="off" oninput="validateSubName()" >
                            <span id="subnameError" style="display:none;color:red;">Please enter a valid Subject Name.</span>
                        </div>

                        <div class="col-md-4 my-4">
                            <label class="form-label">Center Name : <label style="color: red;">*</label></label>
                            <input type="text" class="form-control" id="center" id="text-input2" name="center" placeholder="Enter name" autocomplete="off" oninput="validateCenterName()" >
                            <span id="centernameError" style="display:none;color:red;">Please enter a valid Center Name.</span>
                        </div>

                        <div class="col-md-4 my-4">
                            <label class="form-label">University : <label style="color: red;">*</label></label>
                            <input type="text" class="form-control" id="university" id="text-input3" name="university" placeholder="Enter Subject" autocomplete="off" oninput="validateUniversity()" >
                            <span id="universityError" style="display:none;color:red;">Please enter a valid University Name.</span>
                        </div>

                        <div class="col-md-4 my-4" >
                            <label class="form-label">Year of Recognition : <label style="color: red;">*</label></label>
                            <input type="text" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" maxlength="4" autocomplete="off" >
                            <span id="error-message" style="color: red; display: none;">Please enter a valid Year.</span>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var currentYear = new Date().getFullYear(); // Get the current year

                                $("#datepicker").datepicker({
                                    format: "yyyy",
                                    viewMode: "years",
                                    minViewMode: "years",
                                    startDate: "1992",
                                    endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                    autoclose: true
                                });

                                // Add an input event handler to validate numeric input
                                $("#datepicker").on("input", function() {
                                    var inputValue = $(this).val();
                                    var numericValue = parseInt(inputValue);
                                    
                                    if (isNaN(numericValue)) {
                                        $(this).val(""); // Clear the input
                                    }
                                });
                            });
                        </script>

                        <div class="col-md-4 my-4" >
                            <label class="form-label">Upload Recognition Letter : <label style="color: red;">*</label></label>
                            <input type="file" id="rletter" class="form-control" name="letter" accept=".pdf" placeholder="" autocomplete="off" onchange="validateRecognitionLetter(event)" required>
                            <span id="rletterError" style="color: red;"></span>
                        </div>

                        <div class="col-12 text-center my-3">
                            <a class="btn btn-outline-primary" href="<?= base_url('reaserchGuideInfo2')?>">Next</a>
                        </div>
                     </div>
                 </div>    
            </div>
            <div class="col-12 text-center" >
                <button type="submit" class="btn btn-outline-primary" >Submit</button>
            </div>
        </form>
    </div>

<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Are you a Ph.D.Guide</th>
                <th scope="col">Are you a Ph.D.Co-Guide</th>
                <th scope="col">Subject Name </th>
                <th scope="col">Center Name</th>
                <th scope="col">University </th>
                <th scope="col">Year of Recognition </th>
                <th scope="col">Recognition Letter </th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->RGuide1;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                    $letter=$chapter->Recognition_Letter;
            ?>
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Ph_D_Guide?> </td>
                <td class="text-center" >
                    <?php if(empty($chapter->Ph_D_Co_Guide)):?> 
                        No
                    <?php else:?>
                        <?= $chapter->Ph_D_Co_Guide?> 
                    <?php endif;?>
                </td>
                <td class="text-center"> <?= $chapter->Subject_Name?> </td>
                <td class="text-center"> <?= $chapter->Center_Name?> </td>
                <td class="text-center"> <?= $chapter->University?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Recognition ?> </td>
                <td class="text-center"> 
                    <?php if(!empty($letter)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$letter;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"> 
                    <img src="<?= base_url('assets/images/iconsDelete.gif')?>"><br>
                    <form action="<?= base_url('deleteReaserchGuideInfo1')?>" method="post">
                        <input type="text" class="form-control text-center" style="display:none" name="srnumber" readonly value="<?= $chapter->RGuide1_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RGuide1_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RGuide1_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Guide Details</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateReaserchGuideInfo1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">BookAndChapter id : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RGuide1_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>

                                    <div class="md-4" >
                                        <label class="form-label">Subject Name : <label style="color: red;">*(Subject name from recognition letter.)</label></label>
                                        <input type="text" class="form-control" name="subject" id="subject1<?= $chapter->RGuide1_id?>" value="<?= $chapter->Subject_Name ?>" id="text-input1"  placeholder="Enter Subject" autocomplete="off" oninput="validateSubName1<?= $chapter->RGuide1_id?>()" >
                                        <span id="subnameError1<?= $chapter->RGuide1_id?>" style="display:none;color:red;">Please enter a valid Subject Name.</span>
                                    </div><br>
                                    
                                    <script>
                                        function validateSubName1<?= $chapter->RGuide1_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('subject1<?= $chapter->RGuide1_id?>').value;
                                            var error = document.getElementById("subjectnameError1<?= $chapter->RGuide1_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalSubName1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('subject1<?= $chapter->RGuide1_id?>').value = finalSubName1;
                                        
                                            if (finalSubName1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalSubName1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                <div class="md-4" >
                                    <label class="form-label">Center Name : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" id="center1<?= $chapter->RGuide1_id?>" id="text-input2<?= $chapter->RGuide1_id?>" name="center" value="<?= $chapter->Center_Name?>"  placeholder="Enter name" autocomplete="off" oninput="validateCenterName1<?= $chapter->RGuide1_id?>()" required>
                                    <span id="centernameError1<?= $chapter->RGuide1_id?>" style="display:none;color:red;">Please enter a valid CenterName.</span>
                                </div><br>
                                <script>
                                    function validateCenterName1<?= $chapter->RGuide1_id?>() {
                                        var regName = /[a-zA-Z ]$/;
                                        var name = document.getElementById('center1<?= $chapter->RGuide1_id?>').value;
                                        var error = document.getElementById("centernameError1<?= $chapter->RGuide1_id?>");
                                    
                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finalCenterName1 = capitalizedWords.join(" ");
                                        
                                        document.getElementById('center1<?= $chapter->RGuide1_id?>').value = finalCenterName1;
                                    
                                        if (finalCenterName1.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finalCenterName1)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>

                                <div class="md-4">
                                    <label class="form-label">University : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" id="university1<?= $chapter->RGuide1_id?>" id="text-input3<?= $chapter->RGuide1_id?>" value="<?= $chapter->University?>" name="university" placeholder="Enter Subject" autocomplete="off" oninput="validateUniversity1<?= $chapter->RGuide1_id?>()" required>
                                    <span id="universityError1<?= $chapter->RGuide1_id?>" style="display:none;color:red;">Please enter a valid University Name.</span>
                                </div><br>

                                <script>
                                    function validateUniversity1<?= $chapter->RGuide1_id?>() {
                                        var regName = /[a-zA-Z ]$/;
                                        var name = document.getElementById('university1<?= $chapter->RGuide1_id?>').value;
                                        var error = document.getElementById("universityError1<?= $chapter->RGuide1_id?>");
                                    
                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finalUniName1 = capitalizedWords.join(" ");
                                        
                                        document.getElementById('university1<?= $chapter->RGuide1_id?>').value = finalUniName1;
                                    
                                        if (finalUniName1.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finalUniName1)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>

                                <div class="md-4">
                                    <label class="form-label">Year of Recognition : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="datepicker" value="<?= $chapter->Year_Of_Recognition?>" id="datepicker1<?= $chapter->RGuide1_id?>" placeholder="yyyy" maxlength="4" autocomplete="off" >
                                    <span id="error-message1<?= $chapter->RGuide1_id?>" style="color: red; display: none;">Please enter a valid Year.</span>
                                </div><br>

                                <script>
                                    $(document).ready(function() {
                                        var currentYear = new Date().getFullYear(); // Get the current year

                                        $("#datepicker1<?= $chapter->RGuide1_id?>").datepicker({
                                            format: "yyyy",
                                            viewMode: "years",
                                            minViewMode: "years",
                                            startDate: "1992",
                                            endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                            autoclose: true
                                        });

                                        // Add an input event handler to validate numeric input
                                        $("#datepicker1<?= $chapter->RGuide1_id?>").on("input", function() {
                                            var inputValue = $(this).val();
                                            var numericValue = parseInt(inputValue);
                                            
                                            if (isNaN(numericValue)) {
                                                $(this).val(""); // Clear the input
                                            }
                                        });
                                    });
                                </script>

                                <div class="md-4" >
                                    <label class="form-label">Upload Recognition Letter : <label style="color: red;">*</label></label>
                                    <input type="file" id="rletter1<?= $chapter->RGuide1_id?>" class="form-control" name="letter" accept=".pdf" placeholder="" autocomplete="off" onchange="validateRecognitionLetter1<?= $chapter->RGuide1_id?>(event)" >
                                    <span id="rletterError1<?= $chapter->RGuide1_id?>" style="color: red;"></span>
                                </div><br>
                                <script>
                                    //Upload Recognition Letter
                                    function validateRecognitionLetter1<?= $chapter->RGuide1_id?>(event) {
                                    const file = event.target.files[0];
                                    const errorElement = document.getElementById('rletterError1<?= $chapter->RGuide1_id?>');
                                    if (!file.type.match('pdf')) {
                                    errorElement.textContent = 'File is not a PDF.';
                                    event.target.value = ''; // Clear the file input
                                    return;
                                    }
                                    if (file.size > 500 * 1024) {
                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                    event.target.value = ''; // Clear the file input
                                    return;
                                    }
                                    // If the file is valid, clear the error message
                                    errorElement.textContent = '';
                                    }

                                </script>
                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit"  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

   
          

    <script src="<?= base_url('assets/js/Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo1_view.js'); ?>"></script>
 


<?= $this->endSection();?>