<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
 
    <h1 class="text-center my-3">Research Guide Details</h1>
    <div class="container-fluid border border-primary border-3 my-3">

        <h4>Students Awarded Ph.D. :</h4>
        <form class="row g-2 my-3" id="myForm" action="<?= base_url('saveReaserchGuideInfo2')?>" method="post"
            enctype="multipart/form-data">

            <div id="form-container">

                <div class="form-fields">

                    <div class="row mx-2 pt-3 pb-3 border border-2">
                        <div class="col-md-4 my-4" id="text-input5" style="display:block;">
                            <label class="form-label">Research Title : <label style="color: red;">*</label></label>
                            <input type="text" id="researchtitlename" class="form-control" id="text-input5" name="title" placeholder="Enter Title" autocomplete="off" oninput="validateResearchTitleName()" required>
                            <span id="researchtitlenameError" style="display:none;color:red;">Please enter a valid Research Title Name.</span>
                        </div>

                        <div class="col-md-4 my-4" id="text-input6" style="display:block;">
                            <label class="form-label">Name of Researcher : <label style="color: red;">*</label></label>
                            <input type="text" id="researchername" class="form-control" id="text-input6" name="researcher" placeholder="Enter Name" autocomplete="off" oninput="validateResearcherName()" required>
                            <span id="researchernameError" style="display:none;color:red;">Please enter a valid Researcher Name.</span>
                        </div>

                        <div class="col-md-4 my-4" id="year1" style="display:block;">
                            <label class="form-label">Year of Degree Award : <label style="color: red;">*</label></label>
                            <input type="text" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" autocomplete="off" maxlength="4" required>
                            <span id="error-message" style="color: red; display: none;">Please enter a valid Year.</span>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var currentYear = new Date().getFullYear(); // Get the current year

                                $("#datepicker").datepicker({
                                    format: "yyyy",
                                    viewMode: "years",
                                    minViewMode: "years",
                                    startDate: "1992",
                                    endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                    autoclose: true
                                });

                                // Add an input event handler to validate numeric input
                                $("#datepicker").on("input", function() {
                                    var inputValue = $(this).val();
                                    var numericValue = parseInt(inputValue);
                                    
                                    if (isNaN(numericValue)) {
                                        $(this).val(""); // Clear the input
                                    }
                                });
                            });
                        </script>

                        <div class="col-md-4 my-4" id="upload2" style="display:block;">
                            <label class="form-label">Upload Provisional/Degree Certificate : <label style="color: red;"><strong>* </strong>Select PDF file under 500KB</label></label>
                            <input type="file" id="certificate" class="form-control" name="dCertificate" accept=".pdf" onchange="validateCertificate(event)" required>
                            <span id="certificateError" style="display:block;color:red;"></span>
                        </div>

                        
                    </div>
                </div>
            </div>
            <div class="col-12 my-3 text-center">
               <a class="btn btn-outline-primary" href="<?= base_url('reaserchGuideInfo1');?>">Previous</a>
                <input type="submit" class="btn btn-outline-primary" value="Submit">
                <a class="btn btn-outline-primary" href="<?= base_url('reaserchGuideInfo3')?>">Next </a>
            </div>
        </form>
    </div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Research Title</th>
                <th scope="col">Name of Researcher</th>
                <th scope="col">Year of Degree Award</th>
                <th scope="col">Provisional/Degree Certificate</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->RGuide2;
        ?>
        <tbody>
            <?php
                foreach($book as $chapter):
                $degree = $chapter->Degree_Certificate;
            ?>
            <tr>
                <th  class="text-center" scope="row"><?= $row++?></th>
                <td  class="text-center"><?= $chapter->Research_Title?> </td>
                <td  class="text-center" ><?= $chapter->Name_of_Researcher?> </td>
                <td  class="text-center"> <?= $chapter->Year_of_Degree_Award?> </td>
                <td  class="text-center"> 
                    <?php if(!empty($degree)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$degree;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td  class="text-center"> 
                    <img src="<?= base_url('assets/images/iconsDelete.gif')?>"><br>
                    <form action="<?= base_url('deleteReaserchGuideInfo2')?>" method="post">
                        <input type="text" class="form-control text-center" style="display:none" name="srnumber" readonly value="<?= $chapter->RGuide2_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RGuide2_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RGuide2_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Guide Details</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateReaserchGuideInfo2')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">BookAndChapter id : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RGuide2_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>

                                    <div class="md-4" id="text-input5" style="display:block;">
                                        <label class="form-label">Research Title : <label style="color: red;">*</label></label>
                                        <input type="text" id="researchtitlename1<?= $chapter->RGuide2_id ?>" class="form-control" id="text-input5" name="title" value="<?= $chapter->Research_Title ?>" placeholder="Enter Title" autocomplete="off" oninput="validateResearchTitleName1<?= $chapter->RGuide2_id ?>()">
                                        <span id="researchtitlenameError1<?= $chapter->RGuide2_id ?>" style="display:none;color:red;">Please enter a valid Research Title Name.</span>
                                    </div><br>

                                    <script>
                                        function validateResearchTitleName1<?= $chapter->RGuide2_id ?>() {
                                            var regName = /^[a-zA-Z ]*$/;  // Updated regular expression pattern
                                            var name = document.getElementById('researchtitlename1<?= $chapter->RGuide2_id ?>').value;
                                            var error = document.getElementById("researchtitlenameError1<?= $chapter->RGuide2_id ?>");

                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });

                                            // Join the capitalized words back together
                                            var finalresearchtitle1 = capitalizedWords.join(" ");

                                            document.getElementById('researchtitlename1<?= $chapter->RGuide2_id ?>').value = finalresearchtitle1;

                                            if (finalresearchtitle1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalresearchtitle1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                    <div class="md-4" id="text-input6" style="display:block;">
                                        <label class="form-label">Name of Researcher : <label style="color: red;">*</label></label>
                                        <input type="text" id="researchername1<?= $chapter->RGuide2_id ?>" class="form-control" id="text-input6" value="<?= $chapter->Name_of_Researcher?>" name="researcher" placeholder="Enter Name" autocomplete="off" oninput="validateResearcherName1<?= $chapter->RGuide2_id ?>()" >
                                        <span id="researchernameError1<?= $chapter->RGuide2_id ?>" style="display:none;color:red;">Please enter a valid Researcher Name.</span>
                                    </div><br>
                                    <script>
                                        function validateResearcherName1<?= $chapter->RGuide2_id ?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('researchername1<?= $chapter->RGuide2_id ?>').value;
                                            var error = document.getElementById("researchernameError1<?= $chapter->RGuide2_id ?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalresearchername1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('researchername1<?= $chapter->RGuide2_id ?>').value = finalresearchername1;
                                        
                                            if (finalresearchername1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalresearchername1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                    <div class="md-4" id="year1" style="display:block;">
                                        <label class="form-label">Year of Degree Award : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="datepicker" value="<?= $chapter->Year_of_Degree_Award?>" id="datepicker1<?= $chapter->RGuide2_id ?>" placeholder="yyyy" maxlength="4" autocomplete="off" >
                                        <span id="error-message1<?= $chapter->RGuide2_id ?>" style="color: red; display: none;">Please enter a valid Year.</span>
                                    </div><br>

                                    <script>
                                    $(document).ready(function() {
                                        var currentYear = new Date().getFullYear(); // Get the current year

                                        $("#datepicker1<?= $chapter->RGuide2_id ?>").datepicker({
                                            format: "yyyy",
                                            viewMode: "years",
                                            minViewMode: "years",
                                            startDate: "1992",
                                            endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                            autoclose: true
                                        });

                                        // Add an input event handler to validate numeric input
                                        $("#datepicker1<?= $chapter->RGuide2_id ?>").on("input", function() {
                                            var inputValue = $(this).val();
                                            var numericValue = parseInt(inputValue);
                                            
                                            if (isNaN(numericValue)) {
                                                $(this).val(""); // Clear the input
                                            }
                                        });
                                    });
                                </script>

                                    <div class="md-4" id="upload2" style="display:block;">
                                        <label class="form-label">Upload Provisional/Degree Certificate <label style="color: red;">*</label> :<label style="color: red;">(Select PDF file under 500KB)</label></label>
                                        <input type="file" id="certificate1<?= $chapter->RGuide2_id ?>" class="form-control" name="dCertificate" accept=".pdf" onchange="validateCertificate1<?= $chapter->RGuide2_id ?>(event)" >
                                        <span id="certificateError1<?= $chapter->RGuide2_id ?>" style="display:block;color:red;"></span>
                                    </div><br>
                                    <script>
                                        function validateCertificate1<?= $chapter->RGuide2_id ?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('certificateError1<?= $chapter->RGuide2_id ?>');
                                            if (!file.type.match('pdf')) {
                                                errorElement.textContent = 'File is not a PDF.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            if (file.size > 500 * 1024) {
                                                errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }

                                    </script>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit"  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </td>            
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>



    <script
        src="<?= base_url('assets/js/Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo2_view.js'); ?>"></script>

<?= $this->endSection();?>