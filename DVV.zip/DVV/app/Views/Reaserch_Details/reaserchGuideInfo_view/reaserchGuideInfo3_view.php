<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

    <h1 class="text-center my-3">Research Guide Details</h1>
    <div class="container-fluid border border-info-subtle my-3">

        <h4>Students Registered for Ph.D. :</h4>
        <form class="row g-2 my-3" id="myForm" action="<?= base_url('saveReaserchGuideInfo3')?>" method="post"
            enctype="multipart/form-data">

            <div id="form-container">

                <div class="form-fields">

                    <div class="row mx-2 pt-3 pb-3 border border-2">

                        <div class="col-md-4 my-3" id="text-input5" style="display:block;">
                            <label class="form-label">Research Title : <label style="color: red;">*</label></label>
                            <input type="text" id="researchtitlename" class="form-control" id="text-input5" name="title" placeholder="Enter Title" autocomplete="off" oninput="validateResearchTitleName()" required>
                            <span id="researchtitlenameError" style="display:none;color:red;">Please enter a valid Research Title Name.</span>
                        </div>

                        <div class="col-md-4 my-3" id="text-input6" style="display:block;">
                            <label class="form-label">Name of Researcher : <label style="color: red;">*</label></label>
                            <input type="text" id="researchername" class="form-control" id="text-input6" name="researcher" placeholder="Enter Name" autocomplete="off" oninput="validateResearcherName()" required>
                            <span id="researchernameError" style="display:none;color:red;">Please enter a valid Researcher Name.</span>
                        </div>

                        <div class="col-md-4 my-3" id="date" style="display:block;">
                            <label class="form-label">Registration Date : <label style="color: red;">*</label></label>
                            <input type="date" class="form-control" name="rdob" id="dob" min="2018-01-01" required>
                        </div>

 
                        <div class="col-md-4 my-3" id="upload2" style="display:block;">
                            <label class="form-label">Upload RR Letter :<label style="color: red;">* (Select PDF file under 500KB)</label></label>
                            <input type="file" id="rrletter" class="form-control" name="RRletter" accept=".pdf" onchange="validateRRLetter(event)" required>
                            <span id="rrletterError" style="display:block;color:red;"></span>
                        </div>

                     
                    </div>
                </div>
            </div>

            <div class="col-12 text-center">
                 <a class="btn btn-outline-primary"  href = "<?= base_url('reaserchGuideInfo2');?>">Previous</a>
                <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
        </form>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Research Title</th>
                <th scope="col">Name of Researcher</th>
                <th scope="col">Registration Date </th>
                <th scope="col">RR Letter </th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->RGuide3;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $latter = $chapter->RR_Latter;
            ?>
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Research_Title?> </td>
                <td class="text-center"><?= $chapter->Name_of_Researcher ?> </td>
                <td class="text-center"> <?= $chapter->Registration_Date ?> </td>
                <td class="text-center"> 
                    <?php if(!empty($latter)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$latter;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <img src="<?= base_url('assets/images/iconsDelete.gif')?>"><br>
                    <form action="<?= base_url('deleteReaserchGuideInfo3')?>" method="post">
                        <input type="text" style="display:none" class="form-control text-center" name="srnumber" readonly  value="<?= $chapter->RGuide3_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>

                </td> 
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RGuide3_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RGuide3_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Guide Details</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateReaserchGuideInfo3')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">BookAndChapter id : <label style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RGuide3_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>

                                    <div class="md-4" id="text-input5">
                                        <label class="form-label">Research Title : <label style="color: red;">*</label></label>
                                        <input type="text" id="researchtitlename1<?= $chapter->RGuide3_id?>" class="form-control" id="text-input5" name="title" value="<?= $chapter->Research_Title?>" placeholder="Enter Title" autocomplete="off" oninput="validateResearchTitleName1<?= $chapter->RGuide3_id?>()" >
                                        <span id="researchtitlenameError1<?= $chapter->RGuide3_id?>" style="display:none;color:red;">Please enter a valid Research Title Name.</span>
                                    </div><br>
                                    <script>
                                        function validateResearchTitleName1<?= $chapter->RGuide3_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('researchtitlename1<?= $chapter->RGuide3_id?>').value;
                                            var error = document.getElementById("researchtitlenameError1<?= $chapter->RGuide3_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalresearchtitle1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('researchtitlename1<?= $chapter->RGuide3_id?>').value = finalresearchtitle1;
                                        
                                            if (finalresearchtitle1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalresearchtitle1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>

                                    <div class="md-4" id="text-input6" >
                                        <label class="form-label">Name of Researcher : <label style="color: red;">*</label></label>
                                        <input type="text" id="researchername1<?= $chapter->RGuide3_id?>" class="form-control" id="text-input6" name="researcher" value="<?= $chapter->Name_of_Researcher?>" placeholder="Enter Name" autocomplete="off" oninput="validateResearcherName1<?= $chapter->RGuide3_id?>()" >
                                        <span id="researchernameError1<?= $chapter->RGuide3_id?>" style="display:none;color:red;">Please enter a valid Researcher Name.</span>
                                    </div><br>
                                    <script>
                                        function validateResearcherName1<?= $chapter->RGuide3_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('researchername1<?= $chapter->RGuide3_id?>').value;
                                            var error = document.getElementById("researchernameError1<?= $chapter->RGuide3_id?>");
                                        
                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalresearchername1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('researchername1<?= $chapter->RGuide3_id?>').value = finalresearchername1;
                                        
                                            if (finalresearchername1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalresearchername1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                        }
                                    </script>
                                   
                                    <div class="md-4" id="date">
                                        <label class="form-label">Registration Date : <label style="color: red;">*</label></label>
                                        <input type="date" class="form-control" name="rdob" value="<?= $chapter->Registration_Date ?>" min="2018-01-01" id="dob1<?= $chapter->RGuide3_id ?>">
                                    </div><br>
                                
                                    <script>
                                       function setupDateValidation1<?= $chapter->RGuide3_id ?>() {
                                            // Validation for the Date
                                            const dobDateInput = document.getElementById('dob1<?= $chapter->RGuide3_id ?>');

                                            // Set the minimum date allowed (2018-01-01 in this case)
                                            const minDate = new Date('2018-01-01');

                                            // Function to set the maximum date allowed to the current date
                                            function setMaxDate1<?= $chapter->RGuide3_id ?>() {
                                                const today = new Date();
                                                const maxDate = today.toISOString().split('T')[0]; // Format as "YYYY-MM-DD"
                                                dobDateInput.max = maxDate;
                                            }

                                            // Call the setMaxDate1 function to set the maximum date initially
                                            setMaxDate1<?= $chapter->RGuide3_id ?>();

                                            // Attach an event listener to the input element to dynamically update the maximum date
                                            dobDateInput.addEventListener('input', setMaxDate1<?= $chapter->RGuide3_id ?>);

                                            // Function to validate the selected date on form submission
                                            function validateRegDate1<?= $chapter->RGuide3_id ?>() {
                                                const selectedDate = new Date(dobDateInput.value);
                                                if (selectedDate < minDate) {
                                                    alert('Please select a date on or after 2018-01-01.');
                                                    return false;
                                                }
                                                return true;
                                            }

                                            // Attach an event listener to the form to validate the date on form submission
                                            const form = document.querySelector('form');
                                            form.addEventListener('submit', validateRegDate1<?= $chapter->RGuide3_id ?>);
                                        }

                                        // Call the setupDateValidation function to set up the validation for this specific element
                                        setupDateValidation1<?= $chapter->RGuide3_id ?>();

                                    </script>

                                    <div class="md-4" id="upload2" >
                                        <label class="form-label">Upload RR Letter :<label style="color: red;">* (Select PDF file under 500KB)</label></label>
                                        <input type="file" id="rrletter1<?= $chapter->RGuide3_id?>" class="form-control" name="RRletter"  accept=".pdf" onchange="validateRRLetter1<?= $chapter->RGuide3_id?>(event)" >
                                        <span id="rrletterError1<?= $chapter->RGuide3_id?>" style="display:block;color:red;"></span>
                                    </div>
                                    <script>
                                        function validateRRLetter1<?= $chapter->RGuide3_id?>(event) {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('rrletterError1<?= $chapter->RGuide3_id?>');
                                            if (!file.type.match('pdf')) {
                                                errorElement.textContent = 'File is not a PDF.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            if (file.size > 500 * 1024) {
                                                errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }
                                    </script>
                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit"  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </td>                 
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

    <script
        src="<?= base_url('assets/js/Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo3_view.js'); ?>"></script>

<?= $this->endSection();?>