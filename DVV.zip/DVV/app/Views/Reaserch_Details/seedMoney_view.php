<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Seed Money by the College for Research </h1>
<div class="container-fluid border border-info-subtle my-3" style="display:none" id="seedMony">
		
		<form class="row g-3 my-3" method="POST" action="<?= base_url('saveProjectMoney')?>" enctype="multipart/form-data" >
        <div  id="form-container" >

            <div class="form-fields">
    
                <div class="row mx-2 pt-3 pb-3 border border-2">

            <div class="col-md-4 my-3">
                <label class="form-label" for="reason">If seed money received for Project : <label
                        style="color: red;">*</label></label>
                <select id="seed" name="yes-no" onclick="show()"  class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option  value="Yes" >Yes</option>
                    <option  value="No" >No</option>
                </select>
            </div>
            <script>
                 function show() {
                    var type = document.getElementById("seed");
                    if (type.value == "Yes") {
                        document.getElementById("text-input1").style.display="block";
                    }
                    else {
                        document.getElementById("text-input1").style.display="none";
                    }
                }

            </script>
           

            <div class="col-md-4  my-3">
              <label class="form-label">Title of Research Project : <label style="color: red;">*</label></label>
              <input id="researchname" type="text" class="form-control" name="researchname" oninput="validateRPName()" autocomplete="off" required>
              <span id="researchError" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>

            <div class="col-md-4  my-3">
              <label class="form-label">Duration : <label style="color: red;">* (in Years)</label></label>
              <input id="duration" type="tel" class="form-control" name="duration" min="1" max="5" maxlength="1" autocomplete="off" required>
              <span id = "durationError" style="display:none;color:red;">Please Enter a Valid Duration of Project between 1 to 5.</span>
            </div>

       

            <div class="col-md-4  my-3" id="text-input1" style="display:none;">
                <label class="form-label">Amount : <label style="color: red;">* (in INR)</label></label>
                <input id="amount" type="tel" class="form-control" name="amount" min="20000" max="599999" autocomplete="off" maxlength="6" >
                <span id="amountError" style="color:red; display:none;">Please enter a valid amount between 20000 and 599999.</span>
            </div>
            
            <div class="col-md-4  my-3">
              <label for="year-of-award" class="form-label">Date of Sanction : <label style="color: red;">*</label></label>
              <input type="date" id="awarddate" name="awarddate" class="form-control"  min="2022-01-01" required>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label" for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
                <input id="sanctiondocument" type="file" class="form-control" name="sletter" accept=".pdf" onchange="validateSanction(event)" required>
                <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
            </div>
            </div>
            </div>
            </div>
            
            <div class="col-12 text-center">
                  <input type="submit" class="btn btn-outline-primary" value="Submit">
            </div>
		</form>
</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>


<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">If seed money received for Project?</th>
                <th scope="col">Title of Research Project</th>
                <th scope="col">Duration</th>
                <th scope="col">Date of Award</th>
                <th scope="col">Upload Sanction Letter</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
              $row=1;
            foreach($documents as $doc):
                $book=  $doc->RMoneyInfo;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Sanction_Letter;
            ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"> 
                    <?php if($chapter->If_Send_Money_Received_For_Project === "Yes"):?>
                        <?= $chapter->Amount?> 
                    <?php else:?>
                        <?= $chapter->If_Send_Money_Received_For_Project?> 
                    <?php endif;?>
                </td>
                <td class="text-center"><?= $chapter->Title_Of_Research_Project?> </td>
                <td class="text-center"> <?= $chapter->Duration?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Award?> </td>
                <td class="text-center"> 
                    <?php if(!empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                </td>
              
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>

                    <form action="<?= base_url('deleteProjectMoney')?>" method="post">
                         <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->RMoneyInfo_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                      
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" ><br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RMoneyInfo_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RMoneyInfo_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Seed Money by the College for Research</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateProjectMoney')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                <div class="md-4" style="display:none;">
                                    <label class="form-label">ResearchPublication id: <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RMoneyInfo_id?>" >
                                    <span style="display:none;color:red;">Please enter a valid title.</span>
                                </div>
                                <div class="md-4  my-3">
                                    <label class="form-label" for="reason">If seed money received for Project : <label style="color: red;">*</label></label>
                                    <select id="seed1<?= $chapter->RMoneyInfo_id?>" name="yes-no" onclick="show1<?= $chapter->RMoneyInfo_id?>()"  class="form-control">
                                        <option value="<?= $chapter->If_Send_Money_Received_For_Project?>"><?= $chapter->If_Send_Money_Received_For_Project?></option>
                                        <option  value="Yes" >Yes</option>
                                        <option  value="No" >No</option>
                                    </select>
                                </div>
                                <script>
                                    function show1<?= $chapter->RMoneyInfo_id?>() {
                                        var type = document.getElementById("seed1<?= $chapter->RMoneyInfo_id?>");
                                        if (type.value == "Yes") {
                                            document.getElementById("text-input1<?= $chapter->RMoneyInfo_id?>").style.display="block";
                                        }
                                        else {
                                            document.getElementById("text-input1<?= $chapter->RMoneyInfo_id?>").style.display="none";
                                        }
                                    }

                                 </script>

                                <div class="md-4  my-3" id="text-input1<?= $chapter->RMoneyInfo_id?>" style="display:none;">
                                    <label class="form-label">Amount : <label style="color: red;">* (in INR)</label></label>
                                    <input id="amount1<?= $chapter->RMoneyInfo_id?>" type="tel" class="form-control" name="amount" value="<?= $chapter->Amount?>" min="20000" max="599999" autocomplete="off" maxlength="6"  >
                                    <span id="amountError1<?= $chapter->RMoneyInfo_id?>" style="display:none;color:red;">Please enter a valid amount between 20000 and 599999.</span>
                                </div>

                                
                                <script>
                                    function validateAmount<?= $chapter->RMoneyInfo_id?>(inputElement) {
                                        var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
                                        inputElement.value = sanitizedValue; // Set sanitized value back into the input field

                                        var enteredValue = parseInt(sanitizedValue);
                                        var minLimit = parseInt(inputElement.getAttribute("min"));
                                        var maxLimit = parseInt(inputElement.getAttribute("max"));

                                        // Check if the entered value is within the specified limits
                                        if (sanitizedValue.length === 0) {
                                            document.getElementById("amountError1<?= $chapter->RMoneyInfo_id?>").style.display = "none"; // Hide the error message
                                            inputElement.setCustomValidity(""); // Clear custom validity
                                        } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                            document.getElementById("amountError1<?= $chapter->RMoneyInfo_id?>").style.display = "block";
                                            inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                        } else {
                                            document.getElementById("amountError1<?= $chapter->RMoneyInfo_id?>").style.display = "none";
                                            inputElement.setCustomValidity("");
                                        }
                                    }

                                    // Add an event listener to the input field
                                    document.getElementById("text-input1<?= $chapter->RMoneyInfo_id?>").addEventListener("input", function () {
                                        validateAmount<?= $chapter->RMoneyInfo_id?>(this.querySelector('input'));
                                    });
                                </script>

                                

                                    <div class="md-4  my-3">
                                        <label class="form-label">Title of Research Project : <label style="color: red;">*</label></label>
                                        <input id="researchname1<?= $chapter->RMoneyInfo_id?>" type="text" value="<?= $chapter->Title_Of_Research_Project?>" class="form-control" name="researchname" oninput="validateRPName1<?= $chapter->RMoneyInfo_id?>()" autocomplete="off" required>
                                        <span id="researchError1<?= $chapter->RMoneyInfo_id?>" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                        </div>

                                        <script>
                                            function validateRPName1<?= $chapter->RMoneyInfo_id?>() {
                                                var regName = /^[a-zA-Z ]+$/;
                                                var name = document.getElementById('researchname1<?= $chapter->RMoneyInfo_id?>').value;
                                                var error = document.getElementById("researchError1<?= $chapter->RMoneyInfo_id?>");

                                                var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

                                                var words = sanitizedName.split(" ");
                                                var capitalizedWords = words.map(function(word) {
                                                    return word.charAt(0).toUpperCase() + word.slice(1);
                                                });

                                                var finalresearchname1 = capitalizedWords.join(" ");
                                                document.getElementById('researchname1<?= $chapter->RMoneyInfo_id?>').value = finalresearchname1;

                                                if (finalresearchname1.length === 0 || regName.test(finalresearchname1)) {
                                                    error.style.display = "none";
                                                } else {
                                                    error.style.display = "block";
                                                }
                                                }

                                                // Attach event listener using JavaScript
                                                document.getElementById('researchname1').addEventListener('input', validateRPName1);

                                        </script>

                                        <div class="md-4  my-3">
                                            <label class="form-label">Duration : <label style="color: red;">* (in Years)</label></label>
                                            <input id="duration1<?= $chapter->RMoneyInfo_id?>" type="tel" class="form-control" value="<?= $chapter->Duration?>" name="duration" min="1" max="5" maxlength="1" autocomplete="off" required>
                                            <span id = "durationError1<?= $chapter->RMoneyInfo_id?>" style="display:none;color:red;">Please Enter a Valid Duration of Project between 1 to 5.</span>
                                        </div>

                                        <script>
                                            function validateDuration1<?= $chapter->RMoneyInfo_id?>(inputElement) {
                                            var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
                                            inputElement.value = sanitizedValue; // Set sanitized value back into the input field

                                            var enteredValue = parseInt(sanitizedValue);
                                            var minLimit = parseInt(inputElement.getAttribute("min"));
                                            var maxLimit = parseInt(inputElement.getAttribute("max"));

                                            // Check if the entered value is within the specified limits
                                            if (sanitizedValue.length === 0) {
                                                document.getElementById("durationError1<?= $chapter->RMoneyInfo_id?>").style.display = "none"; // Hide the error message
                                                inputElement.setCustomValidity(""); // Clear custom validity
                                            } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                                document.getElementById("durationError1<?= $chapter->RMoneyInfo_id?>").style.display = "block";
                                                inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                            } else {
                                                document.getElementById("durationError1<?= $chapter->RMoneyInfo_id?>").style.display = "none";
                                                inputElement.setCustomValidity("");
                                            }
                                            }

                                            // Add an event listener to the input field
                                            document.getElementById("duration1<?= $chapter->RMoneyInfo_id?>").addEventListener("input", function () {
                                            validateDuration1<?= $chapter->RMoneyInfo_id?>(this);
                                            });
                                        </script>
                                        
                                        
                                        <div class="md-4  my-3">
                                            <label for="year-of-award" class="form-label">Date of Sanction : <label style="color: red;">*</label></label>
                                            <input type="date" id="awarddate1<?= $chapter->RMoneyInfo_id?>" name="awarddate" class="form-control" value="<?= $chapter->Year_Of_Award?>"  min="2022-01-01" >
                                        </div>

                                        <script>
                                            function setupDateValidation1<?= $chapter->RMoneyInfo_id?>() {
                                                // Validation for the Date
                                                const dobDateInput = document.getElementById('awarddate1<?= $chapter->RMoneyInfo_id?>');

                                                // Set the minimum date allowed (2022-01-01 in this case)
                                                const minDate = new Date('2022-01-01');

                                                // Function to set the maximum date allowed to the current date
                                                function setMaxDate1<?= $chapter->RMoneyInfo_id?>() {
                                                    const today = new Date();
                                                    const maxDate = today.toISOString().split('T')[0]; // Format as "YYYY-MM-DD"
                                                    dobDateInput.max = maxDate;
                                                }

                                                // Call the setMaxDate1 function to set the maximum date initially
                                                setMaxDate1<?= $chapter->RMoneyInfo_id?>();

                                                // Attach an event listener to the input element to dynamically update the maximum date
                                                dobDateInput.addEventListener('input', setMaxDate1<?= $chapter->RMoneyInfo_id?>);

                                                // Function to validate the selected date on form submission
                                                function validateRegDate1<?= $chapter->RMoneyInfo_id?>() {
                                                    const selectedDate = new Date(dobDateInput.value);
                                                    if (selectedDate < minDate) {
                                                        alert('Please select a date on or after 2022-01-01.');
                                                        return false;
                                                    }
                                                    return true;
                                                }

                                                // Attach an event listener to the form to validate the date on form submission
                                                const form = document.querySelector('form');
                                                form.addEventListener('submit', validateRegDate1<?= $chapter->RMoneyInfo_id?>);
                                            }

                                            // Call the setupDateValidation function to set up the validation for this specific element
                                            setupDateValidation1<?= $chapter->RMoneyInfo_id?>();

                                        </script>

                                        <div class="md-4  my-3">
                                            <label class="form-label" for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
                                            <input id="sanctiondocument<?= $chapter->RMoneyInfo_id?>" type="file" class="form-control" name="sletter" accept=".pdf" onchange="validateSanction<?= $chapter->RMoneyInfo_id?>(event)" >
                                            <span id="sanctiondocumentError<?= $chapter->RMoneyInfo_id?>" name="sanctiondocument" style="color:red;"></span>
                                        </div>

                                        <script>
                                            function validateBeneficiary<?= $chapter->RMoneyInfo_id?>"(event) {
                                                const file = event.target.files[0];
                                                const errorElement = document.getElementById('beneficiaryError<?= $chapter->RMoneyInfo_id?>"');
                                                if (!file.type.match('pdf')) {
                                                    errorElement.textContent = 'File is not a PDF.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                if (file.size > 500 * 1024) {
                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                // If the file is valid, clear the error message
                                                errorElement.textContent = '';
                                            }
                                        </script>

                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('seedMony');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>

  <script src="<?php echo base_url('assets/js/Reaserch_Details/seedMoney_view.js'); ?>"></script>

<?= $this->endSection();?>
