<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center">Fellowship/Financial Support  </h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="fellowship">
    <form class="row g-3 my-3" method="POST" action="<?= base_url('saveProjectFollowship')?>" enctype="multipart/form-data">
    <div  id="form-container" >

        <div class="form-fields">
    
            <div class="row mx-2 pt-3 pb-3 border border-2">
        <div class="col-md-4 my-3">
            <label class="form-label">Awarding Agency : <label style="color: red;">*</label></label>
            <input id="AwardingAgency" type="text" class="form-control" name="awardingAgency" oninput="validateAgency()" autocomplete="off" required>
            <span id="AwardingAgencyError" style="display:none;color:red;">Please Enter a Valid Information.</span>
        </div>

        <div class="col-md-4 my-3" id="year1" style="display:block;">
          <label class="form-label">Year of Award : <label style="color: red;">*</label></label>
          <input type="text" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" autocomplete="off" required>
          <span id="error-message" style="color: red; display: none;">Please enter a valid Year.</span>
       </div>

        <div class="col-md-4 my-3">
            <label class="form-label">Name of Award/Fellowship : <label style="color: red;">*</label></label>
            <input type="text" class="form-control" id="Awardname" name="AwardName" placeholder="" oninput="validateAwardName()" autocomplete="off" required>
            <span id="AwardNameError" style="display:none;color:red;">Please enter a valid Name of Award/Fellowship.</span>
        </div>

         
        <div class="col-md-4 my-3">
            <label class="form-label" for="reason">Fellowship/Financial Support Status : <label
                    style="color: red;">*</label></label>
            <select id="reason" onclick="showOther()" name="fstatus"  class="form-control">
                <option disabled selected hidden>--- Select one ---</option>
                <option  value="National" >National</option>
                <option  value="International">International</option>
                <option value="Other">Other</option>
            </select>
            <script>
                function showOther() {
                var type = document.getElementById("reason");
                if (type.value == "Other") 
                {
                    document.getElementById("other").style.display="block";
                }
                else 
                {
                    document.getElementById("other").style.display="none";
                } 
                }
            </script>
        </div>

        <div class="col-md-4 my-3" id="other" style="display:none;">
            <label class="form-label">Other: <label style="color: red;">*</label></label>
            <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" autocomplete="off" oninput="validateOther()">
            <span id="otherErrror" style="display:none;color:red;">Please enter a valid Name of Award/Fellowship.</span>
        </div>

      
        <div class="col-md-4 my-3">
            <label class="col-form-label col-sm-2 pt-0">Type:</label>
            <div class="col-sm-7">
                <div class="form-label">
                    <input class="form-check-input" type="checkbox" name="studies1" id="checkbox1" value="For Advanced Studies">
                    <label class="form-check-label" for="checkbox1">For Advanced Studies</label>
                </div>
                <div class="form-label">
                    <input class="form-check-input" type="checkbox" name="studies2" id="checkbox2" value="For Research">
                    <label class="form-check-label" for="checkbox2">For Research</label>
                </div>
            </div>
        </div>

        <div class="col-md-4 my-3">
          <label for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
          <input id="sanctiondocument" type="file" class="form-control" name="sletter" accept=".pdf" onchange="validateSanction(event)" required>
          <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label" for="reason">Have you received travel grant : <label
                    style="color: red;">*</label></label>
            <select id="seed" name="grant" onclick="show()"  class="form-control">
                <option disabled selected hidden>--- Select one ---</option>
                <option  value="Yes" >Yes</option>
                <option  value="No" >No</option>
            </select>
        </div>
            <script>
                 function show() {
                    var type = document.getElementById("seed");
                    if (type.value == "Yes") {
                        document.getElementById("text-input").style.display="block";
                    }
                    else {
                        document.getElementById("text-input").style.display="none";
                    }
                }

            </script>

        

        <div class="col-md-4 my-3" id="text-input" style="display:none;">
            <label class="form-label">Amount : <span style="color: red;">* (in INR)</span></label>
            <input id="funds-id" type="text" class="form-control" name="amount" autocomplete="off" min="1000" max="100000" maxlength="6">
            <span id="error-message2" style="color:red;"></span>
        </div>
        </div>
        </div>
        </div>

        <div class="col-12 text-center">
            <input type="submit" class="btn btn-outline-primary" value="Submit">
        </div>
    </form>
</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>


<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Awarding Agency</th>
                <th scope="col">Year of Award</th>
                <th scope="col">Name of Award/Fellowship</th>
                <th scope="col">Fellowship/Financial Support Status</th>
                <th scope="col">Type</th>
                <th scope="col">Have you received travel grant</th>
                <th scope="col">Upload Sanction Letter</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->RFollow;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Sanction_Latter;
                $test1 = $chapter->Type1;
                $test2 = $chapter->Type2;

                $type = $test1 ." ,<br>".$test2;
            ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Awarding_Agency?> </td>
                <td class="text-center"><?= $chapter->Year_Of_Award?> </td>
                <td class="text-center"> <?= $chapter->Name_Of_Award_Fellowship?> </td>
                <td class="text-center"> <?= $chapter->Fellowship_Financial_Support_Status?> </td>
                <td class="text-center"> <?= $type?> </td>
                <td class="text-center">
                    <?php if($chapter->Have_You_Received_Travel_Grant === "Yes"):?> 
                        <?= $chapter->Amount?> 
                    <?php else:?>
                        <?= $chapter->Have_You_Received_Travel_Grant?> 
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <?php if(!empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>

                    <form action="<?= base_url('deleteProjectFollowship')?>" method="post">
                       <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->RFollow_id?>">
                       <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br> 
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->RFollow_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->RFollow_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Fellowship/Financial Support </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateProjectFollowship')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">

                                <div class="md-4 my-3" style="display:none;">
                                    <label class="form-label">RFollow id : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->RFollow_id?>" >
                                    <span style="display:none;color:red;">Please enter a valid title.</span>
                                </div>
                                    
                                <div class="md-4 my-3">
                                    <label class="form-label">Awarding Agency: <label style="color: red;">*</label></label>
                                    <input id="UpdateAwardingAgency<?= $chapter->RFollow_id?>" type="text" class="form-control" name="awardingAgency" value="<?= $chapter->Awarding_Agency?>" oninput="validateUpdateAgency<?= $chapter->RFollow_id?>()" >
                                    <span id="UpdateAwardingAgencyError<?= $chapter->RFollow_id?>" style="display:none;color:red;">Please Enter a Valid Information.</span>
                                </div>
                                <script>
                                    function validateUpdateAgency<?= $chapter->RFollow_id?>() {
                                        var regName = /^[a-zA-Z ]+$/;
                                        var name = document.getElementById('UpdateAwardingAgency<?= $chapter->RFollow_id?>').value;
                                        var error = document.getElementById("UpdateAwardingAgencyError<?= $chapter->RFollow_id?>");

                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });

                                        var finalUpdateAwardingAgency = capitalizedWords.join(" ");
                                        document.getElementById('UpdateAwardingAgency<?= $chapter->RFollow_id?>').value = finalUpdateAwardingAgency;

                                        if (finalUpdateAwardingAgency.length === 0 || regName.test(finalUpdateAwardingAgency)) {
                                            error.style.display = "none";
                                        } else {
                                            error.style.display = "block";
                                        }
                                    }

                                    // Attach event listener using JavaScript
                                    document.getElementById('UpdateAwardingAgency<?= $chapter->RFollow_id?>').addEventListener('input', validateUpdateAgency<?= $chapter->RFollow_id?>);
                                </script>


                                <div class="md-4 my-3" id="year1<?= $chapter->RFollow_id?>" >
                                    <label class="form-label">Year of Award : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="datepicker" value="<?= $chapter->Year_Of_Award?>" id="datepicker<?= $chapter->RFollow_id?>" placeholder="yyyy" autocomplete="off">
                                    <span id="error-message" style="color: red; display: none;">Please enter a valid Year.</span>
                                </div>
                                <script>
                                    $(document).ready(function () {
                                        var currentYear = new Date().getFullYear();
                                        var minYear = 1992;

                                        function validateYear(year) {
                                            return year >= minYear && year <= currentYear;
                                        }

                                        function showError() {
                                            $("#error-message").show();
                                        }

                                        function hideError() {
                                            $("#error-message").hide();
                                        }

                                        $("#datepicker").datepicker({
                                            format: "yyyy",
                                            viewMode: "years",
                                            minViewMode: "years",
                                            startDate: new Date(minYear, 0, 1), // January 1st of 1983
                                            endDate: new Date(currentYear, 0, 1), // January 1st of the current year
                                            autoclose: true
                                        });

                                        $("#datepicker").on("keyup change", function () {
                                            var enteredYear = parseInt($(this).val());
                                            if (!$(this).val() || isNaN(enteredYear) || !validateYear(enteredYear)) {
                                                showError();
                                            } else {
                                                hideError();
                                            }
                                        });

                                        $("#datepicker").on("blur", function () {
                                            // Hide the error message when the input field loses focus (blurred) and it's empty
                                            if ($(this).val().trim() === '') {
                                                hideError();
                                            }
                                        });
                                    });
                                </script>

                                <div class="md-4 my-3">
                                    <label class="form-label">Name of Award/Fellowship: <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" id="Awardname" name="AwardName" value="<?= $chapter->Name_Of_Award_Fellowship?>" placeholder="" oninput="validateAwardName()" required>
                                    <span id="AwardNameError" style="display:none;color:red;">Please enter a valid Name of Award/Fellowship.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label" for="reason">Fellowship/Financial Support Status : <label
                                            style="color: red;">*</label></label>
                                    <select id="reason<?= $chapter->RFollow_id?>" onclick="showOther<?= $chapter->RFollow_id?>()"name="fstatus"  class="form-control">
                                        <option  selected hidden value="<?= $chapter->Fellowship_Financial_Support_Status?>"><?= $chapter->Fellowship_Financial_Support_Status?></option>
                                        <option  value="National" >National</option>
                                        <option  value="International">International</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <div class="md-4" id="other<?= $chapter->RFollow_id?>" style="display:none;">
                                        <label class="form-label">Other: <label style="color: red;">*</label></label>
                                        <input id="otherJournal" type="text" class="form-control"  name="other" value="<?= $chapter->Fellowship_Financial_Support_Status?>" autocomplete="off" oninput="validateOther()">
                                        <span id="otherErrror" style="display:none;color:red;"></span>
                                    </div>

                                    <script>
                                        function showOther<?= $chapter->RFollow_id ?>() {
                                        var type = document.getElementById("reason<?= $chapter->RFollow_id?>");
                                        if (type.value == "Other") 
                                        {
                                            document.getElementById("other<?= $chapter->RFollow_id?>").style.display="block";
                                        }
                                        else 
                                        {
                                            document.getElementById("other<?= $chapter->RFollow_id?>").style.display="none";
                                        } 
                                        }
                                    </script>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="col-form-label col-sm-2 pt-0">Type:</label>
                                    <div class="col-sm-7">
                                        <div class="form-label">
                                            <input class="form-check-input" type="checkbox"  name="studies1" id="checkbox1"  value="<?=  $test1?>"
                                                <?php if(!empty($test1)):?>
                                                checked
                                                <?php endif;?>>
                                            <label class="form-check-label" for="checkbox1">For Advanced Studies</label>
                                        </div>
                                        <div class="form-label">
                                            <input class="form-check-input" type="checkbox" name="studies2" id="checkbox2" value="For Research"
                                            <?php if(!empty($test2)):?>
                                                checked
                                                <?php endif;?>>
                                            <label class="form-check-label" for="checkbox2">For Research</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Sanction Letter : <label style="color: red;">* (.pdf only)</label></label>
                                    <input id="sanctiondocument" type="file" class="form-control" name="sletter"   accept=".pdf" onchange="validateSanction(event)" >
                                    <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label" for="reason">Have you received travel grant : <label
                                            style="color: red;">*</label></label>
                                    <select id="seed1<?= $chapter->RFollow_id?>" name="grant" onclick="show1<?= $chapter->RFollow_id?>()"  class="form-control">
                                        <option value="<?= $chapter->Have_You_Received_Travel_Grant?>"><?= $chapter->Have_You_Received_Travel_Grant?></option>
                                        <option  value="Yes" >Yes</option>
                                        <option  value="No" >No</option>
                                    </select>
                                </div>
                                    <script>
                                        function show1<?= $chapter->RFollow_id?>() {
                                            var type = document.getElementById("seed1<?= $chapter->RFollow_id?>");
                                            if (type.value == "Yes") {
                                                document.getElementById("text-input1<?= $chapter->RFollow_id?>").style.display="block";
                                            }
                                            else {
                                                document.getElementById("text-input1<?= $chapter->RFollow_id?>").style.display="none";
                                            }
                                        }

                                    </script>

                                <div class="md-4 my-3" id="text-input1<?= $chapter->RFollow_id?>" style="display:none;">
                                    <label class="form-label">Amount: <label style="color: red;">* (in INR)</label></label>
                                    <input id="funds-id" type="text" class="form-control" name="amount" value="<?= $chapter->Amount?>" autocomplete="off" min="1000" max="100000" maxlength="6">
                                    <span id="error-message2" style="display:none;color:red;">Please enter a valid amount between 1000 and 100000.</span>
                                </div>
                            </div>
                        </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('fellowship');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>

<script src="<?php echo base_url('assets/js/Reaserch_Details/reaserchProjectFollwship_view.js'); ?>"></script>


<?= $this->endSection();?>
