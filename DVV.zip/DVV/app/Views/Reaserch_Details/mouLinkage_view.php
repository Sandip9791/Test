<?= $this->extend('Layouts/base'); ?>

<?= $this->section("Content"); ?>

<h1 class="text-center my-3">MOU and Linkages</h1>

<div class="container-fluid border border-primary-subtle my-4" style="display:none" id="MOU">
  <form class=" g-3 my-3" method="post" action="<?= base_url('saveMou_Linkage') ?>" enctype="multipart/form-data">
    <div class="row mx-2 pt-3 pb-3 border border-2">

        <div class="col-md-4 my-3">
            <label class="form-label">Name of the Organisation/Industry/Institute : <label style="color: red;">*</label></label>
            <input id="orgname" type="text" class="form-control"  name="orgname" autocomplete="off" oninput="validateOrgname()" required>
            <span id="orgnameError" style="display:none;color:red;">Please Enter a Valid Information.</span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label" for="reason">Place : <label style="color: red;">*</label></label>
            <select id="seed" name="Place"   class="form-control">
                <option disabled selected hidden>--- Select one ---</option>
                <option  value="India">India</option>
                <option  value="Abroad">Abroad</option>
            </select>
        </div>

      <div class="col-md-4 my-3">
        <label class="form-label">Type of Collaboration : <label style="color: red;">*</label></label>
          <select name="Colaboration" onclick="showOther()" id="Colaboration" class="form-control" required>
            <option disabled selected hidden>--- Select one ---</option>
            <option value="Internship">Internship</option>
            <option value="On Job Training">On Job Training</option>
            <option value="Project Work">Project Work</option>
            <option value="Student Faculty Exchange">Student Faculty Exchange</option>
            <option value="Collaborative Research">Collaborative Research</option>
            <option value="Other">Other</option>
          </select>
        </div>
      
 
        <div class="col-md-4 my-3" id="other" style="display:none;">
            <label class="form-label">Other: <label style="color: red;">*</label></label>
            <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOther()">
            <span id="otherErrror" style="display:none;color:red;">Please enter a valid Journal Name.</span>
        </div>  

        <div class="col-md-4 my-3">
            <label for="from" class="form-label">From : <label style="color: red;">*</label></label>
            <input type="date" class="form-control" id="fromdate" name="fdate" placeholder="dd-mm-yyyy" min="2022-01-01" onchange="enableToDate()" required>
        </div>

        <div class="col-md-4">
            <label for="to" class="form-label">To : <label style="color: red;">*</label></label>
            <input type="date" class="form-control" id="todate" name="tdate" placeholder="dd-mm-yyyy" disabled>
        </div>

 
        <div class="col-md-4 my-3">
            <label class="form-label">Document of Activity : <label style="color: red;">* (.pdf only)</label></label>
            <input id="activitydoc" type="file" class="form-control" name="adocument" accept=".pdf" onchange="validateAcitvityDoc(event)" required>
            <span id="activitydocError" style="display:block;color:red;"></span>
        </div>
        
        <br><br><br><br>

        <div class="col-md-4">
            <label class="form-label">Number of Beneficiary:<label style="color: red;">*</label></label>
            <input id="beneficiary" type="tel" name="Beneficiary" min="1" max="150" class="form-control" autocomplete="off" maxlength="3" required>
            <span id="beneficiaryError" style="color: red; display: none;">Please enter a valid amount between 1 and 150.</span>
        </div>

 
        <p style="color: red;"><b><strong>Note:- Select only .pdf files under 500kb.</strong></b></p>

        <div class="col-md-4 my-3">
            <label class="form-label">Upload the Document : <label style="color: red;">*</label><br></label>
            <input type="file" id="Udocument0" class="form-control" name="Udocument0" accept=".pdf" onchange="validateUdocument(event)" disabled>
            <span id="UdocumentError0" style="display:block;color:red;"></span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label"><label style="color: red;"></label><br></label>
            <input type="file" id="Udocument1" class="form-control" name="Udocument1" accept=".pdf" onchange="validateUdocument1(event)" disabled>
            <span id="UdocumentError1" style="display:block;color:red;"></span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label"><label style="color: red;"></label><br></label>
            <input type="file" id="Udocument2" class="form-control" name="Udocument2" accept=".pdf" onchange="validateUdocument2(event)" disabled>
            <span id="UdocumentError2" style="display:block;color:red;"></span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label"><label style="color: red;"></label><br></label>
            <input type="file" id="Udocument3" class="form-control" name="Udocument3" accept=".pdf" onchange="validateUdocument3(event)" disabled>
            <span id="UdocumentError3" style="display:block;color:red;"></span>
        </div>

        <div class="col-md-4 my-3">
            <label class="form-label"><label style="color: red;"></label><br></label>
            <input type="file" id="Udocument4" class="form-control" name="Udocument4" accept=".pdf" onchange="validateUdocument4(event)" disabled>
            <span id="UdocumentError4" style="display:block;color:red;"></span>
        </div>
        
        </div> 
        <div class="col-md-12 my-3 text-center">
            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </div>

    </form>
    </div>


<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>



<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Name of the Organisation/Industry/Institute </th>
                <th scope="col">Place</th>
                <th scope="col">Type of Collaboration </th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Document of Activity </th>
                <th scope="col">Number of Beneficiary</th>
                <th scope="col">Upload the Document</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if (isset($documents)):
            $row = 1;
            foreach ($documents as $doc):
                $book = $doc->MOU_Linkage;
                ?>
                <tbody>
                    <?php
                    foreach ($book as $chapter):
                        $cover = $chapter->Document_of_Activity ;
                        $content1 = $chapter->Upload_Document1;
                        $content2 = $chapter->Upload_Document2;
                        $content3 = $chapter->Upload_Document3;
                        $content4 = $chapter->Upload_Document4;
                        $content5 = $chapter->Upload_Document5;

                        ?>
                        <tr>
                            <th class="text-center" scope="row"><?= $row++; ?></th>
                            <td class="text-center">
                                <?= $chapter->Name_Organization ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Place?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Name_Colaborations ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->From ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->To ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->No_Beneficiary ?>
                            </td>
                            <td class="text-center">
                                <?php if(!empty($cover)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if(!empty($content1)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$content1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                            <p class="my-3"></p>

                                <?php if(!empty($content2)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$content2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                             <p class="my-3"></p>

                                <?php if(!empty($content3)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$content3;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                            <p class="my-3"></p>

                                <?php if(!empty($content4)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$content4;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                             <p class="my-3"></p>

                                <?php if(!empty($content5)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Research/').$content5;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>

                            <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif') ?>"><br>
                                <form action="<?= base_url('deleteMou_Linkage') ?>" method="post">
                                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber"
                                        readonly value="<?= $chapter->MOU_Linkage_id ?>">
                                    <input class="btn btn-danger" type="submit" value="Delete">
                                </form>
                            </td>
                            <td>
                                <div class="text-center">
                                    <img src="<?= base_url('assets/images/iconsUpdate.gif') ?>"><br>
                                    <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?= $chapter->MOU_Linkage_id ?>"
                                        data-bs-whatever="@mdo">Update</button>
                                </div>


                                <div class="modal fade" id="exampleModal<?= $chapter->MOU_Linkage_id ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">MOU and Linkages</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= base_url('updateMou_Linkage') ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="md-4 my-3" style="display:none;">
                                                                <label class="form-label">BookAndChapter id : <label
                                                                        style="color: red;">*</label></label>
                                                                <input type="text" class="form-control" name="srnumber" readonly
                                                                    value="<?= $chapter->MOU_Linkage_id ?>">
                                                                <span style="display:none;color:red;">Please enter a valid
                                                                    title.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Name of the Organisation/Industry/Institute : <label style="color: red;">*</label></label>
                                                                <input id="orgname1<?= $chapter->MOU_Linkage_id ?>" type="text" class="form-control"  name="orgname" value="<?= $chapter->Name_Organization ?>" autocomplete="off" oninput="validateOrgname1<?= $chapter->MOU_Linkage_id ?>()" >
                                                                <span id="orgnameError1<?= $chapter->MOU_Linkage_id ?>" style="display:none;color:red;">Please Enter a Valid Information.</span>
                                                            </div>

                                                            <script>
                                                                function validateOrgname1<?= $chapter->MOU_Linkage_id ?>() {
                                                                    var regName = /^[a-zA-Z ]+$/;
                                                                    var name = document.getElementById('orgname1<?= $chapter->MOU_Linkage_id ?>').value;
                                                                    var error = document.getElementById("orgnameError1<?= $chapter->MOU_Linkage_id ?>");
                                                                
                                                                    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                                                
                                                                    var words = sanitizedName.split(" ");
                                                                    var capitalizedWords = words.map(function(word) {
                                                                        return word.charAt(0).toUpperCase() + word.slice(1);
                                                                    });
                                                                
                                                                    var finalorgname = capitalizedWords.join(" ");
                                                                    document.getElementById('orgname1<?= $chapter->MOU_Linkage_id ?>').value = finalorgname;
                                                                
                                                                    if (finalorgname.length === 0 || regName.test(finalorgname)) {
                                                                        error.style.display = "none";
                                                                    } else {
                                                                        error.style.display = "block";
                                                                    }
                                                                }
                                                                
                                                                // Attach event listener using JavaScript
                                                                document.getElementById('orgname1<?= $chapter->MOU_Linkage_id ?>').addEventListener('input', validateOrgname1<?= $chapter->MOU_Linkage_id ?>);
  
                                                            </script>


                                                            <div class="md-4 my-3">
                                                                <label class="form-label" for="reason">Place : <label style="color: red;">*</label></label>
                                                                <select id="seed" name="Place"   class="form-control">
                                                                    <option value="<?= $chapter->Place ?>"><?= $chapter->Place ?></option>
                                                                    <option  value="India">India</option>
                                                                    <option  value="Abroad">Abroad</option>
                                                                </select>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Type of Collaboration : <label style="color: red;">*</label></label>
                                                                <select name="Colaboration" onclick="showOther<?= $chapter->MOU_Linkage_id ?>()" id="Colaboration<?= $chapter->MOU_Linkage_id ?>" class="form-control" required>
                                                                    <option  selected hidden value="<?= $chapter->Name_Colaborations ?>"><?= $chapter->Name_Colaborations ?></option>
                                                                    <option value="Internship">Internship</option>
                                                                    <option value="On Job Training">On Job Training</option>
                                                                    <option value="Project Work">Project Work</option>
                                                                    <option value="Student Faculty Exchange">Student Faculty Exchange</option>
                                                                    <option value="Collaborative Research">Collaborative Research</option>
                                                                    <option value="Other">Other</option>
                                                                </select>
                                                            </div>

                                                            <div class="md-4 my-3" id="other<?= $chapter->MOU_Linkage_id ?>" style="display:none;">
                                                                <label class="form-label">Other: <label style="color: red;">*</label></label>
                                                                <input id="otherUpdateJournal<?= $chapter->MOU_Linkage_id ?>" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOtherUpdate<?= $chapter->MOU_Linkage_id ?>()">
                                                                <span id="otherUpdateErrror<?= $chapter->MOU_Linkage_id ?>" style="display:none;color:red;"></span>
                                                            </div>

                                                            <script>
                                                                function showOther<?= $chapter->MOU_Linkage_id ?>() {
                                                                    var type = document.getElementById("Colaboration<?= $chapter->MOU_Linkage_id ?>");
                                                                        if (type.value == "Other") 
                                                                        {
                                                                            document.getElementById("other<?= $chapter->MOU_Linkage_id ?>").style.display="block";
                                                                        }
                                                                        else 
                                                                        {
                                                                            document.getElementById("other<?= $chapter->MOU_Linkage_id ?>").style.display="none";
                                                                        } 
                                                                    }


                                                                function validateOtherUpdate<?= $chapter->MOU_Linkage_id ?>() {
                                                                    var regName = /^[a-zA-Z ]+$/;
                                                                    var name = document.getElementById('otherUpdateJournal<?= $chapter->MOU_Linkage_id ?>').value;
                                                                    var error = document.getElementById("otherUpdateErrror<?= $chapter->MOU_Linkage_id ?>");

                                                                    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');

                                                                    var words = sanitizedName.split(" ");
                                                                    var capitalizedWords = words.map(function(word) {
                                                                        return word.charAt(0).toUpperCase() + word.slice(1);
                                                                    });

                                                                    var finalotherUpdateJournal = capitalizedWords.join(" ");
                                                                    document.getElementById('otherUpdateJournal<?= $chapter->MOU_Linkage_id ?>').value = finalotherUpdateJournal;

                                                                    if (finalotherUpdateJournal.length === 0 || regName.test(finalotherUpdateJournal)) {
                                                                        error.style.display = "none";
                                                                    } else {
                                                                        error.style.display = "block";
                                                                    }
                                                                }

                                                                // Attach event listener using JavaScript
                                                                document.getElementById('otherUpdateJournal<?= $chapter->MOU_Linkage_id ?>').addEventListener('input', validateOtherUpdate<?= $chapter->MOU_Linkage_id ?>);

                                                            </script>
                                                        </div>


                                                        <div class="md-4 my-3">
                                                            <label for="from" class="form-label">From : <label style="color: red;">*</label></label>
                                                            <input type="date" class="form-control" id="fromdate1<?= $chapter->MOU_Linkage_id ?>" name="fdate" value="<?= $chapter->From ?>" placeholder="dd-mm-yyyy" min="1992-01-01" onchange="enableToDate1<?= $chapter->MOU_Linkage_id ?>()">
                                                        </div>

                                                        <div class="md-4 my-3">
                                                            <label for="to" class="form-label">To : <label style="color: red;">*</label></label>
                                                            <input type="date" class="form-control" id="todate1<?= $chapter->MOU_Linkage_id ?>" name="tdate" value="<?= $chapter->To ?>" placeholder="dd-mm-yyyy" disabled>
                                                        </div>

                                                        <script>
                                                            document.addEventListener("DOMContentLoaded", function() {
                                                                var currentDate = new Date();
                                                                currentDate.setHours(0, 0, 0, 0);

                                                                var fromdateInput = document.getElementById("fromdate1<?= $chapter->MOU_Linkage_id ?>");
                                                                var todateInput = document.getElementById("todate1<?= $chapter->MOU_Linkage_id ?>");

                                                                fromdateInput.setAttribute("max", formatDate1<?= $chapter->MOU_Linkage_id ?>(currentDate));

                                                                fromdateInput.addEventListener("change", function() {
                                                                    var jDate = new Date(fromdateInput.value);

                                                                    todateInput.setAttribute("min", formatDate1<?= $chapter->MOU_Linkage_id ?>(jDate));

                                                                    var maxDate = new Date();
                                                                    maxDate.setHours(0, 0, 0, 0);
                                                                    todateInput.setAttribute("max", formatDate1<?= $chapter->MOU_Linkage_id ?>(maxDate));

                                                                    if (new Date(todateInput.value) < jDate) {
                                                                        todateInput.value = "";
                                                                    }
                                                                });

                                                                function formatDate1<?= $chapter->MOU_Linkage_id ?>(date) {
                                                                    var dd = String(date.getDate()).padStart(2, "0");
                                                                    var mm = String(date.getMonth() + 1).padStart(2, "0");
                                                                    var yyyy = date.getFullYear();
                                                                    return yyyy + "-" + mm + "-" + dd;
                                                                }
                                                            });

                                                            function enableToDate1<?= $chapter->MOU_Linkage_id ?>() {
                                                                var fromDateInput = document.getElementById('fromdate1<?= $chapter->MOU_Linkage_id ?>');
                                                                var toDateInput = document.getElementById('todate1<?= $chapter->MOU_Linkage_id ?>');

                                                                if (fromDateInput.value !== '') {
                                                                    toDateInput.removeAttribute('disabled');
                                                                } else {
                                                                    toDateInput.setAttribute('disabled', 'disabled');
                                                                }
                                                            }
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label">Document of Activity : <label style="color: red;">* (.pdf only)</label></label>
                                                            <input id="activityupdatedoc<?= $chapter->MOU_Linkage_id ?>" type="file" class="form-control" name="aupdatedocument" accept=".pdf" onchange="validateAcitvityUpdateDoc<?= $chapter->MOU_Linkage_id ?>(event)">
                                                            <span id="activityupdatedocError<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateAcitvityUpdateDoc<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('activityupdatedocError<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }

                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label">Number of Beneficiary:<label style="color: red;">*</label></label>
                                                            <input id="beneficiaryupdate<?= $chapter->MOU_Linkage_id ?>" type="tel" name="BeneficiaryUpdate" value="<?= $chapter->No_Beneficiary ?>" min="1" max="150" class="form-control" autocomplete="off" maxlength="3" required>
                                                            <span id="beneficiaryupdateError<?= $chapter->MOU_Linkage_id ?>" style="color: red; display: none;">Please enter a valid amount between 1 and 150.</span>
                                                        </div>

 
                                                        <p class="my-3" style="color: red;"><strong>Note:- Select only .pdf files under 500kb.</strong></p>

                                                        <script>
                                                            function updateUploadFieldsUpdate<?= $chapter->MOU_Linkage_id ?>(num) {
                                                                for (let i = 11; i < 16; i++) {
                                                                    const uploadField = document.getElementById(`Udocument${i}<?= $chapter->MOU_Linkage_id ?>`);
                                                                    uploadField.disabled = true; // Disable all fields by default
                                                                }
                                                                for (let i = 11; i < num; i++) {
                                                                    const uploadField = document.getElementById(`Updatedocument${i}<?= $chapter->MOU_Linkage_id ?>`);
                                                                    uploadField.disabled = false; // Enable the specified number of fields
                                                                }
                                                            }

                                                            function validateBeneficiaryUpdate<?= $chapter->MOU_Linkage_id ?>(inputElement) {
                                                                var sanitizedValue = inputElement.value.replace(/\D/g, ''); // Remove non-numeric characters
                                                                inputElement.value = sanitizedValue; // Set sanitized value back into the input field

                                                                var enteredValue = parseInt(sanitizedValue);
                                                                var minLimit = parseInt(inputElement.getAttribute("min"));
                                                                var maxLimit = parseInt(inputElement.getAttribute("max"));

                                                                // Check if the entered value is within the specified limits
                                                                if (sanitizedValue.length === 0) {
                                                                    document.getElementById("beneficiaryupdateError<?= $chapter->MOU_Linkage_id ?>").style.display = "none"; // Hide the error message
                                                                    inputElement.setCustomValidity(""); // Clear custom validity
                                                                    updateUploadFieldsUpdate<?= $chapter->MOU_Linkage_id ?>(0); // Disable all upload fields
                                                                } else if (isNaN(enteredValue) || enteredValue < minLimit || enteredValue > maxLimit) {
                                                                    document.getElementById("beneficiaryupdateError<?= $chapter->MOU_Linkage_id ?>").style.display = "block";
                                                                    inputElement.setCustomValidity("Invalid value. Enter a number between " + minLimit + " and " + maxLimit + ".");
                                                                } else {
                                                                    document.getElementById("beneficiaryupdateError<?= $chapter->MOU_Linkage_id ?>").style.display = "none";
                                                                    inputElement.setCustomValidity("");
                                                                    updateUploadFieldsUpdate<?= $chapter->MOU_Linkage_id ?>(enteredValue);
                                                                }
                                                            }

                                                            // Add an event listener to the input field
                                                            document.getElementById("beneficiaryupdate<?= $chapter->MOU_Linkage_id ?>").addEventListener("input", function () {
                                                                validateBeneficiary<?= $chapter->MOU_Linkage_id ?>(this);
                                                            });
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label">Upload the Document : <label style="color: red;">*</label><br></label>
                                                            <input type="file" id="Updatedocument11<?= $chapter->MOU_Linkage_id ?><?= $chapter->MOU_Linkage_id ?>" class="form-control" name="Udocument0" accept=".pdf" onchange="validateUpadatedocument11<?= $chapter->MOU_Linkage_id ?>(event)" disabled>
                                                            <span id="UdocumentError11<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateUpadatedocument11<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('UdocumentError11<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label"><label style="color: red;"></label><br></label>
                                                            <input type="file" id="Updatedocument12<?= $chapter->MOU_Linkage_id ?>" class="form-control" name="Udocument1" accept=".pdf" onchange="validateUpdatedocument12<?= $chapter->MOU_Linkage_id ?>(event)" disabled>
                                                            <span id="UdocumentError12<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateUpdatedocument12<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('UdocumentError12<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label"><label style="color: red;"></label><br></label>
                                                            <input type="file" id="Updatedocument13<?= $chapter->MOU_Linkage_id ?>" class="form-control" name="Udocument2" accept=".pdf" onchange="validateUpdatedocument13<?= $chapter->MOU_Linkage_id ?>(event)" disabled>
                                                            <span id="UdocumentError13<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateUpdatedocument13<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('UdocumentError13<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label"><label style="color: red;"></label><br></label>
                                                            <input type="file" id="Updatedocument14<?= $chapter->MOU_Linkage_id ?>" class="form-control" name="Udocument3" accept=".pdf" onchange="validateUpdatedocument14<?= $chapter->MOU_Linkage_id ?>(event)" disabled>
                                                            <span id="UdocumentError14<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateUpdatedocument14<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('UdocumentError14<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }
                                                        </script>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label"><label style="color: red;"></label><br></label>
                                                            <input type="file" id="Updatedocument15<?= $chapter->MOU_Linkage_id ?>" class="form-control" name="Udocument0" accept=".pdf" onchange="validateUpdatedocument15<?= $chapter->MOU_Linkage_id ?>(event)" disabled>
                                                            <span id="UdocumentError15<?= $chapter->MOU_Linkage_id ?>" style="display:block;color:red;"></span>
                                                        </div>

                                                        <script>
                                                            function validateUpdatedocument15<?= $chapter->MOU_Linkage_id ?>(event) {
                                                                const file = event.target.files[0];
                                                                const errorElement = document.getElementById('UdocumentError15<?= $chapter->MOU_Linkage_id ?>');
                                                                if (!file.type.match('pdf')) {
                                                                    errorElement.textContent = 'File is not a PDF.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                if (file.size > 500 * 1024) {
                                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                                    event.target.value = ''; // Clear the file input
                                                                    return;
                                                                }
                                                                // If the file is valid, clear the error message
                                                                errorElement.textContent = '';
                                                            }
                                                        </script>
                                                    </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <button class="btn btn-outline-warning">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('MOU');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>

<script src="<?php echo base_url('assets/js/Reaserch_Details/mouLinkage_view.js'); ?>"></script>


<?= $this->endSection(); ?>