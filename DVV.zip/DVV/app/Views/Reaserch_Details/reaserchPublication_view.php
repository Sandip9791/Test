<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Research Publication Information </h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="reaserchPublication">
 
  <form class="row g-3 my-3" method="post" action="<?= base_url('saveResearchPublication')?>" enctype="multipart/form-data" >
        <div  id="form-container" >

            <div class="form-fields">

                <div class="row mx-2 pt-3 pb-3 border border-2">
                    <div class="col-md-4 my-3">
                        <label class="form-label">Title of the Paper : <label style="color: red;">*</label></label>
                        <input id="titlepaper" type="text" class="form-control" name="titleofPaper" autocomplete="off" oninput="validateTPaper()" required >
                        <span id="titlepaperErrror" style="display:none;color:red;">Please enter a valid Title.</span>
                    </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label">Name of the Journal : <label style="color: red;">*</label></label>
                        <input id="journalname" type="text" class="form-control" name="nameOfJournal" autocomplete="off" oninput="validateJournalName()" required >
                        <span id="journalNameError" style="display:none;color:red;">Please enter a valid Journal name.</span>
                    </div>
        
                    <div class="col-md-4 my-3">
                        <label class="form-label" for="year-of-award">Year of Publication : <label style="color: red;">*</label></label>
                        <input type="year" class="form-control" name="datepicker" id="datepicker" placeholder="yyyy" maxlength="4" autocomplete="off" required>
                        <span id="error-message" style="color: red; display: none;"></span>
                    </div>

                 

                    <script>
                        $(document).ready(function() {
                            var currentYear = new Date().getFullYear(); // Get the current year

                            $("#datepicker").datepicker({
                                format: "yyyy",
                                viewMode: "years",
                                minViewMode: "years",
                                startDate: "2020",
                                endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                autoclose: true
                            });

                            // Add an input event handler to validate numeric input
                            $("#datepicker").on("input", function() {
                                var inputValue = $(this).val();
                                var numericValue = parseInt(inputValue);
                                
                                if (isNaN(numericValue)) {
                                    $(this).val(""); // Clear the input
                                }
                            });
                        });
                    </script>

                    <div class="col-md-4 my-3">
                        <label class="form-label" for="reason">Journal Approved by : <label style="color: red;">*</label></label>
                        <select id="approve" onclick="showOther()" name="approved" class="form-control">
                            <option disabled selected hidden>--- Select one ---</option>
                            <option value=" UGC Care List">UGC Care List</option>
                            <option value="Web of Science">Web of Science</option>
                            <option value="Scopus">Scopus</option>
                            <option value="All">All</option>
                            <option value="Other">Other</option>
                        </select>
                        <br>

                        <div class="col-md-12 my-3" id="other" style="display:none;">
                            <label class="form-label">Other: <label style="color: red;">*</label></label>
                            <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOther()">
                            <span id="otherErrror" style="display:none;color:red;">Please enter a valid Journal Name.</span>
                        </div>

                    </div>

                    <script>
                        function showOther() {
                            var type = document.getElementById("approve");
                            if (type.value == "Other") 
                            {
                                document.getElementById("other").style.display="block";
                            }
                            else 
                            {
                                document.getElementById("other").style.display="none";
                            } 
                        }
                    </script>

                    <div class="col-md-4 my-3">
                        <label class="form-label" for="reason">Is link of the website available ? <label style="color: red;">*</label></label>
                        <select id="reason" name="yesno" onclick="show()" class="form-control">
                            <option disabled selected hidden>--- Select one ---</option>
                            <option  value="Yes" >Yes</option>
                            <option  value="No" >No</option>
                        </select>
                    </div>

                    <script>
                        function show() {
                            var type = document.getElementById("reason");
                            if (type.value == "Yes") {
                                document.getElementById("text-input1").style.display="block";
                            }
                            else {
                                document.getElementById("text-input1").style.display="none";
                            }

                            if (type.value == "No") {
                                document.getElementById("text-input2").style.display="block";
                            }
                            else {
                                document.getElementById("text-input2").style.display="none";
                            }  
                        }
                    </script>

                    <div class="col-md-4 my-3" id="text-input1" style="display:none;">
                        <label class="form-label">Enter Link : <label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="enterLink"  name="enterLink" placeholder="http://" autocomplete="off">
                        <span id="linkValidationError" style="display:none; color: red;">Please enter a valid link format.</span>
                    </div>


                    <div class="col-md-4 my-3" id="text-input2" style="display:none;">
                        <label class="form-label">Upload Screen Shot :<label style="color: red;">* (Please select only .jpg, .jpeg, .png image)</label></label>
                        <input type="file" id="screenshot" class="form-control" name="screenShot" accept=".jpg, .jpeg, .png" onchange="validateScreenShot(event)">
                        <span id="screenshotError" style="display:block;color:red;"></span>
                    </div>

                    </div>
                    </div>
                    </div>
                        
                    <div class="col-12 text-center">
                        <input type="submit" class="btn btn-outline-primary" value="Submit">
                    </div>
                </form>
        </div>

        <div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
            <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
            <label class="btn btn-success" for="btncheck1"> Add Data</label>
        </div>




<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('reaserchPublication');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });
</script>


<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Title of the Paper </th>
                <th scope="col">Name of the Journal</th>
                <th scope="col">Year of Publication</th>
                <th scope="col">Is link of the website available</th>
                <th scope="col">Journal Approved by</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->ResearchPublication;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Screenshot;
            ?>
            <tr >
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Title_Of_Paper?> </td>
                <td class="text-center"><?= $chapter->Name_Of_Journal?> </td>
                <td class="text-center"> <?= $chapter->Year_Of_Publication?> </td>
                <td class="text-center"> 
                   <?php if($chapter->Check === "Yes"):?>
                      <?= $chapter->Link_Of_Website?> 
                   <?php else:?>
                        <a href="<?= base_url('Userfiles/Teachers/Research/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php endif;?>
                   
               </td>
                <td class="text-center"> <?= $chapter->Journal_Approved_By;?> </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>
                    <form action="<?= base_url('deleteResearchPublication')?>" method="post">
                        <input type="text"  style="display:none;" name="srnumber" readonly value="<?= $chapter->ResearchPublication_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                      
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->ResearchPublication_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->ResearchPublication_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Publication Information</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateResearchPublication')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                            <div class="col-12">
                                <div class="md-4" style="display:none;">
                                    <label class="form-label">ResearchPublication id <label
                                            style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->ResearchPublication_id?>" >
                                    <span style="display:none;color:red;">Please enter a valid title.</span>
                                </div>

                                <div class="md-4">
                                    <label class="form-label">Title of the Paper : <label style="color: red;">*</label></label>
                                    <input id="titlepaper1<?= $chapter->ResearchPublication_id?>" type="text" class="form-control" name="titleofPaper" value="<?= $chapter->Title_Of_Paper?>" autocomplete="off" oninput="validateTPaper1<?= $chapter->ResearchPublication_id?>()"  >
                                    <span id="titlepaperErrror1<?= $chapter->ResearchPublication_id?>" style="display:none;color:red;">Please enter a valid Title.</span>
                                </div><br>

                                <script>
                                    function validateTPaper1<?= $chapter->ResearchPublication_id?>() {
                                        var regName = /[a-zA-Z ]$/;
                                        var name = document.getElementById('titlepaper1<?= $chapter->ResearchPublication_id?>').value;
                                        var error = document.getElementById("titlepaperErrror1<?= $chapter->ResearchPublication_id?>");
                                    
                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finaltitlepaper = capitalizedWords.join(" ");
                                        
                                        document.getElementById('titlepaper1<?= $chapter->ResearchPublication_id?>').value = finaltitlepaper;
                                    
                                        if (finaltitlepaper.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finaltitlepaper)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>

                                <div class="md-4">
                                    <label class="form-label">Name of the Journal : <label style="color: red;">*</label></label>
                                    <input id="journalname1<?= $chapter->ResearchPublication_id?>" type="text" class="form-control" name="nameOfJournal" value="<?= $chapter->Name_Of_Journal?>" autocomplete="off" oninput="validateJournalName1<?= $chapter->ResearchPublication_id?>()"  >
                                    <span id="journalNameError1<?= $chapter->ResearchPublication_id?>" style="display:none;color:red;">Please enter a valid Journal name.</span>
                                </div><br>

                                <script>
                                    function validateJournalName1<?= $chapter->ResearchPublication_id?>() {
                                        var regName = /[a-zA-Z ]$/;
                                        var name = document.getElementById('journalname1<?= $chapter->ResearchPublication_id?>').value;
                                        var error = document.getElementById("journalNameError1<?= $chapter->ResearchPublication_id?>");
                                    
                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finaljournalname = capitalizedWords.join(" ");
                                        
                                        document.getElementById('journalname1<?= $chapter->ResearchPublication_id?>').value = finaljournalname;
                                    
                                        if (finaljournalname.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finaljournalname)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>
                    
                                <div class="md-4">
                                    <label for="year-of-award">Year of Publication : <label style="color: red;">*</label></label>
                                    <input type="year" class="form-control" name="datepicker" value="<?= $chapter->Year_Of_Publication?>" id="datepicker1<?= $chapter->ResearchPublication_id?>" placeholder="yyyy" autocomplete="off" >
                                    <span id="error-message1<?= $chapter->ResearchPublication_id?>" style="color: red; display: none;">Please enter a valid Year.</span>
                                </div><br>
                                <script>
                                    $(document).ready(function() {
                                        var currentYear = new Date().getFullYear(); // Get the current year

                                        $("#datepicker1<?= $chapter->ResearchPublication_id?>").datepicker({
                                            format: "yyyy",
                                            viewMode: "years",
                                            minViewMode: "years",
                                            startDate: "2020",
                                            endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                            autoclose: true
                                        });

                                        // Add an input event handler to validate numeric input
                                        $("#datepicker1<?= $chapter->ResearchPublication_id?>").on("input", function() {
                                            var inputValue = $(this).val();
                                            var numericValue = parseInt(inputValue);
                                            
                                            if (isNaN(numericValue)) {
                                                $(this).val(""); // Clear the input
                                            }
                                        });
                                    });
                                </script>

                                <div class="md-4">
                                    <label class="form-label" for="reason">Journal Approved by : <label
                                                style="color: red;">*</label></label>
                                        <select id="approved1<?= $chapter->ResearchPublication_id?>" name="approved" onclick="showOther1<?= $chapter->ResearchPublication_id?>()" class="form-control">
                                            <option value="<?= $chapter->Journal_Approved_By?>"><?= $chapter->Journal_Approved_By?></option>
                                            <option value=" UGC Care List">UGC Care List</option>
                                            <option value="Web of Science">Web of Science</option>
                                            <option value="Scopus">Scopus</option>
                                            <option value="Other">Other</option>
                                        </select>
                                </div><br>

                                <script>
                                     function showOther1<?= $chapter->ResearchPublication_id?>() {
                                        var type = document.getElementById("approved1<?= $chapter->ResearchPublication_id?>");
                                        if (type.value == "Other") {
                                            document.getElementById("other1<?= $chapter->ResearchPublication_id?>").style.display="block";
                                        }
                                        else {
                                            document.getElementById("other1<?= $chapter->ResearchPublication_id?>").style.display="none";
                                        } 
                                    }
                                </script>

                                <div class="md-4" id="other1<?= $chapter->ResearchPublication_id?>" style="display:none;">
                                    <label class="form-label">Other: <label style="color: red;">*</label></label>
                                    <input id="other1<?= $chapter->ResearchPublication_id?>" type="text" class="form-control"  name="other" value="<?= $chapter->Journal_Approved_By?>" autocomplete="off" oninput="validateOther1<?= $chapter->ResearchPublication_id?>()" >
                                    <span id="otherErrror1<?= $chapter->ResearchPublication_id?>" style="display:none;color:red;">Please enter a valid Journal Name.</span>
                                </div><br>
                                <script>
                                    function validateOther1<?= $chapter->ResearchPublication_id?>() {
                                        var regName = /^[a-zA-Z ]+$/;
                                        var inputElement = document.getElementById('otherJournal1<?= $chapter->ResearchPublication_id?>');
                                        var name = inputElement.value;
                                        var error = document.getElementById("otherError1<?= $chapter->ResearchPublication_id?>");

                                        // Remove any non-alphabetical characters from the input
                                        var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                        
                                        // Split the input into words and capitalize the first letter of each word
                                        var words = sanitizedName.split(" ");
                                        var capitalizedWords = words.map(function(word) {
                                            return word.charAt(0).toUpperCase() + word.slice(1);
                                        });
                                        
                                        // Join the capitalized words back together
                                        var finalOther = capitalizedWords.join(" ");
                                        
                                        inputElement.value = finalOther;

                                        if (finalOther.length === 0) {
                                            error.style.display = "none";
                                        } else if (!regName.test(finalOther)) {
                                            error.style.display = "block";
                                        } else {
                                            error.style.display = "none";
                                        }
                                    }
                                </script>        


                                <div class="md-4">
                                    <label class="form-label" for="reason">Is link of the website available:<label style="color: red;">*</label></label>
                                    <select id="reason1<?= $chapter->ResearchPublication_id?>" name="yesno" onclick="show1<?= $chapter->ResearchPublication_id?>()" class="form-control">
                                        <option  value="<?= $chapter->Check?>"><?= $chapter->Check?></option>
                                        <option  value="Yes" >Yes</option>
                                        <option  value="No" >No</option>
                                    </select>
                                </div><br>

                                <script>
                                    function show1<?= $chapter->ResearchPublication_id?>() {
                                            var type = document.getElementById("reason1<?= $chapter->ResearchPublication_id?>");
                                            if (type.value == "Yes") {
                                                document.getElementById("text-input3<?= $chapter->ResearchPublication_id?>").style.display="block";
                                            }
                                            else {
                                                document.getElementById("text-input3<?= $chapter->ResearchPublication_id?>").style.display="none";
                                            }

                                            if (type.value == "No") {
                                                document.getElementById("text-input4<?= $chapter->ResearchPublication_id?>").style.display="block";
                                            }
                                            else {
                                                document.getElementById("text-input4<?= $chapter->ResearchPublication_id?>").style.display="none";
                                            }  
                                        }
                                </script>


                                <div class="md-4" id="text-input3<?= $chapter->ResearchPublication_id?>" style="display:none;">
                                    <label class="form-label">Enter Link : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" id="enterLink1<?= $chapter->ResearchPublication_id?>"  name="enterLink" value="<?= $chapter->Link_Of_Website?>" placeholder="http://" autocomplete="off">
                                    <span id="linkValidationError1<?= $chapter->ResearchPublication_id?>" style="display:none; color: red;">Please enter a valid link format.</span>
                                </div><br>

                                <script>
                                    function validateLink1<?= $chapter->ResearchPublication_id?>() {
                                        var linkInput = document.getElementById('enterLink1<?= $chapter->ResearchPublication_id?>');
                                        var linkValidationError = document.getElementById('linkValidationError1<?= $chapter->ResearchPublication_id?>');
                                        var linkRegex = /^(ftp|http|https):\/\/[^ "]+$/;

                                        if (linkInput.value.trim() === '') {
                                            // Empty input, hide error message
                                            linkValidationError.style.display = 'none';
                                        } else if (!linkRegex.test(linkInput.value)) {
                                            // Invalid link format, show error message
                                            linkValidationError.style.display = 'block';
                                        } else {
                                            // Valid link format, hide error message
                                            linkValidationError.style.display = 'none';
                                        }
                                    }

                                    // Attach event listener to validate link on keyup
                                    document.getElementById('enterLink1<?= $chapter->ResearchPublication_id?>').addEventListener('keyup', validateLink1<?= $chapter->ResearchPublication_id?>);

                                </script>

                                <div class="md-4" id="text-input4<?= $chapter->ResearchPublication_id?>" style="display:none;">
                                    <label class="form-label">Upload Screen Shot :<label style="color: red;">* (Please select only .jpg, .jpeg, .png image)</label></label>
                                    <input type="file" id="screenshot1<?= $chapter->ResearchPublication_id?>" class="form-control" name="screenShot"  accept=".jpg, .jpeg, .png" onchange="validateScreenShot1<?= $chapter->ResearchPublication_id?>(event)">
                                    <span id="screenshotError1<?= $chapter->ResearchPublication_id?>" style="display:block;color:red;"></span>
                                </div><br>
                                <script>
                                    function validateScreenShot1<?= $chapter->ResearchPublication_id?>(event) {
                                        const file = event.target.files[0];
                                        const errorElement = document.getElementById('screenshotError1<?= $chapter->ResearchPublication_id?>');
                                        const allowedFormats = ['image/jpeg', 'image/jpg', 'image/png'];

                                        if (!allowedFormats.includes(file.type)) {
                                            errorElement.textContent = 'Invalid file format. Please select only .jpg, .jpeg, .png images.';
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }

                                        const maxSizeKB = 500; // Maximum file size in KB
                                        if (file.size > maxSizeKB * 1024) {
                                            errorElement.textContent = `File is too big. Maximum size is ${maxSizeKB} KB.`;
                                            event.target.value = ''; // Clear the file input
                                            return;
                                        }

                                        // If the file is valid, clear the error message
                                        errorElement.textContent = '';
                                    }

                                </script>
                                
                            </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>



    <script src="<?php echo base_url('assets/js/Reaserch_Details/reaserchPublication_view.js'); ?>"></script>

<?= $this->endSection();?>

