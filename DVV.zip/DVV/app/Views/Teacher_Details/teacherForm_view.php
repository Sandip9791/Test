<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
<h1 class="text-center my-3">Teacher's Personal Information</h1>
  <div class="container-fluid border border-info my-4">
    <form class="row g-4 my-2" action="<?= base_url('personalData');?>" method="post" enctype="multipart/form-data">

     <?php if(isset($documents)):
          foreach($documents as $doc):
          $pid= $doc->PID; 
          $adhar = $pid->Adhar_Document;
          $pan = $pid->Pan_Document; 
          $images = $pid->Current_Image;
      ?>
      
      <?php if(empty($adhar) && empty($pan)):?>
      <div class="col-md-3">
        <label class="form-label">Title <label style="color: red;">*</label></label>

        <span id="titleError" style="display:none;color:red;">Please select a name title.</span>
        <select class="form-select" name="title" required>
          <option selected value="<?= $doc->Title?>"> <?=$doc->Title ?></option>
          <option value="Dr.">Dr.</option>
          <option value="Mr.">Mr.</option>
          <option value="Mrs.">Mrs.</option>
          <option value="Ms.">Ms.</option>
        </select>
      </div> 

      <div class="col-md-3">
        <label class="form-label">First name <label style="color: red;">*</label></label>
        <input id="firstname" type="text" class="form-control person-name" name="fname" value="<?=  $doc->First_Name?>" oninput="validateFirstName()" autocomplete="off" maxlength="20" required>
        <span id="firstnameError" style="display:none;color:red;">Please enter a valid name.</span>

      </div>
      <div class="col-md-3">
        <label class="form-label">Last name <label style="color: red;">*</label></label>
        <input id="lastname" type="text" class="form-control person-name" name="lname" value="<?=  $doc->Last_Name?>" oninput="validateLastName()" autocomplete="off" maxlength="20" required>
        <span id="lastnameError" style="display:none;color:red;">Please enter a valid name.</span>

      </div>
      <div class="col-md-3">
        <label class="form-label">Middle name <label style="color: red;"> (Optional)</label></label>
        <input id="middlename" type="text" class="form-control person-name" name="mname" value="<?=  $doc->Midd_Name;?>" oninput="validateMiddleName()" autocomplete="off" maxlength="20">
        <span id="midnameError" style="display:none;color:red;">Please enter a valid name.</span>
      </div>

      <br><br><br><br>

      <div class="col-md-3">
        <label class="form-label">Gender <label style="color: red;">*</label></label>
        <select id="gender" class="form-select" name="gender" required>
          <option selected hidden value="<?= $pid->Gender?>"><?= $pid->Gender?></option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>
      
      <div class="col-md-3">
        <label class="form-label">Date of Birth <label style="color: red;">*</label></label>
        <input type="date" class="form-control" name="dob" placeholder="dd-mm-yyyy"  value="<?= $pid->DOB?>" min="1963-01-01" autocomplete="off" required>
      </div>

      <div class="col-md-3">
        <label class="form-label">Category: <label style="color: red;">*</label></label>
        <!-- <span id="titleError" style="display:none;color:red;">Please select a name title.</span> -->
        <select class="form-select" name="cat" required>
        <option selected hidden value="<?= $pid->Category?>"><?= $pid->Category?></option>
        <option value="General">General</option>
        <option value="OBC">OBC</option>
        <option value="SC">SC</option>
        <option value="ST">ST</option>
        <option value="NT-A">NT-A</option>
        <option value="NT-B">NT-B</option>
        <option value="NT-C">NT-C</option>
        <option value="NT-D">NT-D</option>
        <option value="SBC">SBC</option>
        <option value="PWD">PWD</option>
        <option value="Others">Others</option>
        </select>
      </div>

      <div class="col-md-3">
          <label class="form-label">Mobile Number <label style="color: red;">*</label></label>
          <input id="mobilenumber" type="text" class="form-control" name="mobile" min="6000000000" max="9999999999" value="<?= $pid->Mobile_Number?>" autocomplete="off" maxlength="10" required>
          <span id="mobileError" style="display:none;color:red;">Please enter a valid mobile number.</span>
      </div>

      <br><br><br><br>

      <div class="col-md-3">
        <label class="form-label">Email ID : <label style="color: red;">*</label></label>
        <input id="email" type="text" class="form-control" name="email" value="<?=$pid->Email ?>" placeholder="" onkeyup="validateEmail()" autocomplete="off" required>
        <span id="emailError" style="display:none;color:red;">Please enter a valid email address.</span>
      </div>

      <div class="col-md-3">
        <label class="form-label">Residential Address : <label style="color: red;">*</label></label>
        <input id="residential" type="text" class="form-control" name="address" value="<?= $pid->Address?>" placeholder="Enter Current Address" autocomplete="off" onkeyup="validateResidentialAddress()" maxlength="50" required>
        <span id="residentialError" style="display:none;color:red;">Please enter a valid Residential Address.</span>
      </div>

      <div class="col-md-3">
        <label class="form-label">Aadhar Number <span style="color: red;">*</span></label>
        <input id="aadhar" type="text" inputmode="numeric" class="form-control" name="adhar" value="<?= $pid->Adhar_Number ?>" min="100000000000" max="999999999999" placeholder="" autocomplete="off" maxlength="12" required>
        <span id="aadharError" style="display:none;color:red;">Please enter a valid Aadhar number.</span>
      </div>

      <div class="col-md-3">
        <label class="form-label">Pan Card Number <label style="color: red;">*</label></label>
        <input id="pan" type="text" class="form-control" name="pan" value="<?= $pid->Pan_Card_Number?>" placeholder="" autocomplete="off" oninput="handlePanInput(this);" maxlength="10" required>
        <span id="panError" style="display:none;color:red;">Please enter valid pan number.</span>
      </div>

      <br><br><br><br><br><br>

        <label class="form-label">
          <b style="color: red;">Note: All PDF files and Current Photo size should be less than 500 kb.</b>
        </label>

      <div class="col-md-4">
        <label class="form-label">Upload Aadhar Card Document <label style="color: red;">(Select only .pdf file) *</label></label>
        <input type="file" id="aadhardoc" class="form-control" name="adocument"  accept=".pdf" oninput="validateAadharDoc(event)" required>
        <span id="aadhardocError" style="color:red;"></span>
      </div>

      <div class="col-md-4">
        <label class="form-label">Upload Pan Card Document <label style="color: red;">(Select only .pdf file) *</label></label>
        <input type="file" id = "pandoc" class="form-control" name="pdocument" accept=".pdf" oninput="validatePanDoc(event)" required>
        <span id="pandocError" style="color:red;"></span>
      </div>

      <div class="col-md-4">
        <label class="form-label">Upload Current Photo <label style="color: red;">(Select only .jpg, .jpeg, .png file) *</label></label>
        <input type="file" id="currentphoto" class="form-control" name="cphoto"  accept=".jpg,.jpeg,.png" oninput="validateCurrentPhoto(event)" required>
        <span id="currentphotoError" style="color:red;"></span>
      </div>

<br><br><br><br>

      <div class="col-12 text-center">
        <input  type="submit" class="btn btn-outline-primary" value="Submit">
      </div>

<!-- /*********************************************************************************************************************************************************/ -->
      <?php else:?>
        <h3 class="text-center animate__heartBeat" id="msg" style="color:#52BE80;"> Want's to Update Your Profile (let's click on Update Button ) ...</h3>   
        <div id="personalInfo" style="display:none;">
        
        <div class="row">
          <div class="col-md-3">
              <label class="form-label">Title <label style="color: red;">*</label></label>
              <span id="titleError" style="display:none;color:red;">Please select a name title.</span>
              <select class="form-select" name="title" required>
                <option selected  hidden value="<?=$doc->Title ?>"><?=$doc->Title ?></option>
                <option value="Dr.">Dr.</option>
                <option value="Mr.">Mr.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Ms.">Ms.</option>
              </select>
          </div>

          <div class="col-md-3">
            <label class="form-label">First name <label style="color: red;">*</label></label>
            <input id="firstname" type="text" class="form-control person-name" name="fname" value="<?=  $doc->First_Name?>" oninput="validateFirstName()" autocomplete="off" maxlength="20" required>
            <span id="firstnameError" style="display:none;color:red;">Please enter a valid name.</span>
          </div>

          <div class="col-md-3">
            <label class="form-label">Last name <label style="color: red;">*</label></label>
            <input id="lastname" type="text" class="form-control person-name" name="lname" value="<?=  $doc->Last_Name?>" oninput="validateLastName()" autocomplete="off" maxlength="20" required>
            <span id="lastnameError" style="display:none;color:red;">Please enter a valid name.</span>
          </div>

          <div class="col-md-3">
            <label class="form-label">Middle name <label style="color: red;"> (Optional)</label></label>
            <input id="middlename" type="text" class="form-control person-name" name="mname" value="<?=  $doc->Midd_Name;?>" oninput="validateMiddleName()" autocomplete="off" maxlength="20">
            <span id="midnameError" style="display:none;color:red;">Please enter a valid name.</span>
          </div>

          <br><br><br><br>

          <div class="col-md-3">
            <label class="form-label">Gender <label style="color: red;">*</label></label>
            <select id="gender" class="form-select" name="gender" required>
              <option selected  hidden value="<?= $pid->Gender?>"><?= $pid->Gender?></option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div class="col-md-3">
            <label class="form-label">Date of Birth <label style="color: red;">*</label></label>
            <input type="date" class="form-control " name="dob" value="<?= $pid->DOB?>" placeholder="dd-mm-yyyy" min="1963-01-01" autocomplete="off" required>
          </div>

          <div class="col-md-3">
            <label class="form-label">Category: <label style="color: red;">*</label></label>
            <!-- <span id="titleError" style="display:none;color:red;">Please select a name title.</span> -->
            <select class="form-select" name="cat" required>
            <option selected  hidden value="<?= $pid->Category?>"><?= $pid->Category?></option>
            <option value="General">General</option>
            <option value="OBC">OBC</option>
            <option value="SC">SC</option>
            <option value="ST">ST</option>
            <option value="NT-A">NT-A</option>
            <option value="NT-B">NT-B</option>
            <option value="NT-C">NT-C</option>
            <option value="NT-D">NT-D</option>
            <option value="SBC">SBC</option>
            <option value="PWD">PWD</option>
            <option value="Others">Others</option>
            </select>
          </div>

          <div class="col-md-3">
              <label class="form-label">Mobile Number <label style="color: red;">*</label></label>
              <input id="mobilenumber" type="text" class="form-control" name="mobile" min="6000000000" max="9999999999" value="<?= $pid->Mobile_Number?>" autocomplete="off" maxlength="10" required>
              <span id="mobileError" style="display:none;color:red;">Please enter a valid mobile number.</span>
          </div>

<br><br><br><br>

          <div class="col-md-3">
            <label class="form-label">Email ID : <label style="color: red;">*</label></label>
            <input id="email" type="text" class="form-control" name="email" value="<?=$pid->Email ?>" placeholder="" onkeyup="validateEmail()" autocomplete="off" required>
            <span id="emailError" style="display:none;color:red;">Please enter a valid email address.</span>
          </div>

          <div class="col-md-3">
            <label class="form-label">Residential Address : <label style="color: red;">*</label></label>
            <input id="residential" type="text" class="form-control" name="address" value="<?= $pid->Address?>" placeholder="Enter Current Address" autocomplete="off" onkeyup="validateResidentialAddress()" maxlength="50" required>
            <span id="residentialError" style="display:none;color:red;">Please enter a valid Residential Address.</span>
          </div>

          <div class="col-md-3">
            <label class="form-label">Aadhar Number <span style="color: red;">*</span></label>
            <input id="aadhar" type="text" inputmode="numeric" class="form-control" name="adhar" value="<?= $pid->Adhar_Number ?>" min="100000000000" max="999999999999" placeholder="" autocomplete="off" maxlength="12" required>
            <span id="aadharError" style="display:none;color:red;">Please enter a valid Aadhar number.</span>
          </div>

          <div class="col-md-3">
            <label class="form-label">Pan Card Number <label style="color: red;">*</label></label>
            <input id="pan" type="text" class="form-control" name="pan" value="<?= $pid->Pan_Card_Number?>" placeholder="" autocomplete="off" oninput="handlePanInput(this);" maxlength="10" required>
            <span id="panError" style="display:none;color:red;">Please enter valid pan number.</span>
          </div>

<br><br><br><br><br>

      <label class="form-label">
        <b style="color: red;">Note: All PDF files and Current Photo size should be less than 500 kb.</b>
      </label>

<div class="col-md-4">
            <label class="form-label">Upload Aadhar Card Document <label style="color: red;">(Select only .pdf file) *</label></label>
            <input type="file" id="aadhardoc" class="form-control" name="adocument"  accept=".pdf" oninput="validateAadharDoc(event)" >
            <span id="aadhardocError" style="color:red;"></span>
          </div>


          <div class="col-md-4">
            <label class="form-label">Upload Pan Card Document <label style="color: red;">(Select only .pdf file) *</label></label>
            <input type="file" id = "pandoc" class="form-control" name="pdocument" accept=".pdf" oninput="validatePanDoc(event)" >
            <span id="pandocError" style="color:red;"></span>

          </div>

          <div class="col-md-4">
            <label class="form-label">Upload Current Photo <label style="color: red;">(Select only .jpg, .jpeg, .png file) *</label></label>
            <input type="file" id="currentphoto" class="form-control" name="cphoto"  accept=".jpg,.jpeg,.png" oninput="validateCurrentPhoto(event)" >
            <span id="currentphotoError" style="color:red;"></span>
          </div>

<br><br><br><br>

          <div class="col-12 text-center pt-3">
            <input  type="submit" class="btn btn-outline-primary" value="Submit">
          </div>
        </div>
      </div>     
         
      <?php endif;?>
      <?php endforeach;?>
      <?php endif;?>
    </form>
  </div>
    

    <div class=" my-5 ">
        <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center animate__flip">
          <tr>
          <th scope="col">Uploaded Photo</th>
            <th scope="col">Full Name</th>
            <th scope="col">Gender</th>
            <th scope="col">DOB</th>
            <th scope="col">Category</th>
            <th scope="col">Mobile Number</th>
            <th scope="col">Email ID</th>
            <th scope="col">Residential Address </th>
            <th scope="col">Adhar Number</th>
            <th scope="col">Uploaded Adhar</th>
            <th scope="col">Pan Number</th>
            <th scope="col">Uploaded Pan</th>
            <th scope="col">Action</th>
           
          </tr>
        </thead>
        <?php if(isset($documents)):
          foreach($documents as $doc):
          $pid= $doc->PID; 

          $title=$doc->Title;
          $fname=$doc->First_Name;
          $lname=$doc->Last_Name;
          $mname=$doc->Midd_Name;
   
          $Name = $title." ".$fname." ".$mname." ".$lname;

          $adhar = $pid->Adhar_Document;
          $pan = $pid->Pan_Document; 
          $images = $pid->Current_Image;
        ?>
        <tbody class="text-center">
          <tr>
            <td>
                <?php if(!empty($images)):?>
                  <img src="<?=base_url("Userfiles/Teachers/Profile/$images")?>" style=" width: 100px; height: 80px; border-radius: 10%;" target="_blank">
                <?php else:?>
                  <img src="<?= base_url("assets/images/profile/pro.png");?>" style=" width: 100px; height: 80px; border-radius: 10%;" target="_blank">
                <?php endif;?>
              </td>
            <td>
                <?php if(isset($Name) && !empty($Name)):?>
                  <?= $Name?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if(isset($pid->Gender) && !empty($pid->Gender)):?>
                  <?= $pid->Gender?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if(isset($pid->DOB) && !empty($pid->DOB)):?>
                  <?= $pid->DOB?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
               <?php if(isset($pid->Category) && !empty($pid->Category)):?>
                  <?= $pid->Category?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
               <?php if(isset($pid->Mobile_Number) && !empty($pid->Mobile_Number)):?>
                  <?= $pid->Mobile_Number?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>  
            </td>

            <td>
                <?php if(isset($pid->Email) && !empty($pid->Email)):?>
                  <?= $pid->Email?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>
            <td>
               <?php if(isset($pid->Address) && !empty($pid->Address)):?>
                  <?= $pid->Address?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if(isset($pid->Adhar_Number) && !empty($pid->Adhar_Number)):?>
                  <?= $pid->Adhar_Number?>
                  <?php else:?>
                    <b> Not Found</b>
                  <?php endif;?>
            </td>
            <td class="ms-3"> 
                  <?php if( !empty($adhar)):?>
                  <a href="<?= base_url('Userfiles/Teachers/Profile/').$adhar;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                     <button class="btn btn-outline-success"> Download File </button>
                  </a>
                <?php else:?>
                    <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if(isset($pid->Pan_Card_Number) && !empty($pid->Pan_Card_Number)):?>
                  <?= $pid->Pan_Card_Number?>
                <?php else:?>
                  <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if( !empty($pan)):?>
                  <a href="<?= base_url('Userfiles/Teachers/Profile/').$pan;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                     <button class="btn btn-outline-success"> Download File </button>
                  </a>
                <?php else:?>
                    <b> Not Found</b>
                <?php endif;?>
            </td>

            <td>
                <?php if(!empty($adhar) && !empty($pan)):?>
                  <img src="<?= base_url('assets/images/iconsUpdate.gif')?>" >
                  <div class="btn-group " role="group" aria-label="Basic checkbox toggle button group">
                      <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                      <label class="btn btn-outline-warning" for="btncheck1"> Update</label>
                  </div>
                <?php else:?>
                 <h4 class="animate__heartBeat text-danger">Please Fill The Form...</h4>
                <?php endif;?>
            </td>
          </tr>
        </tbody>

        <?php endforeach;?>
        <?php endif;?>
      </table>
    </div>

    <script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('personalInfo');
        const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            msg.style.display="none";
          } else {
            myForm.style.display="none";
            msg.style.display="block";
          }
        });
    </script>
    
  <script src="<?= base_url('assets/js/Teacher_Details/teacherForm_view.js')?>"></script>

<?= $this->endSection();?>


