<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center">Awards/Recognition </h1>

<div class="container-fluid border border-subtprimary my-4" id="Awards" style="display:none" >
        <form class="row g-3 my-3" id="dynamic-form" action="<?= base_url('saveTeacherAwards')?>" method="post"
            enctype="multipart/form-data">
           
        <div class="row mx-2 pt-3 pb-3 border border-2">
                <div class="col-md-12">
                <input  class="form-check-input" type="checkbox"  name="National" value="National" id="form1Checkbox" onclick="showForm1()"  >
                <label for="">National </label>
                <div id="form1">
                    <div class="row py-2 mx-1">
                         <div class="col-md-4">
                             <label class="form-label">Name of Award/Recognition Name<label style="color: red;">*</label> :</label><br>
                             <input type="text" id="national" class="form-control" name="AwardNational" autocomplete="off" oninput="validateNationalAward()">
                             <span id="nationalError" style="display:none;color:red;">Please enter valid Award Name.</span>
                             <br>
                         </div>
             
                         <div class="col-md-4">
                             <label class="form-label">Upload Certificate<label style="color: red;">* <strong>(Choose PDF files only, under 500KB)</strong></label> :</label><br>
                             <input type="file" id="nationaldocument" class="form-control" name="nationaldocument" accept=".pdf" onchange="validatenationalDoc()">
                             <span id="nationaldocError" style="color:red;"></span>
                             <br>
                         </div>
                    </div>
                </div>
                  
                 <br>
                <input class="form-check-input" type="checkbox" name="International" value="International" id="form2Checkbox" onclick="showForm2()"  >
                <label for="">International </label>

                <div id="form2">
                    <div class="row py-2 mx-1 ">
                         <div class="col-md-4">
                             <label class="form-label">Name of Award/Recognition Name<label style="color: red;">*</label> :</label><br>
                             <input type="text" id="international" class="form-control" name="AwardInternational" autocomplete="off" oninput="validateInternationalAward()">
                             <span id="internationalError" style="display:none;color:red;">Please enter valid Award Name.</span>
                             <br>
                         </div>
             
                         <div class="col-md-4">
                             <label class="form-label">Upload Certificate<label style="color: red;">* <strong>(Choose PDF files only, under 500KB)</strong></label> :</label><br>
                             <input type="file" id="internationaldocument" class="form-control" name="internationaldocument" accept=".pdf" onchange="validateinternationalDoc()">
                             <span id="internationaldocError" style="color:red;"></span>
                             <br>
                         </div>
                    </div>
                </div>

            </div>
             
        </div>
           
            <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
        </form>

</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Name of Award/Recognition Name (National)</th>
                <th scope="col">Uploaded Certificate (National)</th>
                <th scope="col">Name of Award/Recognition  (International)</th>
                <th scope="col">Uploaded Certificate (International)</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Teacher_Award;
        ?>
        <tbody>
            <?php
                foreach($book as $chapter):
                $national = $chapter->National_Document;
                $international = $chapter->International_Document;
             
            ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++;?></th>
                <td class="text-center"> <?= $chapter->National_Name_of_Award?> </td>
                <td class="text-center"> 
                    <?php if( !empty($national)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Profile/').$national;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td> 
                <td class="text-center"><?= $chapter->International_Name_of_Award?>  </td>
                <td class="text-center">
                    <?php if( !empty($international)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Profile/').$international;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center">
                    <form action="<?= base_url('deleteTeacherAwards')?>" method="post">
                         <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->Teacher_Award_id?>"> 
                          <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br><input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                   
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br> 
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Teacher_Award_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Teacher_Award_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Awards/Recognition</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateTeacherAwards')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">BookAndChapter id : <label
                                                style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->Teacher_Award_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>
                                    <input type="checkbox" id="form1Checkbox1<?= $chapter->Teacher_Award_id?>" name="National" onclick="showForm1<?= $chapter->Teacher_Award_id?>()"  >
                                    <label for="">National </label>

                                    <div id="form3<?= $chapter->Teacher_Award_id?>" style="display:none;">
                                        <div class="row py-2 mx-1">
                                            <div class="md-4">
                                                <label class="form-label">Name of Award/Recognition Name<label style="color: red;">*</label> :</label><br>
                                                <input type="text" id="national1<?= $chapter->Teacher_Award_id?>" class="form-control" name="AwardNational" value="<?= $chapter->National_Name_of_Award?>" autocomplete="off" oninput="validateNationalAward1<?= $chapter->Teacher_Award_id?>()">
                                                <span id="nationalError1<?= $chapter->Teacher_Award_id?>" style="display:none;color:red;">Please enter valid Award Name.</span>
                                                <br>
                                            </div>
                                            <script>
                                                function validateNationalAward1<?= $chapter->Teacher_Award_id?>() {
                                                var regName = /[a-zA-Z ]$/;
                                                var name = document.getElementById('national1<?= $chapter->Teacher_Award_id?>').value;
                                                var error = document.getElementById("nationalError1<?= $chapter->Teacher_Award_id?>");

                                                // Remove any non-alphabetical characters from the input
                                                var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                                
                                                // Split the input into words and capitalize the first letter of each word
                                                var words = sanitizedName.split(" ");
                                                var capitalizedWords = words.map(function(word) {
                                                    return word.charAt(0).toUpperCase() + word.slice(1);
                                                });
                                                
                                                // Join the capitalized words back together
                                                var finalName1 = capitalizedWords.join(" ");
                                                
                                                document.getElementById('national1<?= $chapter->Teacher_Award_id?>').value = finalName1;

                                                if (finalName1.length === 0) {
                                                    error.style.display = "none";
                                                } else if (!regName.test(finalName1)) {
                                                    error.style.display = "block";
                                                } else {
                                                    error.style.display = "none";
                                                }
                                            }
                                            </script>

                                            <div class="md-4">
                                                <label class="form-label">Upload Certificate<label style="color: red;">* (Choose PDF files only, under 500KB)</label> :</label><br>
                                                <input type="file" id="nationaldocument1<?= $chapter->Teacher_Award_id?>" class="form-control" name="nationaldocument" accept=".pdf" onchange="validatenationalDoc1<?= $chapter->Teacher_Award_id?>()">
                                                <span id="nationaldocError1<?= $chapter->Teacher_Award_id?>" style="color:red;"></span>
                                                <br>
                                            </div>
                                            <script>
                                                function validatenationalDoc1<?= $chapter->Teacher_Award_id?>() 
                                                {
                                                    const file = event.target.files[0];
                                                    const errorElement = document.getElementById('nationaldocError1<?= $chapter->Teacher_Award_id?>');
                                                    if (!file.type.match('pdf')) 
                                                    {
                                                        errorElement.textContent = 'File is not a PDF.';
                                                        event.target.value = ''; // Clear the file input
                                                        return;
                                                    }
                                                    if (file.size > 500 * 1024) 
                                                    {
                                                        errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                        event.target.value = ''; // Clear the file input
                                                        return;
                                                    }
                                                    // If the file is valid, clear the error message
                                                    errorElement.textContent = '';
                                                }
                                            </script>
                                        </div>
                                    </div>
                                    
                                    <br>
                                    <input type="checkbox" id="form2Checkbox2<?= $chapter->Teacher_Award_id?>" name="International" onclick="showForm2<?= $chapter->Teacher_Award_id?>()"  >
                                    <label for="">International </label>

                                    <div id="form4<?= $chapter->Teacher_Award_id?>" style="display:none;">
                                        <div class="row py-2 mx-1 ">
                                            <div class="md-4">
                                                <label class="form-label">Name of Award/Recognition Name<label style="color: red;">*</label> :</label><br>
                                                <input type="text" id="international1<?= $chapter->Teacher_Award_id?>" class="form-control" name="AwardInternational" value="<?= $chapter->International_Name_of_Award?>" autocomplete="off" oninput="validateInternationalAward1<?= $chapter->Teacher_Award_id?>()">
                                                <span id="internationalError1<?= $chapter->Teacher_Award_id?>" style="display:none;color:red;">Please enter valid Award Name.</span>
                                                <br>
                                            </div>
                                            <script>
                                                function validateInternationalAward1<?= $chapter->Teacher_Award_id?>() {
                                                    var regName = /[a-zA-Z ]$/;
                                                    var name = document.getElementById('international1<?= $chapter->Teacher_Award_id?>').value;
                                                    var error = document.getElementById("internationalError1<?= $chapter->Teacher_Award_id?>");

                                                    // Remove any non-alphabetical characters from the input
                                                    var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                                    
                                                    // Split the input into words and capitalize the first letter of each word
                                                    var words = sanitizedName.split(" ");
                                                    var capitalizedWords = words.map(function(word) {
                                                        return word.charAt(0).toUpperCase() + word.slice(1);
                                                    });
                                                    
                                                    // Join the capitalized words back together
                                                    var finalName1 = capitalizedWords.join(" ");
                                                    
                                                    document.getElementById('international1<?= $chapter->Teacher_Award_id?>').value = finalName1;

                                                    if (finalName1.length === 0) {
                                                        error.style.display = "none";
                                                    } else if (!regName.test(finalName1)) {
                                                        error.style.display = "block";
                                                    } else {
                                                        error.style.display = "none";
                                                    }
                                                }
                                            </script>
                                
                                            <div class="md-4">
                                                <label class="form-label">Upload Certificate<label style="color: red;">* (Choose PDF files only, under 500KB)</label> :</label><br>
                                                <input type="file" id="internationaldocument1<?= $chapter->Teacher_Award_id?>" class="form-control" name="internationaldocument" accept=".pdf" onchange="validateinternationalDoc1<?= $chapter->Teacher_Award_id?>()">
                                                <span id="internationaldocError1<?= $chapter->Teacher_Award_id?>" style="color:red;"></span>
                                                <br>
                                            </div>
                                            <script>
                                                function validateinternationalDoc1<?= $chapter->Teacher_Award_id?>() 
                                                {
                                                const file = event.target.files[0];
                                                const errorElement = document.getElementById('internationaldocError1<?= $chapter->Teacher_Award_id?>');
                                                if (!file.type.match('pdf')) 
                                                {
                                                    errorElement.textContent = 'File is not a PDF.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                if (file.size > 500 * 1024) 
                                                {
                                                    errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                    event.target.value = ''; // Clear the file input
                                                    return;
                                                }
                                                // If the file is valid, clear the error message
                                                errorElement.textContent = '';
}     
                                            </script>
                                        </div>
                                    </div>

                                    <script>
                                        function showForm1<?= $chapter->Teacher_Award_id?>()
                                        {
                                            // Get references to the checkboxes and forms
                                            const form1Checkbox1 = document.getElementById('form1Checkbox1<?= $chapter->Teacher_Award_id?>');
                                            const form3 = document.getElementById('form3<?= $chapter->Teacher_Award_id?>');

                                            form1Checkbox1.addEventListener('change', () => 
                                            {
                                                form3.style.display = form1Checkbox1.checked ? 'block' : 'none';
                                            });
                                        }

                                        function showForm2<?= $chapter->Teacher_Award_id?>()
                                        {
                                            // Get references to the checkboxes and forms
                                            const form2Checkbox2 = document.getElementById('form2Checkbox2<?= $chapter->Teacher_Award_id?>');
                                            const form4 = document.getElementById('form4<?= $chapter->Teacher_Award_id?>');

                                            form2Checkbox2.addEventListener('change', () => 
                                            {
                                                form4.style.display = form2Checkbox2.checked ? 'block' : 'none';
                                            });  
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

    <script src="<?php echo base_url('assets/js/Teacher_Details/teaAwards_view.js'); ?>"></script>

    <script>
         
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('Awards');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
    
        
   </script>


<?= $this->endSection();?>

