<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center">Faculty Development Program (FDP)</h1>
    <div class="container-fluid border border-info my-4" style="display:none" id="reaserchProjectInfo">
        <form class="row g-3 my-3" action="<?= base_url('saveFDP')?>" method="post" enctype="multipart/form-data">
      
                    
        <div class="row mx-2 pt-3 pb-3 border border-2" >
            <div class="col-md-4">
                <label class="form-label" for="reason">Programs : <label style="color: red;">*</label></label>
                <select id="" name="program" class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option value="Professional/Management Development Programme">Professional/Management Development Programme</option>
                    <option value="Orientation / Induction Programme">Orientation / Induction Programme</option>
                    <option value="Refresher and Short-term course">Refresher and Short-term course</option>
                </select>
            </div>

        
            <div class="col-md-4">
                <label class="form-label">From : <label style="color: red;">*</label></label>
                <input type="date" class="form-control" id="" name="From" placeholder="" autocomplete="off" required>
                <span id="" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
            </div>

            <div class="col-md-4">
                <label class="form-label">To : <label style="color: red;">*</label></label>
                <input type="date" class="form-control" id="" name="To" placeholder="" autocomplete="off" required>
                <span id="" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
                <br>
            </div>
            
            <div class="col-md-4" id="">
                    <label class="form-label">Institution Name Offering Programme : <label style="color: red;">*</label></label>
                    <input id="" type="text" class="form-control"  name="Institution" autocomplete="off">
                    <span id="" style="display:none;color:red;"></span>

                   
            </div>

            <div class="col-md-4">
                <label class="form-label" for="">Upload Certificate : <label style="color: red;">* (.pdf only)</label></label>
                <input id="" type="file" class="form-control" name="Certificate" accept=".pdf" onchange="validateSanction(event)" required>
                <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
            </div>     
          </div>

            <div class="col-12 text-center">
            <input type="submit" class="btn btn-outline-primary" value="Submit">
            </div>
        </form>
    </div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Programs</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Institution Name Offering Programme</th>
                <th scope="col">Upload Certificate</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->FDP;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $cover = $chapter->Certificate;
            ?>
            <tr >
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Programs?> </td>
                <td class="text-center"><?= $chapter->From?> </td>
                <td class="text-center"> <?= $chapter->To?> </td>
                <td class="text-center"> <?= $chapter->Institution_Name_Offering_Programme?> </td>
                <td class="text-center"> 
                    <?php if( !empty($cover)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Profile/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                 </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>
                    <form action="<?= base_url('deleteFDP')?>" method="post">
                        <input type="text"  style="display:none;" name="srnumber" readonly value="<?= $chapter->FDP_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                   </form>
                </td> 
                      
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->FDP_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->FDP_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateFDP')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->FDP_id?>" >
                                    </div>
                                    <div class="md-4">
                                        <label class="form-label" for="reason">Programs : <label style="color: red;">*</label></label>
                                        <select id="" name="program" class="form-control">
                                            <option  selected hidden value="<?= $chapter->Programs?>"><?= $chapter->Programs?></option>
                                            <option value="Professional/Management Development Programme">Professional/Management Development Programme</option>
                                            <option value="Orientation / Induction Programme">Orientation / Induction Programme</option>
                                            <option value="Refresher and Short-term course">Refresher and Short-term course</option>
                                        </select>
                                    </div>

                                    <div class="md-4">
                                        <label class="form-label">From : <label style="color: red;">*</label></label>
                                        <input type="date" class="form-control" id="" name="From" value="<?= $chapter->From?>" placeholder="" autocomplete="off" required>
                                        <span id="" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
                                    </div>

                                    <div class="md-4">
                                        <label class="form-label">To : <label style="color: red;">*</label></label>
                                        <input type="date" class="form-control" id="" name="To" value="<?= $chapter->To?>" placeholder="" autocomplete="off" required>
                                        <span id="" style="display:none;color:red;">Please Enter Valid Name of Agency.</span>
                                        <br>
                                    </div>
                                    
                                    <div class="md-4" id="">
                                            <label class="form-label">Institution Name Offering Programme : <label style="color: red;">*</label></label>
                                            <input id="" type="text" class="form-control"  name="Institution" value="<?= $chapter->Institution_Name_Offering_Programme?>" autocomplete="off">
                                            <span id="" style="display:none;color:red;"></span> 
                                    </div>

                                    <div class="md-4">
                                        <label class="form-label" for="">Upload Certificate : <label style="color: red;">* (.pdf only)</label></label>
                                        <input id="" type="file" class="form-control" name="Certificate" accept=".pdf" onchange="validateSanction(event)">
                                        <span id="sanctiondocumentError" name="sanctiondocument" style="color:red;"></span>
                                    </div>
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('reaserchProjectInfo');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/Reaserch_Details/reaserchProjectInfo_view.js'); ?>"></script>


<?= $this->endSection();?>