
<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
   
<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="<?= base_url(); ?>">Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link " aria-current="page" href="<?= base_url();?>/teaFaculty">Teacher Faculty Enrollment</a>
                </li>

                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?= base_url();?>/teaFacultyFecth">Show Inserted Data</a>
                </li>

            </ul>
            <form class="d-flex" method="Post" action="<?= base_url()?>/teaLogout">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('admin_user'); echo $myusername ;?></label>
                    <input type="submit" value="Logout" class="btn btn-outline-danger">
                </form>
        </div>
    </div>
</nav>

<img src="data:image/jpeg;base64,<?= base64_encode($binaryData) ?>" alt="<?= $metadata['filename'] ?>">


<?= $this->endSection();?>





