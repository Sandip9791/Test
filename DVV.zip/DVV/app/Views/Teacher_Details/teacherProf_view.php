<!DOCTYPE html>
<html>
<head>
	<title>Teacher Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        }) 
    </script>

    <link rel="stylesheet" href="<?php echo base_url('assets/css/teacherProf_view.css'); ?>">

</head>
<body >
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
    
    
    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="<?= base_url('teaProf');?>"></a>
                    </li>
                   
                    <li class="nav-item dropdown">
                    </li>
                </ul>

                <form class="d-flex" method="Post" action="<?= base_url()?>/teaLogout">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('loged_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
           </div>
       </div>
   </nav>
   
    <h1 style="margin-top:10px; margin-bottom:10px; text-align:center;">Teacher Dashboard</h1>
    <div class="container">
		<div class="section1">
			<div class="section1a mt-1">
                <h3>&nbsp; Profile</h3>
            </div>

                <?php if(isset($documents)):
                    foreach($documents as $doc):
                        $pid= $doc->PID; 
                        $images = $pid->Current_Image;
                        $title=$doc->Title;
                        $fname=$doc->First_Name;
                        $lname=$doc->Last_Name;
                        $mname=$doc->Midd_Name;
                
                        $Name = $title." ".$fname." ".$mname." ".$lname;
                        
                ?>
			<div class="section1b">
                 <?php if(!empty($images)):?>
                   <img src="<?= base_url("Userfiles/Teachers/Profile/$images")?>" alt="profile" class="profilr_pic"><br>
                 <?php else:?>
                    <img src="<?= base_url("assets/images/profile/pro.png");?>" alt="profile" class="profilr_pic"><br>
                 <?php endif;?>


                <h6><b>Name :&nbsp;</b><?= $Name?></h6>
                <h6><b>Designation :&nbsp;</b><?= $doc->Designation?></h6>
                <h6><b>Teacher Type :&nbsp;</b><?= $doc->Teacher_Type?></h6>
                <h6><b>Mobile No. :&nbsp;</b><?= $pid->Mobile_Number?></h6>
                <h6><b>Email :&nbsp;</b><?= $doc->Email?></h6>
             
                <h6><b>Gender :&nbsp;</b><?= $pid->Gender?></h6>
                <h6><b>Category :&nbsp;</b><?= $pid->Category?></h6>
                
                <h6><b>Department :&nbsp;</b><?= $doc->Department?></h6>
                <h6><b>Address :&nbsp;</b>
                  <?= $pid->Address?>
                </h6>
                <h6><b>Name of the College / Institute : </b>
                    Progressive Education Society's
                    Modern College Of Arts, Science & Commerce
                    Ganeshkhind,Pune-16.
                </h6>
            </div>
		</div>

		<div class="section2">
			<div class="section2a pt-3 ">
                <h3 class="">&nbsp; Important links :</h3>
                <?php if($doc->Teacher_Type === "HOD"):?>
                    <div class="position-absolute top-0 end-0 my-2 mx-2">
                    <a href="<?= base_url('hodProf')?>"  class=" btn btn-primary"><h6>&nbsp;HOD Dashboard&nbsp;</h6></a>
                    </div>
                <?php endif;?>
            </div>
			<div class="row g-3 my-3" style="padding-left: 0.5cm;">
                <div class="col-md-6">
                    <h3> <img src="<?= base_url('assets/images/profile/profile.png');?>" alt="Profile" class="icon1"> Profile :</h3>
                    <div class="pt-3; px-4">
                        <a href="<?= base_url('teaForm')?>" style="color:green;"><h6>&nbsp;Teacher's Details&nbsp;</h6></a>
                       
                        <a href="<?= base_url('teaAwards')?>" style="color:green;"><h6>&nbsp;Teacher's Awards&nbsp;</h6></a>
                        
                        <a href="<?= base_url('teaLearning')?>" style="color:green;"><h6>&nbsp;Teaching Learning&nbsp;</h6></a>
                        <a href="<?= base_url('fdp')?>" style="color:green;"><h6>&nbsp;Faculty Development Program (FDP)&nbsp;</h6></a>
                    </div>
                   
                </div>
                <br>
               
                
                <div class="col-md-6">
                    <h3><img src="<?= base_url('assets/images/profile/forensic.png');?>" alt="Research" class="icon2"> Research :</h3>

                    <div class="px-4">
                        <a href="<?= base_url('reaserchGuideInfo1')?>" style="color:green;"  ><h6>&nbsp;Research Guide&nbsp;</h6></a>                  
                        <a href="<?= base_url('reaserchProjectInfo')?>" style="color:green;"  ><h6>&nbsp;Research Project&nbsp;</h6></a>
                        <a href="<?= base_url('reaserchPublication')?>" style="color:green;"  ><h6>&nbsp;Research Publications&nbsp;</h6></a>
                        <a href="<?= base_url('booksAndChapter')?>" style="color:green;"  ><h6>&nbsp;Books and Chapter&nbsp;</h6></a>
                        <a href="<?= base_url('reaserchProjectMoney')?>" style="color:green;"  ><h6>&nbsp;Seed Money&nbsp;</h6></a>
                        <a href="<?= base_url('consultancy')?>"  style="color:green;"  ><h6>&nbsp;Consultancy&nbsp;</h6></a>
                        <a href="<?= base_url('mou_Linkage')?>" style="color:green;"  ><h6>&nbsp;MOU/Linkages&nbsp;</h6></a>
                        <a href="<?= base_url('reaserchProjectFollowship')?>" style="color:green;" ><h6>&nbsp;Fellowship/Financial Support&nbsp;</h6></a>
                    </div>
                </div>
                <br>
                <div class="col-md-6">
                    <h3><img src="<?= base_url('assets/images/profile/chart.png');?>" alt="Research" class="icon2"> Teaching Learning Evaluation :</h3>
                    <div class="pt-4; px-4">
                        <a href="<?= base_url('experientialLearning')?>" style="color:green;"  ><h6>&nbsp;Experiential Learning&nbsp;</h6></a>
                        <a href="<?= base_url('studentcentric')?>" style="color:green;"  ><h6>&nbsp;Student Centric Methods&nbsp;</h6></a>
                        <a href="<?= base_url('mentor')?>" style="color:green;"  ><h6>&nbsp;Mentor-Mentee Scheme&nbsp;</h6></a>
                        <a href="<?= base_url('studyTour')?>" style="color:green;"  ><h6>&nbsp;Study Tour/Field Visits&nbsp;</h6></a>
                    </div>
                </div>
                <br>
                <div class="col-md-6">
                    <h3><img src="<?= base_url('assets/images/profile/program.png');?>" alt="Program" class="icon2"> Extension & Outreach Program :</h3>
                    <div class="px-4">
                        <a href="<?= base_url('activitiesOfForum')?>" style="color:green;"  ><h6>&nbsp;Activities of Forum&nbsp;</h6></a>
                        <a href="<?= base_url('financialSupport')?>" style="color:green;"  ><h6>&nbsp;Financial Support&nbsp;</h6></a>
                        <a href="<?= base_url('alumniEngagement')?>" style="color:green;"  ><h6>&nbsp;Alumni Engagement&nbsp;</h6></a>
                        <a href="<?= base_url('sensitization')?>" style="color:green;"  ><h6>&nbsp;Sensitization of Students&nbsp;</h6></a>
                     </div>
                </div>
                
            </div>
		</div>
	</div>
<?php endforeach;?>
<?php endif;?>
</body>
</html>







    


 
 
