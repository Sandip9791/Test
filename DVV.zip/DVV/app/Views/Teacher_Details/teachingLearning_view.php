<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center">Teaching Plan </h1>
<div class="container-fluid border border-info-subtle my-4" id="Learning" style="display:none" >
		
    <form class="row g-3 my-3 mx-2 border" id="dynamic-form" action="<?= base_url('saveTeacherLearning')?>" method="post"
            enctype="multipart/form-data">

            
            <div class="col-md-4">
                <label class="form-label"> Academic Year : <label style="color: red;">*</label></label>
                <input id="Alumni" type="date" name="scode" class="form-control" autocomplete="off" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>

            <div class="col-md-4">
                <label class="form-label"> Subject Code : <label style="color: red;">*</label></label>
                <input id="Alumni" type="text" name="scode" class="form-control" autocomplete="off" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>


            <div class="col-md-4">
              <label class="form-label">Subject Name : <label style="color: red;">*</label></label>
              <input id="subject" type="text" class="form-control" name="sname" autocomplete="off" oninput="validateSubjectName()" required>
              <span id="subjectnameError" style="display:none;color:red;">Please Enter a valid Subject Name.</span>
            </div>

            <div class="col-sm-4">
                <label class="form-label" for="sanction-name"> Upload Teaching Plan : <label style="color: red;">* (Choose PDF files only, under 500KB)</label></label><br>
                <input type="file" id="teaPlan" class="form-control" name="plan"  accept=".pdf" onchange="validateTeaPlan(event)" required>
                <span id="teaPlanError" style="color:red;"></span>
            </div>


            <div class="col-12 py-2 text-center">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Subject Code</th>
                <th scope="col">Subject Name</th>
                <th scope="col">Teaching Plan</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Teacher_Learning;
        ?>
        <tbody>
            <?php
                foreach($book as $chapter):
                $national = $chapter->Teaching_Plan;
             
            ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++;?></th>
                <td class="text-center"> <?= $chapter->Subject_Code?></td>
                <td class="text-center"> <?= $chapter->Subject_Name?></td>
                <td class="text-center">
                     <?php if( !empty($national)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Profile/').$national;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"> 
                    <form action="<?= base_url('deleteTeacherLearning')?>" method="post">
                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->Teacher_Learning_id?>">
                    <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br><input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                    
                <td> 
                    <div class="text-center">
                        <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  <br>
                        <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Teacher_Learning_id?>" data-bs-whatever="@mdo">Update</button>
                    </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Teacher_Learning_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Teaching Plan</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('updateTeacherLearning')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">BookAndChapter id : <label
                                                style="color: red;">*</label></label>
                                        <input type="text" class="form-control" name="srnumber" readonly  value="<?= $chapter->Teacher_Learning_id?>" >
                                        <span style="display:none;color:red;">Please enter a valid title.</span>
                                    </div>

                                     <div class="md-4">
                                          <label class="form-label"> Subject Code : <label style="color: red;">*</label></label>
                                          <input id="Alumni1<?= $chapter->Teacher_Learning_id?>" type="text" name="scode" value="<?= $chapter->Subject_Code?>" class="form-control" autocomplete="off" required>
                                          <span id="researcherror1<?= $chapter->Teacher_Learning_id?>" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                      </div><br>


                                      <div class="md-4">
                                        <label class="form-label">Subject Name : <label style="color: red;">*</label></label>
                                        <input id="subject1<?= $chapter->Teacher_Learning_id?>" type="text" class="form-control" name="sname" value="<?= $chapter->Subject_Name?>" autocomplete="off" oninput="validateSubjectName1<?= $chapter->Teacher_Learning_id?>()" required>
                                        <span id="subjectnameError1<?= $chapter->Teacher_Learning_id?>" style="display:none;color:red;">Please Enter a valid Subject Name.</span>
                                      </div><br>

                                      <script>
                                        function validateSubjectName1<?= $chapter->Teacher_Learning_id?>() {
                                            var regName = /[a-zA-Z ]$/;
                                            var name = document.getElementById('subject1<?= $chapter->Teacher_Learning_id?>').value;
                                            var error = document.getElementById("subjectnameError1<?= $chapter->Teacher_Learning_id?>");

                                            // Remove any non-alphabetical characters from the input
                                            var sanitizedName = name.replace(/[^a-zA-Z ]/g, '');
                                            
                                            // Split the input into words and capitalize the first letter of each word
                                            var words = sanitizedName.split(" ");
                                            var capitalizedWords = words.map(function(word) {
                                                return word.charAt(0).toUpperCase() + word.slice(1);
                                            });
                                            
                                            // Join the capitalized words back together
                                            var finalSubName1 = capitalizedWords.join(" ");
                                            
                                            document.getElementById('subject1<?= $chapter->Teacher_Learning_id?>').value = finalSubName1;

                                            if (finalSubName1.length === 0) {
                                                error.style.display = "none";
                                            } else if (!regName.test(finalSubName1)) {
                                                error.style.display = "block";
                                            } else {
                                                error.style.display = "none";
                                            }
                                            }

                                      </script>

                                      <div class="md-4">
                                          <label for="sanction-name"> Upload Teaching Plan : <label style="color: red;">* (Choose PDF files only, under 500KB)</label></label><br>
                                          <input type="file" id="teaPlan1<?= $chapter->Teacher_Learning_id?>" class="form-control" name="plan"  accept=".pdf" onchange="validateTeaPlan1<?= $chapter->Teacher_Learning_id?>(event)">
                                          <span id="teaPlanError1<?= $chapter->Teacher_Learning_id?>" style="color:red;"></span>
                                      </div>  
                                      <script>
                                        function validateTeaPlan1<?= $chapter->Teacher_Learning_id?>(event) 
                                        {
                                            const file = event.target.files[0];
                                            const errorElement = document.getElementById('teaPlanError1<?= $chapter->Teacher_Learning_id?>');
                                            if (!file.type.match('pdf')) 
                                            {
                                                errorElement.textContent = 'File is not a PDF.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            if (file.size > 500 * 1024) 
                                            {
                                                errorElement.textContent = 'File is too big. Maximum size is 500 KB.';
                                                event.target.value = ''; // Clear the file input
                                                return;
                                            }
                                            // If the file is valid, clear the error message
                                            errorElement.textContent = '';
                                        }    
                                      </script>
                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit"  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
         const showFormCheckbox = document.getElementById('btncheck1');
         const myForm = document.getElementById('Learning');
         //const msg = document.getElementById('msg');
 
         showFormCheckbox.addEventListener('change', function() {
           if (this.checked) {
             myForm.style.display="block";
             //msg.style.display="none";
           } else {
             myForm.style.display="none";
             //msg.style.display="block";
           }
         });
</script>
  <script src="<?php echo base_url('assets/js/Teacher_Details/teachingLearning_view.js'); ?>"></script>

<?= $this->endSection();?>

