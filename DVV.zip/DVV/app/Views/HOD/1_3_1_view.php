<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>

<h1 class="text-center my-3">1.3.1</h1>
<h5 class="my-3" >( Institution integrates cross-cutting issues relevant to Professional Ethics, Gender, Human Values, Environment and Sustainability and other value framework enshrined in Sustainable Development Goals and National Education Policy - 2020 into the Curriculum )</h5>

<div class="container-fluid border border-info-subtle my-4 " style="display:none" id="hod">
        <form class="row g-3 my-3 mx-2" method="post" action="<?= base_url('save_1_3_1') ?>" enctype="multipart/form-data">

        <div class="pt-3 pb-3 border border-2">
            <div class="col-md-12 mx-3 my-3">
                <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist(1)">
                <label class="form-check-label ps-2 " for="flexRadioDefault1">Professional Ethics</label>

                <div class="col-md-11 my-3" id="sublist1" style="display: none;"><br>
                    <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                    <textarea name="professional_ethics" class="form-control" id="wordLimitedTextarea1" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords1"> 200</span></p>
                    
                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                        <input id="" type="file" class="form-control" name="professional_ethics_document" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                        
                    </div>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">* Select PDF file under 500KB (Optional)</label></label>
                        <input id="" type="file" class="form-control" name="professional_ethics_photo" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                    </div>
               </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2">
            <div class="col-md-12 mx-3 my-3 ">
                <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist(2)">
                <label class="form-check-label ps-2" for="flexRadioDefault1">Gender</label>
                <div class="col-md-11" id="sublist2" style="display: none;"><br>
                    <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                    <textarea name="gender" class="form-control" id="wordLimitedTextarea2" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords2"> 200</span></p>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                        <input id="" type="file" class="form-control" name="gender_document" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                        
                    </div>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">* Select PDF file under 500KB (Optional)</label></label>
                        <input id="" type="file" class="form-control" name="gender_photo" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                    </div>
                </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2">
            <div class="col-md-12 mx-3 my-3">
                <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist(3)">
                <label class="form-check-label ps-2" for="flexRadioDefault1">Human Values</label>
                <div class="col-md-11"  id="sublist3" style="display: none;"><br>
                    <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                    <textarea name="human_values" class="form-control" id="wordLimitedTextarea3" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords3"> 200</span></p>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                        <input id="" type="file" class="form-control" name="human_values_document" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                        
                    </div>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">* Select PDF file under 500KB (Optional)</label></label>
                        <input id="" type="file" class="form-control" name="human_values_photo" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                    </div>
                </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2">
            <div class="col-md-12 mx-3 my-3">
                <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault4" onclick="toggleSublist(4)">
                <label class="form-check-label ps-2" for="flexRadioDefault4">Environment and Sustainability</label>
                <div class="col-md-11"  id="sublist4" style="display: none;"><br>
                    <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                    <textarea name="environment" class="form-control" id="wordLimitedTextarea4" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords4"> 200</span></p>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                        <input id="" type="file" class="form-control" name="environment_document" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                        
                    </div>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">* Select PDF file under 500KB (Optional)</label></label>
                        <input id="" type="file" class="form-control" name="environment_photo" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                    </div>
                </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2">
            <div class="col-md-12 mx-3 my-3">
                <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault5" onclick="toggleSublist(5)">
                <label class="form-check-label ps-2" for="flexRadioDefault5">Others</label>
                <div class="col-md-11"  id="sublist5" style="display: none;"><br>
                    <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                    <textarea name="others" class="form-control" id="wordLimitedTextarea5" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords5"> 200</span></p>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                        <input id="" type="file" class="form-control" name="others_document" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                        
                    </div>

                    <div class="col-md-6 my-3" >
                        <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">* Select PDF file under 500KB (Optional)</label></label>
                        <input id="" type="file" class="form-control" name="others_photo" accept=".pdf" oninput="validatesyllabi(event)" >
                        <span id="uploadPOsError" style="color:red;"></span> 
                    </div>
                </div>
            </div>
        </div>

                <script>
                    function toggleSublist(listNum) {
                    var sublist = document.getElementById("sublist" + listNum);
                    sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                    }
                </script>

                
            <div class="col-sm-4 my-3">
                <label class="form-label" for="sanction-name">Upload Course syllabi : <label style="color: red;">* Select PDF file under 500KB</label></label><br>
                <input id="syllabi" type="file" class="form-control" name="syllabi" accept=".pdf" oninput="validatesyllabi(event)" required>
                <span id="syllabiError" style="color:red;"></span>
                <br>
            </div>

            <div class="col-12 my-3 text-center">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
            </div>
            
		</form>
</div>


<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Professional Ethics</th>
                <th scope="col">Professional Ethics Document</th>
                <th scope="col">Professional Ethics Photo</th>
                <th scope="col">Gender</th>
                <th scope="col">Gender Document</th>
                <th scope="col">Gender Photo</th>
                <th scope="col">Human Values</th>
                <th scope="col">Human Values Document</th>
                <th scope="col">Human Values Photo</th>
                <th scope="col">Environment and Sustainability</th>
                <th scope="col">Environment Document</th>
                <th scope="col">Environment Photo</th>
                <th scope="col">Others</th>
                <th scope="col">Others Document</th>
                <th scope="col">Others Photo</th>
                <th scope="col">Course Syllabi</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_1_3_1;
                $po1 = $book->Professional_Ethics_Document;
                $po2 = $book->Professional_Ethics_Photo;

                $co1 = $book->Gender_Document;
                $co2 = $book->Gender_Photo;

                $Values1 = $book->Human_Values_Document;
                $Values2 = $book->Human_Values_Photo;

                $Environment1 = $book->Environment_Document;
                $Environment2 = $book->Environment_Photo;

                $other1 = $book->Others_Document;
                $other2 = $book->Others_Photo;

                $course = $book->Course_Syllabi;
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <!--  -->
                <td class="text-center"><?= $book->Professional_Ethics?> </td>
                <td class="text-center"> 
                    <?php if(!empty($po1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <td class="text-center"> 
                    <?php if(!empty($po2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <!--  -->
                <td class="text-center"><?= $book->Gender?> </td>
                <td class="text-center"> 
                    <?php if(!empty($co1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$co1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <td class="text-center"> 
                    <?php if(!empty($co2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$co2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                </td>

                  <!--  -->
                <td class="text-center"> <?= $book->Human_Values?></td>
                <td class="text-center">
                    <?php if(!empty($Values1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Values1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <td class="text-center"> 
                    <?php if(!empty($Values2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Values2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  

                  
                </td>
                
                <!--  -->
                <td class="text-center"> <?= $book->Environment_and_Sustainability?></td>
                <td class="text-center">
                    <?php if(!empty($Environment1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Environment1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <?php if(!empty($Environment2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Environment2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <!--  -->
                <td class="text-center"> <?= $book->Others?></td>
                <td class="text-center">
                    <?php if(!empty($other1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$other1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>   

                   
                </td>
                <td class="text-center"> 
                    <?php if(!empty($other2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$other2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>

                <td class="text-center"> 
                    <?php if(!empty($course)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$course;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>    
                </td>

               
                <td> 

                    <?php if(empty($course)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>


                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_1_3_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>
                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <div class="md-12 mx-3 ">
                                            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist<?= $book->HOD_id?>(1)">
                                            <label class="form-check-label ps-2 " for="flexRadioDefault1">Professional Ethics</label>

                                            <div class="md-11" id="sublist<?= $book->HOD_id?>1" style="display: none;"><br>
                                                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                                <textarea name="professional_ethics" class="form-control" id="wordLimitedTextarea1" rows="3" data-word-limit="200"><?= $book->Professional_Ethics?></textarea>
                                                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords1"> 200</span></p>
                                                
                                                <div class="md-6 py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">Select PDF file under 500KB</label></label>
                                                    <input id="" type="file" class="form-control" name="professional_ethics_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                   

                                                </div>

                                                <div class="md-6 py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">Select file under 500KB (Optional)</label></label>
                                                    <input id="" type="file" class="form-control" name="professional_ethics_photo" accept=".jpg,.jpeg,.png" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                     
                                                    <br>
                                                </div>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <div class="md-12 mx-3 ">
                                            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist<?= $book->HOD_id?>(2)">
                                            <label class="form-check-label ps-2" for="flexRadioDefault1">Gender</label>
                                            <div class="md-11" id="sublist<?= $book->HOD_id?>2" style="display: none;"><br>
                                                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                                <textarea name="gender" class="form-control" id="wordLimitedTextarea2" rows="3" data-word-limit="200"><?= $book->Gender?></textarea>
                                                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords2"> 200</span></p>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">Select PDF file under 500KB</label></label>
                                                    <input id="" type="file" class="form-control" name="gender_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">Select file under 500KB (Optional)</label></label>
                                                    <input id="" type="file" class="form-control" name="gender_photo" accept=".jpg,.jpeg,.png" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <div class="md-12 mx-3 ">
                                            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist<?= $book->HOD_id?>(3)">
                                            <label class="form-check-label ps-2" for="flexRadioDefault1">Human Values</label>
                                            <div class="md-11"  id="sublist<?= $book->HOD_id?>3" style="display: none;"><br>
                                                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                                <textarea name="human_values" class="form-control" id="wordLimitedTextarea3" rows="3" data-word-limit="200"><?= $book->Human_Values?></textarea>
                                                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords3"> 200</span></p>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">Select PDF file under 500KB</label></label>
                                                    <input id="" type="file" class="form-control" name="human_values_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">Select file under 500KB (Optional)</label></label>
                                                    <input id="" type="file" class="form-control" name="human_values_photo" accept=".jpg,.jpeg,.png" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <div class="md-12 mx-3 ">
                                            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault4" onclick="toggleSublist<?= $book->HOD_id?>(4)">
                                            <label class="form-check-label ps-2" for="flexRadioDefault4">Environment and Sustainability</label>
                                            <div class="md-11"  id="sublist<?= $book->HOD_id?>4" style="display: none;"><br>
                                                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                                <textarea name="environment" class="form-control" id="wordLimitedTextarea4" rows="3" data-word-limit="200"><?= $book->Environment_and_Sustainability?></textarea>
                                                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords4"> 200</span></p>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">Select PDF file under 500KB</label></label>
                                                    <input id="" type="file" class="form-control" name="environment_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>

                                                <div class="md-6  py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">Select file under 500KB (Optional)</label></label>
                                                    <input id="" type="file" class="form-control" name="environment_photo" accept=".jpg,.jpeg,.png" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <div class="md-12 mx-3 ">
                                            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault5" onclick="toggleSublist<?= $book->HOD_id?>(5)">
                                            <label class="form-check-label ps-2" for="flexRadioDefault5">Others</label>
                                            <div class="md-11"  id="sublist<?= $book->HOD_id?>5" style="display: none;"><br>
                                                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                                <textarea name="others" class="form-control" id="wordLimitedTextarea5" rows="3" data-word-limit="200"><?= $book->Others?></textarea>
                                                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords5"> 200</span></p>

                                                <div class="md-6 py-3">
                                                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">Select PDF file under 500KB</label></label>
                                                    <input id="" type="file" class="form-control" name="others_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>

                                                <div class="md-6  py-3" >
                                                    <label class="form-label" for="sanction-name">Upload Relavent Photo : <label style="color: red;">Select file under 500KB (Optional)</label></label>
                                                    <input id="" type="file" class="form-control" name="others_photo" accept=".jpg,.jpeg,.png" oninput="validatesyllabi(event)" >
                                                    <span id="uploadPOsError" style="color:red;"></span> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="md-4  py-3">
                                        <label class="form-label" for="sanction-name">Upload Course syllabi : <label style="color: red;">Select PDF file under 500KB</label></label><br>
                                        <input id="syllabi" type="file" class="form-control" name="syllabi" accept=".pdf" oninput="validatesyllabi(event)">
                                        <span id="syllabiError" style="color:red;"></span>
                                    </div>

                                    <script>
                                        function toggleSublist<?= $book->HOD_id?>(listNum) {
                                        var sublist = document.getElementById("sublist<?= $book->HOD_id?>" + listNum);
                                        sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                                        }
                                    </script>
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>
<script src="<?php echo base_url('assets/js/HOD/1_3_1_view.js'); ?>"></script>

<?= $this->endSection();?>



