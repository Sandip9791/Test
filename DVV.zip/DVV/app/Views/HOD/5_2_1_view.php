<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>

<h1 class="text-center my-3">Student progression & placement (5.2.1,5.2.2)</h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
		<form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_5_2_1') ?>" enctype="multipart/form-data">
    <div class="row pt-3 pb-3 border border-2">
            <div class="col-md-5 my-3">
                <label class="form-label"><b>A. <u>Placement</u> :</b></label><br>
                <label class="form-label">Download Excel :</label><br>
                <label class="form-label">Fill the excel and upload : <a href="<?= base_url('assets\pdf\5_2_1.xlsx') ?>">Download Excel Templete</a></label>
                <input type="file" class="form-control" name="excel"  accept=".csv,.xlsx" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            <div class="col-md-1">

            </div>
            <div class="col-md-5 my-3">
                <label class="form-label"><b>B. <u>Student Progression</u> :</b></label><br>
                <label class="form-label">Google form to be shared to student & the link of form to be given :</label>
                <label class="form-label">Fill the excel and upload : <a href="<?= base_url('assets\pdf\5_2_2.xlsx') ?>">Download Excel Templete</a></label>
                <input class="form-control" type="url" name="gform_link" >
            </div>
            </div>
           

            <div class="col-12 my-3 text-center">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
</div>

<!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Placement</th>
                <th scope="col">Student Progression</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_5_2_1;
                $co = $book->Excel_Student_progression_placement;
        ?>
        <tbody >
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"> 
                    <?php if( !empty($co)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_V/').$co;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                   
                </td>
                <td class="text-center"><?= $book->Google_form_link?> </td>
                <td> 

                    <?php if( empty($co)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_5_2_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="md-5 py-4">
                                        <label class="form-label"><b>A. <u>Placement</u> :</b></label><br>
                                        <label class="form-label">Download Excel :</label><br>
                                        <label class="form-label">Fill the excel and upload : <a href="<?= base_url('assets\pdf\5_2_1.xlsx') ?>">Download Excel Templete</a></label>
                                        <input type="file" class="form-control" name="excel"  accept=".csv,.xlsx" >
                                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                                       
                                    </div>

                                    <div class="md-5 py-4">
                                        <label class="form-label"><b>B. <u>Student Progression</u> :</b></label><br>
                                        <label class="form-label">Google form to be shared to student & the link of form to be given :</label>
                                        <label class="form-label">Fill the excel and upload : <a href="<?= base_url('assets\pdf\5_2_2.xlsx') ?>">Download Excel Templete</a></label>
                                        <input class="form-control" type="url" name="gform_link" value="<?= $book->Google_form_link?>">
                                    </div>      
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/5_2_1_view.js'); ?>"></script>

<?= $this->endSection();?>



