
<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">7.1.8</h1>
<h5 class="ps-3 my-3">( Describe the Institutional efforts/initiatives in providing an inclusive environment i.e., tolerance and harmony towards cultural, regional, linguistic, communal socioeconomic and such other diversities )  </h5>

  <div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
	<form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_7_1_8') ?>" enctype="multipart/form-data"> 
    <div class="row pt-3 pb-3 border border-2">
        <div class="col-md-12 form-check">

                <input type="checkbox" name="Cultural_Checkbox" id="form1Checkbox" onclick="showForm1()">
                <label for=""> Cultural</label>
                <div id="form1">
                    <div class="row py-2 mx-1">
                         <div class="col-md-4 my-3">
                             <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only) </label></label><br>
                             <input type="file" class="form-control" name="cultural" accept=".pdf">
                         </div>
                    </div>
                 </div>
                  

                 <br>
                <input type="checkbox" name="Regional_Checkbox" id="form2Checkbox" onclick="showForm2()"  >
                <label for="">Regional </label>
                <div id="form2">
                    <div class="row py-2 mx-1 ">
                            <div class="col-md-4 my-3">
                                <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                                <input type="file" class="form-control" name="regional" accept=".pdf">
                            </div>
                    </div>
                 </div>

                 <br>
                <input type="checkbox" name="Linguistic_Checkbox" id="form3Checkbox" onclick="showForm3()"  >
                <label for="">Linguistic</label>
                <div id="form3">
                    <div class="col-md-4 my-3">
                        <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                        <input type="file" class="form-control" name="linguistic" accept=".pdf">
                    </div>
                 </div>
    
                 <br>
                <input type="checkbox" name="Communal_Socioeconomic_Checkbox" id="form4Checkbox" onclick="showForm4()">
                <label for="">Communal Socioeconomic</label><br>
                <div id="form4">
                    <div class="col-md-4 my-3">
                        <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                        <input type="file" class="form-control" name="communal_socioeconomic"  accept=".pdf">
                    </div>
                 </div>

               
                 <input type="checkbox" name="other_Diversities_Checkbox" id="form5Checkbox" onclick="showForm5()">
                 <label for="">other Diversities</label>
                 <div id="form5">
                    <div class="row">
                        <div class="col-md-4 my-3">
                            <label class="form-label">other  :<label style="color: red;">* </label></label>
                            <input type="text" class="form-control" name="other_diversities">
                           
                        </div>
                        <div class="col-md-4 my-3">
                           <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label>
   
                           <input type="file" class="form-control" name="other_diversities_doc" accept=".pdf">
                       </div>
                    </div>
                  </div>

        </div>

        <div class="col-md-12 my-3">
                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                <textarea name="institutional_efforts" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                <script>
                    // Function to enforce the word limit on the textarea
                    function enforceWordLimit(event) {
                        const wordLimit =  200; // Set your desired word limit here
                        const textarea = event.target;
                        const words = textarea.value.trim().split(/\s+/);
                        const remainingWords = wordLimit - words.length;
            
                        if (remainingWords < 0) {
                            // If the user exceeds the word limit, prevent further input
                            event.preventDefault();
                            textarea.value = words.slice(0, wordLimit).join(' ');
                        }
            
                        // Update the remaining words count
                        document.getElementById('remainingWords').textContent = remainingWords;
                    }
            
                    // Attach the event listener to the textarea
                    const textareaElement = document.getElementById('wordLimitedTextarea');
                    textareaElement.addEventListener('input', enforceWordLimit);
                </script>
        </div>

    </div>
            <br>

            <div class="col-12 my-3 text-center">
               <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
	</div>


    <!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Cultural</th>
                <th scope="col">Regional</th>
                <th scope="col">Linguistic</th>
                <th scope="col">Communal Socioeconomic</th>
                <th scope="col">Other Diversities</th>
                <th scope="col">Institutional Efforts</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_7_1_8;
                $Cultural = $book->Cultural;
                $Regional = $book->Regional;
                $Linguistic = $book->Linguistic;
                $Communal_socioeconomic = $book->Communal_socioeconomic;
                $other_Diversities_Document = $book->other_Diversities_Document;
        ?>
        <tbody >
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"> 
                    <?php if( !empty($Cultural)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Cultural;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
 
                </td>
                <td class="text-center"> 
                    <?php if( !empty($Regional)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Regional;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>

                  
                </td>
                <td class="text-center">
                    <?php if( !empty($Linguistic)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Linguistic;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center">

                    <?php if( !empty($Communal_socioeconomic)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Communal_socioeconomic;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                    
                </td>
                <td class="text-center"> 
                       <?= $book->other_Diversities?>
                       <br>

                    <?php if( !empty($other_Diversities_Document)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$other_Diversities_Document;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"><?= $book->Institutional_efforts?> </td>
                <td > 

                    <?php if(empty($book->Institutional_efforts) && empty($book->Institutional_efforts)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">7.1.8</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_7_1_8')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                     <div class="md-12 form-check">

                                            <input type="checkbox" name="Cultural_Checkbox" id="form1Checkbox<?= $book->HOD_id?>" onclick="showForm1<?= $book->HOD_id?>()">
                                            <label for=""> Cultural</label>
                                            <div id="form1<?= $book->HOD_id?>">
                                                <div class="row py-2 mx-1">
                                                    <div class="md-4 py-3">
                                                        <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                                                        <input type="file" class="form-control" name="cultural" accept=".pdf">
                                                        <?php if(isset($Cultural->Name) && !empty($Cultural->Name) && !($Cultural->Name === "dummy.pdf")):?>
                                                             <a href="<?= base_url("assets/userFiles/$Cultural->Name")?>"><?= $Cultural->Name?></a>
                                                        <?php endif;?>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <input type="checkbox" name="Regional_Checkbox" id="form2Checkbox<?= $book->HOD_id?>" onclick="showForm2<?= $book->HOD_id?>()"  >
                                            <label for="">Regional </label>
                                            <div id="form2<?= $book->HOD_id?>">
                                                <div class="row py-2 mx-1 ">
                                                        <div class="md-4 py-3">
                                                            <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                                                            <input type="file" class="form-control" name="regional" accept=".pdf">
                                                            <?php if(isset($Regional->Name) && !empty($Regional->Name) && !($Regional->Name === "dummy.pdf")):?>
                                                                <a href="<?= base_url("assets/userFiles/$Regional->Name")?>"><?= $Regional->Name?></a>
                                                            <?php endif;?>
                                                        </div>
                                                </div>
                                            </div>
                                            <br>
                                            <input type="checkbox" name="Linguistic_Checkbox" id="form3Checkbox<?= $book->HOD_id?>" onclick="showForm3<?= $book->HOD_id?>()"  >
                                            <label for="">Linguistic</label>
                                            <div id="form3<?= $book->HOD_id?>">
                                                <div class="md-4 py-3">
                                                    <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                                                    <input type="file" class="form-control" name="linguistic" accept=".pdf">
                                                    <?php if(isset($Linguistic->Name) && !empty($Linguistic->Name) && !($Linguistic->Name === "dummy.pdf")):?>
                                                        <a href="<?= base_url("assets/userFiles/$Linguistic->Name")?>"><?= $Linguistic->Name?></a>
                                                    <?php endif;?>
                                                </div>
                                            </div>
                                
                                            <br>
                                            <input type="checkbox" name="Communal_Socioeconomic_Checkbox" id="form4Checkbox<?= $book->HOD_id?>" onclick="showForm4<?= $book->HOD_id?>()">
                                            <label for="">Communal Socioeconomic</label><br>
                                            <div id="form4<?= $book->HOD_id?>">
                                                <div class="md-4 py-3">
                                                    <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label><br>
                                                    <input type="file" class="form-control" name="communal_socioeconomic" accept=".pdf">
                                                    <?php if(isset($Communal_socioeconomic->Name) && !empty($Communal_socioeconomic->Name) && !($Communal_socioeconomic->Name === "dummy.pdf")):?>
                                                        <a href="<?= base_url("assets/userFiles/$Communal_socioeconomic->Name")?>"><?= $Communal_socioeconomic->Name?></a>
                                                    <?php endif;?>
                                                </div>
                                            </div>

                                            
                                            <input type="checkbox" name="other_Diversities_Checkbox" id="form5Checkbox<?= $book->HOD_id?>" onclick="showForm5<?= $book->HOD_id?>()">
                                            <label for="">other Diversities</label>
                                            <div id="form5<?= $book->HOD_id?>">
                                                <div class="row">
                                                    <div class="md-4 py-3">
                                                        <label class="form-label">other  :<label style="color: red;">* </label></label>
                                                        <input type="text" class="form-control" name="other_diversities" value="<?= $book->other_Diversities?>"  >
                                                    
                                                    </div>
                                                    <div class="md-4 py-3">
                                                    <label class="form-label">Upload Report of Activity  :<label style="color: red;">* (.pdf only)</label></label>
                                                    <input type="file" class="form-control" name="other_diversities_doc" accept=".pdf">
                                                    <?php if(isset($other_Diversities_Document->Name) && !empty($other_Diversities_Document->Name) && !($other_Diversities_Document->Name === "dummy.pdf")):?>
                                                        <a href="<?= base_url("assets/userFiles/$other_Diversities_Document->Name")?>"><?= $other_Diversities_Document->Name?></a>
                                                    <?php endif;?>
                                                </div>
                                                </div>
                                            </div>

                                    </div>

                                    <div class="md-12">
                                            <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                            <textarea name="institutional_efforts" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"><?= $book->Institutional_efforts?></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                            <script>
                                                // Function to enforce the word limit on the textarea
                                                function enforceWordLimit(event) {
                                                    const wordLimit =  200; // Set your desired word limit here
                                                    const textarea = event.target;
                                                    const words = textarea.value.trim().split(/\s+/);
                                                    const remainingWords = wordLimit - words.length;
                                        
                                                    if (remainingWords < 0) {
                                                        // If the user exceeds the word limit, prevent further input
                                                        event.preventDefault();
                                                        textarea.value = words.slice(0, wordLimit).join(' ');
                                                    }
                                        
                                                    // Update the remaining words count
                                                    document.getElementById('remainingWords').textContent = remainingWords;
                                                }
                                        
                                                // Attach the event listener to the textarea
                                                const textareaElement = document.getElementById('wordLimitedTextarea');
                                                textareaElement.addEventListener('input', enforceWordLimit);
                                            </script>
                                    </div>

                                    <script>

                                            document.getElementById('form1<?= $book->HOD_id?>').style.display='none';
                                            document.getElementById('form2<?= $book->HOD_id?>').style.display='none';
                                            document.getElementById('form3<?= $book->HOD_id?>').style.display='none';
                                            document.getElementById('form4<?= $book->HOD_id?>').style.display='none';
                                            document.getElementById('form5<?= $book->HOD_id?>').style.display='none';

                                            function showForm1<?= $book->HOD_id?>()
                                            {
                                                // Get references to the checkboxes and forms
                                                const form1Checkbox = document.getElementById('form1Checkbox<?= $book->HOD_id?>');
                                                const form1Div = document.getElementById('form1<?= $book->HOD_id?>');

                                                form1Checkbox.addEventListener('change', () => {
                                                form1Div.style.display = form1Checkbox.checked ? 'block' : 'none';
                                                });
                                            }

                                            function showForm2<?= $book->HOD_id?>()
                                            {
                                                // Get references to the checkboxes and forms
                                                const form2Checkbox = document.getElementById('form2Checkbox<?= $book->HOD_id?>');
                                                const form2Div = document.getElementById('form2<?= $book->HOD_id?>');

                                                form2Checkbox.addEventListener('change', () => {
                                                form2Div.style.display = form2Checkbox.checked ? 'block' : 'none';
                                                });
                                                
                                            }

                                            function showForm3<?= $book->HOD_id?>()
                                            {
                                                const form3Checkbox = document.getElementById('form3Checkbox<?= $book->HOD_id?>');
                                                const form3Div = document.getElementById('form3<?= $book->HOD_id?>');

                                                form3Checkbox.addEventListener('change', () => {
                                                form3Div.style.display = form3Checkbox.checked ? 'block' : 'none';
                                                });

                                            }

                                            function showForm4<?= $book->HOD_id?>()
                                            {
                                                const form4Checkbox = document.getElementById('form4Checkbox<?= $book->HOD_id?>');
                                                const form4Div = document.getElementById('form4<?= $book->HOD_id?>');

                                                form4Checkbox.addEventListener('change', () => {
                                                form4Div.style.display = form4Checkbox.checked ? 'block' : 'none';
                                                });
                                            }

                                            function showForm5<?= $book->HOD_id?>()
                                            {
                                                const form5Checkbox = document.getElementById('form5Checkbox<?= $book->HOD_id?>');
                                                const form5Div = document.getElementById('form5<?= $book->HOD_id?>');

                                                form5Checkbox.addEventListener('change', () => {
                                                form5Div.style.display = form5Checkbox.checked ? 'block' : 'none';
                                                });
                                            }

                                    </script>
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script>

    document.getElementById('form1').style.display='none';
    document.getElementById('form2').style.display='none';
    document.getElementById('form3').style.display='none';
    document.getElementById('form4').style.display='none';
    document.getElementById('form5').style.display='none';

    function showForm1()
    {
        // Get references to the checkboxes and forms
        const form1Checkbox = document.getElementById('form1Checkbox');
        const form1Div = document.getElementById('form1');

        form1Checkbox.addEventListener('change', () => {
        form1Div.style.display = form1Checkbox.checked ? 'block' : 'none';
        });
    }

    function showForm2()
    {
        // Get references to the checkboxes and forms
        const form2Checkbox = document.getElementById('form2Checkbox');
        const form2Div = document.getElementById('form2');

        form2Checkbox.addEventListener('change', () => {
        form2Div.style.display = form2Checkbox.checked ? 'block' : 'none';
        });
        
    }

    function showForm3()
    {
        const form3Checkbox = document.getElementById('form3Checkbox');
        const form3Div = document.getElementById('form3');

        form3Checkbox.addEventListener('change', () => {
        form3Div.style.display = form3Checkbox.checked ? 'block' : 'none';
        });

    }

    function showForm4()
    {
        const form4Checkbox = document.getElementById('form4Checkbox');
        const form4Div = document.getElementById('form4');

        form4Checkbox.addEventListener('change', () => {
        form4Div.style.display = form4Checkbox.checked ? 'block' : 'none';
        });
    }

    function showForm5()
    {
        const form5Checkbox = document.getElementById('form5Checkbox');
        const form5Div = document.getElementById('form5');

        form5Checkbox.addEventListener('change', () => {
        form5Div.style.display = form5Checkbox.checked ? 'block' : 'none';
        });
    }

</script>

<script src="<?= base_url('assets/js/HOD/7_1_8_view.js'); ?>"></script>

<?= $this->endSection();?>


 
