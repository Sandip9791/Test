
<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>

    <h1 class="text-center my-3"> 1.1.1 </h1>
    <h5 class="text-center my-3">( Program outcome and course outcome )</h5>
<div class="container-fluid border border-info-subtle" style="display:none" id="hod" >
        
    <form method="post" action="<?=base_url('save_1_1_1')?>" enctype="multipart/form-data">
    <br>
        <div class="row mx-2 pt-3 pb-3 border border-2" >
          
                <div class="col-md-12 my-3">
                    <label >Curricula developed and implemented have relevance to the local, regional, national, and global developmental needs, which is reflected in the Programme outcomes (POs) and Course Outcomes(COs) of the Programmes offered by the institution : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="curriculaDeveloped" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    
                </div>
                 

                 <div class="col-md-6 my-3">
                    <label class="form-label">Enter POs Link : <label style="color: red;">*</label></label>
                    <input id="" type="text" class="form-control" name="posLink" autocomplete="off" required>
                    <span id="" style="display:none;color:red;">Please enter a valid link.</span>
                     
                </div>

                <div class="col-md-6 my-3">
                    <label class="form-label">Upload POs:<label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="uploadPOs" name="poFile" type="file" class="form-control" accept=".pdf" oninput="validateuploadPOs(event)">
                    <span id="uploadPOsError" style="color:red;"></span> 
                </div>
                   
                <div class="col-md-6 my-3">
                    <label class="form-label">Enter COs Link : <label style="color: red;">*</label></label>
                    <input id="" type="text" class="form-control" name="cosLink" accept=".pdf" autocomplete="off" required>
                    <span id="" style="display:none;color:red;">Please enter a valid link.</span>
                     
                </div>
                
                <div class="col-md-6 my-3">
                    <label class="form-label">Upload COs:<label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="uploadCOs" name="coFile" type="file" class="form-control" accept=".pdf" oninput="validateuploadCOs(event)">
                    <span id="uploadCOsError" style="color:red;"></span> 
                </div>              
        </div> 
        <br>
        <div class="col-12 text-center my-3">
                   <input type="submit" class="btn btn-outline-primary">
                 </div>
                 <br>
        </form>
</div>
   
<!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Curricula developed and implemented have relevance to the local, regional, national, and global developmental needs, which is reflected in the Programme outcomes (POs) and Course Outcomes(COs) of the Programmes offered by the institution </th>
                <th scope="col">POs Link</th>
                <th scope="col">COs Link</th>
                <th scope="col">POs</th>
                <th scope="col">COs</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_1_1_1;
                $po = $book->Programme_Outcomes;
                $co = $book->Course_Outcomes;
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Curricula_Developed?> </td>
                <td class="text-center"><?= $book->Pos_Link?> </td>
                <td class="text-center"> <?= $book->cos_Link?> </td>
                <td class="text-center"> 
                    <?php if( !empty($po)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>
                <td class="text-center"> 
                    <?php if( !empty($po)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                      
                </td>

               
                <td> 

                    <?php if(empty($po) && empty($co)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                 

                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_1_1_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="md-12 my-3">
                                        <label >Curricula developed and implemented have relevance to the local, regional, national, and global developmental needs, which is reflected in the Programme outcomes (POs) and Course Outcomes(COs) of the Programmes offered by the institution : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                        <textarea name="curriculaDeveloped" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"><?= $book->Curricula_Developed?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                    </div>
 
                                    <div class="md-6 my-3">
                                        <label class="form-label">Enter POs Link : <label style="color: red;">*</label></label>
                                        <input id="" type="url" class="form-control" name="posLink" value="<?= $book->Pos_Link?>" autocomplete="off"  >
                                        <span id="" style="display:none;color:red;">Please enter a valid link.</span>
                                     </div>

                                    <div class="md-6 my-3">
                                        <label class="form-label">Upload POs:<label style="color: red;">* Select PDF file under 500KB</label></label>
                                        <input id="uploadPOs" name="poFile" type="file" class="form-control" accept=".pdf" oninput="validateuploadPOs(event)">
                                        <span id="uploadPOsError" style="color:red;"></span> 

                                    </div>
                                    
                                    <div class="md-6 my-3">
                                        <label class="form-label">Enter COs Link : <label style="color: red;">* </label></label>
                                        <input id="" type="url" class="form-control" name="cosLink" value="<?= $book->cos_Link?>" accept=".pdf" autocomplete="off"  >
                                        <span id="" style="display:none;color:red;">Please enter a valid link.</span>
                                    </div>
                                    
                                    <div class="md-6 my-3">
                                        <label class="form-label">Upload COs:<label style="color: red;">* Select PDF file under 500KB</label></label>
                                        <input id="uploadCOs" name="coFile" type="file" class="form-control" accept=".pdf" oninput="validateuploadCOs(event)">
                                        <span id="uploadCOsError" style="color:red;"></span> 
                                    </div>         
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script src="<?php echo base_url('assets/js/HOD/1_1_1_view.js'); ?>"></script>
<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>


<?= $this->endSection();?>