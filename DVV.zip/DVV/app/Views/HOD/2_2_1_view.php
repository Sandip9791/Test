<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">2.2.1</h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
 		<form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_2_2_1') ?>" enctype="multipart/form-data">
         <div class="row pt-3 pb-3 border border-2">
            <div class="col-md-11 my-3">
                <label><b>The institution assesses the learning levels of the students and  organises special Programmes to cater to  differential learning needs of the student : </b><b style="color: rgb(235, 15, 15);" >* 200 words only</b> </label><br><br>
                <textarea name="learning_levels" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
            </div>

            <div class="col-md-12 my-3">
                <label class="form-label">Upload Related Documents : <label style="color: red;"><strong> * Note : Please Select all PDF files under 500KB.</strong></label></label><br>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">1. Bridge course attendance :<label style="color: red;">*</label></label>
                <input id="attendace" type="file" class="form-control" name="attendace" accept=".pdf" oninput="validateattendace(event)" required>
                <span id="attendaceError" style="color:red;"></span>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label"> Bridge Course Notice :<label style="color: red;">*</label></label>
                <input id="notice" type="file" class="form-control" name="notice" accept=".pdf" oninput="validatenotice(event)" required>
                <span id="noticeError" style="color:red;"></span>
            </div>

            <div class="col-md-2 my-3 ">
                <label class="form-label">Number of Students  :<label style="color: red;">* (1 to 500)</label></label>
                <input id="studBridge" type="text" class="form-control" name="students_bridge" min="1" max="500" maxlength="3" autocomplete="off" required>
                <span id="studBridgeError" style="display:none;color:red;">Student's should between in 1 to 500.</span>
            </div>


            <div class="col-md-4 py-4">
                <label class="form-label">2. Report of Diagnostic Test :<label style="color: red;">*</label></label>
                <input id="report" type="file" class="form-control" name="report" accept=".pdf" oninput="validatereport(event)" required>
                <span id="reportError" style="color:red;"></span>
            </div>

            <div class="col-md-4 py-4">
                <label class="form-label"> Attendance of Diagnostic Test :<label style="color: red;">*</label></label>
                <input id="attendace_diagnostic" type="file" class="form-control" name="attendace_diagnostic" oninput="validateAttDign(event)" accept=".pdf" required>
                <span id="attDignError" style="color:red;"></span>
            </div>

            <div class="col-md-2 py-4">
                <label class="form-label">Number of Students :<label style="color: red;">* (1 to 500)</label></label>
                <input id="studDign" type="text" class="form-control" name="students_diagnostic" min="1" max="500" maxlength="3" autocomplete="off"  required>
                <span id="studDignError" style="display:none;color:red;">Student's should between in 1 to 500.</span>
            </div>

            <div class="col-md-2 py-4">

                <label class="form-label" for="reason">Course Name :  <label style="color: red;">*</label></label>
                    <select id="reason" name="course_name" class="form-control">
                        <option disabled selected hidden>--- Select one ---</option>
                        <option  value="UG" >UG</option>
                        <option  value="PG" >PG</option>
                    </select>
            </div>
            </div>

         

            <div class="col-12 text-center py-4">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
</div>

<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">The institution assesses the learning levels of the students and organises special Programmes to cater to differential learning needs of the student </th>
                <th scope="col">Bridge course attendance</th>
                <th scope="col">Bridge Course Notice</th>
                <th scope="col">Number of Students</th>
                <th scope="col">Report of Diagnostic Test</th>
                <th scope="col">Attendance of Diagnostic Test</th>
                <th scope="col">Number of Students</th>
                <th scope="col">Course Name</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_2_2_1;
                $po1 = $book->Bridge_course_attendance;
                $po2 = $book->Bridge_course_notice;

                $co1 = $book->Report_of_diagnostic_test;
                $co2 = $book->Attendance_of_diagnostic_test;
                
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <!--  -->
                <td class="text-center"><?= $book->Learning_levels_of_students?></td>

                <td class="text-center"> 
                    <?php if( !empty($po1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_II/').$po1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>

                <td class="text-center"> 
                    <?php if( !empty($po2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_II/').$po2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 

                   
                </td>
                <td class="text-center"><?= $book->Bridge_number_of_students?></td>
                
                <td class="text-center"> 
                    <?php if( !empty($co1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_II/').$co1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                 </td>

                <td class="text-center">
                    <?php if( !empty($co2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_II/').$co2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>   
                </td>

                <td class="text-center"><?= $book->Diagnostic_number_of_studnets?></td>

                <td class="text-center"><?= $book->Course_name?></td>
                
                <td> 

                    <?php if(empty($po1)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>


                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_2_2_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>
                                    <div class="md-11 py-4">
                                        <label><b>The institution assesses the learning levels of the students and  organises special Programmes to cater to  differential learning needs of the student : </b><b style="color: rgb(235, 15, 15);" >* 200 words only</b> </label><br><br>
                                        <textarea name="learning_levels" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"><?= $book->Learning_levels_of_students?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                    </div>

                                    <div class="md-12 my-3">
                                        <label class="form-label">Upload Related Documents : <label style="color: red;"><strong> * Note : Please Select all PDF files under 500KB.</strong></label></label><br>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">1. Bridge course attendance :<label style="color: red;">*</label></label>
                                        <input id="attendace" type="file" class="form-control" name="attendace" accept=".pdf" oninput="validateattendace(event)" >
                                        <span id="attendaceError" style="color:red;"></span>
                                      
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label"> Bridge Course Notice :<label style="color: red;">*</label></label>
                                        <input id="notice" type="file" class="form-control" name="notice" accept=".pdf" oninput="validatenotice(event)" >
                                        <span id="noticeError" style="color:red;"></span>
                                        
                                    </div>

                                    <div class="md-2 my-3">
                                        <label class="form-label">Number of Students  :<label style="color: red;">* (1 to 500)</label></label>
                                        <input id="studBridge" type="text" class="form-control" name="students_bridge" value="<?= $book->Bridge_number_of_students?>" min="1" max="500" maxlength="3" autocomplete="off" >
                                        <span id="studBridgeError" style="display:none;color:red;">Student's should between in 1 to 500.</span>
                                    </div>


                                    <div class="md-4  my-3">
                                        <label class="form-label">2. Report of Diagnostic Test :<label style="color: red;">*</label></label>
                                        <input id="report" type="file" class="form-control" name="report" accept=".pdf" oninput="validatereport(event)" >
                                        <span id="reportError" style="color:red;"></span>
 
                                    </div>

                                    <div class="md-4  my-3">
                                        <label class="form-label"> Attendance of Diagnostic Test :<label style="color: red;">*</label></label>
                                        <input id="attendace_diagnostic" type="file" class="form-control" name="attendace_diagnostic" oninput="validateAttDign(event)" accept=".pdf" >
                                        <span id="attDignError" style="color:red;"></span>
                                        
                                    </div>

                                    <div class="md-2 my-3">
                                        <label class="form-label">Number of Students :<label style="color: red;">* (1 to 500)</label></label>
                                        <input id="studDign" type="text" class="form-control" name="students_diagnostic" value="<?= $book->Diagnostic_number_of_studnets?>" min="1" max="500" maxlength="3" autocomplete="off">
                                        <span id="studDignError" style="display:none;color:red;">Student's should between in 1 to 500.</span>
                                    </div>

                                    <div class="md-4 my-3">
                                       <label class="form-label" for="reason">Course Name :  <label style="color: red;">*</label></label>
                                        <select id="reason" name="course_name" class="form-control">
                                            <option selected hidden value="<?= $book->Course_name?>"><?= $book->Course_name?></option>
                                            <option  value="UG" >UG</option>
                                            <option  value="PG" >PG</option>
                                        </select>
                                    </div> 
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>


<script src="<?php echo base_url('assets/js/HOD/2_2_1_view.js'); ?>"></script>

<?= $this->endSection();?>


 
