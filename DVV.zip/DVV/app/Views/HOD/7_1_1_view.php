<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">7.1.1</h1>
<h5  class="text-center my-3">( Institution has initiated the Gender Audit and measures for the promotion of gender equity during the last five years ) </h5>

<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
        
        <div class="mx-3 g-3 my-3">
            <form  method="post" action="<?= base_url('save_7_1_1') ?>" enctype="multipart/form-data" > 
            <div class="row pt-3 pb-3 border border-2">
                <div class="col-md-12 my-3">
                    <label >Curricular : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="curricular" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement = document.getElementById('wordLimitedTextarea');
                        textareaElement.addEventListener('input', enforceWordLimit);
                    </script>
                </div>
               
                <div class="col-md-4 py-3">
                   <label for="">Upload Relevant Document:</label>
                   <input type="file" class="form-control" name="curricular_doc" accept=".pdf">
                  
                </div>
                
                <div class="col-md-12 my-3">
                    <label >Co-Curricular : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="cocurricular" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElemen = document.getElementById('wordLimitedTextarea');
                        textareaElemen.addEventListener('input', enforceWordLimit);
                    </script>
                </div>
                
              
                 <div class="col-md-4 py-3">
                    <label for="">Upload Relevant Document:</label>
                    <input type="file" class="form-control" name="cocurricular_doc" accept=".pdf">
                 </div>

            </div>
                
                 <div class="col-12 text-center py-3">
                   <input type="submit" class="btn btn-outline-primary">
                 </div>
            </form>
        </div> 
</div>

<!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Curricular</th>
                <th scope="col">Relevant Document</th>
                <th scope="col">Co-Curricular</th>
                <th scope="col">Relevant Document</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_7_1_1;
                $co1 = $book->Curricular_doc;
                $co2 = $book->Curricular_doc;
        ?>
        <tbody >
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Curricular?> </td>
                <td class="text-center"> 
                    <?php if( !empty($co1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$co1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"><?= $book->Co_curricular?> </td>
                <td class="text-center"> 
                    <?php if( !empty($co2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$co2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>

                </td>
                <td class=""> 

                    <?php if(empty($book->Curricular) && empty($book->Co_curricular)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">7.1.1</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_7_1_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>
                                    <div class="md-12 py-3">
                                        <label >Curricular : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                        <textarea name="curricular" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"><?= $book->Curricular?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  200; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement = document.getElementById('wordLimitedTextarea');
                                            textareaElement.addEventListener('input', enforceWordLimit);
                                        </script>
                                    </div>
                                
                                    <div class="md-4 py-3">
                                        <label for="">Upload Relevant Document:</label>
                                        <input type="file" class="form-control" name="curricular_doc" accept=".pdf">
                                        <?php if(isset($co1->Name) && !empty($co1->Name) && !($co1->Name === "dummy.pdf")):?>
                                            <a href="<?= base_url("assets/userFiles/$co1->Name")?>"><?= $co1->Name?></a>
                                         <?php endif;?>
                                    </div>
                                    
                                    <div class="md-12 py-3">
                                        <label >Co-Curricular : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                        <textarea name="cocurricular" class="form-control" id="wordLimitedTextarea" rows="5" data-word-limit="200"><?= $book->Co_curricular?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  200; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElemen = document.getElementById('wordLimitedTextarea');
                                            textareaElemen.addEventListener('input', enforceWordLimit);
                                        </script>
                                    </div>
                                    
                                
                                    <div class="md-4 py-3">
                                        <label for="">Upload Relevant Document:</label>
                                        <input type="file" class="form-control" name="cocurricular_doc" accept=".pdf">
                                        <?php if(isset($co2->Name) && !empty($co2->Name) && !($co2->Name === "dummy.pdf")):?>
                                            <a href="<?= base_url("assets/userFiles/$co2->Name")?>"><?= $co2->Name?></a>
                                         <?php endif;?>
                                    </div>
                                   

                                  
                                     
                                       
                                       
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/7_1_1_view.js'); ?>"></script>

<?= $this->endSection();?>








