<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>

<h1 class="text-center my-3">1.2.1</h1>

<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
    <form class="g-3 my-3" method="post" action="<?= base_url('save_1_2_1') ?>" enctype="multipart/form-data">

    <div class="row mx-2 pt-3 pb-3 border border-2">
        <label for=""><b>Percentage of new courses introduced out of the total number of courses across all programmes
            offered during the last five years : </b></label>
        <div class="col-md-6 mx-2 my-3 ">
                <select id="seed" name="courses" onclick="show()"  class="form-control">
                    <option disabled selected hidden>--- Select one ---</option>
                    <option  value="Yes" >Yes</option>
                    <option  value="No" >No</option>
                </select>
         </div>

        <script>
                function show() {
                var type = document.getElementById("seed");
                if (type.value == "Yes") 
                {
                    document.getElementById('text-inputs').style.display = "block";
                }
                else 
                {
                    document.getElementById('text-inputs').style.display = "none";
                } 
                }
       </script>
       
       
        <div id="text-inputs" style="display: none;">
            <div class="row">
                
                <div class="col-md-4 my-3">
                    <label class="form-label" for="course_name"> Name of the Course:<label style="color: red;">*</label></label><br>
                    <input id="course_name" class="form-control" type="text" name="course_name" autocomplete="off" oninput="validatecourse_name()">
                    <span id="course_nameError" style="display:none;color:red;">Please enter a valid name.</span>
                   
                </div>

                <div class="col-md-4 my-3">
                    <label class="form-label" for="course_code"> Course Code:</label> <br>
                    <input class="form-control" type="text" name="course_code" id="course_code">
                </div>

                <div class="col-md-4 my-3">
                    <label class="form-label" for="year_introduction"> Year of Introduction:<label style="color: red;">*</label></label><br>
                    <input id="year_introduction" class="form-control" type="text" name="year_introduction" id="datepicker" maxlength="4" autocomplete="off" placeholder="yyyy" >
                <span id="year_introductionError" style="color: red; display: none;"></span>
                </div>

                <script>
                    $(document).ready(function() {
                        var currentYear = new Date().getFullYear(); // Get the current year

                        $("#datepicker").datepicker({
                            format: "yyyy",
                            viewMode: "years",
                            minViewMode: "years",
                            startDate: "2020",
                            endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                            autoclose: true
                        });

                        // Add an input event handler to validate numeric input
                        $("#datepicker").on("input", function() {
                            var inputValue = $(this).val();
                            var numericValue = parseInt(inputValue);
                            
                            if (isNaN(numericValue)) {
                                $(this).val(""); // Clear the input
                            }
                        });
                    });
                </script>

                <div class="col-md-6 my-3">
                    <label class="form-label"> Upload Minutes of Board of Studies meeting clearly specifying the syllabus approval of new courses <label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="syllabus" type="file" class="form-control" name="syllabus" accept=".pdf" oninput="validatesyllabus(event)" >
                    <span id="syllabusError" style="color:red;"></span>
                </div>

                <div class="col-md-6 my-3">
                    <label class="form-label"> Upload Subsequent Academic Council meeting extracts endorsing the decision of BOS <label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="bos" type="file" class="form-control" name="bos" accept=".pdf" oninput="validatebos(event)"  >
                    <span id="bosError" style="color:red;"></span>
                </div>

            </div>
    </div>
        </div>
        
        <div class="col-12 my-3 text-center">
            <input type="submit" class="btn btn-outline-primary"></input>
        </div>
    </form>
</div>


<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Name of the Course</th>
                <th scope="col">Course Code</th>
                <th scope="col">Year of Introduction</th>
                <th scope="col">Minutes of Board of Studies meeting clearly specifying the syllabus approval of new courses</th>
                <th scope="col">Subsequent Academic Council meeting extracts endorsing the decision of BOS</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_1_2_1;
                $po = $book->Syllabus_Approval;
                $co = $book->Academic_Council_BOS;
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Course_Name?> </td>
                <td class="text-center"><?= $book->Course_Code?> </td>
                <td class="text-center"><?= $book->Year_Of_Introduction?> </td>

                <td class="text-center"> 
                    <?php if( !empty($po)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"> 
                    <?php if( !empty($co)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$co;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                      
                </td>
               
                <td> 

                    <?php if(empty($po) && empty($co)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>


                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_1_2_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <label for=""><b>Percentage of new courses introduced out of the total number of courses across all programmes
                                        offered during the last five years : </b></label>
                                    <div class="md-6 mx-2 my-3 ">
                                            <select id="seed<?= $book->HOD_id?>" name="courses" onclick="show<?= $book->HOD_id?>()"  class="form-control">
                                                <option  selected hidden><?= $book->Course?></option>
                                                <option  value="Yes" >Yes</option>
                                                <option  value="No" >No</option>
                                            </select>
                                            <br>
                                    </div>

                                    <script>
                                            function show<?= $book->HOD_id?>() {
                                            var type = document.getElementById("seed<?= $book->HOD_id?>");
                                            if (type.value == "Yes") 
                                            {
                                                document.getElementById('text-inputs<?= $book->HOD_id?>').style.display = "block";
                                            }
                                            else 
                                            {
                                                document.getElementById('text-inputs<?= $book->HOD_id?>').style.display = "none";
                                            } 
                                            }
                                </script>
                                
                                
                                    <div id="text-inputs<?= $book->HOD_id?>" style="display: none;">
                                        <div class="row">
                                            
                                            <div class="md-4 my-3">
                                                <label class="form-label" for="course_name"> Name of the Course:<label style="color: red;">*</label></label><br>
                                                <input id="course_name" class="form-control" type="text" name="course_name" value="<?= $book->Course_Name?>"  autocomplete="off" oninput="validatecourse_name()">
                                                <span id="course_nameError" style="display:none;color:red;">Please enter a valid name.</span>
                                                <br>
                                            </div>

                                            <div class="md-4 my-3">
                                                <label class="form-label" for="course_code"> Course Code:</label> <br>
                                                <input class="form-control" type="text" name="course_code" id="course_code" value="<?= $book->Course_Code?>">
                                            </div>

                                            <div class="md-4 my-3">
                                                <label class="form-label" for="year_introduction"> Year of Introduction:<label style="color: red;">*</label></label><br>
                                                <input id="year_introduction" class="form-control" type="text" name="year_introduction" value="<?= $book->Year_Of_Introduction?>" id="datepicker" maxlength="4" autocomplete="off" placeholder="yyyy" >
                                            <span id="year_introductionError" style="color: red; display: none;"></span>
                                            </div>

                                            <script>
                                                $(document).ready(function() {
                                                    var currentYear = new Date().getFullYear(); // Get the current year

                                                    $("#datepicker").datepicker({
                                                        format: "yyyy",
                                                        viewMode: "years",
                                                        minViewMode: "years",
                                                        startDate: "2020",
                                                        endDate: "currentYear", // Remove the quotes around currentYear to use the variable
                                                        autoclose: true
                                                    });

                                                    // Add an input event handler to validate numeric input
                                                    $("#datepicker").on("input", function() {
                                                        var inputValue = $(this).val();
                                                        var numericValue = parseInt(inputValue);
                                                        
                                                        if (isNaN(numericValue)) {
                                                            $(this).val(""); // Clear the input
                                                        }
                                                    });
                                                });
                                            </script>

                                            <div class="md-6 my-3">
                                                <label class="form-label"> Upload Minutes of Board of Studies meeting clearly specifying the syllabus approval of new courses <label style="color: red;">* Select PDF file under 500KB</label></label>
                                                <input id="syllabus" type="file" class="form-control" name="syllabus" accept=".pdf" oninput="validatesyllabus(event)" >
                                                <span id="syllabusError" style="color:red;"></span>
                                            </div>

                                            <div class="md-6 my-3">
                                                <label class="form-label"> Upload Subsequent Academic Council meeting extracts endorsing the decision of BOS <label style="color: red;">* Select PDF file under 500KB</label></label>
                                                <input id="bos" type="file" class="form-control" name="bos" accept=".pdf" oninput="validatebos(event)"  >
                                                <span id="bosError" style="color:red;"></span>


                                              
                                            </div>
   
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>


<script src="<?php echo base_url('assets/js/HOD/1_2_1_view.js'); ?>"></script>

<?= $this->endSection();?>
