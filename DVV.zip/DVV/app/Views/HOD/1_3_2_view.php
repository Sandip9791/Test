<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">Certificate/Value Added Courses/Diploma Programmes</h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
		
        <!-- <h6 style="color: blue;">(30 or more contact hours)</h6> -->
		<form class=" mx-3 g-3 my-3" method="post" action="<?= base_url('save_1_3_2') ?>" enctype="multipart/form-data">

        <div class="row pt-3 pb-3 border border-2">
            <div class="col-md-4 my-3">
                <label class="form-label">Calender for Academic Year :<label style="color: red;">*</label></label>
                <input name="academic_year" id="datepicker" type="number" class="form-control" placeholder="Enter a year" autocomplete="off" required>
                <span id = "durationError" style="display:none;color:red;">Please Enter a Valid Duration of Project.</span>
            </div>
            
            <div class="col-md-4 my-3">
                <label class="form-label" >Name of the Cource Offered :<label style="color: red;">*</label></label>
                <input name="course_name" type="text" class="form-control" placeholder="Enter code">
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Online Course Completed by the Student :<label style="color: red;">*</label></label>
                <select name="completed_course" id="cources" class="form-control" >
                    <option value="" disabled selected hidden>---Select One---</option>
                    <option value="MOOC">MOOC</option>
                    <option value="SWAYAM">SWAYAM</option>
                    <option value="E.PG.Pathshala">E.PG.Pathshala</option>
                    <option value="NPTEL">NPTEL</option>
                    <option value="Other">Other</option>
                </select>
                 
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Course Code :<label style="color: red;">*</label></label>
                <input name="course_code" type="text" class="form-control" placeholder="Enter code">
            </div>
            
            <div class="col-md-4 my-3">
                <label class="form-label">Year of Offering :<label style="color: red;">*</label></label>
                <input name="offering_year" id="datepicker" type="number" class="form-control" placeholder="Enter a year" required>
                <span id = "durationError" style="display:none;color:red;">Please Enter a Valid Duration of Project.</span>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Number of Times : <label style="color: red;">*</label></label>
                <select name="no_of_times" id="cources" class="form-control" >
                    <option value="" disabled selected hidden>---Select One---</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>
                
            </div>
             
            <div class="col-md-4 my-3">
                <label class="form-label">Duration of Course : <label style="color: red;">*</label></label>
                <select name="weeks_or_hours" id="cources" class="form-control">
                    <option value="" disabled selected hidden>---Select One---</option>
                    <option value="weeks">Weeks</option>
                    <option value="hours">Hours</option>
                </select>
            </div>

            <div class="col-md-4 my-3" >
                <label class="form-label"> Duration of Course (hours max 30-40 And Weeks max 16 ) :<label style="color: red;">*</label></label>
                <input name="duration" type="text" class="form-control" placeholder="Enter a number">
            </div>
            

            <div class="col-md-4 my-3">
                <label class="form-label"> Name of the Course Co-ordinator :<label style="color: red;">*</label></label>
                <input name="course_coordinator" type="text" class="form-control" placeholder="Enter a name">
                <br>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Number of Student Enrolled : <label style="color: red;">*</label></label>
                <input name="students_enrolled" type="number" class="form-control" placeholder="Enter a number">
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Number of Student Completed Course  :<label style="color: red;">*</label></label>
                <input name="students_completed" type="number" class="form-control" placeholder="Enter a number">
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Upload Related Documents :<label style="color: red;">* (.pdf only)</label></label>
                <input name="Rdocument" type="file" class="form-control" name="document"  accept=".pdf" required>
                 
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Brochure/Notice : <label style="color: red;">* (.pdf only)</label></label>
                <input name="brochure" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-md-5 my-3">
                <label class="form-label" >Course Module & Outcome (for Certificate or value Added programmes) : <label style="color: red;">* (.pdf only)</label></label>
                <input name="module" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-md-3 my-3">
                <label class="form-label">Attendance : <label style="color: red;">* (.pdf only)</label> </label>
                <input name="attendance" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
                <br>
            </div>

            <label class="form-label my-3">Course Complition Certificate (any 5) :<label style="color: red;">* (.pdf only)</label></label>
            <div class="col-md-4 my-3">
                <input name="certificate1" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            <div class="col-md-4 my-3">
                <input name="certificate2" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            <div class="col-md-4 my-3">
                <input name="certificate3" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
                 
            </div>
            <div class="col-md-4 my-3">
                <input name="certificate4" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            <div class="col-md-4 my-3">
                <input name="certificate5" type="file" class="form-control" name="document"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            </div>
            <br>
            <div class="col-12 my-3 text-center">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
</div>

<div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1"> Add Data</label>
</div>
             
<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
        <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Calender for Academic Year</th>
                <th scope="col">Name of the Cource Offered</th>
                <th scope="col">Online Course Completed by the Student</th>
                <th scope="col">Course Code</th>
                <th scope="col">Year of Offering</th>
                <th scope="col">Number of Times</th>
                <th scope="col">Duration of Course </th>
                <th scope="col">Name of the Course Co-ordinator </th>
                <th scope="col">Number of Student Enrolled</th>
                <th scope="col">Number of Student Completed Course</th>
                <th scope="col">Related Documents</th>
                <th scope="col">Brochure/Notice</th>
                <th scope="col">Course Module & Outcome</th>
                <th scope="col">Attendance</th>
                <th scope="col">Course Complition Certificate</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if (isset($documents)):
            $row = 1;
            foreach ($documents as $doc):
                $book = $doc->HOD_1_3_2;
                ?>
                <tbody>
                    <?php
                        foreach ($book as $chapter):

                            $related = $chapter->Related_Documents;
                            $cover = $chapter->Brochure;
                            $content = $chapter->Module;
                            $attendance = $chapter->Attendance;

                            $Certificate1 = $chapter->Certificate1;
                            $Certificate2 = $chapter->Certificate2;
                            $Certificate3 = $chapter->Certificate3;
                            $Certificate4 = $chapter->Certificate4;
                            $Certificate5 = $chapter->Certificate5;

                            $week = $chapter->Weeks_or_Hours;
                            $duration = $chapter->Duration;
                    ?>
                        <tr>
                            <th class="text-center" scope="row"><?= $row++; ?></th>
                            <td class="text-center">
                                <?= $chapter->Academic_year ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Course_name ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Completed_course ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Course_code ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Offering_year ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->No_of_times ?>
                            </td>

                            <td class="text-center">
                                <?= $week."-".$duration?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Course_coordinator ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Students_enrolled ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Students_completed ?>
                            </td>

                            <td class="text-center">
                                <?php if(!empty($related)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$related;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            
                            <td class="text-center">
                                <?php if(!empty($cover)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                                
                            </td>

                            <td class="text-center">
                                <?php if(!empty($content)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$content;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                            </td>

                            <td class="text-center">
                                <?php if(!empty($attendance)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$attendance;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            
                            <td class="text-center">
                                <?php if(!empty($Certificate1)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Certificate1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                                <p class="my-3"></p>

                                <?php if(!empty($Certificate2)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Certificate2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                                <p class="my-3"></p>

                                <?php if(!empty($Certificate3)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Certificate3;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                                <p class="my-3"></p>

                                <?php if(!empty($Certificate4)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Certificate4;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                                
                                <p class="my-3"></p>
                                
                                <?php if(!empty($Certificate5)):?>
                                    <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$Certificate5;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>

                            </td>

                            <td class="text-center"> 
                                <form action="<?= base_url('delete_1_3_2') ?>" method="post">
                                        <input type="text" class="form-control text-center" style="display:none;" name="srnumber"
                                            readonly value="<?= $chapter->HOD_id ?>">
                                    
                                     <img src="<?= base_url('assets/images/iconsDelete.gif') ?>"><input
                                        class="btn btn-danger" type="submit" value="Delete"></td>
                                </form>
                            <td>
                                <div class="text-center">
                                    <img src="<?= base_url('assets/images/iconsUpdate.gif') ?>">
                                    <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?= $chapter->HOD_id ?>"
                                        data-bs-whatever="@mdo">Update</button>
                                </div>


                                <div class="modal fade" id="exampleModal<?= $chapter->HOD_id ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Activities Through Organized Forums</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= base_url('update_1_3_2') ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="md-4" style="display:none;">
                                                                <input type="text" class="form-control" name="srnumber" readonly value="<?= $chapter->HOD_id ?>">
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Calender for Academic Year :<label style="color: red;">*</label></label>
                                                                <input name="academic_year" value="<?= $chapter->Academic_year ?>" id="datepicker" type="number" class="form-control" placeholder="Enter a year" autocomplete="off" required>
                                                                <span id = "durationError" style="display:none;color:red;">Please Enter a Valid Duration of Project.</span>
                                                            </div>
                                                            
                                                            <div class="md-4 py-3">
                                                                <label class="form-label" >Name of the Cource Offered :<label style="color: red;">*</label></label>
                                                                <input name="course_name" value="<?= $chapter->Course_name ?>" type="text" class="form-control" placeholder="Enter code" required>
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Online Course Completed by the Student :<label style="color: red;">*</label></label>
                                                                <select name="completed_course" id="cources" class="form-control" required>
                                                                    <option value="<?= $chapter->Completed_course ?>" selected hidden><?= $chapter->Completed_course ?></option>
                                                                    <option value="MOOC">MOOC</option>
                                                                    <option value="SWAYAM">SWAYAM</option>
                                                                    <option value="E.PG.Pathshala">E.PG.Pathshala</option>
                                                                    <option value="NPTEL">NPTEL</option>
                                                                    <option value="Other">Other</option>
                                                                </select>
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Course Code :<label style="color: red;">*</label></label>
                                                                <input name="course_code" value="<?= $chapter->Course_code ?>"  type="text" class="form-control" placeholder="Enter code" required>
                                                            </div>
                                                            
                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Year of Offering :<label style="color: red;">*</label></label>
                                                                <input name="offering_year" value="<?= $chapter->Offering_year ?>"  id="datepicker" type="number" class="form-control" placeholder="Enter a year" required>
                                                                <span id = "durationError" style="display:none;color:red;">Please Enter a Valid Duration of Project.</span>
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Number of Times : <label style="color: red;">*</label></label>
                                                                <select name="no_of_times"  id="cources" class="form-control" required>
                                                                    <option value="<?= $chapter->No_of_times ?>" selected hidden><?= $chapter->No_of_times ?></option>
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                    <option value="4">4</option>
                                                                </select>
                                                            </div>
                                                            
                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Duration of Course : <label style="color: red;">*</label></label>
                                                                <select name="weeks_or_hours" id="cources" class="form-control" required>
                                                                    <option value="<?= $chapter->Weeks_or_Hours ?>" selected hidden><?= $chapter->Weeks_or_Hours ?></option>
                                                                    <option value="weeks">Weeks</option>
                                                                    <option value="hours">Hours</option>
                                                                </select>
                                                            </div>

                                                            <div class="md-4 py-3" >
                                                                <label class="form-label"> Duration of Course (hours max 30-40 And Weeks max 16 ) :<label style="color: red;">*</label></label>
                                                                <input name="duration" value="<?= $chapter->Duration ?>" type="text" class="form-control" placeholder="Enter a number" required>
                                                            </div>
                                                            

                                                            <div class="md-4 py-3">
                                                                <label class="form-label"> Name of the Course Co-ordinator :<label style="color: red;">*</label></label>
                                                                <input name="course_coordinator" value="<?= $chapter->Course_coordinator ?>" type="text" class="form-control" placeholder="Enter a name" required>
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Number of Student Enrolled : <label style="color: red;">*</label></label>
                                                                <input name="students_enrolled" value="<?= $chapter->Students_enrolled ?>" type="number" class="form-control" placeholder="Enter a number" required>
                                                            </div>

                                                            <div class="md-4 py-3">
                                                                <label class="form-label">Number of Student Completed Course  :<label style="color: red;">*</label></label>
                                                                <input name="students_completed" value="<?= $chapter->Students_completed ?>" type="number" class="form-control" placeholder="Enter a number" required>
                                                            </div>

                                                            <div class="md-4 py-4">
                                                                <label class="form-label">Upload Related Documents :<label style="color: red;">* (.pdf only)</label></label>
                                                                <input name="Rdocument" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <?php if(isset($related->Name) && !empty($related->Name) && !($related->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$related->Name")?>" target="_blank"><?= $related->Name?></a>
                                                                <?php endif;?>
                                                            </div>

                                                            <div class="md-4 py-4">
                                                                <label class="form-label">Brochure/Notice : <label style="color: red;">* (.pdf only)</label></label>
                                                                <input name="brochure" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($cover->Name) && !empty($cover->Name) && !($cover->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$cover->Name")?>" target="_blank"><?= $cover->Name?></a>
                                                                <?php endif;?>
                                                            </div>

                                                            <div class="md-5 py-4">
                                                                <label class="form-label" >Course Module & Outcome (for Certificate or value Added programmes) : <label style="color: red;">* (.pdf only)</label></label>
                                                                <input name="module" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($content->Name) && !empty($content->Name) && !($content->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$content->Name")?>" target="_blank"><?= $content->Name?></a>
                                                                <?php endif;?>
                                                            </div>

                                                            <div class="md-3 py-4">
                                                                <label class="form-label">Attendance : <label style="color: red;">* (.pdf only)</label> </label>
                                                                <input name="attendance" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($attendance->Name) && !empty($attendance->Name) && !($attendance->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$attendance->Name")?>" target="_blank"><?= $attendance->Name?></a>
                                                                <?php endif;?>
                                                            </div>

                                                            <label class="form-label">Course Complition Certificate (any 5) :<label style="color: red;">* (.pdf only)</label></label>
                                                            <div class="md-4 py-4">
                                                                <input name="certificate1" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($Certificate1->Name) && !empty($Certificate1->Name) && !($Certificate1->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$Certificate1->Name")?>" target="_blank"><?= $Certificate1->Name?></a>
                                                                <?php endif;?>
                                                            </div>
                                                            <div class="md-4 py-4">
                                                                <input name="certificate2" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($Certificate2->Name) && !empty($Certificate2->Name) && !($Certificate2->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$Certificate2->Name")?>" target="_blank"><?= $Certificate2->Name?></a>
                                                                <?php endif;?>
                                                            </div>
                                                            <div class="md-4 py-4">
                                                                <input name="certificate3" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($Certificate3->Name) && !empty($Certificate3->Name) && !($Certificate3->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$Certificate3->Name")?>" target="_blank"><?= $Certificate3->Name?></a>
                                                                <?php endif;?>
                                                               
                                                            </div>
                                                            <div class="md-4 py-4">
                                                                <input name="certificate4" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($Certificate4->Name) && !empty($Certificate4->Name) && !($Certificate4->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$Certificate4->Name")?>" target="_blank"><?= $Certificate4->Name?></a>
                                                                <?php endif;?>
                                                            </div>
                                                            <div class="md-4 py-4">
                                                                <input name="certificate5" type="file" class="form-control" name="document"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                <?php if(isset($Certificate5->Name) && !empty($Certificate5->Name) && !($Certificate5->Name === "dummy.pdf")):?>
                                                                    <a href="<?= base_url("assets/userFiles/$Certificate5->Name")?>" target="_blank"><?= $Certificate5->Name?></a>
                                                                <?php endif;?>
                                                            </div>
                                                        </div>
                                                    </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button class="btn btn-outline-warning">Update</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/1_3_2_view.js'); ?>"></script>

<?= $this->endSection();?>








