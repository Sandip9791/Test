<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3"> 7.2.1</h1>
<h5 class="text-center">( Describe best practice successfully implemented by the Institution as per NAAC format provided in the Manual )</h5>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
		
		<form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_7_2_1') ?>" enctype="multipart/form-data">
             
        <div class="row pt-3 pb-3 border border-2">
                <div class="col-md-4 py-4">
                    <label class="form-label">Title of the Practice  :</label><br>
                    <input type="text" class="form-control" name="title"> 
                    
                </div>
                    
                <div class="col-md-11 py-3">
                    <label >Objectives of the Practice<b style="color: rgb(235, 15, 15);">* 100 words only</b> </label>
                    <textarea name="objectives" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="100"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 100</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  100; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement1 = document.getElementById('wordLimitedTextarea');
                        textareaElement1.addEventListener('input', enforceWordLimit);
                    </script> 
                </div>

                <div class="col-md-11 py-3">
                    <label > Rationale/Context <b style="color: rgb(235, 15, 15);">* 150 words only</b> </label>
                    <textarea name="rationale" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="150"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 150</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  150; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement2 = document.getElementById('wordLimitedTextarea');
                        textareaElement2.addEventListener('input', enforceWordLimit);
                    </script> 
                </div>
                    
                <div class="col-md-11 py-3">
                    <label >Details of Practice:<b style="color: rgb(235, 15, 15);">* 400 words only</b> </label>
                    <textarea name="details" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="400"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 400</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  400; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement = document.getElementById('wordLimitedTextarea');
                        textareaElement.addEventListener('input', enforceWordLimit);
                    </script> 
                </div>

                <div class="col-md-11 py-3">
                    <label >Evidence of Success<b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                    <textarea name="evidence" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  200; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement4 = document.getElementById('wordLimitedTextarea');
                        textareaElement4.addEventListener('input', enforceWordLimit);
                    </script> 
                </div>

                <div class="col-md-11 py-3">
                    <label >Problems Encountered<b style="color: rgb(235, 15, 15);">* 50 words only</b> </label>
                    <textarea name="problems" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"></textarea>
                    <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 50</span></p>
                    <script>
                        // Function to enforce the word limit on the textarea
                        function enforceWordLimit(event) {
                            const wordLimit =  50; // Set your desired word limit here
                            const textarea = event.target;
                            const words = textarea.value.trim().split(/\s+/);
                            const remainingWords = wordLimit - words.length;
                
                            if (remainingWords < 0) {
                                // If the user exceeds the word limit, prevent further input
                                event.preventDefault();
                                textarea.value = words.slice(0, wordLimit).join(' ');
                            }
                
                            // Update the remaining words count
                            document.getElementById('remainingWords').textContent = remainingWords;
                        }
                
                        // Attach the event listener to the textarea
                        const textareaElement5 = document.getElementById('wordLimitedTextarea');
                        textareaElement5.addEventListener('input', enforceWordLimit);
                    </script> 
                </div>

                 <div class="col-md-4 py-4">
                    <label class="form-label">Upload Attendance  :<label style="color: red;">* (.pdf only)</label></label><br>
                    <input type="file" class="form-control" name="attendance"  accept=".pdf" >
                </div>

                <div class="col-md-4 py-4">
                    <label class="form-label">Upload Relevant Document  :<label style="color: red;">* (.pdf only)</label></label><br>
                    <input type="file" class="form-control" name="relevant_doc"  accept=".pdf" >
                </div>

                <div class = "row">
                    <div class="col-md-4 py-4">
                        <label class="form-label">Upload Geotag Photo  :<label style="color: red;">* (.jpg,.jpeg,.png only)</label></label><br>
                        <input type="file" class="form-control" name="geotag1"  accept=".jpg,.jpeg,.png" >
                        <br>
                        <input type="file" class="form-control" name="geotag2"  accept=".jpg,.jpeg,.png" >
                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                    </div>
                
                    <div class="col-md-4 py-4">
                        <label class="form-label">Upload Non-Geotag Photo  :<label style="color: red;"> (.jpg,.jpeg,.png only)</label></label><br>
                        <input type="file" class="form-control" name="nongeotag1" accept=".jpg,.jpeg,.png" >
                        <br>
                        <input type="file" class="form-control" name="nongeotag2"  accept=".jpg,.jpeg,.png" >
                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                    </div>
                </div>

                </div> 

                <div class="col-12 text-center py-3">
                    <input type="submit" class="btn btn-outline-primary"></input>
                </div>
      </div>
            
	</form>
</div>

    <!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Title of the Practice</th>
                <th scope="col">Objectives of the Practice</th>
                <th scope="col">Rationale/Context</th>
                <th scope="col">Details of Practice</th>
                <th scope="col">Evidence of Success</th>
                <th scope="col">Problems Encountered</th>
                <th scope="col">Attendance</th>
                <th scope="col">Relevant Document </th>
                <th scope="col">Geotag Photo 1</th>
                <th scope="col">Geotag Photo 2</th>
                <th scope="col">Non-Geotag Photo 1</th>
                <th scope="col">Non-Geotag Photo 2</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_7_2_1;
                $Attendance = $book->Attendance;
                $Relevant_document = $book->Relevant_document;
                $Geotag1 = $book->Geotag1;
                $Geotag2 = $book->Geotag2;
                $Nongeotag1 = $book->Nongeotag1;
                $Nongeotag2 = $book->Nongeotag2;

        ?>
        <tbody >
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Title_of_the_practice?> </td>
                <td class="text-center"><?= $book->Objectives_of_the_practice?> </td>
                <td class="text-center"><?= $book->Rationale_Context?> </td>
                <td class="text-center"><?= $book->Details_of_practice?> </td>
                <td class="text-center"><?= $book->Evidence_of_success?> </td>
                <td class="text-center"><?= $book->Problems_encountered?> </td>

                <td class="text-center"> 
                    <?php if( !empty($Attendance)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Attendance;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center">
                    <?php if( !empty($Relevant_document)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Relevant_document;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                    
                </td>
                <td class="text-center"> 
                    <?php if( !empty($Geotag1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Geotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>

                   
                </td>
                <td class="text-center">
                    <?php if( !empty($Geotag2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Geotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                </td>

                <td class="text-center"> 
                    <?php if( !empty($Nongeotag1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Nongeotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>

                   
                </td>

                <td class="text-center"> 
                    <?php if( !empty($Nongeotag2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_VII/').$Nongeotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td> 

                    <?php if(empty($Attendance)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">7.2.1</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_7_2_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="md-4 py-4">
                                        <label class="form-label">Title of the Practice :</label><br>
                                        <input type="text" class="form-control" name="title" value="<?= $book->Title_of_the_practice?>"> 
                                        <br> 
                                    </div>
                                        
                                    <div class="md-11 py-3">
                                        <label >Objectives of the Practice<b style="color: rgb(235, 15, 15);">* 100 words only</b> </label>
                                        <textarea name="objectives" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="100"><?= $book->Objectives_of_the_practice?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 100</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  100; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement1 = document.getElementById('wordLimitedTextarea');
                                            textareaElement1.addEventListener('input', enforceWordLimit);
                                        </script> 
                                    </div>

                                    <div class="md-11 py-3">
                                        <label > Rationale/Context <b style="color: rgb(235, 15, 15);">* 150 words only</b> </label>
                                        <textarea name="rationale" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="150"><?= $book->Rationale_Context?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 150</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  150; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement2 = document.getElementById('wordLimitedTextarea');
                                            textareaElement2.addEventListener('input', enforceWordLimit);
                                        </script> 
                                    </div>
                                        
                                    <div class="md-11 py-3">
                                        <label >Details of Practice:<b style="color: rgb(235, 15, 15);">* 400 words only</b> </label>
                                        <textarea name="details" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="400"><?= $book->Details_of_practice?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 400</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  400; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement = document.getElementById('wordLimitedTextarea');
                                            textareaElement.addEventListener('input', enforceWordLimit);
                                        </script> 
                                    </div>

                                    <div class="md-11 py-3">
                                        <label >Evidence of Success<b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                        <textarea name="evidence" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"><?= $book->Evidence_of_success?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  200; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement4 = document.getElementById('wordLimitedTextarea');
                                            textareaElement4.addEventListener('input', enforceWordLimit);
                                        </script> 
                                    </div>

                                    <div class="md-11 py-3">
                                        <label >Problems Encountered<b style="color: rgb(235, 15, 15);">* 50 words only</b> </label>
                                        <textarea name="problems" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"><?= $book->Problems_encountered?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 50</span></p>
                                        <script>
                                            // Function to enforce the word limit on the textarea
                                            function enforceWordLimit(event) {
                                                const wordLimit =  50; // Set your desired word limit here
                                                const textarea = event.target;
                                                const words = textarea.value.trim().split(/\s+/);
                                                const remainingWords = wordLimit - words.length;
                                    
                                                if (remainingWords < 0) {
                                                    // If the user exceeds the word limit, prevent further input
                                                    event.preventDefault();
                                                    textarea.value = words.slice(0, wordLimit).join(' ');
                                                }
                                    
                                                // Update the remaining words count
                                                document.getElementById('remainingWords').textContent = remainingWords;
                                            }
                                    
                                            // Attach the event listener to the textarea
                                            const textareaElement5 = document.getElementById('wordLimitedTextarea');
                                            textareaElement5.addEventListener('input', enforceWordLimit);
                                        </script> 
                                    </div>

                                    <div class="md-4 py-4">
                                        <label class="form-label">Upload Attendance  :<label style="color: red;">* (.pdf only)</label></label><br>
                                        <input type="file" class="form-control" name="attendance"  accept=".pdf" >
                                        <?php if(isset($Attendance->Name) && !empty($Attendance->Name) && !($Attendance->Name === "dummy.pdf")):?>
                                            <a href="<?= base_url("assets/userFiles/$Attendance->Name")?>"><?= $Attendance->Name?></a>
                                        <?php endif;?>
                                    </div>

                                    <div class="md-4 py-4">
                                        <label class="form-label">Upload Relevant Document  :<label style="color: red;">* (.pdf only)</label></label><br>
                                        <input type="file" class="form-control" name="relevant_doc"  accept=".pdf" >
                                        <?php if(isset($Relevant_document->Name) && !empty($Relevant_document->Name) && !($Relevant_document->Name === "dummy.pdf")):?>
                                            <a href="<?= base_url("assets/userFiles/$Relevant_document->Name")?>"><?= $Relevant_document->Name?></a>
                                        <?php endif;?>
                                    </div>

                                    <div class="row">
                                        <div class="md-4 py-4">
                                            <label class="form-label">Upload Geotag Photo  :<label style="color: red;">* (.jpg,.jpeg,.png only)</label></label><br>
                                            <input type="file" class="form-control" name="geotag1"  accept=".jpg,.jpeg,.png" >
                                            <?php if(isset($Geotag1->Name) && !empty($Geotag1->Name) && !($Geotag1->Name === "dummy.pdf")):?>
                                                <a href="<?= base_url("assets/userFiles/$Geotag1->Name")?>"><?= $Geotag1->Name?></a>
                                            <?php endif;?>
                                            <p class="py-2"></p>
                                            <input type="file" class="form-control" name="geotag2"  accept=".jpg,.jpeg,.png" >
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>
                                            <?php if(isset($Geotag2->Name) && !empty($Geotag2->Name) && !($Geotag2->Name === "dummy.pdf")):?>
                                                <a href="<?= base_url("assets/userFiles/$Geotag2->Name")?>"><?= $Geotag2->Name?></a>
                                            <?php endif;?>
                                        </div>
                                    
                                        <div class="md-4 py-4">
                                            <label class="form-label">Upload Non-Geotag Photo  :<label style="color: red;"> (.jpg,.jpeg,.png only)</label></label><br>
                                            <input type="file" class="form-control" name="nongeotag1" accept=".jpg,.jpeg,.png" >
                                            <?php if(isset($Nongeotag1->Name) && !empty($Nongeotag1->Name) && !($Nongeotag1->Name === "dummy.pdf")):?>
                                                <a href="<?= base_url("assets/userFiles/$Nongeotag1->Name")?>"><?= $Nongeotag1->Name?></a>
                                            <?php endif;?>
                                            <p class="py-2"></p>
                                            <input type="file" class="form-control" name="nongeotag2"  accept=".jpg,.jpeg,.png" >
                                            <?php if(isset($Nongeotag2->Name) && !empty($Nongeotag2->Name) && !($Nongeotag2->Name === "dummy.pdf")):?>
                                                <a href="<?= base_url("assets/userFiles/$Nongeotag2->Name")?>"><?= $Nongeotag2->Name?></a>
                                            <?php endif;?>
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>
                                        </div>
                                    </div>

                                   
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/7_2_1_view.js'); ?>"></script>

<?= $this->endSection();?>




