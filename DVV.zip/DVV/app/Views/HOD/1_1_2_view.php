<?= $this->extend('Layouts/hodBase'); ?>
<?= $this->section("Content"); ?>

<h1 class="text-center my-3">1.1.2</h1>
<h5 class="ps-3 my-3">( The programs offered by the institution focus on employability/ entrepreneurship/ skill development and their course syllabi are adequately revised to incorporate contemporary requirements)</h5>

<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
    <form class="row g-3 my-3 mx-2" method="post" action="<?= base_url('save_1_1_2') ?>" enctype="multipart/form-data">
    
        <div class="pt-3 pb-3 border border-2 my-3">
            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist(1)">
            <label class="form-check-label ps-2 " for="flexRadioDefault1">Employability</label> <br>
            <div class="col-md-11 mx-3 my-3" id="sublist1" style="display: none;">

                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                <textarea name="employability" class="form-control" id="wordLimitedTextarea1" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords1"> 200</span></p>
                
                <div class="col-sm-4 my-3">
                    <label class="form-label" for="sanction-name">Upload Relavent Document: <label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="upload" type="file" class="form-control" name="employability_document" accept=".pdf" oninput="validatesyllabi(event)"  >
                    <span id="uploadPOsError" style="color:red;"></span> 
                </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2 my-3">
            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault2" onclick="toggleSublist(2)">
            <label class="form-check-label ps-2" for="flexRadioDefault2">Entreprenurship</label><br>
            <div class="col-md-11 mx-3 my-3" id="sublist2" style="display: none;"><br>
                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                <textarea name="entrepreneurship" class="form-control" id="wordLimitedTextarea2" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords2"> 200</span></p>
                <br>
                <div class="col-sm-4 my-3" >
                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="" type="file" class="form-control" name="entrepreneurship_document" accept=".pdf" oninput="validatesyllabi(event)" >
                    <span id="uploadPOsError" style="color:red;"></span> 
                </div>
            </div>
        </div>

        <div class="pt-3 pb-3 border border-2 my-3">
            <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault3" onclick="toggleSublist(3)">
            <label class="form-check-label ps-2" for="flexRadioDefault3">Skill Development</label>
            <div class="col-md-11 mx-3 my-3" id="sublist3" style="display: none;"><br>
                <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                <textarea name="skill_development" class="form-control" id="wordLimitedTextarea3" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words : <span id="remainingWords3"> 200</span></p>
                <br>
                <div class="col-sm-4 my-3" >
                    <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                    <input id="" type="file" class="form-control" name="skill_development_document" accept=".pdf" oninput="validatesyllabi(event)" >
                    <span id="uploadPOsError" style="color:red;"></span> 
                </div>
            </div>
        </div>

        <script>
            function toggleSublist(listNum) {
                var sublist = document.getElementById("sublist" + listNum);
                var upload = document.getElementById("upload" + listNum);
                sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                upload.style.display = sublist.style.display === "none" ? "block" : "none";
            }
        </script>
        
        <div class="col-sm-4 my-3">
            <label class="form-label" for="sanction-name">Upload Course Syllabi: <label style="color: red;">* Select PDF file under 500KB</label></label>
            <input id="syllabi" type="file" class="form-control" name="syllabi" accept=".pdf" oninput="validatesyllabi(event)" >
            <span id="uploadPOsError" style="color:red;"></span> 
        </div>

        <div class="col-12 text-center my-3">
            <input type="submit" class="btn btn-outline-primary">
        </div>

        <script src="<?= base_url('assets/js/HOD/1_1_2_view.js'); ?>"></script>

    </form>

</div>



<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Employability</th>
                <th scope="col">Employability Document</th>
                <th scope="col">Entreprenurship</th>
                <th scope="col">Entreprenurship Document</th>
                <th scope="col">Skill Development</th>
                <th scope="col">Skill Development Document</th>
                <th scope="col">Course Syllabi</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_1_1_2;
                $po = $book->Employability_Document;
                $co = $book->Entrepreneurship_Document;
                $skill = $book->Skill_Development_Document;
                $course = $book->Course_Syllabi;
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Employability?> </td>
                <td class="text-center"> 
                    <?php if(!empty($po)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$po;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>

                <td class="text-center"><?= $book->Entrepreneurship?> </td>
                <td class="text-center"> 
                    <?php if(!empty($co)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$co;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                      
                </td>

                <td class="text-center"> <?= $book->Skill_Development?></td>
                <td class="text-center"> 
                    <?php if(!empty($skill)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$skill;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>

                <td class="text-center"> 
                    <?php if( !empty($course)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_I/').$course;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                      
                </td>
                <td> 

                    <?php if(empty($course)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>


                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_1_1_2')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="pt-3 pb-3  my-3 border border-2">
                                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" onclick="toggleSublist<?= $book->HOD_id?>(1)">
                                        <label class="form-check-label ps-2 " for="flexRadioDefault1">Employability</label> <br>
                                        <div class="md-11 mx-3 my-3" id="sublist<?= $book->HOD_id?>1" style="display: none;">
                                        <br>
                                            <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                            <textarea name="employability" class="form-control" id="wordLimitedTextarea1" rows="3" data-word-limit="200"><?= $book->Employability?></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords1"> 200</span></p>
                                            <br>
                                            <div class="sm-4 my-3" >
                                                <label class="form-label" for="sanction-name">Upload Relavent Document: <label style="color: red;">* Select PDF file under 500KB</label></label>
                                                <input id="upload" type="file" class="form-control" name="employability_document" accept=".pdf" oninput="validatesyllabi(event)"  >
                                                <span id="uploadPOsError" style="color:red;"></span> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault2" onclick="toggleSublist<?= $book->HOD_id?>(2)">
                                        <label class="form-check-label ps-2" for="flexRadioDefault2">Entreprenurship</label><br>
                                        <div class="md-11 mx-3 my-3" id="sublist<?= $book->HOD_id?>2" style="display: none;"><br>
                                            <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                            <textarea name="entrepreneurship" class="form-control" id="wordLimitedTextarea2" rows="3" data-word-limit="200"><?= $book->Entrepreneurship?></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords2"> 200</span></p>
                                            <br>
                                            <div class="sm-4 my-3" >
                                                <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                                                <input id="" type="file" class="form-control" name="entrepreneurship_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                <span id="uploadPOsError" style="color:red;"></span> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-3 pb-3 my-3 border border-2">
                                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault3" onclick="toggleSublist<?= $book->HOD_id?>(3)">
                                        <label class="form-check-label ps-2" for="flexRadioDefault3">Skill Development</label>
                                        <div class="md-11 mx-3 my-3" id="sublist<?= $book->HOD_id?>3" style="display: none;"><br>
                                            <label style="color: rgb(235, 15, 15);"><b>* 200 words only</b> </label>
                                            <textarea name="skill_development" class="form-control" id="wordLimitedTextarea3" rows="3" data-word-limit="200"><?= $book->Skill_Development?></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words : <span id="remainingWords3"> 200</span></p>
                                            <br>
                                            <div class="sm-4 my-3" >
                                                <label class="form-label" for="sanction-name">Upload Relavent Document : <label style="color: red;">* Select PDF file under 500KB</label></label>
                                                <input id="" type="file" class="form-control" name="skill_development_document" accept=".pdf" oninput="validatesyllabi(event)" >
                                                <span id="uploadPOsError" style="color:red;"></span> 
                                            </div>
                                        </div>
                                    </div>

                                    <script>
                                        function toggleSublist<?= $book->HOD_id?>(listNum) {
                                            var sublist = document.getElementById("sublist<?= $book->HOD_id?>" + listNum);
                                            var upload = document.getElementById("upload<?= $book->HOD_id?>" + listNum);
                                            sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                                            upload.style.display = sublist.style.display === "none" ? "block" : "none";
                                        }
                                    </script>
                                    
                                    <div class="sm-4 my-3">
                                        <label class="form-label" for="sanction-name">Upload Course Syllabi: <label style="color: red;">* Select PDF file under 500KB</label></label>
                                        <input id="syllabi" type="file" class="form-control" name="syllabi" accept=".pdf" oninput="validatesyllabi(event)" >
                                        <span id="uploadPOsError" style="color:red;"></span>
                                    </div>        
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<?= $this->endSection(); ?>
