<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">Academic Calender</h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
		<form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_2_3_3') ?>" enctype="multipart/form-data"  >
    <div class="row pt-3 pb-3 border border-2">
            <div class="col-md-11 my-3">
                <label > <b>Preparation and adherence of Academic Calendar and Teaching plans by the institution Describe the Preparation and
                  adherence to Academic Calendar and Teaching plans by the institution :</b><b style="color: rgb(235, 15, 15);">* 200 words only</b> </label><br><br>
                <textarea name="preparation" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Upload Academic Calendar :<label style="color: red;">* Select PDF file under 500KB</label></label><br>
                <input id="acaCalendar" type="file" class="form-control" name="academic_calendar" accept=".pdf" oninput="validateacaCalendar(event)" required>
                <span id="acaCalendarError" style="color:red;"></span>
            </div>

          </div>
          
          <div class="col-12 text-center py-3">
            <input type="submit" class="btn btn-outline-primary"></input>
          </div>
		</form>
</div>

<!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Preparation and adherence of Academic Calendar and Teaching plans by the institution Describe the Preparation and
                  adherence to Academic Calendar and Teaching plans by the institution</th>
                <th scope="col">Academic Calendar</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_2_3_3;
                $co = $book->Academic_calendar;
        ?>
        <tbody >
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Preparation_adherence_of_Academic_Calendar?> </td>
              
                <td class="text-center"> 
                    <?php if( !empty($co)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_II/').$co;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                </td>

                <td> 

                    <?php if( empty($co) ):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_2_3_3')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="md-11 my-3">
                                        <label > <b>Preparation and adherence of Academic Calendar and Teaching plans by the institution Describe the Preparation and
                                          adherence to Academic Calendar and Teaching plans by the institution :</b><b style="color: rgb(235, 15, 15);">* 200 words only</b> </label><br><br>
                                        <textarea name="preparation" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"><?= $book->Preparation_adherence_of_Academic_Calendar?></textarea>
                                        <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Upload Academic Calendar :<label style="color: red;">* Select PDF file under 500KB</label></label><br>
                                        <input id="acaCalendar" type="file" class="form-control" name="academic_calendar" accept=".pdf" oninput="validateacaCalendar(event)" >
                                        <span id="acaCalendarError" style="color:red;"></span>

                                        
                                    </div>      
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/2_3_3_view.js'); ?>"></script>

<?= $this->endSection();?>







