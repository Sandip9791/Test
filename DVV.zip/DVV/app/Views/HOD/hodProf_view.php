<!DOCTYPE html>
<html>
<head>
	<title> HOD Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

    <link rel="stylesheet" href="<?= base_url('assets\css\hodDashboard.css')?>">
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        }) 
    </script>

</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
      
    
    
    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html"></a>
                    </li>
                    <li class="nav-item dropdown">
                    </li>
                </ul>
                

                <form class="d-flex" method="Post" action="<?= base_url('hodLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('loged_user'); echo $myusername ;?></label>
                   <input type="submit" value="Logout" class="btn btn-outline-danger">
               </form>
           </div>
       </div>
   </nav>
   
    <h1 style="margin-top:10px; margin-bottom:10px; text-align:center;">HOD Dashboard</h1>
    <div class="container">
    <div class="section1">
			<div class="section1a mt-1">
                <h3>&nbsp; Profile</h3>
            </div>

                <?php if(isset($documents)):
                    foreach($documents as $doc):
                        $pid= $doc->PID; 
                        $images = $pid->Current_Image;
                        $title=$doc->Title;
                        $fname=$doc->First_Name;
                        $lname=$doc->Last_Name;
                        $mname=$doc->Midd_Name;
                
                        $Name = $title." ".$fname." ".$mname." ".$lname;
                        
                ?>
			<div class="section1b">
                <?php if(!empty($images)):?>
                   <img src="<?= base_url("Userfiles/Teachers/Profile/$images")?>" alt="profile" class="profilr_pic"><br>
                 <?php else:?>
                    <img src="<?= base_url("assets/images/profile/pro.png");?>" alt="profile" class="profilr_pic"><br>
                 <?php endif;?><br>
                <h6><b>Name :&nbsp;</b><?= $Name?></h6>
                <h6><b>Designation :&nbsp;</b><?= $doc->Designation?></h6>
                <h6><b>Teacher Type :&nbsp;</b><?= $doc->Teacher_Type?></h6>
                <h6><b>Mobile No. :&nbsp;</b><?= $pid->Mobile_Number?></h6>
                <h6><b>Email :&nbsp;</b><?= $doc->Email?></h6>
             
                <h6><b>Gender :&nbsp;</b><?= $pid->Gender?></h6>
                <h6><b>Category :&nbsp;</b><?= $pid->Category?></h6>
                
                <h6><b>Department :&nbsp;</b><?= $doc->Department?></h6>
                <h6><b>Address :&nbsp;</b>
                  <?= $pid->Address?>
                </h6>
                <h6><b>Name of the College / Institute : </b>
                    Progressive Education Society's
                    Modern College Of Arts, Science & Commerce
                    Ganeshkhind,Pune-16.
                </h6>
            </div>
		</div>

		<div class="section2">
			<div class="section2a  pt-3">
                <h3>&nbsp; Important links:</h3>
                <div class="position-absolute top-0 end-0 my-2 mx-2">
                    <a href="<?= base_url('teaProf')?>"  class=" btn btn-primary"><h6>&nbsp;Teacher Dashboard&nbsp;</h6></a>
                </div>
            </div>
			<br>
            <div class="section2b"><u>
                    <ol id="criteria">
                        <li onclick="toggleSublist(1)" class="mx-3" style="color:green;"><b>&nbsp;Criterion I - Curricular Aspects (150)&nbsp;</b></li> 
                            <ul class="criterium1" id="sublist1" style="display: none;">
                                <li onclick="toggleSublist(2)" >1.1 Curriculum Design and Development (50)</li>
                                    <ul class="sub-criterium2" id="sublist2" style="display: none;">
                                        <li><a href="<?= base_url('hod_1_1_1')?>">1.1.1</a></li>
                                        <li><a href="<?= base_url('hod_1_1_2')?>">1.1.2</a></li>
                                    </ul>
                                
                                <li onclick="toggleSublist(3)" >1.2 Academic Flexibility (30)</li>
                                    <ul class="sub-criterium3" id="sublist3" style="display: none;">
                                        <li><a href=""><a href="<?= base_url('hod_1_2_1')?>" >1.2.1</a></a></li>
                                    </ul>
                                
                                <li onclick="toggleSublist(4)">1.3 Curriculum Enrichment (50)</li>
                                    <ul class="sub-criterium4" id="sublist4" style="display: none;">
                                        <li><a href="<?= base_url('hod_1_3_1')?>">1.3.1</a></li>
                                        <li><a href="<?= base_url('hod_1_3_2')?>">1.3.2</a></li>
                                    </ul>
                            </ul>
                            <hr>
                            <br>
                        <li onclick="toggleSublist(6)" class="mx-3" style="color:green;"><b>&nbsp;Criterion II - Teaching-Learning and Evaluation (300)&nbsp;</b></li>
                            <ul class="criterium6" id="sublist6" style="display: none;">
                                
                                <li onclick="toggleSublist(8)">2.2 Catering to Student Diversity (30)</li>
                                    <ul class="sub-criterium8" id="sublist8" style="display: none;">
                                        <li><a href="<?= base_url('hod_2_2_1')?>">2.2.1</a></li>
                                    </ul>
                                <li onclick="toggleSublist(9)">2.3 Teaching - Learning Process (50)</li>
                                    <ul class="sub-criterium9" id="sublist9" style="display: none;">
                                        <li><a href="<?= base_url('hod_2_3_3')?>">2.3.3</a></li>
                                    </ul>
                                                                 
                                <li onclick="toggleSublist(12)">2.6 Student Performance and Learning Outcomes (50)</li>
                                    <ul class="sub-criterium12" id="sublist12" style="display: none;">
                                        <li><a href="<?= base_url('hod_2_6_1')?>">2.6.1</a></li>
                                    </ul>  
                            </ul>
                            <hr>
                            <br>
                        <li onclick="toggleSublist(14)" class="mx-3" style="color:green;"><b>&nbsp;Criterion III - Research, Innovations and Extension (150)&nbsp;</b></li>
                            <ul class="criterium14" id="sublist14" style="display: none;">
                                <li onclick="toggleSublist(15)">3.1 Promotion of Research and Facilities (20)</li>
                                    <ul class="sub-criterium15" id="sublist15" style="display: none;">
                                        <li><a href="<?= base_url('hod_3_1_1')?>">3.1.1</a></li>
                                    </ul>
                                <li onclick="toggleSublist(17)">3.3 Innovation Ecosystem (10)</li>
                                    <ul class="sub-criterium17" id="sublist17" style="display: none;">
                                        <li><a href="<?= base_url('hod_3_3_1')?>">3.3.1</a></li>
                                    </ul>
                                                                  
                                <li onclick="toggleSublist(20)">3.6 Extension Activities (50)</li>
                                    <ul class="sub-criterium20" id="sublist20" style="display: none;">
                                        <li><a href="<?= base_url('hod_3_6_1')?>">3.6.1</a></li>
                                    </ul>   
                            </ul>
                            <hr>
                            <br>
                        <li onclick="toggleSublist(27)" class="mx-3" style="color:green;"><b>&nbsp;Criterion V - Student Support and Progression (100)&nbsp;</b></li>
                            <ul class="criterium27" id="sublist27" style="display: none;">
                                <li onclick="toggleSublist(28)">5.1 Student Support (30)</li>
                                    <ul class="sub-criterium28" id="sublist28" style="display: none;">
                                        <li><a href="<?= base_url('hod_5_1_2')?>">5.1.2</a></li>
                                        <li>5.1.3</li>
                                    </ul>
                                <li onclick="toggleSublist(29)">5.2 Student Progression (30)</li>
                                    <ul class="sub-criterium29" id="sublist29" style="display: none;">
                                        <li><a href="<?= base_url('hod_5_2_1')?>">5.2.1,5.2.2</a></li>
                                        <li><a href="<?= base_url('hod_5_2_3')?>">5.2.3</a></li>
                                    </ul>                                  
                            </ul>
                            <hr>
                            <br>

                        <li onclick="toggleSublist(38)" class="mx-3" style="color:green;"><b>&nbsp;Criterion VII - Institutional Values and Best Practices (100)&nbsp;</b></li>
                            <ul class="criterium38" id="sublist38" style="display: none;">
                                <li onclick="toggleSublist(39)">7.1 Institutional Values and Social Responsibilities (50)</li>
                                    <ul class="sub-criterium39" id="sublist39" style="display: none;">
                                        <li><a href="<?= base_url('hod_7_1_1')?>">7.1.1</a></li>
                                        <li><a href="<?= base_url('hod_7_1_8')?>">7.1.8</a></li>
                                       
                                    </ul>
                                <li onclick="toggleSublist(40)">7.2 Best Practices (30) </li>
                                    <ul class="sub-criterium40" id="sublist40" style="display: none;">
                                        <li><a href="<?= base_url('hod_7_2_1')?>">7.2.1</a></li>
                                    </ul>
                            </ul>
                    </ol></u>
                    <script>
                        function toggleSublist(listNum) {
                        var sublist = document.getElementById("sublist" + listNum);
                        sublist.style.display = sublist.style.display === "none" ? "block" : "none";
                        }
                    </script>
            </div>
            
		</div>
	</div>
<?php endforeach;?>
<?php endif;?>
</body>
</html>