<?= $this->extend('Layouts/hodBase');?>
<?= $this->section("Content");?>
<h1 class="text-center my-3">3.6.1</h1>
<div class="container-fluid border border-info-subtle my-4" style="display:none" id="hod">
        <form class="mx-3 g-3 my-3" method="post" action="<?= base_url('save_3_6_1') ?>" enctype="multipart/form-data">
        <div class="row pt-3 pb-3 border border-2">
            <div class="col-md-11 my-3">
                <label >Outcomes of extension activities in the neighbourhood community in terms of impact and sensitizing the students to social issues and holistic development, and awards received if any during the last five years : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                <textarea name="outcomes" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"></textarea>
                <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                <script>
                    // Function to enforce the word limit on the textarea
                    function enforceWordLimit(event) {
                        const wordLimit =  200; // Set your desired word limit here
                        const textarea = event.target;
                        const words = textarea.value.trim().split(/\s+/);
                        const remainingWords = wordLimit - words.length;
            
                        if (remainingWords < 0) {
                            // If the user exceeds the word limit, prevent further input
                            event.preventDefault();
                            textarea.value = words.slice(0, wordLimit).join(' ');
                        }
            
                        // Update the remaining words count
                        document.getElementById('remainingWords').textContent = remainingWords;
                    }
            
                    // Attach the event listener to the textarea
                    const textareaElement = document.getElementById('wordLimitedTextarea');
                    textareaElement.addEventListener('input', enforceWordLimit);
                </script>
            </div>

            <div class="col-md-5 my-3">
                <label class="form-label">Upload Report  :<label style="color: red;">* (.pdf only)</label></label><br>
                <input type="file" class="form-control" name="report"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            <div class="col-md-5 my-3">
                <label class="form-label">Upload Awards (if any) :<label style="color: red;">(.pdf only)</label></label><br>
                <input type="file" class="form-control" name="awards"  accept=".pdf" >
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-md-5 my-3">
                <label class="form-label">Upload Geotag Photo  :<label style="color: red;">* (..jpg,.jpeg,.png only)</label></label><br>
                <input type="file" class="form-control" name="geotag1"  accept=".jpg,.png,.jpeg" >
                <br>
                <input type="file" class="form-control" name="geotag2"  accept=".jpg,.png,.jpeg" >
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
 
            <div class="col-md-5 my-3">
                <label class="form-label">Upload Non-Geotag Photo  :<label style="color: red;">(.jpg,.jpeg,.png only)</label></label><br>
                <input type="file" class="form-control" name="nongeotag1"  accept=".jpg,.png,.jpeg" >
                <br>
                <input type="file" class="form-control" name="nongeotag2"  accept=".jpg,.png,.jpeg" >
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            </div>
            <br>

            <div class="col-12 my-3 text-center">
              <input type="submit" class="btn btn-outline-primary"></input>
            </div>
		</form>
</div>

<!-- Table View -->
<div class="container-fluid pb-3 mt-3" >
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No.</th>
                <th scope="col">Outcomes of extension activities in the neighbourhood community in terms of impact and sensitizing the students to social issues and holistic development, and awards received if any during the last five years </th>
                <th scope="col">Report</th>
                <th scope="col">Awards</th>
                <th scope="col">Geotag Photo 1</th>
                <th scope="col">Geotag Photo 2</th>
                <th scope="col"> Non-Geotag Photo 1</th>
                <th scope="col"> Non-Geotag Photo 2</th>
                <th scope="col">Update</th>

            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->HOD_3_6_1;
                $report = $book->report;
                $awards = $book->awards;
                $geotag1 = $book->Geotag1;
                $geotag2 = $book->Geotag2;
                $nonGeotag1 = $book->Non_geotag1;
                $nonGeotag2 = $book->Non_geotag2;
        ?>
        <tbody >
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $book->Outcomes_of_extension_activities?> </td>
              
                <td class="text-center"> 
                    <?php if( !empty($report)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$report;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>  
                    
                </td>
                
                <td class="text-center"> 
                    <?php if( !empty($awards)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$awards;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
 
                </td>
                <td class="text-center"> 
                    <?php if( !empty($geotag1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$geotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
 
                </td>
                <td class="text-center"> 
                    <?php if( !empty($geotag2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$geotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>

                
                </td>
                <td class="text-center"> 
                    <?php if( !empty($nonGeotag1)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$nonGeotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td class="text-center"> 
                    <?php if( !empty($nonGeotag2)):?>
                        <a href="<?= base_url('Userfiles/HOD/Criterion_III/').$nonGeotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>

                <td> 

                    <?php if( empty($report)):?>
                        <div class="btn-group pb-1 ps-2 mt-3" role="group" aria-label="Basic checkbox toggle button group">
                                <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
                                <label class="btn btn-success" for="btncheck1"> Add Data</label>
                        </div>
                    <?php else :?>
                        <div class="text-center">
                             <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>
                             <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $book->HOD_id?>" data-bs-whatever="@mdo">Update</button>
                        </div>  
                    <?php endif;?>

                   
                    <div class="modal fade" id="exampleModal<?= $book->HOD_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Research Project Information </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('save_3_6_1')?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12">
                                    <div class="md-4" style="display:none;">
                                            <input type="text" class="form-control" name="srnumber" readonly  value="<?= $book->HOD_id?>" >
                                    </div>

                                    <div class="md-11 my-3">
                                            <label >Outcomes of extension activities in the neighbourhood community in terms of impact and sensitizing the students to social issues and holistic development, and awards received if any during the last five years : <b style="color: rgb(235, 15, 15);">* 200 words only</b> </label>
                                            <textarea name="outcomes" class="form-control" id="wordLimitedTextarea" rows="3" data-word-limit="200"><?= $book->Outcomes_of_extension_activities?></textarea>
                                            <p class="float-end" style="color: rgb(76, 132, 236);">Remaining words: <span id="remainingWords"> 200</span></p>
                                            <script>
                                                // Function to enforce the word limit on the textarea
                                                function enforceWordLimit(event) {
                                                    const wordLimit =  200; // Set your desired word limit here
                                                    const textarea = event.target;
                                                    const words = textarea.value.trim().split(/\s+/);
                                                    const remainingWords = wordLimit - words.length;
                                        
                                                    if (remainingWords < 0) {
                                                        // If the user exceeds the word limit, prevent further input
                                                        event.preventDefault();
                                                        textarea.value = words.slice(0, wordLimit).join(' ');
                                                    }
                                        
                                                    // Update the remaining words count
                                                    document.getElementById('remainingWords').textContent = remainingWords;
                                                }
                                        
                                                // Attach the event listener to the textarea
                                                const textareaElement = document.getElementById('wordLimitedTextarea');
                                                textareaElement.addEventListener('input', enforceWordLimit);
                                            </script>
                                        </div>

                                        <div class="md-5 my-3">
                                            <label class="form-label">Upload Report  :<label style="color: red;">* (.pdf only)</label></label><br>
                                            <input type="file" class="form-control" name="report"  accept=".pdf"  >
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>

                                         
                                        </div>
                                        <div class="md-5 my-3">
                                            <label class="form-label">Upload Awards (if any) :<label style="color: red;">(.pdf only)</label></label><br>
                                            <input type="file" class="form-control" name="awards"  accept=".pdf" >
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>
                                             
                                        </div>

                                        <div class="md-5 my-3">
                                            <label class="form-label">Upload Geotag Photo  :<label style="color: red;">* (.pdf only)</label></label><br>
                                            <input type="file" class="form-control" name="geotag1"  accept=".jpg,.png,.jpeg" >
                                            
                                           <p class="my-3"></p>
                                            <input type="file" class="form-control" name="geotag2"  accept=".jpg,.png,.jpeg" >
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>
                                            
                                        </div>

                                        <div class="md-5 my-3">
                                            <label class="form-label">Upload Non-Geotag Photo  :<label style="color: red;">(.pdf only)</label></label><br>
                                            <input type="file" class="form-control" name="nongeotag1"  accept=".jpg,.png,.jpeg" >
                                            
                                            <p class="my-3"></p>
                                            <input type="file" class="form-control" name="nongeotag2"  accept=".jpg,.png,.jpeg" >
                                            <span  style="display:none;color:red;">Please upload the pdf.</span>
                                        </div> 
                        </div>
                          
                    </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button  class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>


<script>
         
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('hod');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
    if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
    } else {
        myForm.style.display="none";
        //msg.style.display="block";
    }
    });

</script>

<script src="<?php echo base_url('assets/js/HOD/3_6_1_view.js'); ?>"></script>

<?= $this->endSection();?>




