<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">

    <link rel="stylesheet" href="main.css">

</head>

<body>
    <div class="image-container">
        <img src="p1.png" class="img-fluid">
    </div>

    <div class="container-fluid px-4  ">
        <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
            <div class="col">
                <div class="card card-cover h-50 w-100 overflow-hidden bg-success-subtle rounded-4 shadow-lg"
                    style="background-image: url('unsplash-photo-1.jpg');">
                    <div class="d-flex flex-column h-100 p-5 pt-3 mb-4 text-dark text-shadow-1">
                        <h3 class="text-center display-6 lh-1 fw-bold"> <a href="admin.html"
                                style="text-decoration: none;">Admin</a></h3>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card card-cover h-50 w-100 overflow-hidden bg-success-subtle rounded-4 shadow-lg"
                    style="background-image: url('unsplash-photo-1.jpg');">
                    <div class="d-flex flex-column h-100 p-5 pt-3 mb-4 text-dark text-shadow-1">
                        <h3 class="text-center display-6 lh-1 fw-bold"> <a href="teacher.html"
                                style="text-decoration: none;">Teacher</a></h3>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card card-cover h-50 overflow-hidden bg-success-subtle rounded-4 shadow-lg"
                    style="background-image: url('unsplash-photo-3.jpg');">
                    <div class="d-flex flex-column h-100 p-5 pt-3 mb-4 text-shadow-1">
                        <h3 class="text-center display-6 lh-1 fw-bold"> <a href="principal.html"
                                style="text-decoration: none;">Principal | Vice Principal</a></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    
    <div class="contanier">
        <div class="row">

            <div class="col-md-3 pt-3" style="margin-left: 350px;">
                <div id="Maininfo_College">
                    <div class="login_main_inner">
                        <h5>For College Users</h5>
                        <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto:collegesupport@pun.unipune.ac.in">collegesupport@pun.unipune.ac.in</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;020-71533633<br>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a id="linkForgotPass"
                            href="javascript:__doPostBack('linkForgotPass','')">Existing College - Forgot Password ?</a>

                        <hr>
                        <h5>For University &amp; College Teachers</h5>
                        <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto:teachersupport@pun.unipune.ac.in">teachersupport@pun.unipune.ac.in</a><br>
                        <i class="fa fa-phone" style="color: #17a2b8"></i>&nbsp;020-71533633<br>
                        <i class="fa fa-key" style="color: #17a2b8"></i>&nbsp;<a
                            href="GeneralPages/TeacherForgotPassword.aspx">Teacher Forgot Password?</a>

                        <hr>
                        <h5>For University Department Users</h5>

                        <i class="fa fa-envelope" style="color: #17a2b8"></i>&nbsp;<a
                            href="mailto:collegesupport@pun.unipune.ac.in">collegesupport@pun.unipune.ac.in</a>
                    </div>
                </div>


            </div>
            <div class="login-box ">
                <h2>Principal | Vice Principal Login</h2>
                <form>
                    <div class="user-box">
                        <input type="text" name="" required="">
                        <label>Username</label>
                    </div>
                    <div class="user-box">
                        <input type="password" name="" required="">
                        <label>Password</label>
                    </div>
                    <a href="#">
                        Login
                    </a>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N"
        crossorigin="anonymous"></script>
</body>

</html>