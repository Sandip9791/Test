<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modern College Ganeshkhind Pune </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function(){
          $("#datepicker").datepicker({
             format: "yyyy",
             viewMode: "years", 
             minViewMode: "years",
             autoclose:true
          });   
        })
    </script>
</head>

<body>

    <div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
    </div>
   
<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('admin'); ?>">Dashboard</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('teaFaculty');?>">Teacher Faculty Enrollment</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('teaFacultyFecth');?>">Teacher Enroll Data </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('iqacFacultyFecth');?>">IQAC Enroll Data </a>
                </li>
            </ul>
            <form class="d-flex" method="Post" action="<?= base_url('adminLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('admin_user'); echo $myusername ;?></label>
                    <input type="submit" value="Logout" class="btn btn-outline-danger">
                </form>
        </div>
    </div>
</nav>

  <div class="container-fluid mx-1">
    <h2 class="py-3">Enroll Data:</h2>
    <table class="table table-hover table-bordered border border-primary border-3 ">
  <thead class="table-info ">
    <tr>
    <th scope="col ">Username</th>
      <th scope="col">Name</th>
      <th scope="col">Enroll Date</th>
      <th scope="col">Login Time</th>
      <th scope="col">Logout Time</th>
      <th scope="col">Email</th>
      <th scope="col">Teacher ID</th>
      <th scope="col">Teacher Type</th>
      <th scope="col">Faculty</th>
      <th scope="col">Department</th>
      <th scope="col">Designation</th>
      <th scope="col">Nature Of Appointment</th>
      <th scope="col">Joining Date</th>
      <th scope="col">Leaving Data</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>

 <?php if(isset($documents)):?>
      <?php foreach($documents as $document):

            $title=$document->Title;
            $fname=$document->First_Name;
            $lname=$document->Last_Name;
            $mname=$document->Midd_Name;

            $Name = $title." ".$fname." ".$mname." ".$lname;
       ?>
        <tr>
            <td><form action="<?=base_url('iqacFacultyDelete')?>" method="post">
                <input class="form-control" type="text" value="<?= $document->username ?>" name="uname" readonly></td>
            <td ><?= $Name ?></td>
            <td ><?= $document->Time ?></td>
            <td ><?= $document->Login_Time ?></td>
            <td ><?= $document->Logout_Time ?></td>
            <td><?= $document->Email ?></td>
            <td><?= $document->Teacher_ID ?></td>
            <td><?= $document->Teacher_Type ?></td>
            <td><?= $document->Faculty ?></td>
            <td><?= $document->Department ?></td>
            <td><?= $document->Designation ?></td>
            <td><?= $document->Nature_of_Appointment ?></td>
            <td><?= $document->Joining_Date ?></td>
            <td><?= $document->Leaving_Date ?></td>
            <td>
               <img class="mx-3" src="assets/images/profile/delete.gif"> <input class="btn btn-primary" type="submit" value="Remove"></form></td>
        </tr>
     <?php endforeach;?>
 <?php endif;?>
</tbody>
</table>
</div>

</body>

</html>





