<!DOCTYPE html>
<html>
<head>
    <br>
	<title>Teacher Information Form</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>
    <script>
		$(document).ready(function(){
			$("#faculty-select").change(function(){
				var faculty = $(this).val();
				if(faculty == "Arts"){
					$("#department-select").html("<option>History</option><option>Geography</option><option>Economics</option><option>Psychology</option><option>Political Science</option><option>Marathi</option><option>Hindi</option><option>English</option><option>Defence</option><option>Sociology</option><option>Other</option>");
				} else if(faculty == "Science"){
					$("#department-select").html("<option>Computer Science</option><option>BCA(Science)</option><option>Chemistry</option><option>Microbiology</option><option>Biotechnology</option><option>Zoology</option><option>Botany</option><option>Physics</option><option>Mathematics</option><option>Statistics</option><option>Electronics</option><option>B.Voc(Food Processing)</option><option>Other</option>");
				} else if(faculty == "Commerce & Management"){
					$("#department-select").html("<option>Commerce</option><option>BBA(CA)</option>")
                } else if(faculty == "Library"){
					$("#department-select").html("<option>Library</option>")
                } else if(faculty == "Physical Education"){
					$("#department-select").html("<option>Physical Education</option>")
                } else {
					$("#department-select").html("");
				}
			});
		});
	</script>
</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>

<nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
				<li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('admin'); ?>">Dashboard</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('teaFaculty');?>">Teacher Faculty Enrollment</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('teaFacultyFecth');?>">Teacher Enroll Data </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?= base_url('iqacFacultyFecth');?>">IQAC Enroll Data </a>
                </li>

            </ul>
			<form class="d-flex" method="Post" action="<?= base_url('adminLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('admin_user'); echo $myusername ;?></label>
                    <input type="submit" value="Logout" class="btn btn-outline-danger">
                </form>
        </div>
    </div>
</nav>

<div class="container-fluid border border-info-subtle my-4">
		<h1>Faculty Enrollment Details:</h1>
		<form class="row g-4 my-2" action="<?php echo base_url('teaFacultyInsert');?>" method="post" enctype="multipart/form-data">

		<div class="col-md-3">
			<label class="form-label">Title <label style="color: red;">*</label></label>
			<span id="titleError" style="display:none;color:red;">Please select a name title.</span>
			<select class="form-select" name="title" required>
			<option selected value="">...</option>
			<option value="Dr.">Dr.</option>
			<option value="Mr.">Mr.</option>
			<option value="Mrs.">Mrs.</option>
			<option value="Ms.">Ms.</option>
			</select>
      </div>
		<div class="col-md-3">
        <label class="form-label">First name <label style="color: red;">*</label></label>
        <input id="firstname" type="text" class="form-control person-name" name="fname" onkeyup="validateFirstName()" autocomplete="off" required>
        <span id="firstnameError" style="display:none;color:red;">Please enter a valid name.</span>

      </div>
      <div class="col-md-3">
        <label class="form-label">Last name <label style="color: red;">*</label></label>
        <input id="lastname" type="text" class="form-control person-name" name="lname" onkeyup="validateLastName()" autocomplete="off" required>
        <span id="lastnameError" style="display:none;color:red;">Please enter a valid name.</span>

      </div>
      <div class="col-md-3">
        <label class="form-label">Middle name <label style="color: red;">(Optional)</label></label>
        <input id="middlename" type="text" class="form-control person-name" name="mname" onkeyup="validateMiddleName()" autocomplete="off">
        <span id="midnameError" style="display:none;color:red;">Please enter a valid name.</span>

      </div>
            <div class="col-md-4">
				<label for="teacher-name">Email : <label style="color: red;">*</label></label>
				<input type="text" name="email" class="form-control" id="email" placeholder="user123@gmail.com" onkeyup="validateEmail()" autocomplete="off" required>
				<span id="TEmailError" style="display:none;color:red;">Please Enter a Valid EMail ID.</span>
			</div>
			<div class="col-md-4">
				<label for="teacher-id">Teacher ID : <label style="color: red;">*</label></label>
				<input type="text" class="form-control" disabled id="teacher-id" name="tid" value="<?= $lid?>" placeholder="Enter teacher ID" required>
			</div>
			<div class="col-md-4">
				<label for="designation-select">Teacher Type : <label style="color: red;">*</label></label>
				<select class="form-control" id="Teacher_select" onclick="showOther()" name="Ttype" required>
				    <option selected hidden disable> --- Select One --- </option>
					<option value="Teacher">Teacher</option>
					<option value="HOD">HOD (Head Of Department)</option>
					<option Value="Principal">Principal</option>
					<option Value="IQAC">IQAC</option>
					<option Value="Committee">Committee</option>
				</select>
			</div>

			<div class="col-md-4" id="committes" style="display:none">
				<label for="designation-select">Committee's Type : <label style="color: red;">*</label></label>
				<select class="form-control" id="designation-select" name="CommittesType" required>
				   <option selected hidden disable> --- Select One --- </option>
					<option value="Exam">Exam</option>
					<option value="Physical Education">Physical Education</option>
					<option Value="Library">Library</option>
					<option Value="Committee">Committee</option>
				</select>
			</div>
			 
			<script>
				function showOther() {
					var type = document.getElementById("Teacher_select");
					if (type.value == "Committee") 
					{
						document.getElementById("committes").style.display="block";
					}
					else 
					{
						document.getElementById("committes").style.display="none";
					} 
				}
            </script>

			<div class="col-md-4">
				<label for="faculty-select">Faculty : <label style="color: red;">*</label></label>
				<select class="form-control" id="faculty-select" name="faculty" required>
					<option selected hidden disable> --- Select One --- </option>
					<option>Arts</option>
					<option>Science</option>
					<option>Commerce & Management</option>
					<option>Library</option>
					<option>Physical Education</option>
				</select>
			</div>

			<div class="col-md-4">
				<label for="department-select">Department : <label style="color: red;">*</label></label>
				<select class="form-control" id="department-select" name="department" >
				</select>
			</div>

			<div class="col-md-4">
				<label for="designation-select">Designation : <label style="color: red;">*</label></label>
				<select class="form-control" id="designation-select" name="designation" required>
					<option selected hidden disable> --- Select One --- </option>
					<option>Professor</option>
					<option>Associate Professor</option>
					<option>Assistant Professor</option>
				</select>
			</div>
			
			<div class="col-md-4">
    			<label for="validationDefault05" class="form-label">Joining Date: <label style="color: red;">*</label></label>
    			<input type="date" class="form-control" id="validationDefault05" name="jdate" placeholder="dd-mm-yyyy" min="1992-01-01" required>
			</div>

			<div class="col-md-4">
    			<label for="validationDefault06" class="form-label">Leaving Date <label style="color: red;">(Optional)</label></label>
    			<input type="date" class="form-control" id="validationDefault06" name="ldate" placeholder="dd-mm-yyyy">
			</div>

			<div class="col-md-4 ">
				<label class="col-form-label pt-0">Nature of Appointment : <label style="color: red;">*</label></label>
				<div class="col-sm-10">
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios1" value="Against Sanction Post" required>
					<label class="form-check-label" for="gridRadios1">
						Against Sanctioned Post
					</label>
				  </div>
				
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios2" value="Professor By Practice - Industrial & Academic Practice" required>
					<label class="form-check-label" for="gridRadios2">
						Professor By Practice - Industrial & Academic Practice
					</label>
				  </div>
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios2" value="Adhoc" required>
					<label class="form-check-label" for="gridRadios2">
						Adhoc
					</label>
				  </div>
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios2" value="Temporary" required>
					<label class="form-check-label" for="gridRadios2">
						Temporary
					</label>
				  </div>
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios2" value="CHB" required>
					<label class="form-check-label" for="gridRadios2">
						CHB
					</label>
				  </div>
				  <div class="form-label">
					<input class="form-check-input" type="radio" name="nop1" id="gridRadios2" value="CHB (Grantable)" required>
					<label class="form-check-label" for="gridRadios2">
						CHB (Grantable)
					</label>
				  </div>
			</div>
			<br>
			</div>
			<br>
				<div class="container">
				<div class="row">
				<div class="col-md-12 mx-4">
					<label for="yes-no">Is There Any Earlier Experience ?</label><br>
					<input class="form-check-input" type="radio" name="yes-no" id="yes" value="yes" onclick="showTextBox()"> <label class="form-check-label" for="gridRadios6">Yes</label> <br>
					<input class="form-check-input" type="radio" name="yes-no" id="no" value="no" onclick="hideTextBox(),display()"> <label class="form-check-label" for="gridRadios6">No</label><br>
					<br>
				</div>

				<div class="col-md-4" id="instituteNameDiv" style="display:none;">
					<label class="form-label">Institute Name : <label style="color: red;">*</label></label>
					<input type="text" class="form-control" id="institute-name" name="iname" placeholder="Enter Institute Name" onkeyup="validateInstiName()" autocomplete="off">
					<span id="instinameError" style="color: red; display: none;">Please enter a valid institute name.</span>
				</div>

				<div class="col-md-4" id="experienceDiv" style="display:none;">
					<label class="form-label">Experience : <label style="color: red;">*(In Years)</label></label>
					<input type="number" class="form-control" id="experience-years" name="experience" placeholder="Enter Experience" min="0" max="30" oninput="validateExperience()">
					<span id="experienceError" style="color: red; display: none;">Please enter a valid experience (0 to 30 years).</span>
				</div>

				<div class="col-md-4" id="experienceDocDiv" style="display:none;">
					<label class="form-label">Upload Experience Letter : <label style="color: red;">* (Only .pdf)</label></label>
					<input type="file" class="form-control" id="experience-upload" name="eupload" placeholder="Only .pdf" accept=".pdf" onchange="validateExperienceDoc(event)">
					<span id="experiencedocError" style="color:red;"></span>
				</div>
			</div>
		</div>
		<div class="text-center">
           <input  type="submit" class="btn btn-outline-primary" value="Submit">
       </div>
	</form>

<script src="<?php echo base_url('assets/js/Admin/teacherFaculty_view.js'); ?>"></script>

</body>
</html>
