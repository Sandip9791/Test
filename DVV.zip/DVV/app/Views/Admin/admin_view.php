<!DOCTYPE html>
<html>
<head>
    <br>
	<title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    
    <link rel="stylesheet" href="<?= base_url('assets/css/admin_css.css')?>">

</head>
<body>
<div class="img-fluid" style="width:100%;background-color: #034568;">
        <img src="<?= base_url('assets/images/ModernCollageLogo.png'); ?>"/>
</div>
      
    
    
    <nav class="navbar  bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <!-- <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?= base_url('admin'); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?= base_url('teaFaculty');?>">Teacher Faculty Enrollment</a>
                    </li> -->
                </ul>

                <form class="d-flex" method="Post" action="<?= base_url('adminLogout')?>">
                <label  class="btn btn-outline-info rounded-pill mx-4"  title="Login Profile">Username: <?php  $session = \Config\Services::session(); 
                   $myusername= $session->get('admin_user'); echo $myusername ;?></label>
                    <input type="submit" value="Logout" class="btn btn-outline-danger">
                </form>
           </div>
       </div>
   </nav>


<h1 style="margin-top:10px; text-align:center;">Admin Dashboard</h1>
<br>
    <div class="container">
		<div class="section1">
			<div class="section1a">
                <h3>&nbsp; Profile</h3>
            </div>
			<div class="section1b">
                <img src="<?= base_url('assets/images/profile/pro.png')?>" alt="profile" class="profilr_pic"><br>
                <h6><b>Name:&nbsp;</b>Office Staff</h6>
                <h6><b>Designation:&nbsp;</b>Admin</h6>
                <h6><b>Mobile no.:&nbsp;</b> (020) 25634021 / (020) 25650191</h6>
                <h6><b>Email:&nbsp;</b><a href="mailto: moderncollege16@gmail.com"> moderncollege16@gmail.com</a></h6>
                
            </div>
		</div>
		<div class="section2">
			<div class="section2a">
                <h3>&nbsp; Important links:</h3>
            </div >
			<div class="section2b">
                <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('teaFaculty');?>">
                    Teacher Faculty Enrollment
                    <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                </a><br><br>

                <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('teaFacultyFecth');?>">
                    Teachers Enroll Data
                    <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                </a>

                <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('iqacFacultyFecth');?>">
                     IQAC Enroll Data
                    <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                </a>

                <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('commiteeFacultyFecth');?>">
                      Committee Enroll Data
                    <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                </a>
                <hr>
                <h2><b>Reports</b></h2>
                <hr>
                <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('teachingExperiance_Report');?>">
                    Teaching Experiance
                    <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                </a>
 
                <a href="<?= base_url('teachingPeriod_Report');?>">Teaching Period</a><br> 
                <hr>
                   <h4 class="ms-3"><b>Research Reports:</b></h4>
                   <a class="icon-link icon-link-hover ms-4" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('researchProject_Report');?>">
                         Reaserch Project Information
                         <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                   </a>
                   <a class="icon-link icon-link-hover " style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('researchGuide_Report');?>">
                         Reaserch Guide
                         <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                   </a>

                   <a class="icon-link icon-link-hover " style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('seedMoney_Report');?>">
                         Seed Money
                         <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                   </a>

                   <a class="icon-link icon-link-hover " style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('fellowshipFinancial_Report');?>">
                        Fellowship/Financial Support
                         <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                   </a>
                   <p class="ms-3 my-3"></p>
                   <a class="icon-link icon-link-hover" style="--bs-link-hover-color-rgb: 25, 135, 84;" href="<?= base_url('researchPublication_Report');?>">
                        Research Publication Information
                         <svg class="bi" aria-hidden="true"><use xlink:href="#arrow-right"></use></svg>
                   </a>
            </div>
            </div>
		</div>
	</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>
</html>
