<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Sinsitization of student to the constitutional obligations like(Values/Rights/Duties/Responsibilities of
        citizens)</h1>
<div class="container-fluid border border-primary my-4" style="display:none" id="Sensetization">
        <form class=" g-3 my-3" id="dynamic-form" action="<?= base_url('saveSensitization')?>" method="post"
            enctype="multipart/form-data">
           

                    <div class="row mx-2 pt-3 pb-3 border border-2">
                        <div class="col-md-12 my-3" style="padding-bottom: 0.5cm;">
                            <label class="form-label">Details: <label style="color: red;">*</label></label><br>
                            <textarea class="form-control" name="details" id="Details" rows="3"
                                maxlength="700"></textarea>
                            <span style="display:none;color:red;">Please enter a valid year.</span>
                        </div>
                        
                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Attendance: <label style="color: red;">* (.pdf
                                    only)</label></label>
                            <input id="document" type="file" class="form-control my-3" name="attendance" accept=".pdf"
                                onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                            <br>
                            <label for="sanction-name">Upload Notice: <label style="color: red;">* (.pdf
                                    only)</label></label>
                            <input id="document" type="file" class="form-control my-3" name="notice" accept=".pdf"
                                onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>
                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.jpg.,jpeg,.png only)</label></label><br>
                            Photo 1:<input id="document" type="file" class="form-control my-3" name="geotagPhoto1"
                               accept=".jpg.,jpeg,.png" onchange="validateSanction()" required>
                            Photo 2:<input id="document" type="file" class="form-control my-3" name="geotagPhoto2"
                               accept=".jpg.,jpeg,.png" onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;"> (.jpg.,jpeg,.png only)</label></label><br>
                            Photo 1:<input id="document" type="file" class="form-control my-3" name="nongeotagPhoto1"
                               accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                            Photo 2:<input id="document" type="file" class="form-control my-3" name="nongeotagPhoto2"
                               accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>
                    </div>
                

            <div class="col-md-12 text-center my-3">
                <button type="submit" class="btn  btn-outline-primary">Submit</button>
            </div>
        </form>

</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>
   
<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Details</th>
                <th scope="col">Upload documents</th>
                <th scope="col">Upload Geotag photos 1</th>
                <th scope="col">Upload Geotag photos 2</th>
                <th scope="col">Upload Non Geotag photos 1</th>
                <th scope="col">Upload Non Geotag photos 2</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Sensetization_Of_Student;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                     $Student_Document = $chapter->Attendance;

                     $geotagPhoto1 = $chapter->Geotag_Photo1;
                     $geotagPhoto2 = $chapter->Geotag_Photo2;

                     $nonGeotagPhoto1 = $chapter->NonGeotag_Photo1;
                     $nonGeotagPhoto2 = $chapter->NonGeotag_Photo2;


            ?>
            <tr>
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Details?> </td>
                <td class="text-center">
                    <?php if( !empty($Student_Document)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Extension/').$Student_Document;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                 </td>
                <td class="text-center"> 
                    <?php if( !empty($geotagPhoto1)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotagPhoto1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <?php if( !empty($geotagPhoto2)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotagPhoto2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <?php if( !empty($nonGeotagPhoto1)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Extension/').$nonGeotagPhoto1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> 
                    <?php if( !empty($nonGeotagPhoto2)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Extension/').$nonGeotagPhoto2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                </td>
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>
                    <form action="<?= base_url('deleteSensitization')?>" method="post">
                        <input type="text"  style="display:none;" name="srnumber" readonly value="<?= $chapter->Sensetization_Of_Student_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                        
                <td> 
                      <div class="text-center">
                            <img class=" text-center" src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>

                            <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Sensetization_Of_Student_id?>" data-bs-whatever="@mdo">Update</button>                     
                     </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Sensetization_Of_Student_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel"> Sensetization of student </h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                        <div class="modal-body">
                        <form action="<?= base_url('updateSensitization') ?>" method="post" enctype="multipart/form-data">                            
                            <div class="row">

                                <div class="md-4" style="display:none;">
                                    <label class="form-label">Mentee id <label style="color: red;">* </label></label>
                                    <input type="text" class="form-control"  name="srnumber" readonly value="<?= $chapter->Sensetization_Of_Student_id?>"></th>
                                    <span style="display:none;color:red;">Please enter a valid Information.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label">Details: <label style="color: red;">*</label></label><br>
                                    <textarea class="form-control" name="details" id="Details" rows="3"
                                        maxlength="700"><?= $chapter->Details?></textarea>
                                    <span style="display:none;color:red;">Please enter a valid year.</span>
                                </div>
                                
                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Attendance: <label style="color: red;">* (.pdf
                                            only)</label></label>
                                    <input id="document" type="file" class="form-control my-3" name="studDocument" accept=".pdf"
                                        onchange="validateSanction()"  >
                                    <span id="documentError" name="document" style="color:red;"></span>
                                    <label for="sanction-name">Upload Notice: <label style="color: red;">* (.pdf
                                            only)</label></label>
                                    <input id="document" type="file" class="form-control my-3" name="notice" accept=".pdf"
                                        onchange="validateSanction()"  >
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>
                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.jpg.,jpeg,.png only)</label></label><br>
                                    Photo 1:<input id="document" type="file" class="form-control my-3" name="geotagPhoto1"
                                    accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                                    Photo 2:<input id="document" type="file" class="form-control my-3" name="geotagPhoto2"
                                    accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>

                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;"> (.jpg.,jpeg,.png only)</label></label><br>
                                    Photo 1:<input id="document" type="file" class="form-control my-3" name="nongeotagPhoto1"
                                    accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                                    Photo 2:<input id="document" type="file" class="form-control my-3" name="nongeotagPhoto2"
                                    accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>
                            </div>
                     
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-outline-warning">Update</button>
                        </div>
                    </form>
                        </div>
                    </div>
                    </div>
                </td>             
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('Sensetization');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
        if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
        } else {
        myForm.style.display="none";
        //msg.style.display="block";
        }
    });
</script>

<?= $this->endSection();?>