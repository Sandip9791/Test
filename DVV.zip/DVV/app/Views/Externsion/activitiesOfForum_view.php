<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Activities Through Organized Forums</h1>

<div class="container-fluid border border-primary-subtle my-4" style="display:none" id="Activities">
		<form class=" g-3 my-3" method="post" action="<?= base_url('saveActivitiesOfForum')?>" enctype="multipart/form-data">
    <div class="row pt-3 pb-3 mx-2 border border-2">

            <div class="col-md-4 my-3">
              <label class="form-label">Name of the extension activity orginised : <label style="color: red;">*</label></label>
              <textarea name="activity" id="activity" cols="64" rows="1" class="form-control"></textarea>
              <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Information.</span>
              <br>
            </div>

            <div class="col-md-4 my-3">
              <label class="form-label">Outcome: <label style="color: red;">*</label></label><br>
              <textarea name="Outcome" id="Outcome" cols="64" rows="1" class="form-control"></textarea>
              <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Information.</span>
            </div>
            
            <div class="col-md-4 my-3">
              <label class="form-label">No. of participants : <label style="color: red;">*  </label></label>
              <input id="amount" type="number" class="form-control" name="noParticipants" min='0' required>
              <span id="amountError" style="display:none;color:red;">Please enter a valid Information.</span>
            </div>

            <div class="col-md-4 my-3">
              <label class="form-label" for="reason">Forum/Committee/Department:</label>
              <select id="reason" name="forum" class="form-control">
              <option value="" disabled selected hidden>--- Select One --- </option>
              <option value="Cycling Club">Cycling Club</option>
              <option value="Disha">Disha</option>
              <option value="Geography Club">Geography Club</option>
              <option value="IAA">IAA</option>
              <option value="Janeev">Janeev</option>
              <option value="Kisan Students' Forum">Kisan Students' Forum</option>
              <option value="Future bankers forum">Future bankers forum</option>
              <option value="NCC">NCC</option>
              <option value="NSS">NSS</option>
              <option value="Red Cross">Red Cross</option>
              <option value="Sports">Sports</option>
              <option value="Treking Club">Treking Club</option>
              <option value="Other">Other</option>
              </select>
              <div class="col-md-4 my-3" id="other-reason" style="display:none;">
                  <textarea class="form-control" id="other-reason-text" name="other" cols="64" rows="1" style="margin-top: 10px;"></textarea>
              </div>  

              <script>
              document.getElementById('reason').addEventListener('change', function() {
                  if (this.value === 'other') {
                  document.getElementById('other-reason').style.display = 'block';
                  } else {
                  document.getElementById('other-reason').style.display = 'none';
                  }
              });
              </script>
            </div>

          <div class="col-md-4 my-3">
              <label class="form-label">Collaborating Agency With Whom Activity is Conducted: <label style="color: red;">*</label></label><br>
              <textarea class="form-control" name="conducte" id="Details" rows="1"></textarea>
              <span style="display:none;color:red;">Please enter a valid year.</span>
            </div>

            <div class="col-sm-4 my-3">
              <label for="sanction-name" class="form-label">Upload Attendance : <label style="color: red;">* (.pdf only)</label></label><br>
                      <input type="file" class="form-control" name="attendance"  accept=".pdf" required>
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-sm-4 my-3">
              <label for="sanction-name" class="form-label">Upload Report : <label style="color: red;">* (.pdf only)</label></label><br>
                      <input type="file" class="form-control" name="report"  accept=".pdf" required>
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-sm-4 my-3">
              <label for="sanction-name" class="form-label">Upload Geotag : <label style="color: red;">* (.jpg,.jpeg,.png)</label></label><br>
                      <input type="file" class="form-control" name="geotag1"  accept=".jpg,.jpeg,.png" required>
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
                        <br>
                      <input type="file" class="form-control" name="geotag2"  accept=".jpg,.jpeg,.png" required>
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-sm-4 my-3">
              <label for="sanction-name" class="form-label">Upload Non Geotag : <label style="color: red;">(.jpg,.jpeg,.png)</label></label><br>
                      <input type="file" class="form-control" name="NonGeotag1"  accept=".jpg,.jpeg,.png" >
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
                       <br>
                      <input type="file" class="form-control" name="NonGeotag2"  accept=".jpg,.jpeg,.png" >
                      <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>
            </div>
            <div class="col-md-12 my-3 text-center">
            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </div>
		</form>
</div>
  
<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>

<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Name of the extension activity orginised</th>
                <th scope="col">Outcome</th>
                <th scope="col">No. of participants</th>
                <th scope="col">Forum/Committee/Department</th>
                <th scope="col">Colaborating Agency With Whom Activity is Conducted</th>
                <th scope="col"> Attendance</th>
                <th scope="col">Report</th>
                <th scope="col">Geotag Photo 1</th>
                <th scope="col">Geotag Photo 2</th>
                <th scope="col">Non Geotag Photo 1</th>
                <th scope="col">Non Geotag Photo 2</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if (isset($documents)):
            $row = 1;
            foreach ($documents as $doc):
                $book = $doc->Activities_Of_Forum;
                ?>
                <tbody>
                    <?php
                    foreach ($book as $chapter):
                        $cover = $chapter->Upload_Attendance;
                        $content = $chapter->Upload_Report;

                        $geotag1 = $chapter->Geotag_Photo1;
                        $geotag2 = $chapter->Geotag_Photo2;
                         
                        $nongeotag1 = $chapter->NonGeotag_Photo1;
                        $nongeotag2 = $chapter->NonGeotag_Photo2;


                        ?>
                        <tr>
                            <th class="text-center" scope="row">
                                <?= $row++; ?>
                            </th>
                            <td class="text-center">
                                <?= $chapter->Name_Of_The_Extension_Activity_Orginised ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Outcome ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Number_Of_Participants ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Forum ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Activity_Conducted ?>
                            </td>
                            
                            <td class="text-center">
                                <?php if( !empty($cover)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                              
                            </td>
                            <td class="text-center">
                                <?php if( !empty($content)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$content;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>

                            <td class="text-center">
                                <?php if( !empty($geotag1)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                               
                            </td>
                            <td class="text-center">
                                <?php if( !empty($geotag2)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                                
                            </td>

                            <td class="text-center">
                                <?php if( !empty($nongeotag1)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$nongeotag1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                                
                            </td>
                            <td class="text-center">
                                <?php if( !empty($nongeotag2)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$nongeotag2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?> 
                            </td>
                             
                            <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif') ?>">
                                <form action="<?= base_url('deleteActivitiesOfForum') ?>" method="post">
                                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber"
                                        readonly value="<?= $chapter->Activities_Of_Forum_id ?>">
                                    <input class="btn btn-danger" type="submit" value="Delete">
                                </form>
                            </td>
                            
                            <td>
                                <div class="text-center">
                                    <img src="<?= base_url('assets/images/iconsUpdate.gif') ?>">
                                    <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?= $chapter->Activities_Of_Forum_id ?>"
                                        data-bs-whatever="@mdo">Update</button>
                                </div>


                                <div class="modal fade" id="exampleModal<?= $chapter->Activities_Of_Forum_id ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Activities Through Organized Forums</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= base_url('updateActivitiesOfForum') ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="md-4" style="display:none;">
                                                                <label class="form-label">BookAndChapter id : <label
                                                                        style="color: red;">*</label></label>
                                                                <input type="text" class="form-control" name="srnumber" readonly
                                                                    value="<?= $chapter->Activities_Of_Forum_id ?>">
                                                                <span style="display:none;color:red;">Please enter a valid
                                                                    title.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Name of the extension activity orginised : <label style="color: red;">*</label></label>
                                                                <textarea name="activity" id="activity" cols="64" rows="1" class="form-control"> <?= $chapter->Name_Of_The_Extension_Activity_Orginised ?></textarea>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Information.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Outcome: <label style="color: red;">*</label></label><br>
                                                                <textarea name="Outcome" id="Outcome" cols="64" rows="1" class="form-control"> <?= $chapter->Outcome ?></textarea>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Information.</span>
                                                            </div>
                                                                
                                                            <div class="md-4 my-3">
                                                                <label class="form-label">No. of participants : <label style="color: red;">*  </label></label>
                                                                <input id="amount" type="number" class="form-control" name="noParticipants"  value="<?= $chapter->Number_Of_Participants ?>" min='0' required>
                                                                <span id="amountError" style="display:none;color:red;">Please enter a valid Information.</span>
                                                            </div>
                                                            <div class="md-4 my-3">
                                                                    <label class="form-label" for="reason">Forum/Committee/Department:</label>
                                                                    <select id="reason<?= $chapter->Activities_Of_Forum_id ?>" name="forum" class="form-control">
                                                                    <option value="<?= $chapter->Forum ?>" selected hidden><?= $chapter->Forum ?></option>
                                                                    <option value="Cycling Club">Cycling Club</option>
                                                                    <option value="Disha">Disha</option>
                                                                    <option value="Geography Club">Geography Club</option>
                                                                    <option value="IAA">IAA</option>
                                                                    <option value="Janeev">Janeev</option>
                                                                    <option value="Kisan Students' Forum">Kisan Students' Forum</option>
                                                                    <option value="Future bankers forum">Future bankers forum</option>
                                                                    <option value="NCC">NCC</option>
                                                                    <option value="NSS">NSS</option>
                                                                    <option value="Red Cross">Red Cross</option>
                                                                    <option value="Sports">Sports</option>
                                                                    <option value="Treking Club">Treking Club</option>
                                                                    <option value="Other">Other</option>
                                                                    </select>
                                                                    <div class="md-4 my-3" id="other-reason<?= $chapter->Activities_Of_Forum_id ?>" style="display:none;">
                                                                        <textarea class="form-control" id="other-reason-text" name="other" cols="64" rows="1" style="margin-top: 10px;"></textarea>
                                                                    </div>  

                                                                    <script>
                                                                    document.getElementById('reason<?= $chapter->Activities_Of_Forum_id ?>').addEventListener('change', function() {
                                                                        if (this.value === 'other') {
                                                                        document.getElementById('other-reason<?= $chapter->Activities_Of_Forum_id ?>').style.display = 'block';
                                                                        } else {
                                                                        document.getElementById('other-reason<?= $chapter->Activities_Of_Forum_id ?>').style.display = 'none';
                                                                        }
                                                                    });
                                                                    </script>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Colaborating Agency With Whom Activity is Conducted: <label style="color: red;">*</label></label><br>
                                                                <textarea class="form-control" name="conducte" id="Details" rows="1"> <?= $chapter->Activity_Conducted ?></textarea>
                                                                <span style="display:none;color:red;">Please enter a valid year.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name" class="form-label">Upload Attendance : <label style="color: red;">* (.pdf only)</label></label><br>
                                                                <input type="file" class="form-control" name="attendance"  accept=".pdf" >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name" class="form-label">Upload Report : <label style="color: red;">* (.pdf only)</label></label><br>
                                                                <input type="file" class="form-control" name="report"  accept=".pdf" >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name" class="form-label">Upload Geotag : <label style="color: red;">* (.jpg,.jpeg,.png)</label></label><br>
                                                                        <input type="file" class="form-control" name="geotag1"  accept=".jpg,.jpeg,.png" >
                                                                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                            <br>
                                                                        <input type="file" class="form-control" name="geotag2"  accept=".jpg,.jpeg,.png" >
                                                                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name" class="form-label">Upload Non Geotag : <label style="color: red;">(.jpg,.jpeg,.png)</label></label><br>
                                                                        <input type="file" class="form-control" name="NonGeotag1"  accept=".jpg,.jpeg,.png" >
                                                                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                                        <br>
                                                                        <input type="file" class="form-control" name="NonGeotag2"  accept=".jpg,.jpeg,.png" >
                                                                        <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                            </div>
                                                        </div>
                                                    </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button class="btn btn-outline-warning">Update</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('Activities');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
</script>

  <?= $this->endSection();?>