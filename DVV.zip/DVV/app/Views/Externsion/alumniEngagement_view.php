<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Alumni Engagement </h1>
<div class="container-fluid border border-primary-subtle my-4 " style="display:none" id="Alumni">
		<br>  
        <h6>(Alumni contribution in academics and other support system)</h6><br>
		<form class=" g-3 my-3" method="post" action="<?= base_url('saveAlumniEngagement')?>" enctype="multipart/form-data">
             
        <div class="row pt-3 pb-3 mx-2 border border-2">
            <div class="col-md-4 my-3">
                <label class="form-label" for="reason">Activities:</label>
                <select id="reason" name="activities" class="form-control">
                <option value="" disabled selected hidden>--- Select One --- </option>
                <option value="Guest lecture">Guest lecture</option>
                <option value="Career counselling">Career counselling</option>
                <option value="BOS">BOS</option>
                <option value="Placement">Placement</option>
                <option value="Softskill">Softskill</option>
                <option value="Personality development">Personality development</option>
                <option value="Visits">Visits</option>
                <option value="Research">Research</option>
                <option value="NCC">Entrepreneurial Development</option>
                <option value="Other">Other</option>
                </select>
                <div id="other-reason" style="display:none;">
                    <textarea class="form-control" id="other-reason-text" name="other" cols="64" rows="1" style="margin-top: 10px;"></textarea>
                </div>  
  
                <script>
                document.getElementById('reason').addEventListener('change', function() {
                    if (this.value === 'Other') {
                    document.getElementById('other-reason').style.display = 'block';
                    } else {
                    document.getElementById('other-reason').style.display = 'none';
                    }
                });
                </script>
                <br>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Name of Alumnis : <label style="color: red;">*</label></label>
                <input id="Alumni" type="text" class="form-control" name="Alumni" onkeyup="validateRPName()" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>


            <div class="col-md-4 my-3">
                <label class="form-label">Mobile Number: <label style="color: red;">*</label></label>
                <input id="Alumni" type="text" class="form-control" name="mobile" onkeyup="validateRPName()" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Designation of Alumnus : <label style="color: red;">*</label></label>
                <input id="Alumni" type="text" class="form-control" name="designation" onkeyup="validateRPName()" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                <br>
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label">Organization Name : <label style="color: red;">*</label></label>
                <input id="Alumni" type="text" class="form-control" name="oname" onkeyup="validateRPName()" required>
                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
            </div>

            <div class="col-sm-4 my-3">
                <label for="sanction-name">Upload Related Documents: <small>(Attendance/Report)</small>  <label style="color: red;">* (.pdf only)</label></label><br>
                <input type="file" class="form-control" name="rdocument"  accept=".pdf" required>
                <span  style="display:none;color:red;">Please upload the pdf.</span>
            </div>

            <div class="col-md-4 my-3">
                <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.jpg.,jpeg,.png only)</label></label><br>
                Photo 1:<input id="document" type="file" class="form-control my-3" name="photo1"  accept=".jpg.,jpeg,.png" onchange="validateSanction()" required>
                Photo 2:<input id="document" type="file" class="form-control my-3" name="photo2"  accept=".jpg.,jpeg,.png" onchange="validateSanction()" required>
                <span id="documentError" name ="document" style="color:red;"></span>
            </div>

            <div class="col-md-4 my-3">
                <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;">(.jpg.,jpeg,.png only)</label></label><br>
                Photo 1:<input id="document" type="file" class="form-control my-3" name="photo3"  accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                Photo 2:<input id="document" type="file" class="form-control my-3" name="photo4"  accept=".jpg.,jpeg,.png" onchange="validateSanction()">
                <span id="documentError" name ="document" style="color:red;"></span>
            </div>
          
        </div>
        <div class="col-md-12 my-3 text-center">
            <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
		</form>
</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>


<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Activities</th>
                <th scope="col">Name of Alumni</th>
                <th scope="col">Mobile Number</th>
                <th scope="col">Designation</th>
                <th scope="col">Organization Name </th>
                <th scope="col">Upload Related Documents(Attendance/Report) </th>
                <th scope="col">Geotag photos 1</th>
                <th scope="col">Geotag photos 2</th>
                <th scope="col">Non Geotag photos 1</th>
                <th scope="col">Non Geotag photos 2</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if (isset($documents)):
            $row = 1;
            foreach ($documents as $doc):
                $book = $doc->Alumni_Engagement;
                ?>
                <tbody>
                    <?php
                    foreach ($book as $chapter):
                        $doc = $chapter->Upload_Related_Documents;
                        $geotagPhoto1 = $chapter->Upload_Geotag_Photos1;
                        $geotagPhoto2 = $chapter->Upload_Geotag_Photos2;
                        $nonGeotagPhoto1 = $chapter->Upload_Non_Geotag_Photos1;
                        $nonGeotagPhoto2 = $chapter->Upload_Non_Geotag_Photos2;
                        ?>
                        <tr>
                            <th class="text-center" scope="row">
                                <?= $row++; ?>
                            </th>
                            <td class="text-center">
                                <?= $chapter->Activities ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Name_Of_Alumni ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Mobile_Number ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Designation ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Organization_Name ?>
                            </td>
                            <td class="text-center">
                                <?php if( !empty($doc)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$doc;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if( !empty($geotagPhoto1)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotagPhoto1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                                 
                            </td>
                            <td class="text-center">
                                <?php if( !empty($geotagPhoto2)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$geotagPhoto2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if( !empty($nonGeotagPhoto1)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$nonGeotagPhoto1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if( !empty($nonGeotagPhoto2)):?>
                                    <a href="<?= base_url('Userfiles/Teachers/Extension/').$nonGeotagPhoto2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                        <button class="btn btn-outline-success"> Download File </button>
                                    </a>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>

                            <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif') ?>">
                                <form action="<?= base_url('deleteAlumniEngagement') ?>" method="post">
                                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber"
                                        readonly value="<?= $chapter->Alumni_Engagement_id ?>">
                                    <input class="btn btn-danger" type="submit" value="Delete">
                                </form>
                            </td>
                           
                            <td>
                                <div class="text-center">
                                    <img src="<?= base_url('assets/images/iconsUpdate.gif') ?>">
                                    <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?= $chapter->Alumni_Engagement_id ?>"
                                        data-bs-whatever="@mdo">Update</button>
                                </div>


                                <div class="modal fade" id="exampleModal<?= $chapter->Alumni_Engagement_id ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Book And Chapter</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= base_url('updateAlumniEngagement') ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="md-4" style="display:none;">
                                                                <label class="form-label">BookAndChapter id : <label
                                                                        style="color: red;">*</label></label>
                                                                <input type="text" class="form-control" name="srnumber" readonly
                                                                    value="<?= $chapter->Alumni_Engagement_id ?>">
                                                                <span style="display:none;color:red;">Please enter a valid
                                                                    title.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label" for="reason">Activities:</label>
                                                                <select id="reason<?= $chapter->Alumni_Engagement_id ?>" name="activities" class="form-control">
                                                                <option value="<?= $chapter->Activities ?>"><?= $chapter->Activities ?></option>
                                                                <option value="Janeev">Guest lecture</option>
                                                                <option value="Future bankers forum">Career counselling</option>
                                                                <option value="NSS">BOS</option>
                                                                <option value="NCC">Placement</option>
                                                                <option value="Red Cross">Softskill</option>
                                                                <option value="Colaboration">Personality development</option>
                                                                <option value="NCC">Visits</option>
                                                                <option value="NCC">Resarch</option>
                                                                <option value="NCC">Entrepreneurial Development</option>
                                                                <option value="Other">Other</option>
                                                                </select>
                                                                <div id="other-reason<?= $chapter->Alumni_Engagement_id ?>" style="display:none;">
                                                                    <textarea class="form-control" id="other-reason-text" name="other" cols="64" rows="1" style="margin-top: 10px;"><?= $chapter->Activities ?></textarea>
                                                                 </div>  
                                                
                                                                <script>
                                                                document.getElementById('reason<?= $chapter->Alumni_Engagement_id ?>').addEventListener('change', function() {
                                                                    if (this.value === 'Other') {
                                                                    document.getElementById('other-reason<?= $chapter->Alumni_Engagement_id ?>').style.display = 'block';
                                                                    } else {
                                                                    document.getElementById('other-reason<?= $chapter->Alumni_Engagement_id ?>').style.display = 'none';
                                                                    }
                                                                });
                                                                </script>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Name of Alumni : <label style="color: red;">*</label></label>
                                                                <input id="Alumni" type="text" class="form-control" name="Alumni" value="<?= $chapter->Name_Of_Alumni ?>" onkeyup="validateRPName()" required>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Mobile Number: <label style="color: red;">*</label></label>
                                                                <input id="Alumni" type="text" class="form-control" name="mobile" value="<?= $chapter->Mobile_Number ?>" onkeyup="validateRPName()" required>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Designation : <label style="color: red;">*</label></label>
                                                                <input id="Alumni" type="text" class="form-control" name="designation" value="<?= $chapter->Designation ?>" onkeyup="validateRPName()" required>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label class="form-label">Organization Name : <label style="color: red;">*</label></label>
                                                                <input id="Alumni" type="text" class="form-control" name="oname" value="<?= $chapter->Organization_Name ?>" onkeyup="validateRPName()" required>
                                                                <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project Name.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name">Upload Related Documents: <small>(Attendance/Report)</small>  <label style="color: red;">* (.pdf only)</label></label><br>
                                                                <input type="file" class="form-control" name="rdocument"  accept=".pdf"  >
                                                                <span  style="display:none;color:red;">Please upload the pdf.</span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.jpg.,jpeg,.png only)</label></label><br>
                                                                Photo 1:<input id="document" type="file" class="form-control my-3" name="photo1"  accept=".jpg.,jpeg,.png" onchange="validateSanction()"  >
                                                                Photo 2:<input id="document" type="file" class="form-control my-3" name="photo2"  accept=".jpg.,jpeg,.png" onchange="validateSanction()"  >
                                                                <span id="documentError" name ="document" style="color:red;"></span>
                                                            </div>

                                                            <div class="md-4 my-3">
                                                                <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;">* (.jpg.,jpeg,.png only)</label></label><br>
                                                                Photo 1:<input id="document" type="file" class="form-control my-3" name="photo3"  accept=".jpg.,jpeg,.png" onchange="validateSanction()"  >
                                                                Photo 2:<input id="document" type="file" class="form-control my-3" name="photo4"  accept=".jpg.,jpeg,.png" onchange="validateSanction()"  >
                                                                <span id="documentError" name ="document" style="color:red;"></span>
                                                            </div>
          
                                                        </div>
                                                    </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button class="btn btn-outline-warning">Update</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('Alumni');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
        if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
        } else {
        myForm.style.display="none";
        //msg.style.display="block";
        }
    });
</script>

  <?= $this->endSection();?>