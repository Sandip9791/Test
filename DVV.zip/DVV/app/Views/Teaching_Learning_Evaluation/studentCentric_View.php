<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
<h1 class="text-center">Student Centric Methods </h1>
    <div class="container-fluid border border-info-subtle my-4" id="studentCentric">
		<form class="row g-3 my-3" action="<?= base_url('saveStudentCentric')?>" method="POST">

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Student_Centric;
        ?>
        
            <div class="col-sm-7">
                <div class="form-label ms-4">
                    <input class="form-check-input" type="checkbox"  id="checkbox1" value="option1" onclick="myFunction1()">
                    <label class="form-check-label" for="checkbox1">
                        Experiential learning
                    </label>
                    <textarea id="a" cols="150" rows="1" style="display:none" name="experimentalLearning"><?= $book->Experimental_Learning?> </textarea>

                    <script>
                        function myFunction1() {
                        var checkBox = document.getElementById("checkbox1");
                        var text = document.getElementById("text");
                        if (checkBox.checked == true){
                            a.style.display = "block";
                        } else {
                            a.style.display = "none";
                        }
                        }
                    </script>
                </div>
                <div class="form-label ms-4">
                    <input class="form-check-input" type="checkbox"  id="checkbox2" value="option1" onclick="myFunction2()">
                    <label class="form-check-label" for="checkbox2">
                        Participative learning
                    </label>
                    <textarea id="b" cols="150" rows="1" style="display:none" name="participativeLearning"><?= $book->Participative_Learning?></textarea>

                    <script>
                        function myFunction2() {
                        var checkBox = document.getElementById("checkbox2");
                        var text = document.getElementById("text");
                        if (checkBox.checked == true){
                            b.style.display = "block";
                        } else {
                            b.style.display = "none";
                        }
                        }
                    </script>
                </div>
                <div class="form-label ms-4">
                    <input class="form-check-input" type="checkbox"  id="checkbox3" value="option1" onclick="myFunction3()">
                    <label class="form-check-label" for="checkbox3">
                        Problem Solving Methodlogies
                    </label>
                    <textarea id="c" cols="150" rows="1" style="display:none" name="problemSolving"><?= $book->Problem_Solving?></textarea>

                    <script>
                        function myFunction3() {
                        var checkBox = document.getElementById("checkbox3");
                        var text = document.getElementById("text");
                        if (checkBox.checked == true){
                            c.style.display = "block";
                        } else {
                            c.style.display = "none";
                        }
                        }
                    </script>
                </div>
                <div class="form-label ms-4">
                    <input class="form-check-input" type="checkbox"  id="checkbox4" value="option1" onclick="myFunction4()">
                    <label class="form-check-label" for="checkbox4">
                        Use of ICT enable tools
                    </label>
                    <textarea id="d" cols="150" rows="1" style="display:none" name="UseOfICT"><?= $book->Use_Of_ICT?></textarea>

                    <script>
                        function myFunction4() {
                        var checkBox = document.getElementById("checkbox4");
                        var text = document.getElementById("text");
                        if (checkBox.checked == true){
                            d.style.display = "block";
                        } else {
                            d.style.display = "none";
                        }
                        }
                    </script>
                </div>   
            </div>
            
            <div class="col-12 text-center">
                <input type="submit" class="btn btn-outline-primary" value="Submit">
            </div>
        <?php endforeach;?>
        <?php endif;?>
        </form>
	</div>

    

<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Experiential learning</th>
                <th scope="col">Participative learning</th>
                <th scope="col">Problem Solving Methodlogies</th>
                <th scope="col">Use of ICT enable tools</th>>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Student_Centric;
        ?>
        <tbody>
           
            <tr>
                <th class="text-center" scope="row"><?= $row++?></th>
                <td  class="text-center"><?= $book->Experimental_Learning?> </td>
                <td class="text-center"><?= $book->Participative_Learning?> </td>
                <td class="text-center"><?= $book->Problem_Solving?> </td>
                <td class="text-center"> <?= $book->Use_Of_ICT?> </td>
            </tr>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<!-- <script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('studentCentric');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
</script> -->
<?= $this->endSection();?>