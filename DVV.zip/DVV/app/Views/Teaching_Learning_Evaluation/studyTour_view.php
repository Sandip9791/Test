<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Study Tour/ Field Visit</h1>
    <div class="container-fluid border border-primary my-4" style="display:none" id="study">
        <form class="row g-3 my-3" method="post" action="<?= base_url('saveStudyTour')?>" enctype="multipart/form-data">
            <div id="form-container">

                <div class="form-fields">

                    <div class="row mx-2 pt-3 pb-3 border border-2">
                        <div class="col-md-4 my-3">
                            <label class="form-label" for="reason">Name of the program: <label
                                    style="color: red;">*</label></label>
                                    <input id="Alumni" type="text" class="form-control" name="Pname" onkeyup="validateRPName()"
                                required>

                        </div>

                        <div class="col-md-4 my-3">
                            <label class="form-label">Program code: <label style="color: red;">*</label></label>
                            <input id="Alumni" type="text" class="form-control" name="pcode" onkeyup="validateRPName()"
                                required>
                            <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                Name.</span>
                        </div>
                        <div class="col-md-4 my-3">
                            <label class="form-label">Subject/Course code: <label style="color: red;">*</label></label>
                            <input id="Alumni" type="text" class="form-control" name="scode" onkeyup="validateRPName()"
                                required>
                            <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                Name.</span>
                        </div>

                       

                        <div class="col-md-4 my-3">
                            <label class="form-label">Place: <label style="color: red;">*</label></label>
                            <input id="Alumni" type="text" class="form-control" name="place" onkeyup="validateRPName()"
                                required>
                            <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                Name.</span>
                        </div>
                        <div class="col-md-4 my-3">
                            <label for="year-of-award">Date: <label style="color: red;">*</label></label>
                            <input type="date" class="form-control" name="datepicker" id="datepicker"
                                placeholder="dd-mm-yyyy">
                        </div>

                        

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload documents:(Permission letter) <label style="color: red;">*
                                    (.pdf only)</label></label>
                            <input id="document" type="file" class="form-control" name="pdocument" accept=".pdf"
                                onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>

                        

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload documents:(Attendance sheet) <label style="color: red;">*
                                    (.pdf only)</label></label>
                            <input id="document" type="file" class="form-control" name="adocument" accept=".pdf"
                                onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.jeg,.jpeg,.png
                                    only)</label></label><br>
                            
                                <div class="">
                                    <label for="">Photo 1:</label>
                                    <input id="document" type="file" class="form-control" name="document1" accept=".jeg,.jpeg,.png"
                                        onchange="validateSanction()" required>
                                </div>
                                <div class="">
                                    <label for="">Photo 2:</label>
                                    <input id="document" type="file" class="form-control" name="document2" accept=".jeg,.jpeg,.png"
                                        onchange="validateSanction()" required>
                                </div>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;"> (.jeg,.jpeg,.png
                                    only)</label></label><br>
                            
                                <div class="">
                                    <label for="">Photo 1:</label>
                                    <input id="document" type="file" class="form-control" name="document3" accept=".jeg,.jpeg,.png"
                                        onchange="validateSanction()" >
                                </div>
                                <div class="">
                                    <label for="">Photo 2:</label>
                                    <input id="document" type="file" class="form-control" name="document4" accept=".jeg,.jpeg,.png"
                                        onchange="validateSanction()" >
                                </div>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>


                        <script>
                            document.getElementById('reason').addEventListener('change', function () {
                                if (this.value === 'Other') {
                                    document.getElementById('other-reason').style.display = 'block';
                                } else {
                                    document.getElementById('other-reason').style.display = 'none';
                                }
                            });
                        </script>

                    </div>
                </div>
            </div>

            <div class="col-md-12 my-3 text-center">
                <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
        </form>
    </div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Name of the program</th>
                <th scope="col">Program Code</th>
                <th scope="col">Subject/Course code</th>
                <th scope="col">Place</th>
                <th scope="col">Date</th>
                <th scope="col">Permission Letter</th>
                <th scope="col">Attendance Sheet</th>
                <th scope="col">Geotag Photos 1</th>
                <th scope="col">Geotag photos 2</th>
                <th scope="col">Non Geotag Photos 1</th>
                <th scope="col">Non Geotag Photos 2</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
            $row=1;
            foreach($documents as $doc):
                $book=  $doc->Study_Tour;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $pLatter = $chapter->Permission_Letter;
                $aSheet = $chapter->Attendance_Sheet;
 
                $doc1 = $chapter->Geotag_Photos_1;
                $doc2 = $chapter->Geotag_Photos_2;

                $doc3 = $chapter->Non_Geotag_Photos_1;
                $doc4 = $chapter->Non_Geotag_Photos_2;
             ?>
            <tr>
                <th  class="form-control text-center" scope="row"><?= $row++?></th>
                <td class="text-center"><?= $chapter->Name_Program?> </td>
                <td class="text-center"><?= $chapter->Program_Code?> </td>
                <td class="text-center"><?= $chapter->Subject_Code?> </td>
                <td class="text-center"> <?= $chapter->Place?> </td>
                <td class="text-center"> <?= $chapter->Date?> </td>
                <td class="text-center"> 
                    <?php if( !empty($pLatter)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$pLatter;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                    
                </td>
                <td class="text-center">
                    <?php if( !empty($aSheet)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$aSheet;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                    
                </td>
                <td class="text-center">
                    <?php if( !empty($doc1)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc2)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc3)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc3;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc4)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc4;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
               
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br>
                    <form action="<?= base_url('deleteStudyTour')?>" method="post">
                        <input type="text" style="display:none;" name="srnumber" readonly value="<?= $chapter->Study_Tour_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                      <div class="text-center">
                            <img class=" text-center" src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>

                            <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Study_Tour_id?>" data-bs-whatever="@mdo">Update</button>                     
                     </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Study_Tour_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Effective Mentee-Mentor Scheme</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                        <div class="modal-body">
                           <form action="<?= base_url('updateStudyTour')?>" method="post" enctype="multipart/form-data">
                            <div class="row">

                                <div class="md-4" style="display:none;">
                                    <label class="form-label">Mentee id <label style="color: red;">* </label></label>
                                    <input type="text" class="form-control"  name="srnumber" readonly value="<?= $chapter->Study_Tour_id?>"></th>
                                    <span style="display:none;color:red;">Please enter a valid Information.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label" for="reason">Name of the program: <label
                                            style="color: red;">*</label></label>
                                        <input id="Alumni" type="text" class="form-control" name="Pname" value="<?= $chapter->Name_Program?>" onkeyup="validateRPName()"
                                        required>
                               </div>

                                <div class="md-4 my-3">
                                    <label class="form-label">Prgram code: <label style="color: red;">*</label></label>
                                    <input id="Alumni" type="text" class="form-control" name="pcode" value="<?= $chapter->Program_Code?>" onkeyup="validateRPName()"
                                        required>
                                    <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                        Name.</span>
                                </div>
                                <div class="md-4 my-3">
                                    <label class="form-label">Subject/Course code: <label style="color: red;">*</label></label>
                                    <input id="Alumni" type="text" class="form-control" name="scode" value="<?= $chapter->Subject_Code?>" onkeyup="validateRPName()"
                                        required>
                                    <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                        Name.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label">Place: <label style="color: red;">*</label></label>
                                    <input id="Alumni" type="text" class="form-control" name="place" value="<?= $chapter->Place?>" onkeyup="validateRPName()"
                                        required>
                                    <span id="researcherror" style="display:none;color:red;">Please Enter a Valid Project
                                        Name.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label for="year-of-award">Date: <label style="color: red;">*</label></label>
                                    <input type="number" class="form-control" name="datepicker" value="<?= $chapter->Date?>" id="datepicker"
                                        placeholder="dd-mm-yyyy">
                                </div>

                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload documents:(Permission letter) <label style="color: red;">*
                                            (.pdf only)</label></label>
                                    <input id="document" type="file" class="form-control" name="pdocument"  accept=".pdf"
                                        onchange="validateSanction()" >
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>

                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload documents:(Attendance sheet) <label style="color: red;">*
                                            (.pdf only)</label></label>
                                    <input id="document" type="file" class="form-control" name="adocument"  accept=".pdf"
                                        onchange="validateSanction()"  >
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>

                                <div class="md-8 my-3">
                                    <label for="sanction-name">Upload Geotag photos : <label style="color: red;">* (.pdf
                                            only)</label></label><br>
                                    <div class="row">
                                        <div class="md-6 my-3">
                                            <label for="">Photo 1:</label>
                                            <input id="document" type="file" class="form-control" name="document1" accept=".pdf"
                                                onchange="validateSanction()"  >
                                        </div>
                                        <div class="md-6 my-3">
                                            <label for="">Photo 2:</label>
                                            <input id="document" type="file" class="form-control" name="document2" accept=".pdf"
                                                onchange="validateSanction()"  >
                                        </div>
                                    </div>
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>
                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Non Geotag photos : <label style="color: red;"> (.jeg,.jpeg,.png
                                            only)</label></label><br>
                                    
                                        <div  class="md-6 my-3">
                                            <label for="">Photo 1:</label>
                                            <input id="document" type="file" class="form-control" name="document3" accept=".jeg,.jpeg,.png"
                                                onchange="validateSanction()" >
                                        </div>
                                        <div  class="md-6 my-3">
                                            <label for="">Photo 2:</label>
                                            <input id="document" type="file" class="form-control" name="document4" accept=".jeg,.jpeg,.png"
                                                onchange="validateSanction()" >
                                        </div>
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>

                                <script>
                                    document.getElementById('reason<?= $chapter->Study_Tour_id?>').addEventListener('change', function () {
                                        if (this.value === 'Other') {
                                            document.getElementById('other-reason<?= $chapter->Study_Tour_id?>').style.display = 'block';
                                        } else {
                                            document.getElementById('other-reason<?= $chapter->Study_Tour_id?>').style.display = 'none';
                                        }
                                    });
                                </script>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </td> 
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('study');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
</script>

<?= $this->endSection();?>
