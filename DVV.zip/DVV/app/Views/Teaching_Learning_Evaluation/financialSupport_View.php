<?= $this->extend('Layouts/base'); ?>

<?= $this->section("Content"); ?>

<h1 class="text-center my-3">Financial Support</h1>


<div class="container-fluid border border-primary-subtle my-4" style="display:none" id="financialSupport">
    <form class=" g-3 my-3 " action="<?= base_url('saveFinancialSupport') ?>" method="post"
        enctype="multipart/form-data">
        <div class="row mx-2 pt-3 pb-3 border border-2">


            <div class="col-md-6 my-3">
                <label class="form-label" for="reason">Financial Support By :<label style="color: red;">*</label></label>
                <select id="reason" name="supportBy" class="form-control">
                    <option value="" disabled selected hidden>--- Select One ---</option>
                    <option value="Individual teachers">Individual teachers</option>
                    <option value="NGO">NGO</option>
                    <option value="Industry">Industry</option>
                    <option value="Philanthropist">Philanthropist</option>
                    <option value="other">Other</option>
                </select>


                <script>
                    document.getElementById('reason').addEventListener('change', function () {
                        let supportField = document.getElementById('support');
                        if(this.value === 'Individual teachers' || 
                           this.value === 'NGO' ||
                           this.value === 'Industry' ||
                           this.value === 'Philanthropist'||
                           this.value === 'other'){
                            supportField.disabled = false;
                           }
                        else{
                            supportField.disabled = true;
                        }
                        if (this.value === 'other') {
                            document.getElementById('other-reason').style.display = 'block';
                        }
                        else {
                            document.getElementById('other-reason').style.display = 'none';
                        }
                    });
                </script>
                 
            </div>
            <div id="other-reason" style="display:none;" class="col-md-6 my-3"> 
                <label class="form-label" for="Student name">Other :<label style="color: red;">*</label></label>
                <input type="text" class="form-control" id="other-reason-text" name="other">
            </div>

            <div class="col-md-4 my-3">
                <label class="form-label" for="reason" >Provided any financial support to any student? <label
                        style="color: red;">*</label></label>
                <select id="support" name="yesno" onclick="show()" class="form-control" disabled>
                    <option disabled selected hidden>--- Select one ---</option>
                    <option  value="Yes" >Yes</option>
                    <option  value="No" >No</option>
                </select>
                 
            </div>


            <div id="anotherForm" style="display:none;">
                <div class="row">
                    <div class="col-md-4 my-3">
                        <label for="Amount">Amount :<label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="Amount" name="amount">
                        
                    </div>
                    <div class="col-md-4 my-3">
                        <label for="Student name">Student name :<label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="Student name" name="studentName">
                    </div>
                    <div class="col-md-4 my-3">
                        <label for="Class">Class :<label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="Class" name="class">
                    </div>
                    <div class="col-md-4 my-3">
                        <label for="Roll no">Roll no :<label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="Roll no" name="rollNo">
                         
                    </div>
                    <div class="col-md-4 my-3">
                        <label for="Purpose">Purpose : <label style="color: red;">*</label></label>
                        <input type="text" class="form-control" id="Purpose" name="purpose">
                    </div>


                    <div class="col-md-4 my-3">
                        <label class="form-label"> Document : <label style="color: red;">*</label></label>
                        <input type="file" class="form-control" name="studentDocument" accept=".pdf">
                    </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label"> Photo : <label style="color: red;"></label></label>
                        <input type="file" class="form-control" name="photograph" accept=".pdf">
                    </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label"> Upload Sanction Letter : <label style="color: red;">*</label></label>
                        <input type="file" class="form-control" name="sanctionLetter" accept=".pdf">
                    </div>
                </div>
            </div>
            <script>

                function show() {
                        var type = document.getElementById("support");
                        if (type.value == "Yes") {
                            document.getElementById("anotherForm").style.display="block";
                        }
                        else {
                            document.getElementById("anotherForm").style.display="none";
                        }
                    }
            </script>

        </div>
        <div class="col-md-12 pt-3 my-3 text-center">

            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </div>

    </form>
</div>


<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>


<div class="container-fluid pb-3">
    <table class="table table-hover table-bordered border border-success border-4 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Financial support by</th>
                <th scope="col">Provided any financial support to any student</th>
                <th scope="col">Amount</th>
                <th scope="col">Student name</th>
                <th scope="col">Class</th>
                <th scope="col">Roll no</th>
                <th scope="col">Purpose</th>
                <th scope="col">Document</th>
                <th scope="col">Photo</th>
                <th scope="col">Sanction Letter</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if (isset($documents)):
            $row = 1;
            foreach ($documents as $doc):
                $book = $doc->Financial_Support_By;
                ?>
                <tbody>
                    <?php
                    foreach ($book as $chapter):
                        $cover = $chapter->Student_Document;
                        $content = $chapter->Photograph;
                        $firstPage = $chapter->Sanction_Letter;
                        ?>
                        <tr>
                            <th class="text-center" scope="row">
                                <?= $row++; ?>
                            </th>
                            <td class="text-center">
                                <?= $chapter->Financial_Support ?>
                            </td>
                            <td class="text-center">
                                <?= $chapter->Financial_Support_to_Any_Student ?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?= $chapter->Amount ?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?= $chapter->Student_Name ?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?= $chapter->Class ?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?= $chapter->Roll_No ?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?= $chapter->Purpose ?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                                <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?php if( !empty($cover)):?>
                                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$cover;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                            <button class="btn btn-outline-success"> Download File </button>
                                        </a>
                                    <?php else:?>
                                        <b> Not Found...</b>
                                    <?php endif;?>
                                      
                                <?php else:?>
                                    <b> Not Found...</b>.
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                               <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?php if( !empty($content)):?>
                                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$content;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                            <button class="btn btn-outline-success"> Download File </button>
                                        </a>
                                    <?php else:?>
                                        <b> Not Found...</b>
                                    <?php endif;?>
                                  
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center">
                               <?php if($chapter->Financial_Support_to_Any_Student === "Yes"):?>
                                    <?php if( !empty($firstPage)):?>
                                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$firstPage;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                                            <button class="btn btn-outline-success"> Download File </button>
                                        </a>
                                    <?php else:?>
                                        <b> Not Found...</b>
                                    <?php endif;?>
                                <?php else:?>
                                    <b> Not Found...</b>
                                <?php endif;?>
                            </td>
                            <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif') ?>"><br>
                                <form action="<?= base_url('deleteFinancialSupport') ?>" method="post">
                                    <input type="text" class="form-control text-center" style="display:none;" name="srnumber"
                                        readonly value="<?= $chapter->Financial_Support_By_id ?>">
                                    <input class="btn btn-danger" type="submit" value="Delete">
                                </form>
                            </td>
                            
                            <td>
                                <div class="text-center">
                                    <img src="<?= base_url('assets/images/iconsUpdate.gif') ?>"><br>
                                    <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal<?= $chapter->Financial_Support_By_id ?>"
                                        data-bs-whatever="@mdo">Update</button>
                                </div>


                                <div class="modal fade" id="exampleModal<?= $chapter->Financial_Support_By_id ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Financial Support By</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= base_url('updateFinancialSupport') ?>" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="md-4" style="display:none;">
                                                                <label class="form-label">BookAndChapter id : <label
                                                                        style="color: red;">*</label></label>
                                                                <input type="text" class="form-control" name="srnumber" readonly
                                                                    value="<?= $chapter->Financial_Support_By_id ?>">
                                                                <span style="display:none;color:red;">Please enter a valid
                                                                    title.</span>
                                                            </div>
                                                            <div class="md-6 my-3">
                                                            <label class="form-label" for="reason">Financial support by:<label style="color: red;">*</label></label>
                                                            <select id="reason<?= $chapter->Financial_Support_By_id ?>" name="supportBy" class="form-control">
                                                                <option value="<?= $chapter->Financial_Support ?>"><?= $chapter->Financial_Support ?></option>
                                                                <option value="Individual teachers">Individual teachers</option>
                                                                <option value="NGO">NGO</option>
                                                                <option value="Industry">Industry</option>
                                                                <option value="Philanthropist">Philanthropist</option>
                                                                <option value="other">Other</option>
                                                            </select>


                                                            <script>
                                                                document.getElementById('reason<?= $chapter->Financial_Support_By_id ?>').addEventListener('change', function () {
                                                                    if (this.value === 'other') {
                                                                        document.getElementById('other-reason<?= $chapter->Financial_Support_By_id ?>').style.display = 'block';
                                                                    }
                                                                    else {
                                                                        document.getElementById('other-reason<?= $chapter->Financial_Support_By_id ?>').style.display = 'none';
                                                                    }
                                                                });
                                                            </script>
                                                        </div>
                                                        <div id="other-reason<?= $chapter->Financial_Support_By_id ?>" style="display:none;" class="md-12 my-3"> 
                                                            <textarea class="form-control" id="other-reason-text" name="other"  style="margin-top: 10px;"><?= $chapter->Financial_Support ?></textarea>
                                                        </div>

                                                        <div class="md-4 my-3">
                                                            <label class="form-label" for="reason">Provided any financial support to any student? <label
                                                                    style="color: red;">*</label></label>
                                                            <select id="<?=  $chapter->Financial_Support_By_id ?>" name="yesno" onclick="show<?=  $chapter->Financial_Support_By_id ?>()" class="form-control">
                                                                <option value="<?= $chapter->Financial_Support_to_Any_Student ?>"><?= $chapter->Financial_Support_to_Any_Student ?></option>
                                                                <?php if($chapter->Financial_Support_to_Any_Student == "Yes"):?>
                                                                    <option value="No" >No</option> 

                                                                <?php else:?>
                                                                    <option value="Yes" >Yes</option>

                                                                <?php endif;?>
                                                            </select>
                                                        </div>

                                                        <script>

                                                            function show<?=  $chapter->Financial_Support_By_id ?>() {
                                                                    var type = document.getElementById("<?= $chapter->Financial_Support_By_id ?>");
                                                                    if (type.value == "Yes") {
                                                                        document.getElementById("anotherForm<?= $chapter->Financial_Support_By_id ?>").style.display="block";
                                                                    }
                                                                    else {
                                                                        document.getElementById("anotherForm<?= $chapter->Financial_Support_By_id ?>").style.display="none";
                                                                    }
                                                                }
                                                         </script>


                                                        <div id="anotherForm<?= $chapter->Financial_Support_By_id ?>" style="display:none;">
                                                            <div class="row">
                                                                <div class="md-4 my-3">
                                                                    <label for="Amount">Amount :<label style="color: red;">*</label></label>
                                                                    <input type="text" class="form-control" id="Amount" name="amount"  value="<?= $chapter->Amount ?>">
                                                                </div>
                                                                <div class="md-4 my-3">
                                                                    <label for="Student name">Student name :<label style="color: red;">*</label></label>
                                                                    <input type="text" class="form-control" id="Student name" name="studentName" 
                                                                       
                                                                            value="<?= $chapter->Student_Name ?>"
                                                                    >
                                                                </div>
                                                                <div class="md-4 my-3">
                                                                    <label for="Class">Class :<label style="color: red;">*</label></label>
                                                                    <input type="text" class="form-control" id="Class" name="class" 
                                                                     
                                                                            value="<?= $chapter->Class ?>"
                                                                     
                                                                    >
                                                                </div>
                                                                <div class="md-4 my-3">
                                                                    <label for="Roll no">Roll no :<label style="color: red;">*</label></label>
                                                                    <input type="text" class="form-control" id="Roll no" name="rollNo" 
                                                                    
                                                                            value="<?= $chapter->Roll_No ?>"
                                                                     
                                                                    >
                                                                </div>
                                                                <div class="md-4 my-3">
                                                                    <label for="Purpose">Purpose : <label style="color: red;">*</label></label>
                                                                    <input type="text" class="form-control" id="Purpose" name="purpose" 
                                                                      
                                                                            value="<?= $chapter->Purpose ?>"

                                                                    > 
                                                                </div>


                                                                <div class="md-4 my-3">
                                                                    <label class="form-label"> Document : <label style="color: red;">*</label></label>
                                                                    <input type="file" class="form-control" name="studentDocument" accept=".pdf" >
                                                                </div>

                                                                <div class="md-4 my-3">
                                                                    <label class="form-label"> Photo : <label style="color: red;"></label></label>
                                                                    <input type="file" class="form-control" name="photograph" accept=".pdf">
                                                                </div>

                                                                <div class="md-4 my-3">
                                                                    <label class="form-label"> Upload Sanction Letter : <label style="color: red;">*</label></label>
                                                                    <input type="file" class="form-control" name="sanctionLetter" accept=".pdf">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button class="btn btn-outline-warning">Update</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
    const showFormCheckbox = document.getElementById('btncheck1');
    const myForm = document.getElementById('financialSupport');
    //const msg = document.getElementById('msg');

    showFormCheckbox.addEventListener('change', function() {
        if (this.checked) {
        myForm.style.display="block";
        //msg.style.display="none";
        } else {
        myForm.style.display="none";
        //msg.style.display="block";
        }
    });
</script>


<?= $this->endSection(); ?>