<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>

<h1 class="text-center my-3">Experiential Learning </h1>

<div class="container-fluid border border-primary my-4" style="display:none" id="Experiential">
    <form class="row g-3 my-3" method="post" action="<?= base_url('saveExperientialLearning')?>"
        enctype="multipart/form-data">
        <div id="form-container">

            <div class="form-fields">

                <div class="row mx-2 pt-3 pb-3 border border-2">

                    <div class="col-md-4 my-3">
                        <label class="form-label">Experience In  : <label style="color: red;">*</label></label>
                        <select name="fields" id="fields" onclick="showOther()" class="form-control" required>
                            <option disabled selected hidden>--- Select one ---</option>
                            <option value="Field Project">Field Project</option>
                            <option value="Research Project">Research Project</option>
                            <option value="Internship">Internship</option>
                            <option value="Other">Other</option>
                        </select>
                        

                        <script>
                            function showOther() {
                                var type = document.getElementById("fields");
                                            if (type.value == "Other") 
                                            {
                                                document.getElementById("other").style.display="block";
                                            }
                                            else 
                                            {
                                                document.getElementById("other").style.display="none";
                                            } 
                                        }
                                    </script>
                                    <br>
                    </div>

                    <div class="col-md-4 my-3" id="other" style="display:none;">
                            <label class="form-label">Other: <label style="color: red;">*</label></label>
                            <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOther()">
                            <span id="otherErrror" style="display:none;color:red;"></span>
                        </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label">Course of Experience : <label style="color: red;">*</label></label>
                        <select name="course" id="fields" class="form-control" required>
                            <option disabled selected hidden>--- Select one ---</option>
                            <option value="UG">UG</option>
                            <option value="PG">PG</option>
                         
                        </select>
                    </div>
                    
                 

                    <div class="col-md-4 my-3">
                        <label class="form-label">Course Code : <label style="color: red;">* </label></label>
                        <input type="text" class="form-control" name="pcode" required>
                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                    </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label">Course Name : <label style="color: red;">* </label></label>
                        <input type="text" class="form-control" name="pname" required>
                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                    </div>

                    

                    <div class="col-md-4 my-3">
                        <label class="form-label">No. of Student : <label style="color: red;">* </label></label>
                        <input type="number" class="form-control" name="snumber" min='0' required>
                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                    </div>

                    <div class="col-md-4 my-3">
                        <label class="form-label">Upload link to the syllabus of the course from college website :
                            <label style="color: red;">* </label></label>
                        <input type="url" class="form-control" name="link">
                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                    </div>

                     

                    <div class="col-sm-12 my-3">
                        <label for="sanction-name">Upload Certificate : <label style="color: red;">* (.pdf
                                only)</label></label><br>

                        <div class="row">
                            <div class="col-sm-4 my-3">

                                <input type="file" class="form-control" name="document1" accept=".pdf"><br>
                                <span style="display:none;color:red;">Please upload the pdf.</span>
                            </div>

                            <div class="col-sm-4 my-3">

                                <input type="file" class="form-control" name="document2" accept=".pdf"><br>
                                <span style="display:none;color:red;">Please upload the pdf.</span>
                            </div>

                            <div class="col-sm-4 my-3">

                                <input type="file" class="form-control" name="document3" accept=".pdf"><br>
                                <span style="display:none;color:red;">Please upload the pdf.</span>
                            </div>

                            <div class="col-sm-4 my-3">

                                <input type="file" class="form-control" name="document4" accept=".pdf"><br>
                                <span style="display:none;color:red;">Please upload the pdf.</span>
                            </div>

                            <div class="col-sm-4 my-3">

                                <input type="file" class="form-control" name="document5" accept=".pdf"><br>
                                <span style="display:none;color:red;">Please upload the pdf.</span>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="col-md-12 text-center">
            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </div>
    </form>

</div>

<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>

<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Field of Experiance</th>
                <th scope="col">Course of Experiance</th>
                <th scope="col">Program Code</th>
                <th scope="col">Program Name </th>
                <th scope="col">Upload link to the syllabus of the course from college website</th>
                <th scope="col">No. of Student</th>
                <th scope="col">Report 1</th>
                <th scope="col">Report 2</th>
                <th scope="col">Report 3</th>
                <th scope="col">Report 4</th>
                <th scope="col">Report 5</th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
             $row=1;
            foreach($documents as $doc):
                $book=  $doc->Expetiential_Learning;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
              
                
                $doc1 = $chapter->Documents_1;
                $doc2 = $chapter->Documents_2;
                $doc3 = $chapter->Documents_3;
                $doc4 = $chapter->Documents_4;
                $doc5 = $chapter->Documents_5;
             ?>
            <tr >
                <th class="text-center" scope="row"><?= $row++?></th>
                <td class="text-center" ><?= $chapter->Field_of_Experiance?> </td>
                <td class="text-center"><?= $chapter->Course_of_Experiance?> </td>
                <td class="text-center"><?= $chapter->Program_Code?> </td>
                <td class="text-center"> <?= $chapter->Program_Name?> </td>
                <td class="text-center"> <?= $chapter->Syllabus_Link?> </td>
                <td class="text-center"> <?= $chapter->Number_Students?> </td>
                <td class="text-center"> 
                    <?php if( !empty($doc1)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc1;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                      
                </td>
                <td class="text-center">
                    <?php if( !empty($doc2)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc2;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?> 
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc3)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc3;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                    
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc4)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc4;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
                <td class="text-center"> 
                    <?php if( !empty($doc5)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$doc5;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>
               
                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" >
                    <form action="<?= base_url('deleteExperientialLearning')?>" method="post">
                        <input type="text" class="form-control text-center" style="display:none;" name="srnumber" readonly value="<?= $chapter->Expetiential_Learning_id?>">  
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                     
                <td> 
                    <div class="text-center">
                     <img  src="<?= base_url('assets/images/iconsUpdate.gif')?>" >  
                     <button type="button" class=" text-center btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Expetiential_Learning_id?>" data-bs-whatever="@mdo">Update</button>

                    </div>
                    <div class="modal fade" id="exampleModal<?= $chapter->Expetiential_Learning_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Experiential Learning</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <form action="<?= base_url('updateExperientialLearning')?>" method="post" enctype="multipart/form-data">
                            <div class="row">

                                    <div class="md-4" style="display:none;">
                                        <label class="form-label">Expetiential Learning id : <label style="color: red;">* </label></label>
                                        <input type="text" class="form-control"  name="srnumber" readonly value="<?= $chapter->Expetiential_Learning_id?>"></th>
                                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Experience In  : <label style="color: red;">*</label></label>
                                        <select name="fields" id="fields" onclick="showOther<?= $chapter->Expetiential_Learning_id?>()" class="form-control" required>
                                            <option disabled selected hidden value="<?= $chapter->Field_of_Experiance?>"><?= $chapter->Field_of_Experiance?></option>
                                            <option value="Field Project">Field Project</option>
                                            <option value="Research Project">Research Project</option>
                                            <option value="Internship">Internship</option>
                                            <option value="Other">Other</option>
                                        </select>
                                        <div class="md-4 my-3" id="other<?= $chapter->Expetiential_Learning_id?>" style="display:none;">
                                            <label class="form-label">Other: <label style="color: red;">*</label></label>
                                            <input id="otherJournal" type="text" class="form-control"  name="other" autocomplete="off" oninput="validateOther()">
                                            <span id="otherErrror" style="display:none;color:red;"></span>
                                        </div>

                                        <script>
                                            function showOther<?= $chapter->Expetiential_Learning_id?>() {
                                                var type = document.getElementById("fields<?= $chapter->Expetiential_Learning_id?>");
                                                            if (type.value == "Other") 
                                                            {
                                                                document.getElementById("other<?= $chapter->Expetiential_Learning_id?>").style.display="block";
                                                            }
                                                            else 
                                                            {
                                                                document.getElementById("other<?= $chapter->Expetiential_Learning_id?>").style.display="none";
                                                            } 
                                                        }
                                                    </script>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Course of Experiance : <label style="color: red;">*</label></label>
                                        <select name="course" id="fields" class="form-control" required>
                                            <option value="<?= $chapter->Course_of_Experiance?>"><?= $chapter->Course_of_Experiance?></option>
                                            <option value="UG">UG</option>
                                            <option value="PG">PG</option>
                                        
                                        </select>
                                    </div>
                                    

                                    <div class="md-4 my-3">
                                        <label class="form-label">Course Code : <label style="color: red;">* </label></label>
                                        <input type="text" class="form-control" name="pcode" value="<?= $chapter->Program_Code?>"   >
                                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Course Name : <label style="color: red;">* </label></label>
                                        <input type="text" class="form-control" name="pname" value="<?= $chapter->Program_Name?>"  >
                                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                                    </div>

                                  
                                    <div class="md-4 my-3">
                                        <label class="form-label">No. of Student : <label style="color: red;">* </label></label>
                                        <input type="number" class="form-control" name="snumber" value="<?= $chapter->Number_Students?>" min='0'  >
                                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label class="form-label">Upload link to the syllabus of the course from college website :
                                            <label style="color: red;">* </label></label>
                                        <input type="url" class="form-control" name="link" value="<?= $chapter->Syllabus_Link?>"  >
                                        <span style="display:none;color:red;">Please enter a valid Information.</span>
                                    </div>

                                    <div class="md-4 my-3">
                                        <label for="sanction-name">Upload Certificate : <label style="color: red;">* (.pdf
                                                only)</label></label><br>

                                        <div class="row">
                                            <div class="md-4 my-3">

                                                <input type="file" class="form-control" name="document1" accept=".pdf"  ><br>
                                                <span style="display:none;color:red;">Please upload the pdf.</span>
                                            </div>

                                            <div class="md-4 my-3">

                                                <input type="file" class="form-control" name="document2" accept=".pdf"  ><br>
                                                <span style="display:none;color:red;">Please upload the pdf.</span>
                                            </div>

                                            <div class="md-4 my-3">

                                                <input type="file" class="form-control" name="document3" accept=".pdf"  ><br>
                                                <span style="display:none;color:red;">Please upload the pdf.</span>
                                            </div>

                                            <div class="md-4 my-3">

                                                <input type="file" class="form-control" name="document4" accept=".pdf"  ><br>
                                                <span style="display:none;color:red;">Please upload the pdf.</span>
                                            </div>

                                            <div class="md-4 my-3">
                                                <input type="file" class="form-control" name="document5" accept=".pdf"  ><br>
                                                <span style="display:none;color:red;">Please upload the pdf.</span>
                                            </div>

                                    </div>

                                    </div>
                            </div>
                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
               </td>
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('Experiential');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
</script>
<script src="<?php echo base_url('assets/js/Teacher_Learning_Evaluation/experientialLearning_view.js'); ?>"></script>

<?= $this->endSection();?>
