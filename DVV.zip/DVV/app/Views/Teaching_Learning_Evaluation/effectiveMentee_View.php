<?= $this->extend('Layouts/base');?>

<?= $this->section("Content");?>
   
<h1 class="text-center my-3">Effective Mentee-Mentor Scheme</h1>
    <div class="container-fluid border border-info-subtle my-4" style="display:none;" id="Mentee">
        <form class="row g-3 my-3" id="dynamic-form" action="<?= base_url('saveMentee')?>" method="post"
            enctype="multipart/form-data">
            <div id="form-container">

                <div class="form-fields">

                    <div class="row mx-2 pt-3 pb-3 border border-2">

                        <div class="col-md-4 my-3">
                            <label class="form-label">Class of mentees : <label style="color: red;">*</label></label>
                            <input type="text" class="form-control" name="date" required>
                            <span style="display:none;color:red;">Please enter a valid year.</span>
                            <br>
                        </div>

                        <div class="col-md-4 my-3">
                            <label class="form-label">Number of mentee allocated : <label
                                    style="color: red;">*</label></label>
                            <input id="amount" type="number" class="form-control" name="mentees" min='0' required>
                            <span id="amountError" style="display:none;color:red;">Please enter a valid Amount.</span>
                        </div>

                        <div class="col-sm-4 my-3">
                            <label class="col-form-label col-sm-2 pt-0">Type : <label
                                    style="color: red;">*</label></label>
                            <div class="col-sm-7">
                                <div class="form-label-1">
                                    <input class="form-check-input" type="checkbox" id="checkbox1" value="option1"
                                        onclick="myFunction1()">
                                    <label class="form-check-label" for="checkbox1">
                                        Academic
                                    </label>
                                    <textarea id="text3" cols="30" rows="3" style="display:none"
                                        name="academic" placeholder="Comment"></textarea>

                                    <script>
                                        function myFunction1() {
                                            var checkBox = document.getElementById("checkbox1");
                                            var text = document.getElementById("text3");
                                            if (checkBox.checked == true) {
                                                text.style.display = "block";
                                            } else {
                                                text.style.display = "none";
                                            }
                                        }
                                    </script>
                                </div>
                                <div class="form-label-1">
                                    <input class="form-check-input" type="checkbox" id="checkbox2" value="option1"
                                        onclick="myFunction2()">
                                    <label class="form-check-label" for="checkbox2">
                                        Psycological
                                    </label>
                                    <textarea id="text4" cols="30" rows="3" style="display:none"
                                        name="pyschological" placeholder="Comment"></textarea>

                                    <script>
                                        function myFunction2() {
                                            var checkBox = document.getElementById("checkbox2");
                                            var text = document.getElementById("text4");
                                            if (checkBox.checked == true) {
                                                text.style.display = "block";
                                            } else {
                                                text.style.display = "none";
                                            }
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 my-3">
                            <label for="sanction-name">Upload Document : <label style="color: red;">* (.pdf
                                    only)</label></label>
                            <input type="file" class="form-control" name="doc" accept=".pdf"
                                onchange="validateSanction()" required>
                            <span id="documentError" name="document" style="color:red;"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 my-3 text-center">
                <button type="submit" class="btn btn-outline-primary">Submit</button>
            </div>
        </form>
    </div>


<div class="btn-group pb-1 ps-2" role="group" aria-label="Basic checkbox toggle button group">
    <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
    <label class="btn btn-success" for="btncheck1">Add Data</label>
</div>
   
<div class="container-fluid pb-3" >
    <table class="table table-hover table-bordered border border-success border-3 ">
        <thead class="table-success text-center">
            <tr>
                <th scope="col">Sr.No</th>
                <th scope="col">Class of mentees</th>
                <th scope="col">Number of mentee allocated</th>
                <th scope="col">Academic</th>
                <th scope="col">Psycological</th>
                <th scope="col">Uploaded Document </th>
                <th scope="col">Delete</th>
                <th scope="col">Update</th>
            </tr>
        </thead>

        <?php if(isset($documents)):
              $row=1;
            foreach($documents as $doc):
                $book=  $doc->Effective_Mentee_Mentor;
        ?>
        <tbody >
            <?php
                foreach($book as $chapter):
                $Document= $chapter->Document;
            ?>
            <tr>
                <th class="form-control text-center" scope="row"><?= $row++?></th>
                 <td class="text-center"><?= $chapter->Class_Of_Mentee?> </td>
                <td class="text-center"> <?= $chapter->Number_Of_Mentee_Allocated?> </td>
                <td class="text-center"> <?= $chapter->Academic?> </td>
                <td class="text-center"> <?= $chapter->Pyschological?> </td>
                <td class="text-center">
                    <?php if( !empty($Document)):?>
                        <a href="<?= base_url('Userfiles/Teachers/Teaching_Learning/').$Document;?>" download><img src="<?= base_url('assets/images/iconspdf.gif')?>" width="33px"> <br> 
                            <button class="btn btn-outline-success"> Download File </button>
                        </a>
                    <?php else:?>
                        <b> Not Found...</b>
                    <?php endif;?>
                     
                </td>

                <td class="text-center"> <img src="<?= base_url('assets/images/iconsDelete.gif')?>" ><br> 
                    <form action="<?= base_url('deleteMentee')?>" method="post">
                        <input type="text" class="form-control text-center" name="srnumber" style="display:none;" readonly value="<?= $chapter->Mentee_id?>">
                        <input class="btn btn-danger" type="submit" value="Delete">
                    </form>
                </td> 
                      
                <td> 
                      <div class="text-center">
                            <img class=" text-center" src="<?= base_url('assets/images/iconsUpdate.gif')?>" > <br>

                            <button type="button" class=" text-center btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $chapter->Mentee_id?>" data-bs-whatever="@mdo">Update</button>                     
                     </div>
                 

                    <div class="modal fade" id="exampleModal<?= $chapter->Mentee_id?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable  ">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Effective Mentee-Mentor Scheme</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                        <div class="modal-body">
                          <form action="<?= base_url('updateMentee')?>" method="post" enctype="multipart/form-data">
                            <div class="row">

                                <div class="md-4" style="display:none;">
                                    <label class="form-label">Mentee id <label style="color: red;">* </label></label>
                                    <input type="text" class="form-control"  name="srnumber" readonly value="<?= $chapter->Mentee_id?>"></th>
                                    <span style="display:none;color:red;">Please enter a valid Information.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label">Class of mentees : <label style="color: red;">*</label></label>
                                    <input type="text" class="form-control" name="date" value="<?= $chapter->Class_Of_Mentee?>" required>
                                    <span style="display:none;color:red;">Please enter a valid year.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="form-label">Number of mentee allocated : <label
                                            style="color: red;">*</label></label>
                                    <input id="amount" type="number" class="form-control" name="mentees" value="<?= $chapter->Number_Of_Mentee_Allocated?>" min='0' required>
                                    <span id="amountError" style="display:none;color:red;">Please enter a valid Amount.</span>
                                </div>

                                <div class="md-4 my-3">
                                    <label class="col-form-label col-sm-2 pt-0">Type : <label
                                            style="color: red;">*</label></label>
                                    <div class="md-4 my-3">
                                        <div class="form-label-1">
                                            <input class="form-check-input" type="checkbox" id="checkbox3" value="option1"
                                                onclick="myFunction3()">
                                            <label class="form-check-label" for="checkbox1">
                                                Academic
                                            </label>
                                            <textarea id="text1" cols="30" rows="3" style="display:none"
                                                name="academic"  placeholder="Comment"><?= $chapter->Academic?></textarea>

                                            <script>
                                                function myFunction3() {
                                                    var checkBox = document.getElementById("checkbox3");
                                                    var text1 = document.getElementById("text1");
                                                    if (checkBox.checked == true) {
                                                        text1.style.display = "block";
                                                    } else {
                                                        text1.style.display = "none";
                                                    }
                                                }
                                            </script>
                                        </div>
                                        <div class="form-label-1">
                                            <input class="form-check-input" type="checkbox" id="checkbox4" value="option1"
                                                onclick="myFunction4()">
                                            <label class="form-check-label" for="checkbox2">
                                                Psycological
                                            </label>
                                            <textarea id="text" cols="40" rows="3" style="display:none"
                                                name="pyschological"  placeholder="Comment"><?= $chapter->Pyschological?></textarea>

                                            <script>
                                                function myFunction4() {
                                                    var checkBox = document.getElementById("checkbox4");
                                                    var text2 = document.getElementById("text");
                                                    if (checkBox.checked == true) {
                                                        text2.style.display = "block";
                                                    } else {
                                                        text2.style.display = "none";
                                                    }
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>

                                <div class="md-4 my-3">
                                    <label for="sanction-name">Upload Document: <label style="color: red;">* (.pdf
                                            only)</label></label>
                                    <input type="file" class="form-control" name="doc" accept=".pdf"
                                        onchange="validateSanction()" >
                                    <span id="documentError" name="document" style="color:red;"></span>
                                </div>

                            </div>
                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-outline-warning">Update</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </td>            
            </tr>
            <?php endforeach;?>
        </tbody>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</div>

<script>
        const showFormCheckbox = document.getElementById('btncheck1');
        const myForm = document.getElementById('Mentee');
        //const msg = document.getElementById('msg');

        showFormCheckbox.addEventListener('change', function() {
          if (this.checked) {
            myForm.style.display="block";
            //msg.style.display="none";
          } else {
            myForm.style.display="none";
            //msg.style.display="block";
          }
        });
</script>

<?= $this->endSection();?>
