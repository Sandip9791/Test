<?php

namespace App\Controllers;

use App\Models\IQAC_Model;
use App\Controllers\SaveUplodedFile_HOD;
use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;

class IQAC extends BaseController
{
    public $test, $save;

    public function __construct()
    {
        $this->test = new IQAC_Model;
        $this->save = new SaveUplodedFile_HOD();
        $this->id = new UniqueID();
    }

    public function iqac_2_3_3()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/2_3_3_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_2_3_3()
    {
        if($this->request->getMethod()== 'post')
        {
            $Academic = $this->request->getPost('Academic');
            $Calendar = $_FILES['Calendar'];

            $document =
            [
               "IQAC_id"=>"1",
               "Preparation_and_adherence_of_Academic_Calendar"=>$Academic,
               "Calendar"=>
               [
                'Name' => $Calendar['name'],
                'Type' => $Calendar['type'],
                'Content' => new Binary(file_get_contents($Calendar['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_2_3_3'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_2_3_3') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_2_3_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


   // -----------------------------------------------------------------------------------------------------------

   public function iqac_4_1_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/4_1_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_4_1_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $adequacy = $this->request->getPost('adequacy');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe_the_adequacy_of_facilities"=>$adequacy,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_4_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_4_1_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_4_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    

    //---------------------------------------------------------------------------------------


    public function iqac_4_4_2()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/4_4_2_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_4_4_2()
    {
        if($this->request->getMethod()== 'post')
        {
            $procedures = $this->request->getPost('procedures');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe_policy_details_of_systems_and_procedures"=>$procedures,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_4_4_2'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_4_4_2') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_4_4_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    //--------------------------------------------------------------------------------------------


    public function iqac_6_1_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_1_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_6_1_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Description = $this->request->getPost('Description');
            $Committeedoc = $_FILES['Committeedoc'];
            $Relaventdoc1 = $_FILES['Relaventdoc1'];
            $Relaventdoc2 = $_FILES['Relaventdoc2'];

            $document =
            [
               "IQAC_id"=>"1",
               "Description"=>$Description,
               "Committeedoc"=>
               [
                'Name' => $Committeedoc['name'],
                'Type' => $Committeedoc['type'],
                'Content' => new Binary(file_get_contents($Committeedoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Relaventdoc1"=>
               [
                'Name' => $Relaventdoc1['name'],
                'Type' => $Relaventdoc1['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc1['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Relaventdoc2"=>
               [
                'Name' => $Relaventdoc2['name'],
                'Type' => $Relaventdoc2['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc2['tmp_name']), Binary::TYPE_GENERIC),
               ],
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_1_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    //---------------------------------------------------------------------------------------

    
        public function iqac_6_2_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_2_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
        public function save_IQAC_6_2_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Description = $this->request->getPost('Description');
            $IPPlandoc = $_FILES['IPPlandoc'];
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Description"=>$Description,
               "IPPlandoc"=>
               [
                'Name' => $IPPlandoc['name'],
                'Type' => $IPPlandoc['type'],
                'Content' => new Binary(file_get_contents($IPPlandoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Relaventdoc1"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_2_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_2_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_2_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    //-----------------------------------------------------------------------------------------

    // public function iqac_6_2_2()
    // {
    //     $session = \Config\Services::session();

    //     if ($session->has('iqac_user')) 
    //     {
    //         //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

    //          //Save File
    //         //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
    //         //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

    //         return view("IQAC/6_2_2_view");
    //     } 
    //     else 
    //     {
    //         $url = base_url();
    //         echo "<script>
    //         alert('Your Session Is Close, Please Login !!!');
    //         window.location.href ='$url';
    //         </script>";
    //     }
    // }

    // public function save_IQAC_6_2_2()
    // {
    //     if($this->request->getMethod()== 'post')
    //     {
    //         $Administration = $this->request->getPost('Administration');

    //         $Description = $this->request->getPost('Description');
    //         $Administration_photo = $_FILES['Administration_photo'];
    //         $Relaventdoc = $_FILES['Relaventdoc'];

    //         if(isset($Administration) && !empty($Administration))
    //         {
    //             $Administration_photo = $_FILES['Administration_photo'];
    //             $document = 
    //             [
                    
    //             ]
    //         }
    //         else
    //         {

    //         }

    //         $document =
    //         [
    //            "IQAC_id"=>"1",
    //            "Description"=>$Description,
    //            "IPPlandoc"=>
    //            [
    //             'Name' => $IPPlandoc['name'],
    //             'Type' => $IPPlandoc['type'],
    //             'Content' => new Binary(file_get_contents($IPPlandoc['tmp_name']), Binary::TYPE_GENERIC),
    //            ],
    //            "Relaventdoc1"=>
    //            [
    //             'Name' => $Relaventdoc['name'],
    //             'Type' => $Relaventdoc['type'],
    //             'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
    //            ]
    //         ];


    //         if (isset($document) && !empty($document)) 
    //         {
    //             $hod = array('$set' =>['IQAC_6_2_2'=>$document]);
    
    //             if ($this->test->saveData($hod)) 
    //             {
    //                 $url = base_url('iqac_6_2_2') ;
    //                 echo "<script>
    //                    alert('Your Profile Is Updated Successfully...');
    //                    window.location.href ='$url';
    //                  </script>";
    //             } 
    //             else 
    //             {
    //                 $url = base_url('iqac_6_2_2');
    //                 echo "<script>
    //                         alert('Your Request Is Not Process, Please Refill The Form !!!');
    //                         window.location.href ='$url';
    //                     </script>";
    //             }
    //         } 
    //         else 
    //         {
    //             $url = base_url('iqacProf') ;
    //             echo "<script>
    //                 alert('Your Request Is Not Process, Please Refill The Form !!!');
    //                 window.location.href ='$url';
    //             </script>";
    //         }
    //     }
    //     else
    //     {
    //         $url=base_url('iqacProf');
    //         echo "<script>
    //             alert('Unable To Process Your Request Please Try Again Some Time !!!');
    //             window.location.href ='$url';
    //         </script>";
    //     }
    // }

    // //----------------------------------------------------------------------------------------

    
    public function iqac_6_3_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_3_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_6_3_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Description = $this->request->getPost('Description');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Description"=>$Description,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_3_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_3_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_3_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //----------------------------------------------------------------------------------------


    public function iqac_6_3_2()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_3_2_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_6_3_2()
    {
        if($this->request->getMethod()== 'post')
        {
            // $Description = $this->request->getPost('Description');
            $policydoc = $_FILES['policydoc'];
            $auditdoc = $_FILES['auditdoc'];
            $annualRdoc = $_FILES['annualRdoc'];

            $document =
            [
               "IQAC_id"=>"1",
            //    "Description"=>$Description,
               "policydoc"=>
               [
                'Name' => $policydoc['name'],
                'Type' => $policydoc['type'],
                'Content' => new Binary(file_get_contents($policydoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "auditdoc"=>
               [
                'Name' => $auditdoc['name'],
                'Type' => $auditdoc['type'],
                'Content' => new Binary(file_get_contents($auditdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "annualRdoc"=>
               [
                'Name' => $annualRdoc['name'],
                'Type' => $annualRdoc['type'],
                'Content' => new Binary(file_get_contents($annualRdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_3_2'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_3_2') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_3_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //--------------------------------------------------------------------------------------

    public function iqac_6_4_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_4_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_6_4_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Describe = $this->request->getPost('Describe');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe"=>$Describe,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_4_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_4_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_4_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


    //--------------------------------------------------------------------------------------------


    public function iqac_6_4_3()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_4_3_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_IQAC_6_4_3()
    {
        if($this->request->getMethod()== 'post')
        {
            $Enumerate = $this->request->getPost('Enumerate');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Enumerate"=>$Enumerate,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_4_3'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_4_3') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_4_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //---------------------------------------------------------------------------------------

    public function iqac_6_5_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_5_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_6_5_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Describe = $this->request->getPost('Describe');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe"=>$Describe,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_5_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_5_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_5_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //-------------------------------------------------------------------------------------------


    public function iqac_6_5_2()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_5_2_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_6_5_2()
    {
        if($this->request->getMethod()== 'post')
        {
            $Describe = $this->request->getPost('Describe');
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe"=>$Describe,
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_5_2'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_5_2') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_5_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //-------------------------------------------------------------------------------------------


    public function iqac_6_5_3()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/6_5_3_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_6_5_3()
    {
        if($this->request->getMethod()== 'post')
        {
            // $Description = $this->request->getPost('Description');
            $IQACdoc = $_FILES['IQACdoc'];
            $NIRFdoc = $_FILES['NIRFdoc'];
            $AAAMdoc = $_FILES['AAAMdoc'];
            $AAARdoc = $_FILES['AAARdoc'];
            $CQIdoc = $_FILES['CQIdoc'];
            $QAReportdoc = $_FILES['QAReportdoc'];
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
            //    "Description"=>$Description,
               "IQACdoc"=>
               [
                'Name' => $IQACdoc['name'],
                'Type' => $IQACdoc['type'],
                'Content' => new Binary(file_get_contents($IQACdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "NIRFdoc"=>
               [
                'Name' => $NIRFdoc['name'],
                'Type' => $NIRFdoc['type'],
                'Content' => new Binary(file_get_contents($NIRFdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "AAAMdoc"=>
               [
                'Name' => $AAAMdoc['name'],
                'Type' => $AAAMdoc['type'],
                'Content' => new Binary(file_get_contents($AAAMdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "AAARdoc"=>
               [
                'Name' => $AAARdoc['name'],
                'Type' => $AAARdoc['type'],
                'Content' => new Binary(file_get_contents($AAARdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "CQIdoc"=>
               [
                'Name' => $CQIdoc['name'],
                'Type' => $CQIdoc['type'],
                'Content' => new Binary(file_get_contents($CQIdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "QAReportdoc"=>
               [
                'Name' => $QAReportdoc['name'],
                'Type' => $QAReportdoc['type'],
                'Content' => new Binary(file_get_contents($QAReportdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_6_5_3'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_6_5_3') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_6_5_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //------------------------------------------------------------------------------------------


    public function iqac_7_1_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/7_1_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_7_1_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Describe = $this->request->getPost('Describe');
            $GAuditdoc = $_FILES['GAuditdoc'];
            $Relaventdoc = $_FILES['Relaventdoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe"=>$Describe,
               "GAuditdoc"=>
               [
                'Name' => $GAuditdoc['name'],
                'Type' => $GAuditdoc['type'],
                'Content' => new Binary(file_get_contents($GAuditdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Relaventdoc"=>
               [
                'Name' => $Relaventdoc['name'],
                'Type' => $Relaventdoc['type'],
                'Content' => new Binary(file_get_contents($Relaventdoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_7_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_7_1_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_7_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //----------------------------------------------------------------------------------------


    public function iqac_7_1_6()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/7_1_6_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_7_1_6()
    {
        if($this->request->getMethod()== 'post')
        {
            // $Describe = $this->request->getPost('Describe');
            $policydoc = $_FILES['policydoc'];
            $GAuditdoc = $_FILES['GAuditdoc'];
            $EAudittdoc = $_FILES['EAudittdoc'];
            $CGCRdoc = $_FILES['CGCRdoc'];
            $EPReportdoc = $_FILES['EPReportdoc'];
            $photo1 = $_FILES['photo1'];
            $photo2 = $_FILES['photo2'];
            $photo3 = $_FILES['photo3'];
            $photo4 = $_FILES['photo4'];

            $document =
            [
               "IQAC_id"=>"1",
            //    "Description"=>$Description,
               "policydoc"=>
               [
                'Name' => $policydoc['name'],
                'Type' => $policydoc['type'],
                'Content' => new Binary(file_get_contents($policydoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "GAuditdoc"=>
               [
                'Name' => $GAuditdoc['name'],
                'Type' => $GAuditdoc['type'],
                'Content' => new Binary(file_get_contents($GAuditdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "EAudittdoc"=>
               [
                'Name' => $EAudittdoc['name'],
                'Type' => $EAudittdoc['type'],
                'Content' => new Binary(file_get_contents($EAudittdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "CGCRdoc"=>
               [
                'Name' => $CGCRdoc['name'],
                'Type' => $CGCRdoc['type'],
                'Content' => new Binary(file_get_contents($CGCRdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "EPReportdoc"=>
               [
                'Name' => $EPReportdoc['name'],
                'Type' => $EPReportdoc['type'],
                'Content' => new Binary(file_get_contents($EPReportdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag1"=>
               [
                'Name' => $photo1['name'],
                'Type' => $photo1['type'],
                'Content' => new Binary(file_get_contents($photo1['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag2"=>
               [
                'Name' => $photo2['name'],
                'Type' => $photo2['type'],
                'Content' => new Binary(file_get_contents($photo2['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag1"=>
               [
                'Name' => $photo3['name'],
                'Type' => $photo3['type'],
                'Content' => new Binary(file_get_contents($photo3['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag2"=>
               [
                'Name' => $photo4['name'],
                'Type' => $photo4['type'],
                'Content' => new Binary(file_get_contents($photo4['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_7_1_6'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_7_1_6') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_7_1_6');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //---------------------------------------------------------------------------------------


    public function iqac_7_1_10()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/7_1_10_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_7_1_10()
    {
        if($this->request->getMethod()== 'post')
        {
            // $Describe = $this->request->getPost('Describe');
            $policyEdoc = $_FILES['policyEdoc'];
            $cpmcdoc = $_FILES['cpmcdoc'];
            $cocdoc = $_FILES['cocdoc'];
            $popedoc = $_FILES['popedoc'];
            $ethicsdoc = $_FILES['ethicsdoc'];
            $reportdoc = $_FILES['reportdoc'];
            $Relaventdoc = $_FILES['Relaventdoc'];
            $photo1 = $_FILES['photo1'];
            $photo2 = $_FILES['photo2'];
            $photo3 = $_FILES['photo3'];
            $photo4 = $_FILES['photo4'];
            $photo5 = $_FILES['photo5'];
            $photo6 = $_FILES['photo6'];
            $photo7 = $_FILES['photo7'];
            $photo8 = $_FILES['photo8'];
    

            $document =
            [
               "IQAC_id"=>"1",
            //    "Describe"=>$Describe,
               "policyEdoc"=>
               [
                'Name' => $policyEdoc['name'],
                'Type' => $policyEdoc['type'],
                'Content' => new Binary(file_get_contents($policyEdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "cpmcdoc"=>
               [
                'Name' => $cpmcdoc['name'],
                'Type' => $cpmcdoc['type'],
                'Content' => new Binary(file_get_contents($cpmcdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "cocdoc"=>
               [
                'Name' => $cocdoc['name'],
                'Type' => $cocdoc['type'],
                'Content' => new Binary(file_get_contents($cocdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "popedoc"=>
               [
                'Name' => $popedoc['name'],
                'Type' => $popedoc['type'],
                'Content' => new Binary(file_get_contents($popedoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "ethicsdoc"=>
               [
                'Name' => $ethicsdoc['name'],
                'Type' => $ethicsdoc['type'],
                'Content' => new Binary(file_get_contents($ethicsdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "reportdoc"=>
               [
                'Name' => $reportdoc['name'],
                'Type' => $reportdoc['type'],
                'Content' => new Binary(file_get_contents($reportdoc['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag1"=>
               [
                'Name' => $photo1['name'],
                'Type' => $photo1['type'],
                'Content' => new Binary(file_get_contents($photo1['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag2"=>
               [
                'Name' => $photo2['name'],
                'Type' => $photo2['type'],
                'Content' => new Binary(file_get_contents($photo2['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag3"=>
               [
                'Name' => $photo3['name'],
                'Type' => $photo3['type'],
                'Content' => new Binary(file_get_contents($photo3['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Geotag4"=>
               [
                'Name' => $photo4['name'],
                'Type' => $photo4['type'],
                'Content' => new Binary(file_get_contents($photo4['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag1"=>
               [
                'Name' => $photo5['name'],
                'Type' => $photo5['type'],
                'Content' => new Binary(file_get_contents($photo5['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag2"=>
               [
                'Name' => $photo6['name'],
                'Type' => $photo6['type'],
                'Content' => new Binary(file_get_contents($photo6['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag3"=>
               [
                'Name' => $photo7['name'],
                'Type' => $photo7['type'],
                'Content' => new Binary(file_get_contents($photo7['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Non-Geotag4"=>
               [
                'Name' => $photo8['name'],
                'Type' => $photo8['type'],
                'Content' => new Binary(file_get_contents($photo8['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_7_1_10'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_7_1_10') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_7_1_10');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    // //-------------------------------------------------------------------------------------------

    public function iqac_7_3_1()
    {
        $session = \Config\Services::session();

        if ($session->has('iqac_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("IQAC/7_3_1_view");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }
    public function save_IQAC_7_3_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $Describe = $this->request->getPost('Describe');
            $Caldoc = $_FILES['Caldoc'];

            $document =
            [
               "IQAC_id"=>"1",
               "Describe"=>$Describe,
               "Caldoc"=>
               [
                'Name' => $Caldoc['name'],
                'Type' => $Caldoc['type'],
                'Content' => new Binary(file_get_contents($Caldoc['tmp_name']), Binary::TYPE_GENERIC),
               ]
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['IQAC_7_3_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('iqac_7_3_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('iqac_7_3_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('iqacProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('iqacProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

}
