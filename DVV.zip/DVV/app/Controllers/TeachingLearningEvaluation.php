<?php

namespace App\Controllers;

use App\Models\TeachingLearningEvaluation_Model;
use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;
 
class TeachingLearningEvaluation extends BaseController
{
   public $test,$id,$save;
      
   public function __construct() 
   {
        $this->test=new TeachingLearningEvaluation_Model();
         $this->id = new UniqueID();
   }

    public function effectiveMentee()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='Effective_Mentee_Mentor');
            return view("Teaching_Learning_Evaluation/effectiveMentee_View",$data);       
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveMentee()
    {
        if($this->request->getMethod()=='post')
        {
            $date = $this->request->getPost('date');
            $mentees = $this->request->getPost('mentees');
            $academic = $this->request->getPost('academic');
            $pyschological = $this->request->getPost('pyschological');

            $doc=$this->request->getFile('doc');
            $doc_Name=$this->id->FileValidation_ManyDoc($doc,$path="./Userfiles/Teachers/Teaching_Learning",$key="Effective_Mentee_Mentor",$subkey="Document");
            
         
            $u_id = $this->id->generate();
            $document=[
        
                "Mentee_id"=>"$u_id",
                "Class_Of_Mentee"=> $date,
                "Number_Of_Mentee_Allocated"=> $mentees,
                "Academic"=> $academic,
                "Pyschological"=> $pyschological,
                "Document"=>$doc_Name
            ];

            if(isset($document) && !empty($document))
            {  
                $Mentee = array('$push' =>['Effective_Mentee_Mentor'=>$document]);

                if($this->test->saveData($Mentee))
                {
                    $url=base_url('effectiveMentee');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('effectiveMentee');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }  
    }

    public function updateMentee()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $date = $this->request->getPost('date');
            $mentees = $this->request->getPost('mentees');
            $academic = $this->request->getPost('academic');
            $pyschological = $this->request->getPost('pyschological');
           
            $doc=$this->request->getFile('doc');
            $doc_Name=$this->id->FileValidation_ManyDoc($doc,$path="./Userfiles/Teachers/Teaching_Learning",$key="Effective_Mentee_Mentor",$subkey="Document");
       
            $document=
            [
        
                "Mentee_id"=>"$srnumber",
                "Class_Of_Mentee"=> $date,
                "Number_Of_Mentee_Allocated"=> $mentees,
                "Academic"=> $academic,
                "Pyschological"=> $pyschological,
                "Document"=>$doc_Name
            ];

            if(isset($document) && !empty($document))
            {  
                if($this->test->updateData_Mentee($document,$srnumber))
                {
                    $url=base_url('effectiveMentee');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('effectiveMentee');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }  
    }

    public function deleteMentee()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Effective_Mentee_Mentor',$subkey='Mentee_id',$srnumber))
            {
                $url=base_url('effectiveMentee');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('effectiveMentee');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }  
    }

/********************************************************************************************************/
    public function studentCentricMethods()
    { 
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='Student_Centric');
           
            return view("Teaching_Learning_Evaluation/studentCentric_View",$data);        
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveStudentCentric()
    {
        if($this->request->getMethod()=='post')
        {
            $experimentalLearning = $this->request->getPost('experimentalLearning');
            $participativeLearning = $this->request->getPost('participativeLearning');
            $problemSolving = $this->request->getPost('problemSolving');
            $UseOfICT = $this->request->getPost('UseOfICT');
                   
            $document=[
                "Experimental_Learning" => $experimentalLearning,
                "Participative_Learning" => $participativeLearning,
                "Problem_Solving" => $problemSolving,
                "Use_Of_ICT" => $UseOfICT,
            ];
    
            if(isset($document) && !empty($document))
            {  
                $Expetiential_Learning = array('$set' =>['Student_Centric'=>$document]);
    
                if($this->test->saveData($Expetiential_Learning))
                {
                    $url=base_url('studentcentric');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>"; 
                }
                else
                {
                        $url=base_url('studentcentric');
                        echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        } 
       
    }
    
/********************************************************************************************************/  
    public function financialSupport()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='Financial_Support_By');
            return view("Teaching_Learning_Evaluation/financialSupport_View",$data);       
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveFinancialSupport()
    {
        if($this->request->getMethod()=='post')
        {
            $supportBy = $this->request->getPost('supportBy');
            $other = $this->request->getPost('other'); 
            $yesno = $this->request->getPost('yesno');
            $amount = $this->request->getPost('amount');
            $studentName = $this->request->getPost('studentName');
            $class = $this->request->getPost('class');
            $rollNo = $this->request->getPost('rollNo');
            $purpose = $this->request->getPost('purpose');
    
    
           if($yesno === "Yes")
           {
                $studentDocument=$this->request->getFile('studentDocument');
                $studentDocument_Name=$this->id->FileValidation_ManyDoc($studentDocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Student_Document");

                $photograph=$this->request->getFile('photograph');
                $photograph_Name=$this->id->FileValidation_ManyDoc($photograph,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Photograph");

                $sanctionLetter=$this->request->getFile('sanctionLetter');
                $sanctionLetter_Name=$this->id->FileValidation_ManyDoc($sanctionLetter,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Sanction_Letter");  
           }
           else
           {
                $studentDocument_Name="";
                $photograph_Name="";
                $sanctionLetter_Name="";  
           }
     
           
            if($supportBy === "other")
            {
                $supportBy = $other;      
            }
         
            $u_id = $this->id->generate();
    
            $document=
            [  
                "Financial_Support_By_id" => $u_id,
                "Financial_Support" => $supportBy,
                "Financial_Support_to_Any_Student"=>$yesno,
                "Amount" => $amount,
                "Student_Name" => $studentName,
                "Class" => $class,
                "Roll_No" => $rollNo,
                "Purpose" => $purpose,
                "Student_Document" =>$studentDocument_Name,
                "Photograph" =>$photograph_Name,
                "Sanction_Letter" =>$sanctionLetter_Name
            ];
    
    
            if(isset($document) && !empty($document))
            {  
                $studyTour = array('$push' =>['Financial_Support_By'=>$document]);
    
                if($this->test->saveData($studyTour))
                {
                    $url=base_url('financialSupport');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('financialSupport');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
       
    }

    public function updateFinancialSupport()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $supportBy = $this->request->getPost('supportBy');
            $other = $this->request->getPost('other'); 
            $yesno = $this->request->getPost('yesno');
            $amount = $this->request->getPost('amount');
            $studentName = $this->request->getPost('studentName');
            $class = $this->request->getPost('class');
            $rollNo = $this->request->getPost('rollNo');
            $purpose = $this->request->getPost('purpose');
    
            if($yesno === "Yes")
            {
                $studentDocument=$this->request->getFile('studentDocument');
                $studentDocument_Name=$this->id->FileValidation_ManyDoc($studentDocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Student_Document");
    
                $photograph=$this->request->getFile('photograph');
                $photograph_Name=$this->id->FileValidation_ManyDoc($photograph,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Photograph");
    
                $sanctionLetter=$this->request->getFile('sanctionLetter');
                $sanctionLetter_Name=$this->id->FileValidation_ManyDoc($sanctionLetter,$path="./Userfiles/Teachers/Teaching_Learning",$key="Financial_Support_By",$subkey="Sanction_Letter");  
            }
            else
            {
                $studentDocument_Name="";
                $photograph_Name="";
                $sanctionLetter_Name="";  
            }
    
            if($supportBy === "other")
            {
                $supportBy = $other;      
            }
    
            if($yesno === "no")
            {
                $amount = "Not Found..";
                $studentName="Not Found..";
                $class="Not Found..";
                $rollNo="Not Found..";
                $purpose="Not Found..";
            }
         
            $document=
            [  
                "Financial_Support_By_id" =>"$srnumber",
                "Financial_Support" => $supportBy,
                "Financial_Support_to_Any_Student"=>$yesno,
                "Amount" => $amount,
                "Student_Name" => $studentName,
                "Class" => $class,
                "Roll_No" => $rollNo,
                "Purpose" => $purpose,
                "Student_Document" =>$studentDocument_Name,
                "Photograph" =>$photograph_Name,
                "Sanction_Letter" =>$sanctionLetter_Name
            ];
    
    
            if(isset($document) && !empty($document))
            {  
                if($this->test->updateData_FinancialSupportBy( $document, $srnumber))
                {
                    $url=base_url('financialSupport');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('financialSupport');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url();
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
       
    }

    public function deleteFinancialSupport()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Financial_Support_By',$subkey='Financial_Support_By_id',$srnumber))
            {
                $url=base_url('financialSupport');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('financialSupport');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

 /**********************************************************************************************************************/

    public function studyTour()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='Study_Tour');
            return view("Teaching_Learning_Evaluation/studyTour_view",$data);           
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
           
    }

    public function saveStudyTour()
    {
        if($this->request->getMethod()=='post')
        {
            $Pname= $this->request->getPost('Pname');
            $pcode=$this->request->getPost('pcode');
            $scode=$this->request->getPost('scode');
            $place=$this->request->getPost('place');
            $date=$this->request->getPost('datepicker');
        
            $pdocument=$this->request->getFile('pdocument');
            $pdocument_Name=$this->id->FileValidation_ManyDoc($pdocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Permission_Letter");

            $adocument=$this->request->getFile('adocument');
            $adocument_Name=$this->id->FileValidation_ManyDoc($adocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Attendance_Sheet");

            $geotag1=$this->request->getFile('document1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Geotag_Photos_1");  

            $geotag2=$this->request->getFile('document2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Geotag_Photos_2");  

            $nongeotag1=$this->request->getFile('document3');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Non_Geotag_Photos_1");  

            $nongeotag2=$this->request->getFile('document4');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Non_Geotag_Photos_2");  

            
            if($Pname == "Other")
            {
                $Pname = $this->request->getPost('other');
            }
                    
            $u_id = $this->id->generate();
            $document=
            [
                    
                "Study_Tour_id"=>"$u_id",
                "Name_Program"=>$Pname,
                "Program_Code"=> $pcode,
                "Subject_Code"=>$scode,
                "Place"=> $place,
                "Date" => $date, 
                "Permission_Letter"=>$pdocument_Name,
                "Attendance_Sheet"=>$adocument_Name,

                "Geotag_Photos_1"=>$geotag1_Name,
                "Geotag_Photos_2"=>$geotag2_Name,

                "Non_Geotag_Photos_1"=>$nongeotag1_Name,
                "Non_Geotag_Photos_2"=>$nongeotag2_Name,
            ];

            if(isset($document) && !empty($document))
            {
                $studyTour = array('$push' =>['Study_Tour'=>$document]);

                if($this->test->saveData($studyTour))
                {
                    $url=base_url('studyTour');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('studyTour');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('studyTour');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateStudyTour()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber= $this->request->getPost('srnumber');
            $Pname= $this->request->getPost('Pname');
            $pcode=$this->request->getPost('pcode');
            $scode=$this->request->getPost('scode');
            $place=$this->request->getPost('place');
            $date=$this->request->getPost('datepicker');
        
            $pdocument=$this->request->getFile('pdocument');
            $pdocument_Name=$this->id->FileValidation_ManyDoc($pdocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Permission_Letter");

            $adocument=$this->request->getFile('adocument');
            $adocument_Name=$this->id->FileValidation_ManyDoc($adocument,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Attendance_Sheet");

            $geotag1=$this->request->getFile('document1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Geotag_Photos_1");  

            $geotag2=$this->request->getFile('document2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Geotag_Photos_2");  

            $nongeotag1=$this->request->getFile('document3');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Non_Geotag_Photos_1");  

            $nongeotag2=$this->request->getFile('document4');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Study_Tour",$subkey="Non_Geotag_Photos_2");  
           
            if($Pname == "Other")
            {
                $Pname = $this->request->getPost('other');
            }
                    
            $document=
            [
                    
                "Study_Tour_id"=>"$srnumber",
                "Name_Program"=>$Pname,
                "Program_Code"=> $pcode,
                "Subject_Code"=>$scode,
                "Place"=> $place,
                "Date" => $date, 
                "Permission_Letter"=>$pdocument_Name,
                "Attendance_Sheet"=>$adocument_Name,
                "Geotag_Photos_1"=>$geotag1_Name,
                "Geotag_Photos_2"=>$geotag2_Name,
                "Non_Geotag_Photos_1"=>$nongeotag1_Name,
                "Non_Geotag_Photos_2"=>$nongeotag2_Name,
            ];

            if(isset($document) && !empty($document))
            {

                if($this->test->updateData_StudyTour($document,$srnumber))
                {
                    $url=base_url('studyTour');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('studyTour');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('studyTour');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteStudyTour()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Study_Tour',$subkey='Study_Tour_id',$srnumber))
            {
                $url=base_url('studyTour');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('studyTour');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

 /**********************************************************************************************************************/
 
    public function experientialLearning()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='Expetiential_Learning');
         
            return view("Teaching_Learning_Evaluation/experientialLearning_view",$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveExperientialLearning()
    {
        if($this->request->getMethod()=='post')
        {
            $fields= $this->request->getPost('fields');
            $other = $this->request->getPost('other');
            $course= $this->request->getPost('course');
            $pcode=$this->request->getPost('pcode');
            $pname=$this->request->getPost('pname');
            $snumber=$this->request->getPost('snumber');
            $link=$this->request->getPost('link');
            $snumber =$this->request->getPost('snumber');

            $document1=$this->request->getFile('document1');
            $document1_Name=$this->id->FileValidation_ManyDoc($document1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_1");

            $document2=$this->request->getFile('document2');
            $document2_Name=$this->id->FileValidation_ManyDoc($document2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_2");

            $document3=$this->request->getFile('document3');
            $document3_Name=$this->id->FileValidation_ManyDoc($document3,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_3");  

            $document4=$this->request->getFile('document4');
            $document4_Name=$this->id->FileValidation_ManyDoc($document4,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_4");  

            $document5=$this->request->getFile('document5');
            $document5_Name=$this->id->FileValidation_ManyDoc($document5,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_5");  


            if($fields === "Other")
            {
                $fields = $other;
            }
           
            $u_id = $this->id->generate();

            $document=
            [
                "Expetiential_Learning_id"=> "$u_id",
                "Field_of_Experiance"=>$fields,
                'Course_of_Experiance'=>$course,
                "Program_Code"=> $pcode,
                "Program_Name"=>$pname,
                "Syllabus_Link"=>$link,
                "Number_Students"=> $snumber,
                "Documents_1"=>$document1_Name,
                "Documents_2"=>$document2_Name,
                "Documents_3"=>$document3_Name,
                "Documents_4"=>$document4_Name,
                "Documents_5"=>$document5_Name,
            ];

            if(isset($document) && !empty($document))
            {
                $Expetiential_Learning = array('$push' =>['Expetiential_Learning'=>$document]);

                if($this->test->saveData($Expetiential_Learning))
                {
                    $url=base_url('experientialLearning');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('experientialLearning');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('experientialLearning');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateExperientialLearning()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber=$this->request->getPost('srnumber');
            $fields= $this->request->getPost('fields');
            $other = $this->request->getPost('other');
            $course= $this->request->getPost('course');
            $pcode=$this->request->getPost('pcode');
            $pname=$this->request->getPost('pname');
            $snumber=$this->request->getPost('snumber');
            $link=$this->request->getPost('link');
            $snumber =$this->request->getPost('snumber');

            $document1=$this->request->getFile('document1');
            $document1_Name=$this->id->FileValidation_ManyDoc($document1,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_1");

            $document2=$this->request->getFile('document2');
            $document2_Name=$this->id->FileValidation_ManyDoc($document2,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_2");

            $document3=$this->request->getFile('document3');
            $document3_Name=$this->id->FileValidation_ManyDoc($document3,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_3");  

            $document4=$this->request->getFile('document4');
            $document4_Name=$this->id->FileValidation_ManyDoc($document4,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_4");  

            $document5=$this->request->getFile('document5');
            $document5_Name=$this->id->FileValidation_ManyDoc($document5,$path="./Userfiles/Teachers/Teaching_Learning",$key="Expetiential_Learning",$subkey="Documents_5");         
           
            if($fields === "Other")
            {
                $fields = $other;
            }

            $document=
            [
                "Expetiential_Learning_id"=> "$srnumber",
                "Field_of_Experiance"=>$fields,
                'Course_of_Experiance'=>$course,
                "Program_Code"=> $pcode,
                "Program_Name"=>$pname,
                "Syllabus_Link"=>$link,
                "Number_Students"=> $snumber,
                "Documents_1"=>$document1_Name,
                "Documents_2"=>$document2_Name,
                "Documents_3"=>$document3_Name,
                "Documents_4"=>$document4_Name,
                "Documents_5"=>$document5_Name,
            ];

            if(isset($document) && !empty($document))
            {
                if($this->test->updateData_ExperientialLearning($document,$srnumber))
                {
                    $url=base_url('experientialLearning');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('experientialLearning');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('experientialLearning');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


    public function deleteExperientialLearning()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Expetiential_Learning',$subkey='Expetiential_Learning_id',$srnumber))
            {
                $url=base_url('experientialLearning');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('experientialLearning');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
}
