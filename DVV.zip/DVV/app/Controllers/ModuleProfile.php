<?php

namespace App\Controllers;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Models\TeacherPersonalInfo_Model;
use App\Models\IQAC_Model;
use App\Models\CommitteeLogin_Model;


class ModuleProfile extends BaseController
{
     public $session,$fetch,$iqac_user;
    public function __construct()
    {
        $this->session = \Config\Services::session();

        $this->fetch = new TeacherPersonalInfo_Model();
        $this->iqac_user=new IQAC_Model();
        $this->committee_user=new CommitteeLogin_Model();
    }

/********************************************************************************************************/
    //  Teacher Dashboard View
    public function teacherProf() 
    { 
        if ($this->session->has('loged_user')) 
        {
            $data['documents']=$this->fetch->fecthingData();
            return view('Teacher_Details/teacherProf_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    } 

/********************************************************************************************************/
    // After HOD Login View
    public function hodProf() 
    { 
        if ($this->session->has('loged_user')) 
        {
            $data['documents']=$this->fetch->fecthingData();
            return view('HOD/hodProf_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    } 
/********************************************************************************************************/
    // After IQAC Login View
    public function iqacProf() 
    { 
        if ($this->session->has('iqac_user')) 
        {
            $data['documents']=$this->iqac_user->fecthingData();

            return view('IQAC/iqacProf_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    } 

/********************************************************************************************************* */
// After IQAC Login View
public function committeeProf() 
{ 
    if ($this->session->has('committee_user')) 
    {
        $data['documents']=$this->committee_user->fecthingData();

        return view('Committee/committeeProf_view',$data);
    } 
    else
    {
        $url=base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>"; 
    }
} 
}