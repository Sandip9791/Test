<?php

namespace App\Controllers;

use App\Models\Dashboard_Model;
use App\Models\Admin_Model;
use App\Models\TeacherLogin_Model;
use App\Models\IQAC_Model;
use App\Models\HODLogin_Model;
use App\Models\CommitteeLogin_Model;

use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;

use CodeIgniter\I18n\Time;


class Dashboard extends BaseController
{
       private $loged_user;
       private $iqac_user;
       private $session;
       private $admin;
       private $forgoot;
       private $hod;
       private $committee;

       public function __construct() 
       {
          $this->session = session();

          $this->loged_user=new TeacherLogin_Model();
          $this->iqac_user=new IQAC_Model();
          $this->admin=new Admin_Model();
          $this->forgoot=new Dashboard_Model();
          $this->hod=new HODLogin_Model();

          $this->committee = new CommitteeLogin_Model();
       }

/********************************************************************************************************/
    // Teacher View
    public function index1()
    {
        return view('Dashboard/teacherLogin_view');
    }

/********************************************************************************************************/
    // Admin View
    public function index2()
    {
        return view('Dashboard/adminLogin_view');
    }

/********************************************************************************************************/
    // Princippal | Vice Principal View
    public function index3()
    {
        return view('Dashboard/principalLogin_view');
    }
    
/********************************************************************************************************/
    // HOD Login View
    public function iqacLogin_view()
    {
        return view('Dashboard/iqacLogin_view');
    }

/********************************************************************************************************/
    // Committe Login View
    public function committeeLogin_View()
    {
        return view('Dashboard/committeLogin_view');
    }
    
    
/********************************************************************************************************/
    // Admin View when Admin Login
    public function admin()
    {
        $session = \Config\Services::session();

        if ($session->has('admin_user')) 
        {
            return view('Admin/admin_view');
        } 
        else
        {
            $url=base_url('ALogin');
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

/********************************************************************************************************/
    // Admin Login
    public function adminLogin()
    {
        if($this->request->getMethod()== 'post')
        {
            $username=$this->request->getPost('username');
            $password=$this->request->getPost('password');

            $document=
            [
                'username'=>$username,
                'password'=>md5($password)
            ];
           
             if( $this->admin->checkUser($document))
             {
                    $this->session->set('admin_user', $username);
                    $url=base_url('admin');
                    echo "<script>
                    alert('$username Welcome To Admin Panel...');
                    window.location.href ='$url';
                   </script>";
             }
             else
             {
                    $url=base_url('ALogin');
                    echo "<script>
                    alert('Invalid Username Or Password. Please try again.');
                    window.location.href ='$url';
                   </script>";
             }
        }
        else
        {
            $url=base_url();
              echo "<script>
              alert('Your Session Is Close...');
              window.location.href ='$url';
             </script>"; 
        }
    }

/********************************************************************************************************/
    // Admin Logout
    public function adminLogout()
    {
        $this->session->remove('admin_user');
        $this->session->destroy();
        
        $url=base_url();
        echo "<script>
        alert('Logout Successfully...');
        window.location.href ='$url';
        </script>"; 
    }

    
/********************************************************************************************************/
    // Teacher Login
    public function teaLogin()
    {
        if($this->request->getMethod()== 'post')
        {
            $username=$this->request->getPost('username');
            $password=$this->request->getPost('password');

            $document=
            [
                'username'=>$username,
                'password'=>md5($password)
            ];
            
             if( $this->loged_user->checkUser($document))
             {
                    $this->session->set('loged_user', $username);
                    $this->loged_user->loginTime($username);

                    $url=base_url('teaProf');
                    echo "<script>
                    window.location.href ='$url';
                    </script>";
                  // return redirect()->to(base_url().'/teaProf');
             }
             else
             {
                  $url=base_url();
                    echo "<script>
                    alert('Invalid Username Or Password. Please try again.');
                    window.location.href ='$url';
                   </script>";

                   // return redirect()->to(base_url());
             }
        }
        else
        {
            $url=base_url();
              echo "<script>
              alert('Data Not Found...');
              window.location.href ='$url';
             </script>"; 

             //return redirect()->to('/');
        }
    }
    
/********************************************************************************************************/
    // Teacher Logout
    public function teaLogout()
    {
       $username=$this->session->get('loged_user');
       $this->loged_user->logoutTime($username);

        $this->session->remove('loged_user');
 
        $url=base_url();
        echo "<script>
        alert('Logout Successfully...');
        window.location.href ='$url';
        </script>"; 

     }

     //Password Reset
     public function index4()
     {
         return view('Dashboard/Reset_Password/forgotPassword_view');
     }
     public function index5()
     {
        return view('Dashboard/Reset_Password/otpEnter_view');
     }

/********************************************************************************************************/
    // Send Email TO Reset Password
    public function teaForgotPass()
    {
          $username=$this->request->getPost('username');
          $userEmail=$this->request->getPost('email');
          
          $document=[
            'username'=>"$username",  
            'Email'=>"$userEmail"
          ];

          if($this->forgoot->checkUser($document))
          {
                $otp=rand(100000,999999);

                $this->session->set('sendOTP', $otp);
                $this->session->set('setEmail',$userEmail);

                $email = \Config\Services::email();
                                    
                $email->setTo($userEmail);
                $email->setFrom('sandipbirajdar.php@gmail.com','ModerCollageGK.org');
                $email->setSubject('OTP');
                $email->setMessage("<div style='background-color: #034568; background-size: cover;background-position: center;width: 100%;height: 100%;'>
                <h3 style='text-align: center; font-family: Courier New, Courier, monospace; color: white; '>Welcome To ModernCollege GK Pune</h3>
                    <div style='text-align: center; font-family: Courier New, Courier, monospace; color: white; '> 
                <label>OTP:-</label>
                <span>$otp</span>
                </div> </div>");
        
                if ($email->send()) 
                {
                    $url=base_url('enterOTP');
                    echo "<script>
                    alert('OTP Are Sent to Your Email...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url=base_url('forgotPassword');
                    echo "<script>
                    alert('Mail Not Send Retry After Some Time...');
                    window.location.href ='$url';
                    </script>";
                }
          }
          else
          {
                $url=base_url('forgotPassword');
                echo "<script>
                alert('Your Credential Not Found... ');
                window.location.href ='$url';
                </script>";
          } 
    }

/********************************************************************************************************/
    // Confirm OTP And Set Password
    public function confirmPassword()
    {
        $check= $this->session->get('sendOTP');

        $otp1=$this->request->getPost('otp');
        $confirmPassword=$this->request->getPost('confirmPassword');

        if($check == $otp1)
        {
            $checkEmail= $this->session->get('setEmail');
 
            if($this->forgoot->updatePass($confirmPassword))
            {
                $url=base_url();
                echo "<script>
                alert('Password Changed...');
                window.location.href ='$url';
                </script>"; 
                    
                // Destroy That Session OTP And Email
                if ($this->session->has('sendOTP') && $this->session->has('setEmail')) 
                {
                    $this->session->remove('sendOTP');
                    $this->session->remove('setEmail');
                    $this->session->destroy();
                }    
            }
            else
            {
                $url=base_url('forgotPassword');
                echo "<script>
                alert('sendOTP... ');
                window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('enterOTP');
            echo "<script>
            alert('Please Enter Valid OTP... ');
            window.location.href ='$url';
            </script>";
        }
    }

/********************************************************************************************************/
    // IQAC Login
    public function iqacLogin()
    {
        if($this->request->getMethod()== 'post')
        {
            $username=$this->request->getPost('username');
            $password=$this->request->getPost('password');

            $document=
            [
                'username'=>$username,
                'password'=>md5($password)
            ];
            
            if( $this->iqac_user->checkUser($document))
            {
                    $this->session->set('iqac_user', $username);
                    $this->iqac_user->loginTime($username);

                    $url=base_url('iqacProf');
                    echo "<script>
                    window.location.href ='$url';
                    </script>";
                    // return redirect()->to(base_url().'/teaProf');
            }
            else
            {
                    $url=base_url();
                    echo "<script>
                    alert('Invalid Username Or Password. Please try again.');
                    window.location.href ='$url';
                    </script>";

                    // return redirect()->to(base_url());
            }
        }
        else
        {
            $url=base_url();
                echo "<script>
                alert('Data Not Found...');
                window.location.href ='$url';
            </script>"; 

            //return redirect()->to('/');
        }
    }
  
/********************************************************************************************************/
    // IQSC Logout
    public function iqacLogout()
    {
        $this->session->remove('iqac_user');
        //$this->session->destroy();

        $url=base_url("ILogin");
        echo "<script>
        alert('Logout Successfully...');
        window.location.href ='$url';
        </script>"; 
    }

/********************************************************************************************************/
    // Committee Login
    public function committeeLogin()
    {
        if($this->request->getMethod()== 'post')
        {
            $username=$this->request->getPost('username');
            $password=$this->request->getPost('password');

            $document=
            [
                'username'=>$username,
                'password'=>md5($password)
            ];
           
            if( $this->committee->checkUser($document))
            {
                $this->session->set('committee_user', $username);

                $url=base_url('committeeProf'); // committee Dashboard Address
                echo "<script>
                window.location.href ='$url';
                </script>";
            }
            else
            {
                $url=base_url('CLogin');
                echo "<script>
                alert('Invalid Username Or Password. Please try again.');
                window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('CLogin');
            echo "<script>
            alert('Data Not Found...');
            window.location.href ='$url';
            </script>"; 
        }
    }
    
/********************************************************************************************************/
    // Committee Logout
    public function committeeLogout()
    {
        $this->session->remove('committee_user');
        //$this->session->destroy();

        $directory ='assets/userFiles' ;
    
        if (!is_dir($directory)) 
        {
            return; // Exit if the directory doesn't exist
        }
    
        $files = array_diff(scandir($directory), array('.', '..'));
    
        foreach ($files as $file) 
        {
            $path = $directory . '/' . $file;
    
            if (is_dir($path)) 
            {
                rmdir($path); // Recursively delete subdirectories
            } 
            else 
            {
                unlink($path); // Delete files within the directory
            }
        }
    
        rmdir($directory); // Delete the directory itself

        $url=base_url();
        echo "<script>
        alert('Logout Successfully...');
        window.location.href ='$url';
        </script>"; 
    }
}
