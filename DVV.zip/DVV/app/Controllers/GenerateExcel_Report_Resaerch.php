<?php

namespace App\Controllers;
use CodeIgniter\I18n\Time;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Models\ExcelReport_Model;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

class GenerateExcel_Report_Resaerch extends BaseController
{
    public $session,$report;
    public function __construct()
    {
        $this->session = \Config\Services::session();

        $this->report = new ExcelReport_Model();

        $this->spreadsheet = new Spreadsheet();
    }
    
    public function dimensionCol_Row($sIndex,$eIndex)
    {
          $count = 0;
        for($i=$sIndex; $i <= $eIndex; $i++)
        {
            
            //setting column width
            $this->spreadsheet->getActiveSheet()->getColumnDimension($i)->setWidth(50);

            // Set the height of row 1 to 30
            $this->spreadsheet->getActiveSheet()->getRowDimension($count)->setRowHeight(30); 
              
            $count++;
        }
    }
/********************************************************************************************************/
    public function researchGuide_Report()
    {
          //styling arrays
          //table head style
          $tableHead = 
          [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>10
            ],
           
          ];

          //styling arrays end

          //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);


          //heading
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A1',"2.4.2 Average percentage of full time teachers with Ph.D./D.M/M.Ch./D.N.B Superspeciality/D.Sc./D’Lit. during the last five years  (20)");
            
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A2',"3.2.3 Percentage of teachers recognised as research guides (3)");

            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A3',"3.4.2 Number  of Ph.D’s registered per teacher (as per the data given w.r.t  recognized Ph.D guides/ supervisors provided at 3.2.3 metric) during the last five years  (5)");

          //merge heading
          $this->spreadsheet->getActiveSheet()->mergeCells("A1:H1");
          $this->spreadsheet->getActiveSheet()->mergeCells("A2:H2");
          $this->spreadsheet->getActiveSheet()->mergeCells("A3:H3");

          // set font style
          $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A2')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A3')->getFont()->setSize(10);

          $this->dimensionCol_Row($sIndex='A',$eIndex='H');

          // set cell alignment
          $this->spreadsheet->getActiveSheet()->getStyle('A5:H5')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

          //header text
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A5',"Name of Full Time Teacher with Ph.d/D.Sc./D.Litt./LLD")
          ->setCellValue('B5',"Qualification (Ph.D/D.Sc/D.Litt/LLD) and Year Of Obtaining")
          ->setCellValue('C5',"Whether Recognised As Reasearch Guide For Ph.D/D.Sc")
          ->setCellValue('D5',"Year Of Recognition")
          ->setCellValue('E5',"Is The Teacher Still Serving In The Institution")
          ->setCellValue('F5',"Name Of The Reaserch Scholar")
          ->setCellValue('G5',"Year Of Registration Of The Scholar")
          ->setCellValue('H5',"Guide Allotment Letter Web Link To Provided");


          // wrap the text
          $this->spreadsheet->getActiveSheet()->getStyle('A5:H5')->getAlignment()->setWrapText(true);

          //set font style and background color
          $this->spreadsheet->getActiveSheet()->getStyle('A5:H5')->applyFromArray($tableHead);

         $data['documents'] = $this->report->checkReaserchGuide_Report();

         $row=6;

         if(isset($data) && !empty($data))
         {
            foreach ($data['documents'] as $arrayItem) 
            {
                $title = $arrayItem->Title;
                $fname = $arrayItem->First_Name;
                $lname = $arrayItem->Last_Name;
                $mname = $arrayItem->Midd_Name;

                $Name = $title." ".$fname." ".$lname." ".$mname;
                $this->spreadsheet->getActiveSheet()
                      ->setCellValue('A'.$row , $Name); 

                 
                $RGuide1 = $arrayItem->RGuide1;

                foreach($RGuide1 as $guideData)
                {
                    $addRow = $row;
                  if($guideData->Ph_D_Guide === 'Yes')
                  {
                      $this->spreadsheet->getActiveSheet()
                      ->setCellValue('B'.$addRow ,"Ph.D Guide")
                      ->setCellValue('C'.$addRow ,"Ph.D");
                  }
                  elseif($guideData->Ph_D_Co_Guide === 'Yes')
                  {
                      $this->spreadsheet->getActiveSheet()
                      ->setCellValue('B'.$addRow ,"Ph.D Co-Guide")
                      ->setCellValue('C'.$addRow ,"Ph.D");  
                  }
                  else
                  {
                      $this->spreadsheet->getActiveSheet()
                      ->setCellValue('B'.$addRow ,"Not Mention")
                      ->setCellValue('C'.$addRow ,"Not Mention");
                  }
                  
                  $this->spreadsheet->getActiveSheet()
                  ->setCellValue('D'.$addRow , $guideData->Year_Of_Recognition);

                  $addRow++;
                }
                if(empty($arrayItem->Leaving_Date))
                {
                  $this->spreadsheet->getActiveSheet()
                  ->setCellValue('E'.$row , "Yes");
                }
                else
                {
                  $this->spreadsheet->getActiveSheet()
                  ->setCellValue('E'.$row , "No");
                }

                $RGuide2 = $arrayItem->RGuide2;

                foreach($RGuide2 as $guideData)
                {
                    $addRow = $row;
                  $this->spreadsheet->getActiveSheet()
                  ->setCellValue('F'.$addRow ,$guideData->Name_of_Researcher)
                  ->setCellValue('G'.$addRow ,$guideData->Year_of_Degree_Award);
                    $addRow++;
                }

                $RGuide3 = $arrayItem->RGuide3;

                foreach($RGuide3 as $guideData)
                {
                    $addRow = $row;
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('H'.$addRow ,base_url('Userfiles/Teachers/Research/').$guideData->RR_Latter);
                }
                
                $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':H'.$row)->applyFromArray($entries);

                $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':H'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

                $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(35);

                $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':H'.$row)->getAlignment()->setWrapText(true);

                $row++; 
            }  
         }
         else
         {
             $url=base_url('admin');
             echo "<script>
             alert('Error,Try After Some Time..');
             window.location.href ='$url';
             </script>"; 
         }


        $fileName="Research_Guide.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }

/********************************************************************************************************/
    public function researchProject_Report()
    {
          //styling arrays
          //table head style
          $tableHead = 
          [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>10
            ],
           
          ];

          //styling arrays end

          //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);


          //heading
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A1',"3.2.1 Grants received from Government and non-governmental agencies for research projects, endowments, Chairs in the institution during the last five years (INR in Lakhs)");
            
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A2'," 3.2.2 Percentage of teachers having research projects during the last five years");

            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A3',"3.2.4 Average Percentage of  departments having Research projects  funded by government and non government agencies during the last five years (3)");

          //merge heading
          $this->spreadsheet->getActiveSheet()->mergeCells("A1:G1");
          $this->spreadsheet->getActiveSheet()->mergeCells("A2:G2");
          $this->spreadsheet->getActiveSheet()->mergeCells("A3:G3");

          // set font style
          $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A2')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A3')->getFont()->setSize(10);

          $this->dimensionCol_Row($sIndex='A',$eIndex='G');

          // set cell alignment
          $this->spreadsheet->getActiveSheet()->getStyle('A5:G5')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

          //header text
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A5',"Name of the Principal Investigator/ Co Investigator (if applicable)")
          ->setCellValue('B5',"Name of the Funding agency")
          ->setCellValue('C5',"Type (Government/Non-Government)")
          ->setCellValue('D5',"Department of Principal Investigator/ Co Investigator")
          ->setCellValue('E5',"Year of Award")
          ->setCellValue('F5',"Funds provided (INR in lakhs) ")
          ->setCellValue('G5',"Duration of the project");
 

          // wrap the text
          $this->spreadsheet->getActiveSheet()->getStyle('A5:G5')->getAlignment()->setWrapText(true);

          //set font style and background color
          $this->spreadsheet->getActiveSheet()->getStyle('A5:G5')->applyFromArray($tableHead);

         $data['documents'] = $this->report->checkReaserchProject_Report();

         $row=6;

         if(isset($data) && !empty($data))
         {
            foreach ($data['documents'] as $arrayItem) 
            {
                $title = $arrayItem->Title;
                $fname = $arrayItem->First_Name;
                $lname = $arrayItem->Last_Name;
                $mname = $arrayItem->Midd_Name;

                $Name = $title." ".$fname." ".$lname." ".$mname;
                
                $RProject = $arrayItem->Reaserch_Project_Info;

                foreach($RProject as $guideData)
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('A'.$row , $Name)
                    ->setCellValue('B'.$row ,$guideData->Name_Of_Funding_Agency)
                    ->setCellValue('C'.$row ,$guideData->Type_Funding_Aggency)
                    ->setCellValue('D'.$row , $arrayItem->Department)
                    ->setCellValue('E'.$row ,$guideData->Year_Of_Award)
                    ->setCellValue('F'.$row ,$guideData->Funds_Provided)
                    ->setCellValue('G'.$row ,$guideData->Duration_Of_Project);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->applyFromArray($entries);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    
                    $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(35);
    
                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->getAlignment()->setWrapText(true);
    
                    $row++; 
                }
            }  
         }
         else
         {
             $url=base_url('admin');
             echo "<script>
             alert('Error,Try After Some Time..');
             window.location.href ='$url';
             </script>"; 
         }


        $fileName="Research_Project_Information.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
/********************************************************************************************************/
    public function seedMoney_Report()
    {
          //styling arrays
          //table head style
          $tableHead = 
          [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>10
            ],
          
          ];

          //styling arrays end

          //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);


          //heading
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A1',"3.1.2 The institution provides seed money to its teachers for research (average per year) (8)");
            
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A2',"3.1.2.1: The amount of seed money provided by institution to its teachers for research year wise during last five years (INR in lakhs)");

          //merge heading
          $this->spreadsheet->getActiveSheet()->mergeCells("A1:D1");
          $this->spreadsheet->getActiveSheet()->mergeCells("A2:D2");
 
          // set font style
          $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A2')->getFont()->setSize(10);
 
          $this->dimensionCol_Row($sIndex='A',$eIndex='D');

          // set cell alignment
          $this->spreadsheet->getActiveSheet()->getStyle('A4:D4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

          //header text
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A4',"Name of the teacher provided with seed money")
          ->setCellValue('B4',"The amount of seed money (INR in Lakhs)")
          ->setCellValue('C4',"Year of receiving")
          ->setCellValue('D4',"Link to the policy documents for Sanction of seed money / grants for research from the institution");
       

          // wrap the text
          $this->spreadsheet->getActiveSheet()->getStyle('A4:D4')->getAlignment()->setWrapText(true);

          //set font style and background color
          $this->spreadsheet->getActiveSheet()->getStyle('A4:D4')->applyFromArray($tableHead);

        $data['documents'] = $this->report->checkSeedMoney_Report();

        $row=5;

        if(isset($data) && !empty($data))
        {
            foreach ($data['documents'] as $arrayItem) 
            {
                $title = $arrayItem->Title;
                $fname = $arrayItem->First_Name;
                $lname = $arrayItem->Last_Name;
                $mname = $arrayItem->Midd_Name;

                $Name = $title." ".$fname." ".$lname." ".$mname;
           
                $RProject = $arrayItem->RMoneyInfo;

                foreach($RProject as $guideData)
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('A'.$row , $Name); 
                   
                    if($guideData->If_Send_Money_Received_For_Project === "Yes")
                    {
                      $this->spreadsheet->getActiveSheet()
                      ->setCellValue('B'.$row ,$guideData->Amount); 
                    }
                    else
                    {
                      $this->spreadsheet->getActiveSheet()
                      ->setCellValue('B'.$row ,"No Send Money Received For Project");
                    }
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('C'.$row ,$guideData->Year_Of_Award)
                    ->setCellValue('D'.$row , base_url('Userfiles/Teachers/Research/').$guideData->Sanction_Letter);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->applyFromArray($entries);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    
                    $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(35);
    
                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->getAlignment()->setWrapText(true);
    
                    $row++; 
                }
            }  
        }
        else
        {
            $url=base_url('admin');
            echo "<script>
            alert('Error,Try After Some Time..');
            window.location.href ='$url';
            </script>"; 
        }


        $fileName="Seed_Money.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
/********************************************************************************************************/
    public function fellowshipFinancial_Report()
    {
          //styling arrays
          //table head style
          $tableHead = 
          [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>10
            ],
          
          ];

          //styling arrays end

          //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);

          //heading
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A1',"3.1.3 Percentage  of teachers awarded national/ international fellowship for advanced studies/ research  during the last five years (6)");
            
          //merge heading
          $this->spreadsheet->getActiveSheet()->mergeCells("A1:D1");

          // set font style
          $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(10);

          $this->dimensionCol_Row($sIndex='A',$eIndex='D');

          // set cell alignment
          $this->spreadsheet->getActiveSheet()->getStyle('A3:D3')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

          //header text
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A3',"Name of the teacher awarded national/ international fellowship/financial support")
          ->setCellValue('B3',"Name of the award/fellowship")
          ->setCellValue('C3',"Year of Award")
          ->setCellValue('D3',"Awarding Agency");
      

          // wrap the text
          $this->spreadsheet->getActiveSheet()->getStyle('A3:D3')->getAlignment()->setWrapText(true);

          //set font style and background color
          $this->spreadsheet->getActiveSheet()->getStyle('A3:D3')->applyFromArray($tableHead);

        $data['documents'] = $this->report->checkFellowship_Report();

        $row=4;

        if(isset($data) && !empty($data))
        {
            foreach ($data['documents'] as $arrayItem) 
            {
                $title = $arrayItem->Title;
                $fname = $arrayItem->First_Name;
                $lname = $arrayItem->Last_Name;
                $mname = $arrayItem->Midd_Name;

                $Name = $title." ".$fname." ".$lname." ".$mname;
          
                $RProject = $arrayItem->RFollow;

                foreach($RProject as $guideData)
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('A'.$row , $Name ."\n"."Awarded By Support Status : ".$guideData->Fellowship_Financial_Support_Status)
                    ->setCellValue('B'.$row ,$guideData->Name_Of_Award_Fellowship) 
                    ->setCellValue('C'.$row ,$guideData->Year_Of_Award)
                    ->setCellValue('D'.$row ,$guideData->Awarding_Agency);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->applyFromArray($entries);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

                    $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(35);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':D'.$row)->getAlignment()->setWrapText(true);

                    $row++; 
                }
            }  
        }
        else
        {
            $url=base_url('admin');
            echo "<script>
            alert('Error,Try After Some Time..');
            window.location.href ='$url';
            </script>"; 
        }


        $fileName="Fellowship_Financial_Support_Stutas.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
/********************************************************************************************************/
    public function researchPublication_Report()
    {
       //styling arrays
          //table head style
          $tableHead = 
          [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>10
            ],
          
          ];

          //styling arrays end

          //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);


          //heading
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A1',"3.4.3 Number of research papers per teacher in the Journals notified on UGC website during the last five years  (5)");
            
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A2',"3.4.3.1: Number of research papers in the Journals notified on UGC website during the last five years");

          //merge heading
          $this->spreadsheet->getActiveSheet()->mergeCells("A1:I1");
          $this->spreadsheet->getActiveSheet()->mergeCells("A2:I2");
 
          // set font style
          $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(10);
          $this->spreadsheet->getActiveSheet()->getStyle('A2')->getFont()->setSize(10);
 
          $this->dimensionCol_Row($sIndex='A',$eIndex='G');

          // set cell alignment
          $this->spreadsheet->getActiveSheet()->getStyle('A4:G4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

          //header text
          $this->spreadsheet->getActiveSheet()
          ->setCellValue('A4',"Title of paper")
          ->setCellValue('B4',"Name of the author/s")
          ->setCellValue('C4',"Department of the teacher")
          ->setCellValue('D4',"Name of journal")
          ->setCellValue('E4',"Year of publication")
          ->setCellValue('F4',"ISSN number")
          ->setCellValue('G4',"Link to the recognition in UGC enlistment of the Journal");
       
          // wrap the text
          $this->spreadsheet->getActiveSheet()->getStyle('A4:G4')->getAlignment()->setWrapText(true);

          //set font style and background color
          $this->spreadsheet->getActiveSheet()->getStyle('A4:G4')->applyFromArray($tableHead);

        $data['documents'] = $this->report->checkResearchPublication_Report();

        $row=5;

        if(isset($data) && !empty($data))
        {
            foreach ($data['documents'] as $arrayItem) 
            {
                $title = $arrayItem->Title;
                $fname = $arrayItem->First_Name;
                $lname = $arrayItem->Last_Name;
                $mname = $arrayItem->Midd_Name;

                $Name = $title." ".$fname." ".$lname." ".$mname;
           
                $RProject = $arrayItem->ResearchPublication;

                foreach($RProject as $guideData)
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('A'.$row , $guideData->Title_Of_Paper)
                    ->setCellValue('B'.$row ,$Name)
                    ->setCellValue('C'.$row ,$arrayItem->Department)
                    ->setCellValue('D'.$row ,$guideData->Name_Of_Journal)
                    ->setCellValue('E'.$row ,$guideData->Year_Of_Publication)
                    ->setCellValue('F'.$row ,"Not Mention");

                    if($guideData->Check === "Yes")
                    {
                        $this->spreadsheet->getActiveSheet()
                        ->setCellValue('G'.$row ,$guideData->Link_Of_Website);
                    }
                    else
                    {
                        $this->spreadsheet->getActiveSheet()
                        ->setCellValue('G'.$row ,base_url('Userfiles/Teachers/Research/').$guideData->Screenshot);
                    }
                    
                   

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->applyFromArray($entries);

                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    
                    $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(35);
    
                    $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':G'.$row)->getAlignment()->setWrapText(true);
    
                    $row++; 
                }
            }  
        }
        else
        {
            $url=base_url('admin');
            echo "<script>
            alert('Error,Try After Some Time..');
            window.location.href ='$url';
            </script>"; 
        }


        $fileName="Research_Publication.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
}