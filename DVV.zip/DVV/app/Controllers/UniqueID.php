<?php

namespace App\Controllers;
use CodeIgniter\I18n\Time;
use App\Models\TeacherPersonalInfo_Model;


class UniqueID extends BaseController
{

    public $session,$store,$test,$extension;
    public function __construct()
    {
         $this->session = \Config\Services::session();
         $this->test=new TeacherPersonalInfo_Model();

    }

    public static function generate()
    {
        $timestamp = microtime(true);
        $randomNumber = mt_rand();
        $length = 12;

        $data = $timestamp . $randomNumber;
        $uniqueID = hash('sha256', $data);

        // Truncate or pad the hash to the desired length
        $uniqueID = substr($uniqueID, 0, $length);

        return $uniqueID;
    }

    // To Upload File Into Directory 

    public function uploadFile_Admin($uploadedFile)
    {
        if ($uploadedFile->isValid() && ! $uploadedFile->hasMoved())
        {
            $newName = $uploadedFile->getRandomName();
            $uploadedFile->move('./Userfiles/Admin/', $newName);

            return $newName;            
        }
        else
        {
             echo "File Not Found";
        }
    }

    public function uploadFile_Teacher($uploadedFile,$path)
    {
        if ($uploadedFile->isValid() && ! $uploadedFile->hasMoved())
        {
            $newName = $uploadedFile->getRandomName();
            $uploadedFile->move($path, $newName);

            return $newName;            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Server Is Not Responding Try After Some Time...');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function FileValidation($uploadedFile,$path,$key,$subkey)
    {
        $fileName = "";

        if (!empty($uploadedFile) && $uploadedFile->isValid()) 
        {
            $fileName = $this->uploadFile_Teacher($uploadedFile,$path);

            return $fileName;
        } 
        else 
        {
            // Fetching data from the database
            $data['documents'] = $this->test->fetchData($key);
        
            foreach ($data['documents'] as $doc) 
            {
                $demo = $doc->$key; // Assuming $doc->PID holds the data
                $fileName = $demo->$subkey;
            }

            return $fileName;
        }
    }

    public function FileValidation_ManyDoc($uploadedFile,$path,$key,$subkey)
    {
        $fileName = "";

        if (!empty($uploadedFile) && $uploadedFile->isValid()) 
        {
            $fileName = $this->uploadFile_Teacher($uploadedFile,$path);

            return $fileName;
        } 
        else 
        {
           // Fetching data from the database
           $data['documents'] =  $this->test->fetchData($key);

            foreach ($data['documents'] as $doc) 
            {
                $demo = $doc->$key;

                foreach($demo as $book)
                {
                    $fileName =  $book->$subkey;
                }    
            }

            return $fileName;
        }
    }

}