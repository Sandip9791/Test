<?php

namespace App\Controllers;

use App\Models\HODLogin_Model;
 use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;

class HOD extends BaseController
{
    public $test, $save;

    public function __construct()
    {
        $this->test = new HODLogin_Model;
         $this->id = new UniqueID();
    }

    public function hod_1_1_1()
    {
        $session = \Config\Services::session();
        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_1_1_1');
            return view("HOD/1_1_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_1_1_1()
    {
        if($this->request->getMethod()=='post')
        {
            $curriculaDeveloped = $this->request->getPost('curriculaDeveloped');

            $posLink= $this->request->getPost('posLink');
            $cosLink= $this->request->getPost('cosLink');

            $poFile=$this->request->getFile('poFile');
            $poFile_Name=$this->id->FileValidation($poFile,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_1",$subkey="Programme_Outcomes");

            $coFile=$this->request->getFile('coFile');
            $coFile_Name=$this->id->FileValidation($coFile,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_1",$subkey="Course_Outcomes");


            $document = 
            [  
                "HOD_id"=>"1",
                "Curricula_Developed"=>$curriculaDeveloped,
                "Pos_Link"=>$posLink,
                "cos_Link"=>$cosLink,
                "Programme_Outcomes"=>$poFile_Name,
                "Course_Outcomes"=>$coFile_Name,
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_1_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_1_1_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hodProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
      
    }

/***************************************************************************************************************************/
    public function hod_1_1_2()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_1_1_2');
            return view("HOD/1_1_2_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_1_1_2()
    {
        if($this->request->getMethod()=='post')
        {
            $employability = $this->request->getPost('employability');
            $entrepreneurship = $this->request->getPost('entrepreneurship');
            $skill_development = $this->request->getPost('skill_development');

            if(isset($employability) && !empty($employability))
            {
                $employability_document=$this->request->getFile('employability_document');
                $employability_document_Name=$this->id->FileValidation($employability_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_2",$subkey="Employability_Document"); 
            }
            else
            {
                $employability_document_Name="";   
            }
 
            if(isset($entrepreneurship) && !empty($entrepreneurship))
            {
                $entrepreneurship_document=$this->request->getFile('entrepreneurship_document');
                $entrepreneurship_document_Name=$this->id->FileValidation($entrepreneurship_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_2",$subkey="Entrepreneurship_Document");
            }
            else
            {
                $entrepreneurship_document_Name="";   
            }
 
            if(isset($skill_development) && !empty($skill_development))
            {
 
                $skill_development_document=$this->request->getFile('skill_development_document');
                $skill_development_document_Name=$this->id->FileValidation($skill_development_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_2",$subkey="Skill_Development_Document");   
            }
            else
            {
                $skill_development_document_Name="";
            }

            $syllabi=$this->request->getFile('syllabi');
            $syllabi_document_Name=$this->id->FileValidation($syllabi,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_1_2",$subkey="Course_Syllabi");   
 
          
            $document = 
            [   
                "HOD_id"=>"1",
                "Employability" => $employability,
                "Employability_Document"=>$employability_document_Name,
                "Entrepreneurship" => $entrepreneurship,
                "Entrepreneurship_Document" => $entrepreneurship_document_Name,
                "Skill_Development" => $skill_development,
                "Skill_Development_Document" => $skill_development_document_Name,
                "Course_Syllabi" =>$syllabi_document_Name,  
            ];


            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_1_1_2'=>$document]);

                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_1_1_2');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_1_2') ;
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hodProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }

    }

/***************************************************************************************************************************/
    public function hod_1_2_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_1_2_1');
            return view("HOD/1_2_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_1_2_1()
    {
        if($this->request->getMethod()=='post')
        {
            $courses = $this->request->getPost('courses');
            $course_name = $this->request->getPost('course_name');
            $course_code = $this->request->getPost('course_code');
            $year_introduction = $this->request->getPost('year_introduction');

 
            if($courses === "Yes")
            {
                $syllabus=$this->request->getFile('syllabus');
                $syllabus_Name=$this->id->FileValidation($syllabus,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_2_1",$subkey="Syllabus_Approval");    
            }
            else
            {
                $syllabus_Name = "";    
            }
 
            if($courses === "Yes")
            {
                $bos=$this->request->getFile('bos');
                $bos_Name=$this->id->FileValidation($bos,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_2_1",$subkey="Academic_Council_BOS");     
            }
            else
            {
                $bos_Name="";     
            }
 
    
            if($courses === "No")
            {
                $course_name="";
                $course_code="";
                $year_introduction="";
            }
            
            $document = 
            [
                "HOD_id"=>"1",
                "Course"=>$courses,
                "Course_Name" => $course_name,
                "Course_Code" => $course_code,
                "Year_Of_Introduction" => $year_introduction,
                "Syllabus_Approval" =>$syllabus_Name,
                "Academic_Council_BOS" =>$bos_Name
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_1_2_1'=>$document]);

                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_1_2_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_2_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } else {
                $url = base_url('hod_1_2_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/***************************************************************************************************************************/
    public function hod_1_3_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_1_3_1');
            return view("HOD/1_3_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_1_3_1()
    {
        if($this->request->getMethod()=='post')
        {
            $professional_ethics = $this->request->getPost('professional_ethics');
            $gender = $this->request->getPost('gender');
            $human_values = $this->request->getPost('human_values');
            $environment = $this->request->getPost('environment');
            $others = $this->request->getPost('others');
            
            if(isset($professional_ethics) && !empty($professional_ethics))
            {

                $professional_ethics_document=$this->request->getFile('professional_ethics_document');
                $professional_ethics_document_Name=$this->id->FileValidation($professional_ethics_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Professional_Ethics_Document");
                
                $professional_ethics_photo=$this->request->getFile('professional_ethics_photo');
                $professional_ethics_photo_Name=$this->id->FileValidation($professional_ethics_photo,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Professional_Ethics_Photo");
    
            }
            else
            {
                 $professional_ethics_document_Name = "";
                 $professional_ethics_photo_Name = "";   
            }
 

            if(isset($gender) && !empty($gender))
            {
                $gender_document=$this->request->getFile('gender_document');
                $gender_document_Name=$this->id->FileValidation($gender_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Gender_Document");
                
                $gender_photo=$this->request->getFile('gender_photo');
                $gender_photo_Name=$this->id->FileValidation($gender_photo,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Gender_Photo");
  
            }
            else
            {
                $gender_document_Name = "";
                $gender_photo_Name = "";     
            }

            if(isset($human_values) && !empty($human_values))
            {

                $human_values_document=$this->request->getFile('human_values_document');
                $human_values_document_Name=$this->id->FileValidation($human_values_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Human_Values_Document");
                
                $human_values_photo=$this->request->getFile('human_values_photo');
                $human_values_photo_Name=$this->id->FileValidation($human_values_photo,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Human_Values_Photo");
   
            }
            else
            {
                $human_values_document_Name = "";
                $human_values_photo_Name = "";     
            }
 

            if(isset($environment) && !empty($environment))
            {
                $environment_document=$this->request->getFile('environment_document');
                $environment_document_Name=$this->id->FileValidation($environment_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Environment_Document");
                
                $environment_photo=$this->request->getFile('environment_photo');
                $environment_photo_Name=$this->id->FileValidation($environment_photo,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Environment_Photo");    
            }
            else
            {
                $environment_document_Name = "";
                $environment_photo_Name = "";       
            }
 
            if(isset($others) && !empty($others))
            {
                $others_document=$this->request->getFile('others_document');
                $others_document_Name=$this->id->FileValidation($others_document,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Others_Document");
                
                $others_photo=$this->request->getFile('others_photo');
                $others_photo_Name=$this->id->FileValidation($others_photo,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Others_Photo");    
  
            }
            else
            {
                $others_document_Name = "";
                $others_photo_Name = "";     
            }

            $syllabi=$this->request->getFile('syllabi');
            $syllabi_Name=$this->id->FileValidation($syllabi,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_1",$subkey="Course_Syllabi");    
          

            $document = 
            [
                "HOD_id"=>"1",
                "Professional_Ethics" => $professional_ethics,
                "Professional_Ethics_Document" => $professional_ethics_document_Name,
                "Professional_Ethics_Photo" => $professional_ethics_photo_Name,
                "Gender" => $gender,
                "Gender_Document" => $gender_document_Name,
                "Gender_Photo" => $gender_photo_Name,
                "Human_Values" => $human_values,
                "Human_Values_Document" => $human_values_document_Name,
                "Human_Values_Photo" => $human_values_photo_Name,
                "Environment_and_Sustainability" => $environment,
                "Environment_Document" => $environment_document_Name,
                "Environment_Photo" => $environment_photo_Name,
                "Others" => $others,
                "Others_Document" => $others_document_Name,
                "Others_Photo" => $others_photo_Name,
                "Course_Syllabi" =>$syllabi_Name,
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_1_3_1'=>$document]);

                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_1_3_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_3_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_1_3_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/*******************************************************************************************************************************************************/
    public function hod_1_3_2()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_1_3_2');

            return view("HOD/1_3_2_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_1_3_2()
    {
        if($this->request->getMethod()=='post')
        {
            $academic_year = $this->request->getPost('academic_year');
            $course_name = $this->request->getPost('course_name');
            $completed_course = $this->request->getPost('completed_course');
            $course_code = $this->request->getPost('course_code');
            $offering_year = $this->request->getPost('offering_year');
            $no_of_times = $this->request->getPost('no_of_times');
            $weeks_or_hours = $this->request->getPost('weeks_or_hours'); //get weeks or hours value
            $duration = $this->request->getPost('duration');  //get a number for duration
            $course_coordinator = $this->request->getPost('course_coordinator');
            $students_enrolled = $this->request->getPost('students_enrolled');
            $students_completed = $this->request->getPost('students_completed');

            $brochure=$this->request->getFile('brochure');
            $brochure_Name=$this->id->FileValidation_ManyDoc($brochure,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Brochure");
            
            $Rdocument=$this->request->getFile('Rdocument');
            $Rdocument_Name=$this->id->FileValidation_ManyDoc($Rdocument,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Related_Documents");

            $module=$this->request->getFile('module');
            $module_Name=$this->id->FileValidation_ManyDoc($module,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Module");

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Attendance");

            $certificate1=$this->request->getFile('certificate1');
            $certificate1_Name=$this->id->FileValidation_ManyDoc($certificate1,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate1");

            $certificate2=$this->request->getFile('certificate2');
            $certificate2_Name=$this->id->FileValidation_ManyDoc($certificate2,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate2");

            $certificate3=$this->request->getFile('certificate3');
            $certificate3_Name=$this->id->FileValidation_ManyDoc($certificate3,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate3");

            $certificate4=$this->request->getFile('certificate4');
            $certificate4_Name=$this->id->FileValidation_ManyDoc($certificate4,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate4");

            $certificate5=$this->request->getFile('certificate5');
            $certificate5_Name=$this->id->FileValidation_ManyDoc($certificate5,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate5");

           
            $u_id = $this->id->generate();
            
            $document = 
            [
                "HOD_id"=>"$u_id", 
                "Academic_year" => $academic_year,
                "Course_name" => $course_name,
                "Completed_course" => $completed_course,
                "Course_code" => $course_code,
                "Offering_year" => $offering_year,
                "No_of_times" => $no_of_times,
                "Weeks_or_Hours" => $weeks_or_hours,
                "Duration" => $duration,
                "Course_coordinator" => $course_coordinator,
                "Students_enrolled" => $students_enrolled,
                "Students_completed" => $students_completed,
                "Related_Documents"=>$Rdocument_Name,
                "Brochure"=>$brochure_Name,
                "Module"=>$brochure_Name,
                "Attendance" =>$attendance_Name,
                'Certificate1' =>$certificate1_Name,
                'Certificate2' =>$certificate2_Name,
                'Certificate3' =>$certificate3_Name,
                'Certificate4' =>$certificate4_Name,
                'Certificate5' =>$certificate5_Name
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$push' =>['HOD_1_3_2'=>$document]);

                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_1_3_2');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_3_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_1_3_2');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function update_1_3_2()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $academic_year = $this->request->getPost('academic_year');
            $course_name = $this->request->getPost('course_name');
            $completed_course = $this->request->getPost('completed_course');
            $course_code = $this->request->getPost('course_code');
            $offering_year = $this->request->getPost('offering_year');
            $no_of_times = $this->request->getPost('no_of_times');
            $weeks_or_hours = $this->request->getPost('weeks_or_hours'); //get weeks or hours value
            $duration = $this->request->getPost('duration');  //get a number for duration
            $course_coordinator = $this->request->getPost('course_coordinator');
            $students_enrolled = $this->request->getPost('students_enrolled');
            $students_completed = $this->request->getPost('students_completed');

            $brochure=$this->request->getFile('brochure');
            $brochure_Name=$this->id->FileValidation_ManyDoc($brochure,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Brochure");
            
            $Rdocument=$this->request->getFile('Rdocument');
            $Rdocument_Name=$this->id->FileValidation_ManyDoc($Rdocument,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Related_Documents");

            $module=$this->request->getFile('module');
            $module_Name=$this->id->FileValidation_ManyDoc($module,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Module");

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Attendance");

            $certificate1=$this->request->getFile('certificate1');
            $certificate1_Name=$this->id->FileValidation_ManyDoc($certificate1,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate1");

            $certificate2=$this->request->getFile('certificate2');
            $certificate2_Name=$this->id->FileValidation_ManyDoc($certificate2,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate2");

            $certificate3=$this->request->getFile('certificate3');
            $certificate3_Name=$this->id->FileValidation_ManyDoc($certificate3,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate3");

            $certificate4=$this->request->getFile('certificate4');
            $certificate4_Name=$this->id->FileValidation_ManyDoc($certificate4,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate4");

            $certificate5=$this->request->getFile('certificate5');
            $certificate5_Name=$this->id->FileValidation_ManyDoc($certificate5,$path="./Userfiles/HOD/Criterion_I",$key="HOD_1_3_2",$subkey="Certificate5");

 
           
            $document = 
            [
                "HOD_id"=>"$srnumber", 
                "Academic_year" => $academic_year,
                "Course_name" => $course_name,
                "Completed_course" => $completed_course,
                "Course_code" => $course_code,
                "Offering_year" => $offering_year,
                "No_of_times" => $no_of_times,
                "Weeks_or_Hours" => $weeks_or_hours,
                "Duration" => $duration,
                "Course_coordinator" => $course_coordinator,
                "Students_enrolled" => $students_enrolled,
                "Students_completed" => $students_completed,
                "Related_Documents"=>$Rdocument_Name,
                "Brochure"=>$brochure_Name,
                "Module"=>$brochure_Name,
                "Attendance" =>$attendance_Name,
                'Certificate1' =>$certificate1_Name,
                'Certificate2' =>$certificate2_Name,
                'Certificate3' =>$certificate3_Name,
                'Certificate4' =>$certificate4_Name,
                'Certificate5' =>$certificate5_Name
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                if ($this->test->updateData_HOD_1_3_2($document,$srnumber)) 
                {
                    $url = base_url('hod_1_3_2');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_1_3_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_1_3_2');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function delete_1_3_2()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='HOD_1_3_2',$subkey='HOD_id',$srnumber))
            {
                $url=base_url('hod_1_3_2');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('hod_1_3_2');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/**************************************************************************************************************************************************/
    public function hod_2_2_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_2_2_1');
            return view("HOD/2_2_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_2_2_1()
    {
        if($this->request->getMethod()=='post')
        {
            $learning_levels = $this->request->getPost('learning_levels');
            $students_bridge = $this->request->getPost('students_bridge');
            $students_diagnostic = $this->request->getPost('students_diagnostic');
            $course_name = $this->request->getPost('course_name');
    
            $attendace=$this->request->getFile('attendace');
            $attendace_Name=$this->id->FileValidation($attendace,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_2_1",$subkey="Bridge_course_attendance");

            $notice=$this->request->getFile('notice');
            $notice_Name=$this->id->FileValidation($notice,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_2_1",$subkey="Bridge_course_notice");

            $report=$this->request->getFile('report');
            $report_Name=$this->id->FileValidation($report,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_2_1",$subkey="Report_of_diagnostic_test");

            $attendace_diagnostic=$this->request->getFile('attendace_diagnostic');
            $attendace_diagnostic_Name=$this->id->FileValidation($attendace_diagnostic,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_2_1",$subkey="Attendance_of_diagnostic_test");

          
            $document = 
            [
                "HOD_id" =>"1",
                "Learning_levels_of_students" => $learning_levels,
                "Bridge_course_attendance" =>$attendace_Name,
                "Bridge_course_notice" =>$notice_Name,
                "Bridge_number_of_students" => $students_bridge,
                "Report_of_diagnostic_test" =>$report_Name,
                "Attendance_of_diagnostic_test" =>$attendace_diagnostic_Name,
                "Diagnostic_number_of_studnets" => $students_diagnostic,
                "Course_name" => $course_name
            ];
    
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_2_2_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_2_2_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_2_2_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hodProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
      
    }

/**************************************************************************************************************************************************/
    public function hod_2_3_3()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_2_3_3');
            return view("HOD/2_3_3_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_2_3_3()
    {
        if($this->request->getMethod()=='post')
        {
            $preparation = $this->request->getPost('preparation');
        
            $academic_calendar=$this->request->getFile('academic_calendar');
            $academic_calendar_Name=$this->id->FileValidation($academic_calendar,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_3_3",$subkey="Academic_calendar");

            $document = 
            [
                "HOD_id"=>"1",
                "Preparation_adherence_of_Academic_Calendar" => $preparation,
                "Academic_calendar" =>$academic_calendar_Name
            ];
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_2_3_3'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_2_3_3');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>";
                } 
                else 
                {
                    $url = base_url('hod_2_3_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            }
            else 
            {
                $url = base_url('hodProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
      
    }
/**************************************************************************************************************************************************/

    public function hod_2_6_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_2_6_1');
            return view("HOD/2_6_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_2_6_1()
    {
        if($this->request->getMethod()=='post')
        {
            $learning_outcomes = $this->request->getPost('learning_outcomes');
            $webLink = $this->request->getPost('webLink');
    
            $related_doc=$this->request->getFile('related_doc');
            $related_doc_Name=$this->id->FileValidation($related_doc,$path="./Userfiles/HOD/Criterion_II",$key="HOD_2_6_1",$subkey="Related_document");

            $document = 
            [
                "HOD_id"=>"1",
                "Learning_outcomes__Graduate_attributes" => $learning_outcomes,
                "Related_document" =>$related_doc_Name,
                "College_Website_Link"=>$webLink
            ];
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_2_6_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_2_6_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_2_6_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hodProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
      
    }
/**************************************************************************************************************************************************/

    public function hod_3_1_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_3_1_1');
            return view("HOD/3_1_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_3_1_1()
    {
        if($this->request->getMethod()=='post')
        {
            $research_facilities = $this->request->getPost('research_facilities');
            $WebLink = $this->request->getPost('WebLink');
    
            $policy=$this->request->getFile('policy');
            $policy_Name=$this->id->FileValidation($policy,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_1_1",$subkey="Policy_for_promotion_of_research");
    
            $document = 
            [
                "HOD_id"=>"1",
                "Research_facilities" => $research_facilities,
                "Policy_for_promotion_of_research" =>$policy_Name,
                "College_Website_Link"=>$WebLink
                  
            ]; 
    
            if (isset($document)) 
            {
                $hod = array('$set' =>['HOD_3_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_3_1_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_3_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hodProf');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
       
    }
/**************************************************************************************************************************************************/
 
    public function hod_3_3_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_3_3_1');

            return view("HOD/3_3_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_3_3_1()
    {
        if($this->request->getMethod()=='post')
        {
            $ecosystems = $this->request->getPost('ecosystems');

            $relevant_doc=$this->request->getFile('relevant_doc');
            $relevant_doc_Name=$this->id->FileValidation($relevant_doc,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_3_1",$subkey="Relevant_document");


            $document = 
            [
                "HOD_id"=>"1",
                "Ecosystem_for_innovations_IKS" => $ecosystems,
                "Relevant_document" =>$relevant_doc_Name
            ]; 
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_3_3_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_3_3_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_3_3_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_3_3_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        } 
    }

/**************************************************************************************************************************************************/
     public function hod_3_6_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_3_6_1');

            return view("HOD/3_6_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_3_6_1()
    {
        if($this->request->getMethod()=='post')
        {
            $outcomes = $this->request->getPost('outcomes');

            $report=$this->request->getFile('report');
            $report_Name=$this->id->FileValidation($report,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="report");

            $geotag1=$this->request->getFile('geotag1');
            $geotag1_Name=$this->id->FileValidation($geotag1,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="Geotag1");

            $geotag2=$this->request->getFile('geotag2');
            $geotag2_Name=$this->id->FileValidation($geotag2,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="Geotag2");

            $awards=$this->request->getFile('awards');
            $awards_Name=$this->id->FileValidation($awards,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="awards");

            $nongeotag1=$this->request->getFile('nongeotag1');
            $nongeotag1_Name=$this->id->FileValidation($nongeotag1,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="Non_geotag1");

            $nongeotag2=$this->request->getFile('nongeotag2');
            $nongeotag2_Name=$this->id->FileValidation($nongeotag2,$path="./Userfiles/HOD/Criterion_III",$key="HOD_3_6_1",$subkey="Non_geotag2");
   
            $document = 
            [
                "HOD_id"=>"1",
                "Outcomes_of_extension_activities"=>$outcomes,
                "report" =>$report_Name,
                "awards" =>$awards_Name,
                "Geotag1"=>$geotag1_Name,
                "Geotag2"=>$geotag2_Name,
                "Non_geotag1"=>$nongeotag1_Name,
                "Non_geotag2"=>$nongeotag2_Name    
            ]; 
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_3_6_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_3_6_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_3_6_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_3_6_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/**************************************************************************************************************************************************/
    public function hod_5_1_2()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_5_1_2');
            return view("HOD/5_1_2_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_5_1_2()
    {
        if($this->request->getMethod()=='post')
        {
            $efforts = $this->request->getPost('efforts');

            $report=$this->request->getFile('report');
            $report_Name=$this->id->FileValidation($report,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_1_2",$subkey="report");
 
            $geotag1=$this->request->getFile('geotag1');
            $geotag1_Name=$this->id->FileValidation($geotag1,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_1_2",$subkey="Geotag1");

            $geotag2=$this->request->getFile('geotag2');
            $geotag2_Name=$this->id->FileValidation($geotag2,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_1_2",$subkey="Geotag2");

            $nongeotag1=$this->request->getFile('nongeotag1');
            $nongeotag1_Name=$this->id->FileValidation($nongeotag1,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_1_2",$subkey="Non_geotag1");

            $nongeotag2=$this->request->getFile('nongeotag2');
            $nongeotag2_Name=$this->id->FileValidation($nongeotag2,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_1_2",$subkey="Non_geotag2");


            $document = 
            [
                "HOD_id"=>"1",
                "Career_counselling_competitive_exam" => $efforts,
                "report" =>$report_Name,
                "Geotag1"=>$geotag1_Name,
                "Geotag2"=>$geotag2_Name,
                "Non_geotag1"=>$nongeotag1_Name,
                "Non_geotag2"=>$nongeotag2_Name,
            ]; 
    
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_5_1_2'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_5_1_2');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>";
                } 
                else 
                {
                    $url = base_url('hod_5_1_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_5_1_2');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
/**************************************************************************************************************************************************/
    public function hod_5_1_3()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) {
            // $data['documents']=$this->test->fetchData($key='Effective_Mentee_Mentor');

            //Save File
            // $this->save->saveFile_Document();

            return view("HOD/5_1_3_view");
        } else {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }
 /**************************************************************************************************************************************************/
    public function hod_5_2_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_5_2_1');
            return view("HOD/5_2_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_5_2_1()
    {
        if($this->request->getMethod()=='post')
        {
            $excel=$this->request->getFile('excel');
            $excel_Name=$this->id->FileValidation($excel,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_2_1",$subkey="Excel_Student_progression_placement");
          
            $gform_link = $this->request->getPost('gform_link');
    
            $document = 
            [
               "HOD_id"=>"1",
                "Excel_Student_progression_placement" =>$excel_Name,
                "Google_form_link" => $gform_link
            ];

            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_5_2_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_5_2_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_5_2_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_5_2_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }   
    }

/**************************************************************************************************************************************************/
    public function hod_5_2_3()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_5_2_3');

            return view("HOD/5_2_3_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_5_2_3()
    {
        if($this->request->getMethod()=='post')
        {
            $excel=$this->request->getFile('excel');
            $excel_Name=$this->id->FileValidation($excel,$path="./Userfiles/HOD/Criterion_V",$key="HOD_5_2_3",$subkey="Excel_Student_qualified");

            $gform_link = $this->request->getPost('gform_link');
    
            $document = 
            [
                "HOD_id"=>"1",
                "Excel_Student_qualified" =>$excel_Name,
                "Google_form_link" => $gform_link
            ];
    
                
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_5_2_3'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_5_2_3');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_5_2_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_5_2_3');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }

    }

/**************************************************************************************************************************************************/
    public function hod_7_1_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_7_1_1');
            return view("HOD/7_1_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_7_1_1()
    {
        if($this->request->getMethod()=='post')
        {
            $curricular = $this->request->getPost('curricular');
            $cocurricular = $this->request->getPost('cocurricular');


            $curricular_doc=$this->request->getFile('curricular_doc');
            $curricular_doc_Name=$this->id->FileValidation($curricular_doc,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_1",$subkey="Curricular_doc");

            $cocurricular_doc=$this->request->getFile('cocurricular_doc');
            $cocurricular_doc_Name=$this->id->FileValidation($cocurricular_doc,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_1",$subkey="Co_curricular_doc");
 
            $document = 
            [
                "HOD_id"=>"1",
                "Curricular" => $curricular,
                "Curricular_doc" =>$curricular_doc_Name,
                "Co_curricular" => $cocurricular,
                "Co_curricular_doc" =>$cocurricular_doc_Name
            ];
    
                
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_7_1_1'=>$document]);
    
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_7_1_1');
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('hod_7_1_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_7_1_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


/**************************************************************************************************************************************************/
    public function hod_7_1_8()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_7_1_8');
            return view("HOD/7_1_8_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_7_1_8()
    {
        if($this->request->getMethod()=='post')
        {
            $Cultural_Checkbox = $this->request->getPost('Cultural_Checkbox');
            $Regional_Checkbox = $this->request->getPost('Regional_Checkbox');
            $Linguistic_Checkbox = $this->request->getPost('Linguistic_Checkbox');
            $Communal_Socioeconomic_Checkbox = $this->request->getPost('Communal_Socioeconomic_Checkbox');

            $other_Diversities_Checkbox = $this->request->getPost('other_Diversities_Checkbox');
            $other_diversities = $this->request->getPost('other_diversities');

            $institutional_efforts = $this->request->getPost('institutional_efforts');
        
     
            $cultural=$this->request->getFile('cultural');
            $cultural_Name=$this->id->FileValidation($cultural,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_8",$subkey="Cultural");

            $regional=$this->request->getFile('regional');
            $regional_Name=$this->id->FileValidation($regional,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_8",$subkey="Regional");

            $linguistic=$this->request->getFile('linguistic');
            $linguistic_Name=$this->id->FileValidation($linguistic,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_8",$subkey="Linguistic");

            $communal_socioeconomic=$this->request->getFile('communal_socioeconomic');
            $communal_socioeconomic_Name=$this->id->FileValidation($communal_socioeconomic,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_8",$subkey="Communal_socioeconomic");

            $other_diversities_doc=$this->request->getFile('other_diversities_doc');
            $other_diversities_doc_Name=$this->id->FileValidation($other_diversities_doc,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_1_8",$subkey="other_Diversities_Document");


            $document = 
            [
                "HOD_id"=>"1",
                "Cultural" =>$cultural_Name,
                "Regional" => $regional_Name,
                "Linguistic" =>$linguistic_Name,
                "Communal_socioeconomic" =>$communal_socioeconomic_Name,
                "other_Diversities"=>$other_diversities,
                "other_Diversities_Document" =>$other_diversities_doc_Name,
                "Institutional_efforts" =>  $institutional_efforts   
            ];
        
                
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_7_1_8'=>$document]);
        
                if ($this->test->saveData($hod))
                {
                    $url = base_url('hod_7_1_8');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('hod_7_1_8');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_7_1_8');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    
    }

/**************************************************************************************************************************************************/

    public function hod_7_2_1()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key='HOD_7_2_1');

          
            return view("HOD/7_2_1_view",$data);
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function save_7_2_1()
    {
        if($this->request->getMethod()=='post')
        {
            $title = $this->request->getPost('title');
            $objectives = $this->request->getPost('objectives');
            $rationale = $this->request->getPost('rationale');
            $details = $this->request->getPost('details');
            $evidence = $this->request->getPost('evidence');
            $problems = $this->request->getPost('problems');

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation($attendance,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Attendance");

            $relevant_doc=$this->request->getFile('relevant_doc');
            $relevant_doc_Name=$this->id->FileValidation($relevant_doc,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Relevant_document");

            $geotag1=$this->request->getFile('geotag1');
            $geotag1_Name=$this->id->FileValidation($geotag1,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Geotag1");

            $geotag2=$this->request->getFile('geotag2');
            $geotag2_Name=$this->id->FileValidation($geotag2,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Geotag2");

            $nongeotag1=$this->request->getFile('nongeotag1');
            $nongeotag1_Name=$this->id->FileValidation($nongeotag1,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Nongeotag1");

            $nongeotag2=$this->request->getFile('nongeotag2');
            $nongeotag2_Name=$this->id->FileValidation($nongeotag2,$path="./Userfiles/HOD/Criterion_VII",$key="HOD_7_2_1",$subkey="Nongeotag2");


            $document = 
            [
                "HOD_id"=>"1",
                "Title_of_the_practice" => $title,
                "Objectives_of_the_practice" => $objectives,
                "Rationale_Context" => $rationale,
                "Details_of_practice" => $details,
                "Evidence_of_success" => $evidence,
                "Problems_encountered" => $problems,
                "Attendance" =>$attendance_Name,
                "Relevant_document" =>$relevant_doc_Name,
                "Geotag1" =>$geotag1_Name,
                "Geotag2" =>$geotag2_Name,
                "Nongeotag1" =>$nongeotag1_Name,
                "Nongeotag2" =>$nongeotag2_Name 
            ];
        
                
            if (isset($document) && !empty($document)) 
            {
                $hod = array('$set' =>['HOD_7_2_1'=>$document]);
        
                if ($this->test->saveData($hod)) 
                {
                    $url = base_url('hod_7_2_1');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('hod_7_2_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('hod_7_2_1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('hodProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
}