<?php

namespace App\Controllers;
use App\Models\ReaserchInfo_Model;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;
use CodeIgniter\I18n\Time;

 
class ReachersProjectInfo extends BaseController
{
   public  $store,$check,$id,$save;
    public function __construct() 
    {
         $this->connection = new DatabaseConnector();
         $database = $this->connection->getDatabase();
         $this->collection = $database->Teacher;

         $this->store=new ReaserchInfo_Model();
         $this->id = new UniqueID();

         $this->myTime = new Time('now');

 
    }

 /********************************************************************************************************/
    // Reaserch Project Information View
    public function reaserchProjectInfo() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {      
            $data['documents'] = $this->store->fetchData($key="Reaserch_Project_Info");
            return view('Reaserch_Details/reaserchProjectInfo_view',$data);  
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

/********************************************************************************************************/
    // Reaserch Project Information Saving Data To Database 
    public function saveProjectInfo()
    {
        if($this->request->getMethod()=='post')
        {
            $pname= $this->request->getPost('pname');
            $agency1=$this->request->getPost('agency1');
            $yow=$this->request->getPost('datepicker');
            $IT=$this->request->getPost('IT');
            $typeAgency=$this->request->getPost('typeAgency');
            $other= $this->request->getPost('other');
            $status=$this->request->getPost('status');
            $funds=$this->request->getPost('funds');
            $DP=$this->request->getPost('DP');

            $sletter=$this->request->getFile('sletter');
            $sletter_Name=$this->id->FileValidation_ManyDoc($sletter,$path="./Userfiles/Teachers/Research",$key="Reaserch_Project_Info",$subkey="Sanction_Latter");

            $u_id = $this->id->generate();

            if($typeAgency === "Other")
            {
                $typeAgency=$other;
            }

            $document=
            [
                "RInfo_id"=> "$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "Name_Of_Project"=>ucwords($pname),
                "Investigator_Type"=>$IT,
                "Name_Of_Funding_Agency"=>ucwords($agency1),
                "Year_Of_Award"=>$yow,
                "Type_Funding_Aggency"=>$typeAgency,
                "Satus"=>$status,
                "Funds_Provided"=>$funds,
                "Duration_Of_Project"=>$DP,
                "Sanction_Latter" =>$sletter_Name
            ];

            if(isset($document) && !empty($document))
            {
                $reaserchProjectInfo = array('$push'=>['Reaserch_Project_Info'=>$document]);

                if($this->store->saveData($reaserchProjectInfo))
                {
                    $url=base_url('reaserchProjectInfo');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectInfo');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchProjectInfo');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }    
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateProjectInfo()
    {
        if($this->request->getMethod() == 'post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $pname= $this->request->getPost('pname');
            $agency1=$this->request->getPost('agency1');
            $yow=$this->request->getPost('datepicker');
            $IT=$this->request->getPost('IT');
            $typeAgency=$this->request->getPost('typeAgency');
            $status=$this->request->getPost('status');
            $funds=$this->request->getPost('funds');
            $DP=$this->request->getPost('DP');

            $sletter=$this->request->getFile('sletter');
            $sletter_Name=$this->id->FileValidation_ManyDoc($sletter,$path="./Userfiles/Teachers/Research",$key="Reaserch_Project_Info",$subkey="Sanction_Latter");
        

            $document=
            [
                "RInfo_id"=> "$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Name_Of_Project"=>ucwords($pname),
                "Name_Of_Funding_Agency"=>ucwords($agency1),
                "Year_Of_Award"=>$yow,
                "Investigator_Type"=>$IT,
                "Type_Funding_Aggency"=>$typeAgency,
                "Satus"=>$status,
                "Funds_Provided"=>$funds,
                "Duration_Of_Project"=>$DP,
                "Sanction_Latter" =>$sletter_Name
            ];

            if(isset($document) && !empty($document))
            {
                if ($this->store->updateData_ResearchProject($document,$srnumber)) 
                {
                    $url=base_url('reaserchProjectInfo');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectInfo');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Your Request Is Not Process !!!');
                    window.location.href ='$url';
                </script>"; 
            }    
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteProjectInfo()
    {
        if($this->request->getMethod() == 'post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='Reaserch_Project_Info',$subkey='RInfo_id',$srnumber))
            {
                $url=base_url('reaserchProjectInfo');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchProjectInfo');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/***************************************************************************************************************/
     // Reaserch Guide Information View
    public function reaserchGuideInfo1() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key="RGuide1");

            return view('Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo1_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveReaserchGuideInfo1()
    {
        if($this->request->getMethod()=='post')
        {
            $guide= $this->request->getPost('yesno');
            $coGuide = $this->request->getPost('yesno1');
            $sname=$this->request->getPost('subject');
            $cname=$this->request->getPost('center');
            $university=$this->request->getPost('university');
            $yor=$this->request->getPost('datepicker');

            $letter=$this->request->getFile('letter');
            $letter_Name=$this->id->FileValidation_ManyDoc($letter,$path="./Userfiles/Teachers/Research",$key="RGuide1",$subkey="Recognition_Letter");
             
            $u_id = $this->id->generate();
            $document=
            [
                "RGuide1_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "Ph_D_Guide"=>$guide,
                "Ph_D_Co_Guide"=>$coGuide,
                "Subject_Name"=>$sname,
                "Center_Name"=>$cname,
                "University"=>$university,
                "Year_Of_Recognition"=>$yor,
                "Recognition_Letter"=>$letter_Name
            ];

            if(isset($document) && !empty($document))
            {
                $rGuid2 = array('$push' =>['RGuide1'=>$document]);

                if($this->store->saveData($rGuid2))
                {
                    $url=base_url('reaserchGuideInfo1');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo1');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchGuideInfo1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateReaserchGuideInfo1()
    {
        if($this->request->getMethod() =='post')
        {

            $srnumber=$this->request->getPost('srnumber');
            $sname=$this->request->getPost('subject');
            $cname=$this->request->getPost('center');
            $university=$this->request->getPost('university');
            $yor=$this->request->getPost('datepicker');

            $letter=$this->request->getFile('letter');
            $letter_Name=$this->id->FileValidation_ManyDoc($letter,$path="./Userfiles/Teachers/Research",$key="RGuide1",$subkey="Recognition_Letter");
        
            $document=
            [
                "RGuide1_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Subject_Name"=>$sname,
                "Center_Name"=>$cname,
                "University"=>$university,
                "Year_Of_Recognition"=>$yor,
                "Recognition_Letter"=>$letter_Name
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_ReaserchGuideInfo1($document,$srnumber))
                {
                    $url=base_url('reaserchGuideInfo1');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo1');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchGuideInfo1');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteReaserchGuideInfo1()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='RGuide1',$subkey='RGuide1_id',$srnumber))
            {
                $url=base_url('reaserchGuideInfo1');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchGuideInfo1');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
/******************************************************************************************************************/
    public function reaserchGuideInfo2() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key="RGuide2");

            return view('Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo2_view',$data);
            
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveReaserchGuideInfo2()
    {
        if($this->request->getMethod()=='post')
        {
            $title= $this->request->getPost('title');
            $researcher = $this->request->getPost('researcher');
            $datepicker=$this->request->getPost('datepicker');

            $dCertificate=$this->request->getFile('dCertificate');
            $dCertificate_Name=$this->id->FileValidation_ManyDoc($dCertificate,$path="./Userfiles/Teachers/Research",$key="RGuide2",$subkey="Degree_Certificate");

            $u_id = $this->id->generate();

            $document=
            [
                "RGuide2_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "Research_Title"=>$title,
                "Name_of_Researcher"=>$researcher,
                "Year_of_Degree_Award"=>$datepicker,
                "Degree_Certificate" =>$dCertificate_Name
            ];

            if(isset($document) && !empty($document))
            {
                $rGuid2 = array('$push' =>['RGuide2'=>$document]);

                if($this->store->saveData($rGuid2))
                {
                    $url=base_url('reaserchGuideInfo2');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo2');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchGuideInfo2');
                echo "<script>
                    alert('Your Request Is Not Process !!!');
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateReaserchGuideInfo2()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $title= $this->request->getPost('title');
            $researcher = $this->request->getPost('researcher');
            $datepicker=$this->request->getPost('datepicker');

            $dCertificate=$this->request->getFile('dCertificate');
            $dCertificate_Name=$this->id->FileValidation_ManyDoc($dCertificate,$path="./Userfiles/Teachers/Research",$key="RGuide2",$subkey="Degree_Certificate");
 
            $document=
            [
                "RGuide2_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Research_Title"=>$title,
                "Name_of_Researcher"=>$researcher,
                "Year_of_Degree_Award"=>$datepicker,
                "Degree_Certificate" =>$dCertificate_Name
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_ReaserchGuideInfo2($document,$srnumber))
                {
                    $url=base_url('reaserchGuideInfo2');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo2');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchGuideInfo2');
                echo "<script>
                    alert('Your Request Is Not Process !!!');
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteReaserchGuideInfo2()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='RGuide2',$subkey='RGuide2_id',$srnumber))
            {
                $url=base_url('reaserchGuideInfo2');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchGuideInfo2');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    
/******************************************************************************************************************/
    public function reaserchGuideInfo3() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           $data['documents'] = $this->store->fetchData($key="RGuide3");

           return view('Reaserch_Details/reaserchGuideInfo_view/reaserchGuideInfo3_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveReaserchGuideInfo3()
    {
        if($this->request->getMethod()=='post')
        {
            $title=$this->request->getPost('title');
            $researcher=$this->request->getPost('researcher');
            $rdob=$this->request->getPost('rdob');

            $rrletter=$this->request->getFile('RRletter');
            $rrletter_Name=$this->id->FileValidation_ManyDoc($rrletter,$path="./Userfiles/Teachers/Research",$key="RGuide3",$subkey="RR_Latter");
            
            $u_id = $this->id->generate();

            $document=
            [
                "RGuide3_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "Research_Title"=>$title,
                "Name_of_Researcher"=> $researcher,
                "Registration_Date"=>$rdob,
                "RR_Latter" =>$rrletter_Name,
            ];

            if(isset($document) && !empty($document))
            {
                $rGuid3 = array('$push' =>['RGuide3'=>$document]);

                if($this->store->saveData($rGuid3))
                {
                    $url=base_url('reaserchGuideInfo3');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo3');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateReaserchGuideInfo3()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber=$this->request->getPost('srnumber');
            $title=$this->request->getPost('title');
            $researcher=$this->request->getPost('researcher');
            $rdob=$this->request->getPost('rdob');

            $rrletter=$this->request->getFile('RRletter');
            $rrletter_Name=$this->id->FileValidation_ManyDoc($rrletter,$path="./Userfiles/Teachers/Research",$key="RGuide3",$subkey="RR_Latter");

            $document=
            [
                "RGuide3_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Research_Title"=>$title,
                "Name_of_Researcher"=> $researcher,
                "Registration_Date"=>$rdob,
                "RR_Latter" =>$rrletter_Name
            ];

            if(isset($document) && !empty($document))
            {

                if($this->store->updateData_ReaserchGuideInfo3($document, $srnumber))
                {
                    $url=base_url('reaserchGuideInfo3');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchGuideInfo3');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
 
    public function deleteReaserchGuideInfo3()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='RGuide3',$subkey='RGuide3_id',$srnumber))
            {
                $url=base_url('reaserchGuideInfo3');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchGuideInfo3');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }
   
     
/********************************************************************************************************/
    // Reaserch Project Followship View
    public function reaserchProjectFollowship() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           
            $data['documents'] = $this->store->fetchData($key="RFollow");
            return view('Reaserch_Details/reaserchProjectFollwship_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveProjectFollowship()
    {
        if($this->request->getMethod()=='post')
        {
            $awardingAgency= $this->request->getPost('awardingAgency');
            $YearOfAward=$this->request->getPost('datepicker');
            $AwardName=$this->request->getPost('AwardName');
            $fstatus=$this->request->getPost('fstatus');
            $other=$this->request->getPost('other');
            $studies1=$this->request->getPost('studies1');
            $studies2=$this->request->getPost('studies2');
            $grant=$this->request->getPost('grant');
            $amount=$this->request->getPost('amount');

            $sdocument=$this->request->getFile('sletter');
            $sdocument_Name=$this->id->FileValidation_ManyDoc($sdocument,$path="./Userfiles/Teachers/Research",$key="RFollow",$subkey="Sanction_Latter");

            $u_id = $this->id->generate();

            if($fstatus === "Other")
            {
                $fstatus = $other;
            }

            $document=
            [
                "RFollow_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "Awarding_Agency"=>$awardingAgency,
                "Year_Of_Award"=> $YearOfAward,
                "Name_Of_Award_Fellowship"=>strtoupper($AwardName),
                "Fellowship_Financial_Support_Status"=>$fstatus,
                "Type1"=>$studies1,
                "Type2"=>$studies2,
                "Have_You_Received_Travel_Grant"=>$grant,
                "Amount"=>$amount,
                "Sanction_Latter" =>$sdocument_Name
            ];

            if(isset($document) && !empty($document))
            {
                $RFollow = array('$push' =>['RFollow'=>$document]);

                if($this->store->saveData($RFollow))
                {
                    $url=base_url('reaserchProjectFollowship');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectFollowship');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function updateProjectFollowship()
    {
        if($this->request->getMethod() == 'post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $awardingAgency= $this->request->getPost('awardingAgency');
            $YearOfAward=$this->request->getPost('datepicker');
            $AwardName=$this->request->getPost('AwardName');
            $fstatus=$this->request->getPost('fstatus');
            $studies1=$this->request->getPost('studies1');
            $studies2=$this->request->getPost('studies2');
            $grant=$this->request->getPost('grant');
            $amount=$this->request->getPost('amount');
            $sdocument=$_FILES['sletter'];

            $sdocument=$this->request->getFile('sletter');
            $sdocument_Name=$this->id->FileValidation_ManyDoc($sdocument,$path="./Userfiles/Teachers/Research",$key="RFollow",$subkey="Sanction_Latter");


            $document=
            [
                "RFollow_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Awarding_Agency"=>$awardingAgency,
                "Year_Of_Award"=> $YearOfAward,
                "Name_Of_Award_Fellowship"=>strtoupper($AwardName),
                "Fellowship_Financial_Support_Status"=>$fstatus,
                "Type1"=>$studies1,
                "Type2"=>$studies2,
                "Have_You_Received_Travel_Grant"=>$grant,
                "Amount"=>$amount,
                "Sanction_Latter" =>$sdocument_Name
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_ProjectFollowship($document,$srnumber))
                {
                    $url=base_url('reaserchProjectFollowship');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectFollowship');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }

    }

    public function deleteProjectFollowship()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='RFollow',$subkey='RFollow_id',$srnumber))
            {
                $url=base_url('reaserchProjectFollowship');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchProjectFollowship');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    }

/********************************************************************************************************/
    // Reaserch Project Money View
    public function reaserchProjectMoney() 
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           
            $data['documents'] = $this->store->fetchData($key="RMoneyInfo");
            return view('Reaserch_Details/seedMoney_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveProjectMoney()
    {
        if($this->request->getMethod()=='post')
        {
            $researchname= $this->request->getPost('researchname');
            $duration=$this->request->getPost('duration');
            $amount=$this->request->getPost('amount');
            $received=$this->request->getPost('yes-no');
            $yoa=$this->request->getPost('awarddate');

            $sdocument=$this->request->getFile('sletter');
            $sdocument_Name=$this->id->FileValidation_ManyDoc($sdocument,$path="./Userfiles/Teachers/Research",$key="RMoneyInfo",$subkey="Sanction_Letter");
            
            $u_id = $this->id->generate();

            $document=
            [
                "RMoneyInfo_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(),
                "If_Send_Money_Received_For_Project"=>$received,
                "Amount"=>$amount,
                "Title_Of_Research_Project"=>$researchname,
                "Duration"=> $duration,
                "Year_Of_Award"=>$yoa,
                "Sanction_Letter" =>$sdocument_Name
            ];

            if(isset($document) && !empty($document))
            {
                $RMoneyInfo = array('$push' =>['RMoneyInfo'=>$document]);

                if($this->store->saveData($RMoneyInfo))
                {
                    $url=base_url('reaserchProjectMoney');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectMoney');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchProjectMoney');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    } 

    public function updateProjectMoney()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber=$this->request->getPost('srnumber');
            $researchname= $this->request->getPost('researchname');
            $duration=$this->request->getPost('duration');
            $amount=$this->request->getPost('amount');
            $received=$this->request->getPost('yes-no');
            $yoa=$this->request->getPost('awarddate');
        
            $sdocument=$this->request->getFile('sletter');
            $sdocument_Name=$this->id->FileValidation_ManyDoc($sdocument,$path="./Userfiles/Teachers/Research",$key="RMoneyInfo",$subkey="Sanction_Letter");
 
        
            $document=
            [
                "RMoneyInfo_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "If_Send_Money_Received_For_Project"=>$received,
                "Amount"=>$amount,
                "Title_Of_Research_Project"=>$researchname,
                "Duration"=> $duration,
                "Year_Of_Award"=>$yoa,
                "Sanction_Letter" =>$sdocument_Name
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_ProjectMoney($document,$srnumber))
                {
                    $url=base_url('reaserchProjectMoney');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchProjectMoney');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('reaserchProjectMoney');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    } 

    public function deleteProjectMoney()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='RMoneyInfo',$subkey='RMoneyInfo_id',$srnumber))
            {
                $url=base_url('reaserchProjectMoney');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchProjectMoney');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/********************************************************************************************************/
    public function reaserchPublication()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key="ResearchPublication");
            return view('Reaserch_Details/reaserchPublication_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveResearchPublication()
    {
        if($this->request->getMethod()=='post')
        {
            $titleOfPaper= $this->request->getPost('titleofPaper');
            $nameOfJournal=$this->request->getPost('nameOfJournal');
            $yearOfPublication=$this->request->getPost('datepicker');
            $website=$this->request->getPost('yesno');
            $link=$this->request->getPost('enterLink');
            $journalAppBy=$this->request->getPost('approved');
            $other=$this->request->getPost('other');

            if($website === "No")
            {
                $screenshot=$this->request->getFile('screenShot');
                $screenshot_Name=$this->id->FileValidation_ManyDoc($screenshot,$path="./Userfiles/Teachers/Research",$key="ResearchPublication",$subkey="Screenshot");
            }
            else
            {
                $screenshot_Name="";
            } 
            
            if($journalAppBy === "Other")
            {
                $journalAppBy=$other;
            }
            

            $u_id = $this->id->generate();

            $document=
            [
                "ResearchPublication_id"=>"$u_id",
                "Current_Year"=> $this->myTime->getYear(), 
                "Title_Of_Paper"=>$titleOfPaper,
                "Name_Of_Journal"=> $nameOfJournal,
                "Year_Of_Publication"=>$yearOfPublication,
                "Check"=>$website,
                "Link_Of_Website"=>$link,
                "Screenshot"=>$screenshot_Name,
                "Journal_Approved_By"=> $journalAppBy,
            ];

            if(isset($document) && !empty($document))
            {
                $ResearchPublication = array('$push' =>['ResearchPublication'=>$document]);

                if($this->store->saveData($ResearchPublication))
                {
                    $url=base_url('reaserchPublication');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchPublication');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    } 

    public function updateResearchPublication()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $titleOfPaper= $this->request->getPost('titleofPaper');
            $nameOfJournal=$this->request->getPost('nameOfJournal');
            $yearOfPublication=$this->request->getPost('datepicker');
            $website=$this->request->getPost('yesno');
            $link=$this->request->getPost('enterLink');
            $journalAppBy=$this->request->getPost('approved');

            $screenshot=$this->request->getFile('screenShot');
            $screenshot_Name=$this->id->FileValidation_ManyDoc($screenshot,$path="./Userfiles/Teachers/Research",$key="ResearchPublication",$subkey="Screenshot");

          
            if($journalAppBy === "Other")
            {
                $journalAppBy=$this->request->getPost('other');
            }
            
            $document=
            [
                "ResearchPublication_id"=>"$srnumber",
                "Current_Year"=> $this->myTime->getYear(),
                "Title_Of_Paper"=>$titleOfPaper,
                "Name_Of_Journal"=> $nameOfJournal,
                "Year_Of_Publication"=>$yearOfPublication,
                "Check"=>$website,
                "Link_Of_Website"=>  $link,
                "Screenshot"=>$screenshot_Name,
                "Journal_Approved_By" => $journalAppBy,
            ];

            if(isset($document) && !empty($document))
            {
                if ($this->store->updateData_ResearchPublication($document,$srnumber)) 
                {
                    $url=base_url('reaserchPublication');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('reaserchPublication');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    } 

    public function deleteResearchPublication()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='ResearchPublication',$subkey='ResearchPublication_id',$srnumber))
            {
                $url=base_url('reaserchPublication');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('reaserchPublication');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    }

/**************************************************************************************************************************************/
    public function booksAndChapter()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key="BookAndChapter");

            return view('Reaserch_Details/booksAndChapter_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveBookAndChapter()
    {
        if($this->request->getMethod()=='post')
        {
            $titleOfBokk= $this->request->getPost('bookPub');
            $titleOfChapter=$this->request->getPost('Tchapter');
            $yearOfPublication=$this->request->getPost('datepicker');
            $isbnNumber=$this->request->getPost('ISBN');
            $nameOfPublisher=$this->request->getPost('npublisher');
            $affiliating =$this->request->getPost('Institute');
        
            $Cover_document=$this->request->getFile('Cover_document');
            $Cover_Name=$this->id->FileValidation_ManyDoc($Cover_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Cover_Page");

            $Content_document=$this->request->getFile('Content_document');
            $Content_Name=$this->id->FileValidation_ManyDoc($Content_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Content_Page");

            $First_document=$this->request->getFile('First_document');
            $First_Name=$this->id->FileValidation_ManyDoc($First_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="First_Page");

            $Back_document=$this->request->getFile('Back_document');
            $Back_Name=$this->id->FileValidation_ManyDoc($Back_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Back_Page");


            $u_id = $this->id->generate();

            $document=
            [
                "BookAndChapter_id"=>"$u_id",
                "Book_Published"=>$titleOfBokk,
                "Title_Of_The_Chapter"=> $titleOfChapter,
                "Year_Of_Publication"=>$yearOfPublication,
                "ISBN_Number"=> $isbnNumber,
                "Name_Of_The_Publisher" => $nameOfPublisher,
                "Time_Of_Publication"=>$affiliating,
                "Cover_Page"=>$Cover_Name,
                "Content_Page"=>$Content_Name,
                "First_Page"=>$First_Name,
                "Back_Page"=>$Back_Name
            ];

                
            if((isset($document) && !empty($document)))
            { 
                $bookAndchapter = array('$push' =>['BookAndChapter'=>$document]);

                if ($this->store->saveData($bookAndchapter)) 
                {
                    $url=base_url('booksAndChapter');
                        echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                } 
                else 
                {
                    $url=base_url('booksAndChapter');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('booksAndChapter');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
            
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        } 
    }

    public function updateBookAndChapter()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber = $this->request->getPost('srnumber');
            $titleOfBokk= $this->request->getPost('bookPub');
            $titleOfChapter=$this->request->getPost('Tchapter');
            $yearOfPublication=$this->request->getPost('datepicker');
            $isbnNumber=$this->request->getPost('ISBN');
            $nameOfPublisher=$this->request->getPost('npublisher');
            $affiliating =$this->request->getPost('Institute');
        
            $Cover_document=$this->request->getFile('Cover_document');
            $Cover_Name=$this->id->FileValidation_ManyDoc($Cover_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Cover_Page");

            $Content_document=$this->request->getFile('Content_document');
            $Content_Name=$this->id->FileValidation_ManyDoc($Content_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Content_Page");

            $First_document=$this->request->getFile('First_document');
            $First_Name=$this->id->FileValidation_ManyDoc($First_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="First_Page");

            $Back_document=$this->request->getFile('Back_document');
            $Back_Name=$this->id->FileValidation_ManyDoc($Back_document,$path="./Userfiles/Teachers/Research",$key="BookAndChapter",$subkey="Back_Page");
 

            $document=
            [
                "BookAndChapter_id"=>"$srnumber",
                "Book_Published"=>$titleOfBokk,
                "Title_Of_The_Chapter"=> $titleOfChapter,
                "Year_Of_Publication"=>$yearOfPublication,
                "ISBN_Number"=> $isbnNumber,
                "Name_Of_The_Publisher" => $nameOfPublisher,
                "Time_Of_Publication"=>$affiliating,
                "Cover_Page"=>$Cover_Name,
                "Content_Page"=>$Content_Name,
                "First_Page"=>$First_Name,
                "Back_Page"=>$Back_Name
            ];

                
            if((isset($document) && !empty($document)))
            { 
                if ($this->store->updateData_BookAndChapter($document,$srnumber)) 
                {
                    $url=base_url('booksAndChapter');
                        echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                } 
                else 
                {
                    $url=base_url('booksAndChapter');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('booksAndChapter');
                echo "<script>
                    alert('Your Request Is Not Process !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        } 
    }

    public function deleteBookChapter()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='BookAndChapter',$subkey='BookAndChapter_id',$srnumber))
            {
                $url=base_url('booksAndChapter');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('booksAndChapter');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        } 
    }

/********************************************************************************************************/
    public function mou_Linkage()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key="MOU_Linkage");

            return view('Reaserch_Details/mouLinkage_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveMou_Linkage()
    {
        if($this->request->getMethod()=='post')
        {
            $orgname= $this->request->getPost('orgname');
            $Place=$this->request->getPost('Place');
            $Colaboration=$this->request->getPost('Colaboration');
            $other = $this->request->getPost('other');
            $from=$this->request->getPost('fdate');
            $to=$this->request->getPost('tdate');
            $Beneficiary=$this->request->getPost('Beneficiary');


            $adocument=$this->request->getFile('adocument');
            $adocument_Name=$this->id->FileValidation_ManyDoc($adocument,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Document_of_Activity");

            $Udocument0=$this->request->getFile('Udocument0');
            $Udocument0_Name=$this->id->FileValidation_ManyDoc($Udocument0,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document1");

            $Udocument1=$this->request->getFile('Udocument1');
            $Udocument1_Name=$this->id->FileValidation_ManyDoc($Udocument1,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document2");

            $Udocument2=$this->request->getFile('Udocument2');
            $Udocument2_Name=$this->id->FileValidation_ManyDoc($Udocument2,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document3");

            $Udocument3=$this->request->getFile('Udocument3');
            $Udocument3_Name=$this->id->FileValidation_ManyDoc($Udocument3,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document4");

            $Udocument4=$this->request->getFile('Udocument4');
            $Udocument4_Name=$this->id->FileValidation_ManyDoc($Udocument4,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document5");

        
            $u_id = $this->id->generate();

            if($Colaboration === "Other")
            {
                $Colaboration = $other;
            }

            $document=
            [
                "MOU_Linkage_id"=>"$u_id",
                "Name_Organization"=>$orgname,
                "Place"=> $Place,
                "Name_Colaborations"=>$Colaboration,
                "From"=> $from,
                "To" => $to,
                "No_Beneficiary"=>$Beneficiary,
                "Document_of_Activity"=>$adocument_Name,
                "Upload_Document1"=>$Udocument0_Name,
                "Upload_Document2"=>$Udocument1_Name,
                "Upload_Document3"=>$Udocument2_Name,
                "Upload_Document4"=>$Udocument3_Name,
                "Upload_Document5"=>$Udocument4_Name,
            
            ];

            if(isset($document) && !empty($document))
            {
                $MOU_Linkage = array('$push' =>['MOU_Linkage'=>$document]);

                if($this->store->saveData($MOU_Linkage))
                {
                    $url=base_url('mou_Linkage');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('mou_Linkage');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateMou_Linkage()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber= $this->request->getPost('srnumber');
            $orgname= $this->request->getPost('orgname');
            $Place=$this->request->getPost('Place');
            $Colaboration=$this->request->getPost('Colaboration');
            $from=$this->request->getPost('fdate');
            $to=$this->request->getPost('tdate');
            $Beneficiary=$this->request->getPost('Beneficiary');

            $adocument=$this->request->getFile('adocument');
            $adocument_Name=$this->id->FileValidation_ManyDoc($adocument,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Document_of_Activity");
    
            $Udocument0=$this->request->getFile('Udocument0');
            $Udocument0_Name=$this->id->FileValidation_ManyDoc($Udocument0,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document1");
    
            $Udocument1=$this->request->getFile('Udocument1');
            $Udocument1_Name=$this->id->FileValidation_ManyDoc($Udocument1,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document2");
    
            $Udocument2=$this->request->getFile('Udocument2');
            $Udocument2_Name=$this->id->FileValidation_ManyDoc($Udocument2,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document3");
    
            $Udocument3=$this->request->getFile('Udocument3');
            $Udocument3_Name=$this->id->FileValidation_ManyDoc($Udocument3,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document4");
    
            $Udocument4=$this->request->getFile('Udocument4');
            $Udocument4_Name=$this->id->FileValidation_ManyDoc($Udocument4,$path="./Userfiles/Teachers/Research",$key="MOU_Linkage",$subkey="Upload_Document5");


            $document=
            [
                "MOU_Linkage_id"=>"$srnumber",
                "Name_Organization"=>$orgname,
                "Place"=> $Place,
                "Name_Colaborations"=>$Colaboration,
                "From"=> $from,
                "To" => $to,
                "No_Beneficiary"=>$Beneficiary,
                "Document_of_Activity"=>$adocument_Name,
                "Upload_Document1"=>$Udocument0_Name,
                "Upload_Document2"=>$Udocument1_Name,
                "Upload_Document3"=>$Udocument2_Name,
                "Upload_Document4"=>$Udocument3_Name,
                "Upload_Document5"=>$Udocument4_Name,
            
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_Mou_Linkage($document, $srnumber))
                {
                    $url=base_url('mou_Linkage');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('mou_Linkage');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('teaProf');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteMou_Linkage()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='MOU_Linkage',$subkey='MOU_Linkage_id',$srnumber))
            {
                $url=base_url('mou_Linkage');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('mou_Linkage');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/********************************************************************************************************/
    public function consultancy()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           
            $data['documents'] = $this->store->fetchData($key="Consultancy");
            return view('Reaserch_Details/consultancy_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        } 
    }

    public function saveConsultancy()
    {
        if($this->request->getMethod()=='post')
        {
            $Place= $this->request->getPost('Place');
            $nProject=$this->request->getPost('projectname');
            $agency=$this->request->getPost('agency');
            $revenue=$this->request->getPost('revenue');
            $trainings=$this->request->getPost('training');

            $beneficiary=$this->request->getFile('beneficiary');
            $beneficiary_Name=$this->id->FileValidation_ManyDoc($beneficiary,$path="./Userfiles/Teachers/Research",$key="Consultancy",$subkey="Letter_Of_Beneficiary");
            
            $u_id = $this->id->generate();

            $document=
            [
                "Consultancy_id"=>"$u_id",
                "Place"=> $Place,
                "Name_Project"=>$nProject,
                "Sponsoring_Agency"=> $agency,
                "Revenue_Generate" => $revenue,
                "No_Trainings"=>$trainings,
                "Letter_Of_Beneficiary"=>  $beneficiary_Name , 
            ];

            if(isset($document) && !empty($document))
            {
                $Consultancy = array('$push' =>['Consultancy'=>$document]);

                if($this->store->saveData($Consultancy))
                {
                    $url=base_url('consultancy');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('consultancy');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('consultancy');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function updateConsultancy()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber= $this->request->getPost('srnumber');
            $Place= $this->request->getPost('Place');
            $nProject=$this->request->getPost('projectname');
            $agency=$this->request->getPost('agency');
            $revenue=$this->request->getPost('revenue');
            $trainings=$this->request->getPost('training');
            
            $beneficiary=$this->request->getFile('beneficiary');
            $beneficiary_Name=$this->id->FileValidation_ManyDoc($beneficiary,$path="./Userfiles/Teachers/Research",$key="Consultancy",$subkey="Letter_Of_Beneficiary");

            $document=
            [
                "Consultancy_id"=>"$srnumber",
                "Place"=> $Place,
                "Name_Project"=>$nProject,
                "Sponsoring_Agency"=> $agency,
                "Revenue_Generate" => $revenue,
                "No_Trainings"=>$trainings,
                "Letter_Of_Beneficiary"=>$beneficiary_Name
                
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_Consultancy($document,$srnumber))
                {
                    $url=base_url('consultancy');
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('consultancy');
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('consultancy');
                echo "<script>
                alert('Your Request Is Not Process !!!');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function deleteConsultancy()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='Consultancy',$subkey='Consultancy_id',$srnumber))
            {
                $url=base_url('consultancy');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('consultancy');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
            </script>";
        }
    }

}