<?php

namespace App\Controllers;
use App\Models\Admin_Model;
use CodeIgniter\I18n\Time;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Controllers\ErrorMessage;

use App\Controllers\UniqueID;



class Admin extends BaseController
{
       public $admin;
       public $auth;
       public function __construct() 
       {
          $this->connection = new DatabaseConnector();
          $database = $this->connection->getDatabase();
          $this->collection = $database->Teacher;
          
          $this->admin=new Admin_Model();
          $this->session = session();

          $this->id=new UniqueID();
       }
       
/********************************************************************************************************/
    // Teacher Enroll View
    public function teaFacultyEnroll()
    {
         // Count Number Documents In Database
         $tcount = $this->admin->numberOfDocument_Teacher();
         $hcount = $this->admin->numberOfDocument_HOD();
         $mcount = $this->admin->numberOfDocument_Committee();

         $count = $tcount+$hcount+$mcount;

         $lid = $count + 101;

        $data['lid']=$lid;

        if ($this->session->has('admin_user')) 
        {
            $myusername=$this->session->get('admin_user');
            return view('Admin/teacherFaculty_view',$data);
            //return redirect()->to(base_url());
        } 
        else
        {
            $url=base_url('ALogin');
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }

    }

/****************************************************************************************************************/

    // Admin Enroll the Teachers Data and sending Email
    public function teaInsertData()
    {
        if($this->request->getMethod()=='post')
        { 
            $title = $this->request->getPost('title');
            $fname = $this->request->getPost('fname');
            $lname = $this->request->getPost('lname');
            $mname = $this->request->getPost('mname');
          
            $Ttype= $this->request->getPost('Ttype');
            $Ctype = $this->request->getPost('CommittesType');

            $mail = $this->request->getPost('email');

            $faculty = $this->request->getPost('faculty');
            $department=$this->request->getPost('department');
            $designation=$this->request->getPost('designation');
            $nop1 = $this->request->getPost('nop1');
            $dob = $this->request->getPost('jdate');
            $ldate = $this->request->getPost('ldate');
                
            $experiance = $this->request->getPost('yes-no');
            
            $doc=[];
            if($experiance === "yes")
            {
                $iname= $this->request->getPost('iname');
                $ee = $this->request->getPost('experiance');
                $euplod =$this->request->getFile('eupload');
                $filename = $this->id->uploadFile_Admin($euplod);

                $doc = 
                [
                    'Institute_Name'=>$iname,
                    'Experiance_Year'=>$ee,
                    'Experiance_Letter'=>$filename,
                ];

            }
            else
            {
                $doc = [
                    'Experiance_Year'=>0,
                    'Experiance' =>$experiance
                    ];
            }

 

            // random user name generator using first name and last name
            $random_number = mt_rand(1000, 9999);
            $username = strtolower($fname) . strtoupper(substr($lname, 0, 1)) . "$random_number";
          
            // Count Number Documents In Database
            $tcount = $this->admin->numberOfDocument_Teacher();
            $hcount = $this->admin->numberOfDocument_HOD();
            $mcount = $this->admin->numberOfDocument_Committee();
    
            $count = $tcount+$hcount+$mcount;

            $lid = $count + 101;

            $myTime = new Time('now', 'GMT+5:30', 'en_US');
              
            $document=[];

            switch($Ttype)
            {
                case "Teacher":
                                $document = 
                                [
                                    "username" => "$username",
                                    "password" =>"3c63c2b77c29c97e0c40612d8680f699",
                                    'Login_Time'=>"",
                                    'Logout_Time'=>"",
                                    "Time" => "$myTime",
                                    'Title'=>$title,
                                    'First_Name'=>ucwords($fname),
                                    'Last_Name'=>ucwords($lname),
                                    'Midd_Name'=>ucwords($mname),
                                    'Email' => $mail,
                                    'Teacher_ID' =>"$lid",
                                    'Teacher_Type' => $Ttype,
                                    'Faculty' => $faculty,
                                    'Department' =>$department,
                                    'Designation' =>$designation,
                                    'Nature_of_Appointment' =>$nop1,
                                    'Joining_Date'=>$dob,
                                    'Leaving_Date'=>$ldate,
                                    'Experiance' => $doc,
                                    'PID' =>
                                    [
                                        'Title'=>$title,
                                        'First_Name'=>ucwords($fname),
                                        'Last_Name'=>ucwords($lname),
                                        'Midd_Name'=>ucwords($mname),
                                        'Email' =>$mail,
                                        'Mobile_Number' => ' ',
                                        'DOB' => ' ',
                                        'Gender'=> 'Select One',
                                        'Category' => 'Select One',
                                        'Address' => ' ',
                                        'Adhar_Number'=>'',
                                        'Pan_Card_Number'=>'',
                                        'Current_Image' =>"",
                                        'Adhar_Document'=>"",
                                        'Pan_Document' =>"",
                                    ],
                                    'Reaserch_Project_Info'=>[],
                                    'BookAndChapter'=>[],
                                    'Expetiential_Learning'=>[],
                                    'Sensetization_Of_Student'=>[],
                                    'Effective_Mentee_Mentor'=>[],
                                    'ResearchPublication'=>[],
                                    'RMoneyInfo'=>[],
                                    'RGuide1'=>[],
                                    'RGuide2'=>[],
                                    'RGuide3'=>[],
                                    'Study_Tour'=>[],
                                    'Consultancy'=>[],
                                    'RFollow'=>[],
                                    'Teacher_Learning'=>[],
                                    'Teacher_Award'=>[],
                                    'FDP'=>[],
                                    'MOU_Linkage'=>[],
                                    'Student_Centric'=>[],
                                    'Activities_Of_Forum'=>[],
                                    'Financial_Support_By'=>[],
                                    'Alumni_Engagement'=>[],
                                    'Student_Centric'=>
                                    [
                                    "Experimental_Learning"=>"",
                                    "Participative_Learning"=>"",
                                    "Problem_Solving"=>"",
                                    "Use_Of_ICT"=>""
                                    ],
                                ];
                                break;
                
                case "HOD":
                                $document = 
                                [
                                    "username" => "$username",
                                    "password" =>"3c63c2b77c29c97e0c40612d8680f699",
                                    'Login_Time'=>"",
                                    'Logout_Time'=>"",
                                    "Time" => "$myTime",
                                    'Title'=>$title,
                                    'First_Name'=>ucwords($fname),
                                    'Last_Name'=>ucwords($lname),
                                    'Midd_Name'=>ucwords($mname),
                                    'Email' => $mail,
                                    'Teacher_ID' =>"$lid",
                                    'Teacher_Type' => $Ttype,
                                    'Faculty' => $faculty,
                                    'Department' =>$department,
                                    'Designation' =>$designation,
                                    'Nature_of_Appointment' =>$nop1,
                                    'Joining_Date'=>$dob,
                                    'Leaving_Date'=>$ldate,
                                    'Experiance' => $doc,
                                    'PID' =>
                                    [
                                        'Title'=>$title,
                                        'First_Name'=>ucwords($fname),
                                        'Last_Name'=>ucwords($lname),
                                        'Midd_Name'=>ucwords($mname),
                                        'Email' =>$mail,
                                        'Mobile_Number' => ' ',
                                        'DOB' => ' ',
                                        'Gender'=> 'Select One',
                                        'Category' => 'Select One',
                                        'Address' => ' ',
                                        'Adhar_Number'=>'',
                                        'Pan_Card_Number'=>'',
                                        'Current_Image' =>"",
                                        'Adhar_Document'=>"",
                                        'Pan_Document' =>"",
                                    ],
                                    'Reaserch_Project_Info'=>[],
                                    'BookAndChapter'=>[],
                                    'Expetiential_Learning'=>[],
                                    'Sensetization_Of_Student'=>[],
                                    'Effective_Mentee_Mentor'=>[],
                                    'ResearchPublication'=>[],
                                    'RMoneyInfo'=>[],
                                    'RGuide1'=>[],
                                    'RGuide2'=>[],
                                    'RGuide3'=>[],
                                    'Study_Tour'=>[],
                                    'Consultancy'=>[],
                                    'RFollow'=>[],
                                    'Teacher_Learning'=>[],
                                    'Teacher_Award'=>[],
                                    'FDP'=>[],
                                    'MOU_Linkage'=>[],
                                    'Student_Centric'=>[],
                                    'Activities_Of_Forum'=>[],
                                    'Financial_Support_By'=>[],
                                    'Alumni_Engagement'=>[],
                                    'Student_Centric'=>
                                    [
                                    "Experimental_Learning"=>"",
                                    "Participative_Learning"=>"",
                                    "Problem_Solving"=>"",
                                    "Use_Of_ICT"=>""
                                    ],
                                    "HOD_1_1_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Curricula_Developed"=>"",
                                        "Pos_Link"=>"",
                                        "cos_Link"=>"",
                                        "Programme_Outcomes"=>"",
                                        "Course_Outcomes"=>""
                                    ],
                                    "HOD_1_1_2"=>
                                    [
                                        "HOD_id"=>"",
                                        "Employability"=>"",
                                        "Employability_Document"=>"",
                                        "Entrepreneurship"=>"",
                                        "Entrepreneurship_Document"=>"",
                                        "Skill_Development"=>"",
                                        "Skill_Development_Document"=>"",
                                        "Course_Syllabi"=>"",
                                    ],
                                    "HOD_1_2_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Course"=>"",
                                        "Course_Name"=>"",
                                        "Course_Code"=>"",
                                        "Year_Of_Introduction"=>"",
                                        "Syllabus_Approval"=>"",
                                        "Academic_Council_BOS"=>"",
                                    ],
                                    "HOD_1_3_1"=>
                                    [
                                        "HOD_id"=>"1",
                                        "Professional_Ethics" => "",
                                        "Professional_Ethics_Document" =>"",
                                        "Professional_Ethics_Photo" => "",
                                        "Gender" =>"",
                                        "Gender_Document" => "",
                                        "Gender_Photo" => "",
                                        "Human_Values" => "",
                                        "Human_Values_Document" => "",
                                        "Human_Values_Photo" => "",
                                        "Environment_and_Sustainability" =>"",
                                        "Environment_Document" => "",
                                        "Environment_Photo" => "",
                                        "Others" => "",
                                        "Others_Document" => "",
                                        "Others_Photo" => "",
                                        "Course_Syllabi" =>"",
                                    ],
                                    "HOD_1_3_2"=>[],
                                    "HOD_2_2_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Learning_levels_of_students"=>"",
                                        "Bridge_course_attendance"=>"",
                                        "Bridge_course_notice"=>"",
                                        "Bridge_number_of_students"=>"",
                                        "Report_of_diagnostic_test"=>"",
                                        "Attendance_of_diagnostic_test"=>"",
                                        "Diagnostic_number_of_studnets"=>"",
                                        "Course_name"=>"",
                                    ],
                                    "HOD_2_3_3"=>
                                    [
                                        "HOD_id"=>"",
                                        "Preparation_adherence_of_Academic_Calendar"=>"",
                                        "Academic_calendar"=>"",
                                    ],
                                    "HOD_2_6_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Learning_outcomes__Graduate_attributes"=>"",
                                        "Related_document"=>"",
                                        "College_Website_Link"=>"",
                                    ],
                                    "HOD_3_1_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Research_facilities"=>"",
                                        "Policy_for_promotion_of_research"=>"",
                                        "College_Website_Link"=>"",
                                    ],
                                    "HOD_3_3_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Ecosystem_for_innovations_IKS"=>"",
                                        "Relevant_document"=>"",
                                    ],
                                    "HOD_3_6_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Outcomes_of_extension_activities"=>"",
                                        "report"=>"",
                                        "awards"=>"",
                                        "Geotag1"=>"",
                                        "Geotag2"=>"",
                                        "Non_geotag1"=>"",
                                        "Non_geotag2"=>"",
                                    ],
                                    "HOD_5_1_2"=>
                                    [
                                        "HOD_id"=>"",
                                        "Career_counselling_competitive_exam"=>"",
                                        "report"=>"",
                                        "Geotag1"=>"",
                                        "Geotag2"=>"",
                                        "Non_geotag1"=>"",
                                        "Non_geotag2"=>"",
                                    ],
                                    "HOD_5_2_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Excel_Student_progression_placement"=>"",
                                        "Google_form_link"=>"",   
                                    ],
                                    "HOD_5_2_3"=>
                                    [
                                        "HOD_id"=>"",
                                        "Excel_Student_qualified"=>"",
                                        "Google_form_link"=>"",   
                                    ],
                                    "HOD_7_1_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Curricular"=>"",
                                        "Curricular_doc"=>"",
                                        "Co_curricular"=>"",
                                        "Co_curricular_doc"=>"",
                                    ],
                                    "HOD_7_1_8"=>
                                    [
                                        "HOD_id"=>"",
                                        "Cultural"=>"",
                                        "Regional"=>"",
                                        "Linguistic"=>"",
                                        "Communal_socioeconomic"=>"",
                                        "other_Diversities"=>"",
                                        "other_Diversities_Document"=>"",
                                        "Institutional_efforts"=>"", 
                                    ],
                                    "HOD_7_2_1"=>
                                    [
                                        "HOD_id"=>"",
                                        "Title_of_the_practice"=>"",
                                        "Objectives_of_the_practice"=>"",
                                        "Rationale_Context"=>"",
                                        "Details_of_practice"=>"",
                                        "Evidence_of_success"=>"",
                                        "Problems_encountered"=>"",
                                        "Attendance"=>"",
                                        "Relevant_document"=>"",
                                        "Geotag1"=>"",
                                        "Geotag2"=>"",
                                        "Nongeotag1"=>"",
                                        "Nongeotag2"=>"",
                                    ]
                                ];
                                break;

                case "Principal":
                                    $document = 
                                    [
                                        "username" => "$username",
                                        "password" =>"3c63c2b77c29c97e0c40612d8680f699",
                                        'Login_Time'=>"",
                                        'Logout_Time'=>"",
                                        "Time" => "$myTime",
                                        'Title'=>$title,
                                        'First_Name'=>ucwords($fname),
                                        'Last_Name'=>ucwords($lname),
                                        'Midd_Name'=>ucwords($mname),
                                        'Email' => $mail,
                                        'Teacher_ID' =>"$lid",
                                        'Teacher_Type' => $Ttype,
                                        'Faculty' => $faculty,
                                        'Department' =>$department,
                                        'Designation' =>$designation,
                                        'Nature_of_Appointment' =>$nop1,
                                        'Joining_Date'=>$dob,
                                        'Leaving_Date'=>$ldate,
                                        'Experiance' => $doc,
                                        'PID' =>
                                        [
                                            'Title'=>$title,
                                            'First_Name'=>ucwords($fname),
                                            'Last_Name'=>ucwords($lname),
                                            'Midd_Name'=>ucwords($mname),
                                            'Email' =>$mail,
                                            'Mobile_Number' => ' ',
                                            'DOB' => ' ',
                                            'Gender'=> 'Select One',
                                            'Category' => 'Select One',
                                            'Address' => ' ',
                                            'Adhar_Number'=>'',
                                            'Pan_Card_Number'=>'',
                                            'Current_Image' =>$cImage,
                                            'Adhar_Document'=>$aPDF,
                                            'Pan_Document' => "",
                                        ],
                                        'Reaserch_Project_Info'=>[],
                                        'BookAndChapter'=>[],
                                        'Expetiential_Learning'=>[],
                                        'Sensetization_Of_Student'=>[],
                                        'Effective_Mentee_Mentor'=>[],
                                        'ResearchPublication'=>[],
                                        'RMoneyInfo'=>[],
                                        'RGuide1'=>[],
                                        'RGuide2'=>[],
                                        'RGuide3'=>[],
                                        'Study_Tour'=>[],
                                        'Consultancy'=>[],
                                        'RFollow'=>[],
                                        'Teacher_Learning'=>[],
                                        'Teacher_Award'=>[],
                                        'FDP'=>[],
                                        'MOU_Linkage'=>[],
                                        'Student_Centric'=>[],
                                        'Activities_Of_Forum'=>[],
                                        'Financial_Support_By'=>[],
                                        'Alumni_Engagement'=>[],
                                        'Student_Centric'=>
                                        [
                                        "Experimental_Learning"=>"",
                                        "Participative_Learning"=>"",
                                        "Problem_Solving"=>"",
                                        "Use_Of_ICT"=>""
                                        ],
                                        "HOD_1_1_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Curricula_Developed"=>"",
                                            "Pos_Link"=>"",
                                            "cos_Link"=>"",
                                            "Programme_Outcomes"=>"",
                                            "Course_Outcomes"=>""
                                        ],
                                        "HOD_1_1_2"=>
                                        [
                                            "HOD_id"=>"",
                                            "Employability"=>"",
                                            "Employability_Document"=>"",
                                            "Entrepreneurship"=>"",
                                            "Entrepreneurship_Document"=>"",
                                            "Skill_Development"=>"",
                                            "Skill_Development_Document"=>"",
                                            "Course_Syllabi"=>"",
                                        ],
                                        "HOD_1_2_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Course"=>"",
                                            "Course_Name"=>"",
                                            "Course_Code"=>"",
                                            "Year_Of_Introduction"=>"",
                                            "Syllabus_Approval"=>"",
                                            "Academic_Council_BOS"=>"",
                                        ],
                                        "HOD_1_3_1"=>
                                        [
                                            "HOD_id"=>"1",
                                            "Professional_Ethics" => "",
                                            "Professional_Ethics_Document" =>"",
                                            "Professional_Ethics_Photo" => "",
                                            "Gender" =>"",
                                            "Gender_Document" => "",
                                            "Gender_Photo" => "",
                                            "Human_Values" => "",
                                            "Human_Values_Document" => "",
                                            "Human_Values_Photo" => "",
                                            "Environment_and_Sustainability" =>"",
                                            "Environment_Document" => "",
                                            "Environment_Photo" => "",
                                            "Others" => "",
                                            "Others_Document" => "",
                                            "Others_Photo" => "",
                                            "Course_Syllabi" =>"",
                                        ],
                                        "HOD_1_3_2"=>[],
                                        "HOD_2_2_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Learning_levels_of_students"=>"",
                                            "Bridge_course_attendance"=>"",
                                            "Bridge_course_notice"=>"",
                                            "Bridge_number_of_students"=>"",
                                            "Report_of_diagnostic_test"=>"",
                                            "Attendance_of_diagnostic_test"=>"",
                                            "Diagnostic_number_of_studnets"=>"",
                                            "Course_name"=>"",
                                        ],
                                        "HOD_2_3_3"=>
                                        [
                                            "HOD_id"=>"",
                                            "Preparation_adherence_of_Academic_Calendar"=>"",
                                            "Bridge_course_attendance"=>"",
                                        ],
                                        "HOD_2_6_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Learning_outcomes__Graduate_attributes"=>"",
                                            "Related_document"=>"",
                                            "College_Website_Link"=>"",
                                        ],
                                        "HOD_3_1_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Research_facilities"=>"",
                                            "Policy_for_promotion_of_research"=>"",
                                            "College_Website_Link"=>"",
                                        ],
                                        "HOD_3_3_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Ecosystem_for_innovations_IKS"=>"",
                                            "Relevant_document"=>"",
                                        ],
                                        "HOD_3_6_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Outcomes_of_extension_activities"=>"",
                                            "report"=>"",
                                            "awards"=>"",
                                            "Geotag1"=>"",
                                            "Geotag2"=>"",
                                            "Non_geotag1"=>"",
                                            "Non_geotag2"=>"",
                                        ],
                                        "HOD_5_1_2"=>
                                        [
                                            "HOD_id"=>"",
                                            "Career_counselling_competitive_exam"=>"",
                                            "report"=>"",
                                            "Geotag1"=>"",
                                            "Geotag2"=>"",
                                            "Non_geotag1"=>"",
                                            "Non_geotag2"=>"",
                                        ],
                                        "HOD_5_2_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Excel_Student_progression_placement"=>"",
                                            "Google_form_link"=>"",   
                                        ],
                                        "HOD_5_2_3"=>
                                        [
                                            "HOD_id"=>"",
                                            "Excel_Student_qualified"=>"",
                                            "Google_form_link"=>"",   
                                        ],
                                        "HOD_7_1_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Curricular"=>"",
                                            "Curricular_doc"=>"",
                                            "Co_curricular"=>"",
                                            "Co_curricular_doc"=>"",
                                        ],
                                        "HOD_7_1_8"=>
                                        [
                                            "HOD_id"=>"",
                                            "Cultural"=>"",
                                            "Regional"=>"",
                                            "Linguistic"=>"",
                                            "Communal_socioeconomic"=>"",
                                            "other_Diversities"=>"",
                                            "other_Diversities_Document"=>"",
                                            "Institutional_efforts"=>"", 
                                        ],
                                        "HOD_7_2_1"=>
                                        [
                                            "HOD_id"=>"",
                                            "Title_of_the_practice"=>"",
                                            "Objectives_of_the_practice"=>"",
                                            "Rationale_Context"=>"",
                                            "Details_of_practice"=>"",
                                            "Evidence_of_success"=>"",
                                            "Problems_encountered"=>"",
                                            "Attendance"=>"",
                                            "Relevant_document"=>"",
                                            "Geotag1"=>"",
                                            "Geotag2"=>"",
                                            "Nongeotag1"=>"",
                                            "Nongeotag2"=>"",
                                        ]
                                    ];
                                    break;
                            
                case "IQAC":
                                $document = 
                                [
                                    "username" => "$username",
                                    "password" =>"3c63c2b77c29c97e0c40612d8680f699",
                                    'Login_Time'=>"",
                                    'Logout_Time'=>"",
                                    "Time" => "$myTime",
                                    'Title'=>$title,
                                    'First_Name'=>ucwords($fname),
                                    'Last_Name'=>ucwords($lname),
                                    'Midd_Name'=>ucwords($mname),
                                    'Email' => $mail,
                                    'Teacher_ID' =>"$lid",
                                    'Teacher_Type' => $Ttype,
                                    'Committes_Type' => $Ctype,
                                    'Faculty' => $faculty,
                                    'Department' =>$department,
                                    'Designation' =>$designation,
                                    'Nature_of_Appointment' =>$nop1,
                                    'Joining_Date'=>$dob,
                                    'Leaving_Date'=>$ldate,
                                    'Experiance' => $doc,
                                ];
                                break;
                
                case "Committee":
                                    $document = 
                                    [
                                        "username" => "$username",
                                        "password" =>"3c63c2b77c29c97e0c40612d8680f699",
                                        'Login_Time'=>"",
                                        'Logout_Time'=>"",
                                        "Time" => "$myTime",
                                        'Title'=>$title,
                                        'First_Name'=>ucwords($fname),
                                        'Last_Name'=>ucwords($lname),
                                        'Midd_Name'=>ucwords($mname),
                                        'Email' => $mail,
                                        'Teacher_ID' =>"$lid",
                                        'Teacher_Type' => $Ttype,
                                        'Committes_Type' => $Ctype,
                                        'Faculty' => $faculty,
                                        'Department' =>$department,
                                        'Designation' =>$designation,
                                        'Nature_of_Appointment' =>$nop1,
                                        'Joining_Date'=>$dob,
                                        'Leaving_Date'=>$ldate,
                                        'Experiance' => $doc,
                                    ];
                                    break;
                    
                default :
                            $url=base_url('teaFaculty');
                            echo "<script>
                                alert('Your Request Is Not Process, Please Refill The Form !!!');
                                window.location.href ='$url';
                            </script>"; 


            }

      

            if(isset($document) && !empty($document))
            {  
               
                if($this->admin->saveData($document))
                {
                    $email = \Config\Services::email();
                        
                    $email->setTo($mail);
                    $email->setFrom('sandipbirajdar.php@gmail.com','ModerCollageGK.org');
                    $email->setSubject('Username And Password');
                    $email->setMessage("<div style='background-color: #034568; background-size: cover;background-position: center;width: 100%;height: 100%;'>
                     <h3 style='text-align: center; font-family: Courier New, Courier, monospace; color: white; '>Welcome To ModernCollege GK Pune</h3>
                    <div style='text-align: center; font-family: Courier New, Courier, monospace; color: white; '> 
                    <label>Your Username:-</label>
                    <span>$username </span> <br>
            
                    <label>Your Password:- </label>
                    <span> Mirror@16 </span>
                    </div> </div> <a><?= base_url();?></a>");
            
                    if ($email->send()) 
                    {
                        $url=base_url().'/admin';
                        echo "<script>
                        alert('Your Faculty Is Added Successfully And EMAIL Send To Your Email ID...');
                        window.location.href ='$url';
                        </script>";
                    } 
                    else 
                    {
                        $url=base_url().'/admin';
                        echo "<script>
                        alert('Your Email Not Send Please Try Again... ');
                        window.location.href ='$url';
                        </script>";
                    }

                }
                else
                {
                    $url=base_url().'/teaFaculty';
                    echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url().'/teaFaculty';
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }        
        }
        else
        { 
            $url=base_url().'/teaFaculty';
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }     
    }

/********************************************************************************************************/
    // Teachers Enroll Data
    public function teaShowData()
    {
        if ($this->session->has('admin_user')) 
        {
            $data['documents']=$this->admin->fetchData_Teacher();
        
            return view('Admin/teacherFetchingData_view',$data);
        } 
        else
        {
            $url=base_url('ALogin');
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
      
    }

    // Teachers Enroll Data To Delete
    public function teaDeleteData()
    {
        if($this->request->getMethod()=='post')
        { 
            $uname = $this->request->getPost('uname');
            
            if($this->admin->teaDeleteData($uname))
            {
                $url=base_url('teaFacultyFecth');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('teaFacultyFecth');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }

        }
    }

/********************************************************************************************************/
    // IQAC Enroll Data
    public function iqacShowData()
    {
        if ($this->session->has('admin_user')) 
        {
            $data['documents']=$this->admin->fetchData_IQAC();
        
            return view('Admin/iqacFetchingData_view',$data);
        } 
        else
        {
            $url=base_url('ALogin');
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
        
    }

    // IQAC Enroll Data To Delete
    public function IQACDeleteData()
    {
        if($this->request->getMethod()=='post')
        { 
            $uname = $this->request->getPost('uname');
            
            if($this->admin->iqacDeleteData($uname))
            {
                $url=base_url('iqacFacultyFecth');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('iqacFacultyFecth');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }

        }
    }

/********************************************************************************************************/

    // Committee Enroll Data
    public function commiteeShowData()
    {
        $data['documents']=$this->admin->fetchData_Committee();
        
        return view('Admin/commiteeFetchingData_view',$data);
    }

    //Commitee Enroll to Delete Data
    public function COMMITEEDeleteData()
    {
        if($this->request->getMethod()=='post')
        { 
            $uname = $this->request->getPost('uname');
            
            if($this->admin->committeeDeleteData($uname))
            {
                $url=base_url('commiteeFacultyFecth');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('commiteeFacultyFecth');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }

        }
    }


/********************************************************************************************************/
  
    // HOD Enroll Data To Delete
    public function hodDeleteData()
    {
        if($this->request->getMethod()=='post')
        { 
            $uname = $this->request->getPost('uname');
            
            if($this->admin->hodDeleteData($uname))
            {
                $url=base_url('teaFacultyFecth');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('teaFacultyFecth');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }

        }
    }
}
