<?php

namespace App\Controllers;

class ErrorMessage extends BaseController
{
      
    public function errorMessage()
    {
        return view('errors/messageBox_view');
    }
      
}