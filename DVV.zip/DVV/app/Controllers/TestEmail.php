<?php

namespace App\Controllers;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Models\TeacherPersonalInfo_Model;
use App\Models\ExcelReport_Model;

use CodeIgniter\I18n\Time;

class TestEmail extends BaseController
{

    public $session,$fetch,$store;
    public function __construct()
    {
         $this->session = \Config\Services::session();

         $this->fetch = new TeacherPersonalInfo_Model();
         $this->report = new ExcelReport_Model();
    }

    public function index()
    {
        // echo md5("Mirror@16");

        $row = 5;
           
        $data['documents'] = $this->report->checkSeedMoney_Report();

        foreach ($data['documents'] as $arrayItem) 
        {
            $title = $arrayItem->Title;
            $fname = $arrayItem->First_Name;
            $lname = $arrayItem->Last_Name;
            $mname = $arrayItem->Midd_Name;

            $Name = $title." ".$fname." ".$lname." ".$mname;
            echo $Name; 

            $RProject = $arrayItem->RMoneyInfo;

            foreach($RProject as $guideData)
            {
               
                if($guideData->If_Send_Money_Received_For_Project === "Yes")
                {
                   
                 echo $guideData->Amount; 
                }
                else
                {
                  echo"No Send Money Received For Project";
                }
               
                 echo $guideData->Year_Of_Award;
                 echo base_url('Userfiles/Teachers/Research/').$guideData->Sanction_Letter;
                 
                 echo "<br>";
                 

                $row++; 
            }
        }  
       
    }



    
    public function testmail()
    {
        $inputs = $this->validate([
            'email' => 'required|valid_email',
            'subject' => 'required|min_length[5]',
            'message' => 'required|min_length[10]'
        ]);

        if (!$inputs) 
        {
            return view('testemail_view', ['validation' => $this->validator]);
        }
        $to = $this->request->getVar('email');
        $subject = $this->request->getVar('subject');
        $message = $this->request->getVar('message');
        
        $email = \Config\Services::email();
 
        $email->setTo($to);
        $email->setFrom('admin@programmingfields.com', 'Contact Email');
        $email->setSubject($subject);
        $email->setMessage($message);
 
        if ($email->send()) {
            $response = 'Email successfully sent';
        } 
        else 
        {
            $data = $email->printDebugger(['headers']);
            $response ='Email send failed';
        }
        return redirect()->to( base_url('index') )->with('message', $response);

     }
}