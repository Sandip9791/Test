<?php

namespace App\Controllers;
use CodeIgniter\I18n\Time;
use App\Libraries\DatabaseConnector;
use MongoDB\BSON\Binary;
use App\Models\ExcelReport_Model;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

class GenerateExcel_Report extends BaseController
{
     public $session,$report;
    public function __construct()
    {
         $this->session = \Config\Services::session();

         $this->report = new ExcelReport_Model();

         $this->spreadsheet = new Spreadsheet();
    }
    

    public function teachingExperiance_Report()
    {
                 //styling arrays
          //table head style
          $tableHead = [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

          $entries = [
            'font'=>[
              'bold'=>true,
              'size'=>13
            ],
           
          ];

           //styling arrays end

           //get current active sheet (first sheet)
           $sheet =  $this->spreadsheet->getActiveSheet();

           //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);
 

           //heading
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A1',"DVV");

          //merge heading
           $this->spreadsheet->getActiveSheet()->mergeCells("A1:H1");

          // set font style
           $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);

          // set cell alignment

           $this->spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('B2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('C2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('D2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('E2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('F2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('G2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('H2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

         
          //setting column width
            $this->spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(45);

          // Set the height of row 1 to 30
            $this->spreadsheet->getActiveSheet()->getRowDimension(3)->setRowHeight(30);   

            $this->spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(40);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(50);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(50);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(50);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(50);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(50);
            $this->spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(50);

           //header text
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A2',"Name OF The Full Time Teachers")
            ->setCellValue('B2',"Designation")
            ->setCellValue('C2',"Year Of Appointment")
            ->setCellValue('D2',"Nature Of Appointment (Against sanctioned Post,Temporary)")
            ->setCellValue('E2',"Name Of The Department")
            ->setCellValue('F2',"Total Years Of Teaching Experience Of The Teacher Including The Previous")
            ->setCellValue('G2',"Total Years Of Teaching Experience Of The Teacher In The Same Instiution")
            ->setCellValue('H2',"Is The Teacher Still Serving The Institution/If Not Last Year Of The Service Of A Teacher In The Institution");

            // wrap the text
            $this->spreadsheet->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('B2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('C2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('D2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('E2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('F2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('G2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('H2')->getAlignment()->setWrapText(true);

           //set font style and background color
            $this->spreadsheet->getActiveSheet()->getStyle('A2:H2')->applyFromArray($tableHead);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
         $data['documents'] = $this->report->checkEnrollData_Report();
         $row=3;

         if(isset($data))
         {
           foreach ($data['documents'] as $arrayItem) 
           {
                $title = $arrayItem->Title;
                $firstName= $arrayItem->First_Name;
                $midName= $arrayItem->Midd_Name;
                $lastName= $arrayItem->Last_Name;

                $Name = $title." ".$firstName." ".$midName." ".$lastName;

                $this->spreadsheet->getActiveSheet()
                ->setCellValue('A'.$row , $Name)
                ->setCellValue('B'.$row , $arrayItem->Designation)
                ->setCellValue('C'.$row , $arrayItem->Joining_Date)
                ->setCellValue('D'.$row , $arrayItem->Nature_of_Appointment)
                ->setCellValue('E'.$row , $arrayItem->Department);
                  
                $experiance = $arrayItem->Experiance;

                $joining = $arrayItem->Joining_Date;
                
                // joining year
                $time1 = Time::parse($joining);
                $year1= $time1->getYear();

                // current year
                $today = Time::createFromDate(); 
                $time2 = Time::parse($today);
                $year2= $time2->getYear();

                // Experiance Year
                $exYear = $experiance->Experiance_Year;
                
                // previous year experiance
                $year = $year2 - $year1 ; 

                $this->spreadsheet->getActiveSheet()
                ->setCellValue('F'.$row , $year + $exYear)
                ->setCellValue('G'.$row , $year);
                
                $leaving = $arrayItem->Leaving_Date;
                if($leaving == null)
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('H'.$row , "Yes");
                }
                else
                {
                    $this->spreadsheet->getActiveSheet()
                    ->setCellValue('H'.$row , $leaving);    
                }
               
                    
                $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':H'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

                // Set the height of row 1 to 30
                $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(30);

                $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':H'.$row)->applyFromArray($entries);

                $row++;
            } 
         }
         else
         {
             $url=base_url('admin');
             echo "<script>
             alert('Error,Try After Some Time..');
             window.location.href ='$url';
             </script>"; 
         }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $fileName="TeachingExperiance.xlsx";

       // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
/********************************************************************************************************/
    public function teachingPeriod_Report()
    {
          //styling arrays
          //table head style
          $tableHead = [
            'font'=>[
              'color'=>[
                'rgb'=>'FFFFFF'
              ],
              'bold'=>true,
              'size'=>11
            ],
            'fill'=>[
              'fillType' => Fill::FILL_SOLID,
              'startColor' => [
                'rgb' => '538ED5'
              ]
            ],
          ];

           //styling arrays end

           //get current active sheet (first sheet)
           $sheet =  $this->spreadsheet->getActiveSheet();

           //set default font
            $this->spreadsheet->getDefaultStyle()
            ->getFont()
            ->setName('Arial')
            ->setSize(10);
 

           //heading
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A1',"DVV");

          //merge heading
           $this->spreadsheet->getActiveSheet()->mergeCells("A1:H1");

          // set font style
           $this->spreadsheet->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);

          // set cell alignment
           $this->spreadsheet->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('B2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('C2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('D2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('E2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('F2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('G2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
           $this->spreadsheet->getActiveSheet()->getStyle('H2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
          

            //setting column width
             $this->spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(45);

            // Set the height of row 1 to 30
             $this->spreadsheet->getActiveSheet()->getRowDimension(3)->setRowHeight(30);   

             $this->spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(40);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(50);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(50);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(50);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(50);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(50);
             $this->spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(50);

           //header text
            $this->spreadsheet->getActiveSheet()
            ->setCellValue('A2',"Name OF The Full Time Teachers")
            ->setCellValue('B2',"Qualification (Ph.D/D.Sc/D.Litt/LLD) and Year Of Obtaining")
            ->setCellValue('C2',"Whether Recognised As Reasearch Guide For Ph.D/D.Sc")
            ->setCellValue('D2',"Year Of Recognition")
            ->setCellValue('E2',"Is The Teacher Still Serving In The Institution")
            ->setCellValue('F2',"Name Of The Reaserch Scholar")
            ->setCellValue('G2',"Year Of Registration Of The Scholar")
            ->setCellValue('H2',"Guide Allotment Letter Web Link To Provided");


            // wrap the text
            $this->spreadsheet->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('B2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('C2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('D2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('E2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('F2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('G2')->getAlignment()->setWrapText(true);
            $this->spreadsheet->getActiveSheet()->getStyle('H2')->getAlignment()->setWrapText(true);

           //set font style and background color
            $this->spreadsheet->getActiveSheet()->getStyle('A2:H2')->applyFromArray($tableHead);

      ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
       
          
        //  $row=3;

        //  if(isset($data1))
        //  {
        //    foreach ($data1['document1'] as $arrayItem) 
        //    {
        //            $this->spreadsheet->getActiveSheet()
        //          ->setCellValue('A'.$row , $arrayItem->degree)
        //          ->setCellValue('B'.$row , $arrayItem->sem);
                   
        //            if(isset($arrayItem['degree']) && isset($arrayItem['sem']))
        //            {
        //                 $this->spreadsheet->getActiveSheet()
        //                ->setCellValue('C'.$row , $arrayItem['Total_Credit']['Mandatory'])
        //                ->setCellValue('D'.$row ,$arrayItem['Total_Credit']['Electives'])
        //                ->setCellValue('E'.$row ,$arrayItem['Total_Credit']['Minor'])
        //                ->setCellValue('F'.$row , $arrayItem['Total_Credit']['RM'])
        //                ->setCellValue('G'.$row , $arrayItem['Total_Credit']['OE'])
        //                ->setCellValue('H'.$row ,$arrayItem['Total_Credit']['VSC'])
        //                ->setCellValue('I'.$row ,$arrayItem['Total_Credit']['SEC'])
        //                ->setCellValue('J'.$row , $arrayItem['Total_Credit']['AEC'])
        //                ->setCellValue('K'.$row , $arrayItem['Total_Credit']['VEC'])
        //                ->setCellValue('L'.$row ,$arrayItem['Total_Credit']['IKS'])
        //                ->setCellValue('M'.$row ,$arrayItem['Total_Credit']['OJT'])
        //                ->setCellValue('N'.$row , $arrayItem['Total_Credit']['FP'])
        //                ->setCellValue('O'.$row , $arrayItem['Total_Credit']['CEP'])
        //                ->setCellValue('P'.$row ,$arrayItem['Total_Credit']['CC'])
        //                ->setCellValue('Q'.$row ,$arrayItem['Total_Credit']['RP'])
        //                ->setCellValue('R'.$row , $arrayItem->Total_Sem_Credit);

        //                 $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':R'.$row)->applyFromArray($evenRow);

        //                 $this->spreadsheet->getActiveSheet()->getStyle('A'.$row.':R'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        //                // Set the height of row 1 to 30
        //                 $this->spreadsheet->getActiveSheet()->getRowDimension($row)->setRowHeight(30);
        //            }

        //             $row++;
        //  }

    
            
        //  }
        //  else
        //  {
        //      $url=base_url('reportCheckDetails');
        //      echo "<script>
        //      alert('Error,Try After Some Time..');
        //      window.location.href ='$url';
        //      </script>"; 
        //  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////

        $fileName="TeachingPeriod.xlsx";
        
        // Specify the directory path where you want to save the file
        $directory ='assets/adminFiles/';

        // Create the directory if it doesn't exist
        if (!is_dir($directory)) 
        {
            mkdir($directory, 0777, true);
        }

        // Set the file path within the directory
        $filePath = $directory . $fileName;

        $writer = new Xlsx( $this->spreadsheet);
        $writer->save($filePath);
        header("Content-Type: application/vnd.ms-excel");
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length:' . filesize($filePath));
        flush();
        readfile($filePath);
        exit;
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   
 

}