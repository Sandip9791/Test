<?php

namespace App\Controllers;

use App\Models\CommitteeLogin_Model;
// use App\Controllers\SaveUplodedFile_HOD;
use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;

class Committee extends BaseController
{
    public $test, $save;

    public function __construct()
    {
        $this->test = new CommitteeLogin_Model;
        // $this->save = new SaveUplodedFile_HOD();
        $this->id = new UniqueID();
    }
/*************************************************************/ 
    public function exam_2_5_1()
    {
        $session = \Config\Services::session();

        if ($session->has('committee_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

             //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("Committee/Exam/exam_2_5_1");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_exam_2_5_1()
    {
        if($this->request->getMethod()== 'post')
        {
            $year = $this->request->getPost('year');
            $semester = $this->request->getPost('semester');
            $program_name = $this->request->getPost('program_name');
            $program_code = $this->request->getPost('program_code');
            $last_date_sem_end = $this->request->getPost('last_date_sem_end');
            $date_of_dec = $this->request->getPost('date_of_dec');
            
            $examination_tt = $_FILES['examination_tt'];
            $result_sheet = $_FILES['result_sheet'];
            $policy_document = $_FILES['policy_document'];
            $report_from_COE = $_FILES['report_from_COE'];

            $document =
            [
               "Committe_id"=>"1",
               "year"=>$year,
               "semester"=>$semester,
               "program_name"=>$program_name,
               "program_code"=>$program_code,
               "last_date_sem_end"=>$last_date_sem_end,
               "date_of_dec"=>$date_of_dec,
               "Examination_time_table"=>
               [
                'Name' => $examination_tt['name'],
                'Type' => $examination_tt['type'],
                'Content' => new Binary(file_get_contents($examination_tt['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Result_Sheet"=>
               [
                'Name' => $result_sheet['name'],
                'Type' => $result_sheet['type'],
                'Content' => new Binary(file_get_contents($result_sheet['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Policy_document"=>
               [
                'Name' => $policy_document['name'],
                'Type' => $policy_document['type'],
                'Content' => new Binary(file_get_contents($policy_document['tmp_name']), Binary::TYPE_GENERIC),
               ],
               "Report_from_COE"=>
               [
                'Name' => $report_from_COE['name'],
                'Type' => $report_from_COE['type'],
                'Content' => new Binary(file_get_contents($report_from_COE['tmp_name']), Binary::TYPE_GENERIC),
               ],


            ];

            if (isset($document) && !empty($document)) 
            {
                $committee = array('$set' =>['exam_2_5_1'=>$document]);
    
                if ($this->test->saveData($committee)) 
                {
                    $url = base_url('exam_2_5_1') ;
                    echo "<script>
                       alert('Your Profile Is Updated Successfully...');
                       window.location.href ='$url';
                     </script>";
                } 
                else 
                {
                    $url = base_url('exam_2_5_1');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('committeeProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('committeeProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }



/*************************************************************/ 
    public function exam_2_5_2()
    {
        $session = \Config\Services::session();

        if ($session->has('committee_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

            //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("Committee/Exam/exam_2_5_2");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_exam_2_5_2()
    {
        if($this->request->getMethod()== 'post')
        {
            $Number_of_complaints = $this->request->getPost('Number_of_complaints');
            $Number_of_Students = $this->request->getPost('Number_of_Students');
            
            $Minutes_of_Grievance = $_FILES['Minutes_of_Grievance'];

            $document =
            [
                // "Committe_id"=>"1",
                "Number_of_complaints"=>$Number_of_complaints,
                "Number_of_Students"=>$Number_of_Students,

                "Minutes_of_Grievance"=>
                [
                    'Name' => $Minutes_of_Grievance['name'],
                    'Type' => $Minutes_of_Grievance['type'],
                    'Content' => new Binary(file_get_contents($Minutes_of_Grievance['tmp_name']), Binary::TYPE_GENERIC),
                ],

            ];

            if (isset($document) && !empty($document)) 
            {
                $committee = array('$set' =>['exam_2_5_2'=>$document]);

                if ($this->test->saveData($committee)) 
                {
                    $url = base_url('exam_2_5_2') ;
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('exam_2_5_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('committeeProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('committeeProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


/*****************************************************************************************/
    public function exam_2_5_3()
    {
        $session = \Config\Services::session();

        if ($session->has('committee_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

            //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("Committee/Exam/exam_2_5_3");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_exam_2_5_3()
    {
        if($this->request->getMethod()== 'post')
        {
            $Examination_Procedure = $this->request->getPost('Examination_Procedure');
            $Process_Integrating_IT = $this->request->getPost('Process_Integrating_IT');
            $Continuous_Internal = $this->request->getPost('Continuous_Internal');

            $document =
            [
                // "Committe_id"=>"1",
                "Examination_Procedure"=>$Examination_Procedure,
                "Process_Integrating_IT"=>$Process_Integrating_IT,
                "Continuous_Internal"=>$Continuous_Internal,
            ];

            if (isset($document) && !empty($document)) 
            {
                $committee = array('$set' =>['exam_2_5_3'=>$document]);

                if ($this->test->saveData($committee)) 
                {
                    $url = base_url('exam_2_5_3') ;
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('exam_2_5_3');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('committeeProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('committeeProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    /*************************************************************/ 
    public function exam_2_6_2()
    {
        $session = \Config\Services::session();

        if ($session->has('committee_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

            //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("Committee/Exam/exam_2_6_2");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_exam_2_6_2()
    {
        if($this->request->getMethod()== 'post')
        {
            $Program_Code = $this->request->getPost('Program_Code');
            $Program_Name = $this->request->getPost('Program_Name');
            $Fresh_Student_appeared = $this->request->getPost('Fresh_Student_appeared');
            $Passed_in_Final = $this->request->getPost('Passed_in_Final');
            $Percentage_of_Passing = $this->request->getPost('Percentage_of_Passing');
            
            $Annual_report = $_FILES['Annual_report'];
            $Certified_report = $_FILES['Certified_report'];

            $document =
            [
                // "Committe_id"=>"1",
                "Program_Code"=>$Program_Code,
                "Program_Name"=>$Program_Name,
                "Fresh_Student_appeared"=>$Fresh_Student_appeared,
                "Passed_in_Final"=>$Passed_in_Final,
                "Percentage_of_Passing"=>$Percentage_of_Passing,

                "Annual_report"=>
                [
                    'Name' => $Annual_report['name'],
                    'Type' => $Annual_report['type'],
                    'Content' => new Binary(file_get_contents($Annual_report['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Certified_report"=>
                [
                    'Name' => $Certified_report['name'],
                    'Type' => $Certified_report['type'],
                    'Content' => new Binary(file_get_contents($Certified_report['tmp_name']), Binary::TYPE_GENERIC),
                ],

            ];

            if (isset($document) && !empty($document)) 
            {
                $committee = array('$set' =>['exam_2_6_2'=>$document]);

                if ($this->test->saveData($committee)) 
                {
                    $url = base_url('exam_2_6_2') ;
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('exam_2_6_2');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('committeeProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('committeeProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


/*****************************************************************************************/
/*************************************************************/
//Library
    public function library_3_4_5()
    {
        $session = \Config\Services::session();

        if ($session->has('committee_user')) 
        {
            //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

            //Save File
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
            //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

            return view("Committee/Library/library_3_4_5");
        } 
        else 
        {
            $url = base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>";
        }
    }

    public function save_library_3_4_5()
    {
        if($this->request->getMethod()== 'post')
        {
            $Year = $this->request->getPost('Year');
            $Citations_in_Scopus = $this->request->getPost('Citations_in_Scopus');
            $Citations_in_Web_of_Science = $this->request->getPost('Citations_in_Web_of_Science');
            $Publications_in_Scopus = $this->request->getPost('Publications_in_Scopus');
            $Publications_in_Web_of_Science = $this->request->getPost('Publications_in_Web_of_Science');
            $Average_Citation_index = $this->request->getPost('Average_Citation_index');
            $Email_ID = $this->request->getPost('Email_ID');
            

            $document =
            [
                // "Committe_id"=>"1",
                "Year"=>$Year,
                "Citations_in_Scopus"=>$Citations_in_Scopus,
                "Citations_in_Web_of_Science"=>$Citations_in_Web_of_Science,
                "Publications_in_Scopus"=>$Publications_in_Scopus,
                "Publications_in_Web_of_Science"=>$Publications_in_Web_of_Science,
                "Average_Citation_index"=>$Average_Citation_index,
                "Email_ID"=>$Email_ID,

            ];

            if (isset($document) && !empty($document)) 
            {
                $committee = array('$set' =>['library_3_4_5'=>$document]);

                if ($this->test->saveData($committee)) 
                {
                    $url = base_url('library_3_4_5') ;
                    echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>";
                } 
                else 
                {
                    $url = base_url('library_3_4_5');
                    echo "<script>
                            alert('Your Request Is Not Process, Please Refill The Form !!!');
                            window.location.href ='$url';
                        </script>";
                }
            } 
            else 
            {
                $url = base_url('committeeProf') ;
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>";
            }
        }
        else
        {
            $url=base_url('committeeProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }


/*****************************************************************************************/
public function library_3_4_6()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Library/library_3_4_6");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_library_3_4_6()
{
    if($this->request->getMethod()== 'post')
    {
        $Year = $this->request->getPost('Year');
        $h_index_scopus = $this->request->getPost('h_index_scopus');
        $h_index_Web_of_Science = $this->request->getPost('h_index_Web_of_Science');
        $Calculate = $this->request->getPost('Calculate');

        $document =
        [
            // "Committe_id"=>"1",
            "Year"=>$Year,
            "h_index_scopus"=>$h_index_scopus,
            "h_index_Web_of_Science"=>$h_index_Web_of_Science,
            "Calculate"=>$Calculate,
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['library_3_4_6'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('library_3_4_6') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('library_3_4_6');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
public function library_4_2_1()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Library/library_4_2_1");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_library_4_2_1()
{
    if($this->request->getMethod()== 'post')
    {
        $Describe = $this->request->getPost('Describe');

        $Automated_with_digital = $_FILES['Automated_with_digital'];
        $Adequate_subscriptions = $_FILES['Adequate_subscriptions'];
        $Footfall_of_Teachers = $_FILES['Footfall_of_Teachers'];
        $Footfall_of_Students = $_FILES['Footfall_of_Students'];

        $document =
        [
            // "Committe_id"=>"1",
            "Describe"=>$Describe,
            "Automated_with_digital"=>
            [
                'Name' => $Automated_with_digital['name'],
                'Type' => $Automated_with_digital['type'],
                'Content' => new Binary(file_get_contents($Automated_with_digital['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Adequate_subscriptions"=>
            [
                'Name' => $Adequate_subscriptions['name'],
                'Type' => $Adequate_subscriptions['type'],
                'Content' => new Binary(file_get_contents($Adequate_subscriptions['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Footfall_of_Teachers"=>
            [
                'Name' => $Footfall_of_Teachers['name'],
                'Type' => $Footfall_of_Teachers['type'],
                'Content' => new Binary(file_get_contents($Footfall_of_Teachers['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Footfall_of_Students"=>
            [
                'Name' => $Footfall_of_Students['name'],
                'Type' => $Footfall_of_Students['type'],
                'Content' => new Binary(file_get_contents($Footfall_of_Students['tmp_name']), Binary::TYPE_GENERIC),
            ],

        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['library_4_2_1'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('library_4_2_1') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('library_4_2_1');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
public function library_4_2_2()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Library/library_4_2_2");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_library_4_2_2()
{
    if($this->request->getMethod()== 'post')
    {
        $Year = $this->request->getPost('Year');

        $Upload_Filled_Template = $_FILES['Upload_Filled_Template'];
        $Audited_income = $_FILES['Audited_income'];

        $document =
        [
            // "Committe_id"=>"1",
            "Year"=>$Year,
            "Upload_Filled_Template"=>
            [
                'Name' => $Upload_Filled_Template['name'],
                'Type' => $Upload_Filled_Template['type'],
                'Content' => new Binary(file_get_contents($Upload_Filled_Template['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Audited_income"=>
            [
                'Name' => $Audited_income['name'],
                'Type' => $Audited_income['type'],
                'Content' => new Binary(file_get_contents($Audited_income['tmp_name']), Binary::TYPE_GENERIC),
            ],
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['library_4_2_2'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('library_4_2_2') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('library_4_2_2');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
                            //Office
/*****************************************************************************************/
public function office_2_1_1()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_2_1_1");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_2_1_1()
{
    if($this->request->getMethod()== 'post')
    {
        $Program_Name = $this->request->getPost('Program_Name');
        $Program_Code = $this->request->getPost('Program_Code');
        $Academic_Year = $this->request->getPost('Academic_Year');
        $Seats_Sanctioned = $this->request->getPost('Seats_Sanctioned');
        $Students_Admitted = $this->request->getPost('Students_Admitted');

        $Approval_of_Sanction = $_FILES['Approval_of_Sanction'];
        $Final_Admission = $_FILES['Final_Admission'];

        $document =
        [
            // "Committe_id"=>"1",
            "Program_Name"=>$Program_Name,
            "Program_Code"=>$Program_Code,
            "Academic_Year"=>$Academic_Year,
            "Seats_Sanctioned"=>$Seats_Sanctioned,
            "Students_Admitted"=>$Students_Admitted,
            "Approval_of_Sanction"=>
            [
                'Name' => $Approval_of_Sanction['name'],
                'Type' => $Approval_of_Sanction['type'],
                'Content' => new Binary(file_get_contents($Approval_of_Sanction['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Final_Admission"=>
            [
                'Name' => $Final_Admission['name'],
                'Type' => $Final_Admission['type'],
                'Content' => new Binary(file_get_contents($Final_Admission['tmp_name']), Binary::TYPE_GENERIC),
            ],
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_2_1_1'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_2_1_1') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_2_1_1');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
public function office_2_1__2_2()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_2_1__2_2");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_2_1__2_2()
{
    if($this->request->getMethod()== 'post')
    {
        $Name_p = $this->request->getPost('Name_p');
        $ID_number_p = $this->request->getPost('ID_number_p');
        $Email_p = $this->request->getPost('Email_p');
        $Designation_p = $this->request->getPost('Designation_p');
        $Date_of_joining_p = $this->request->getPost('Date_of_joining_p');
        
        $Name_l = $this->request->getPost('Name_l');
        $ID_number_l = $this->request->getPost('ID_number_l');
        $Email_l = $this->request->getPost('Email_l');
        $Gender_l = $this->request->getPost('Gender_l');
        $Designation_l = $this->request->getPost('Designation_l');
        $Date_of_joining_l = $this->request->getPost('Date_of_joining_l');
        $Date_of_leaving_l = $this->request->getPost('Date_of_leaving_l');


        $document =
        [
            "Full_time_teachers_presently_working"=>
            [
                "Name_p"=>$Name_p,
                "ID_number_p"=>$ID_number_p,
                "Email_p"=>$Email_p,
                "Designation_p"=>$Designation_p,
                "Date_of_joining_p"=>$Date_of_joining_p,  
            ],
            // "Committe_id"=>"1",
            "Full_time_teachers_who_left"=>
            [
                "Name_l"=>$Name_l,
                "ID_number_l"=>$ID_number_l,
                "Email_l"=>$Email_l,
                "Gender_l"=>$Gender_l,
                "Designation_l"=>$Designation_l,  
                "Date_of_joining_l"=>$Date_of_joining_l,  
                "Date_of_leaving_l"=>$Date_of_leaving_l,  
            ],
            
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_2_1__2_2'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_2_1__2_2') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_2_1__2_2');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}

/******************************************************************************** */
public function office_2_1_2()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_2_1_2");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_2_1_2()
{
    if($this->request->getMethod()== 'post')
    {
        $Academic_Year = $this->request->getPost('Academic_Year');

        $SC_emarked = $this->request->getPost('SC_emarked');
        $ST_emarked = $this->request->getPost('ST_emarked');
        $OBC_emarked = $this->request->getPost('OBC_emarked');
        $GENERAL_emarked = $this->request->getPost('GENERAL_emarked');
        $Divyanjan_emarked = $this->request->getPost('Divyanjan_emarked');
        $Other_emarked = $this->request->getPost('Other_emarked');


        $SC_admitted = $this->request->getPost('SC_admitted');
        $ST_admitted = $this->request->getPost('ST_admitted');
        $OBC_admitted = $this->request->getPost('OBC_admitted');
        $GENERAL_admitted = $this->request->getPost('GENERAL_admitted');
        $Divyanjan_admitted = $this->request->getPost('Divyanjan_admitted');
        $Other_admitted = $this->request->getPost('Other_admitted');

        $Letter_issued_by_Government = $_FILES['Letter_issued_by_Government'];
        $Final_Admission_List = $_FILES['Final_Admission_List'];

        $document =
        [
            
            "Academic_Year"=>$Academic_Year,
            // "Committe_id"=>"1",
            "Number_of_seats_emarked_for_reserved_category"=>
            [
                "SC"=>$SC_emarked,
                "ST"=>$ST_emarked,
                "OBC"=>$OBC_emarked,
                "GENERAL"=>$GENERAL_emarked,
                "Divyanjan"=>$Divyanjan_emarked,
                "Other"=>$Other_emarked,
            ],
            "Number_of_seats_admitted_from_reserved_category"=>
            [
                "SC"=>$SC_admitted,
                "ST"=>$ST_admitted,
                "OBC"=>$OBC_admitted,
                "GENERAL"=>$GENERAL_admitted,
                "Divyanjan"=>$Divyanjan_admitted,
                "Other"=>$Other_admitted,
            ],
            "Letter_issued_by_Government"=>
            [
                'Name' => $Letter_issued_by_Government['name'],
                'Type' => $Letter_issued_by_Government['type'],
                'Content' => new Binary(file_get_contents($Letter_issued_by_Government['tmp_name']), Binary::TYPE_GENERIC),
            ],
            "Final_Admission_List"=>
            [
                'Name' => $Final_Admission_List['name'],
                'Type' => $Final_Admission_List['type'],
                'Content' => new Binary(file_get_contents($Final_Admission_List['tmp_name']), Binary::TYPE_GENERIC),
            ],
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_2_1_2'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_2_1_2') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_2_1_2');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
public function office_2_2_2()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_2_2_2");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_2_2_2()
{
    if($this->request->getMethod()== 'post')
    {
        $Name_of_the_course = $this->request->getPost('Name_of_the_course');
        $Class = $this->request->getPost('Class');
        $Academic_Year = $this->request->getPost('Academic_Year');
        $Link_to_Audited_Statment = $this->request->getPost('Link_to_Audited_Statment');

        $Upload_the_list = $_FILES['Upload_the_list'];

        $document =
        [
            
            "Name_of_the_course"=>$Name_of_the_course,
            "Class"=>$Class,
            "Academic_Year"=>$Academic_Year,
            "Link_to_Audited_Statment"=>$Link_to_Audited_Statment,
            // "Committe_id"=>"1",

            "Upload_the_list"=>
            [
                'Name' => $Upload_the_list['name'],
                'Type' => $Upload_the_list['type'],
                'Content' => new Binary(file_get_contents($Upload_the_list['tmp_name']), Binary::TYPE_GENERIC),
            ],
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_2_2_2'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_2_2_2') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_2_2_2');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
public function office_6_4_2()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_6_4_2");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_6_4_2()
{
    if($this->request->getMethod()== 'post')
    {
        $Academic_Year = $this->request->getPost('Academic_Year');
        $Type = $this->request->getPost('Type');
        $Government_body = $this->request->getPost('Government_body');
        $Purpose_of_grant = $this->request->getPost('Purpose_of_grant');
        $Grants_in_Rs = $this->request->getPost('Grants_in_Rs');
        $Link_to_Audited_Statment = $this->request->getPost('Link_to_Audited_Statment');

        $document =
        [
            
            "Academic_Year"=>$Academic_Year,
            "Type"=>$Type,
            "Government_body"=>$Government_body,
            "Purpose_of_grant"=>$Purpose_of_grant,
            "Grants_in_Rs"=>$Grants_in_Rs,
            "Link_to_Audited_Statment"=>$Link_to_Audited_Statment,
        ];

        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_6_4_2'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_6_4_2') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_6_4_2');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}


/*****************************************************************************************/
//office_412_422_441
public function office_412_422_441()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/office_412_422_441");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_office_412_422_441()
{
    if($this->request->getMethod()== 'post')
    {
        $Year_Infrastructure = $this->request->getPost('Year_Infrastructure');
        $Expenditure_Infrastructure = $this->request->getPost('Expenditure_Infrastructure');
        $Total_Expenditure = $this->request->getPost('Total_Expenditure');
        $Percentage_Infrastructure = $this->request->getPost('Percentage_Infrastructure');
        $Audited_Infrastructure = $_FILES['Audited_Infrastructure'];

        $Expenditure_Books = $this->request->getPost('Expenditure_Books');
        $Percentage_Books = $this->request->getPost('Percentage_Books');
        $Audited_Books = $_FILES['Audited_Books'];

        $Expenditure_physical_facilities = $this->request->getPost('Expenditure_physical_facilities');
        $Expenditure_academic_facilities = $this->request->getPost('Expenditure_academic_facilities');
        $Audited_Physical_Facilites = $_FILES['Audited_Physical_Facilites'];


        $document =
        [
            "Infrastructure_4_1_2"=>[
                "Year"=>$Year_Infrastructure,
                "Amount_of_Expenditure_Infrastructure"=>$Expenditure_Infrastructure,
                "Total_Expenditure"=>$Total_Expenditure,
                "Percentage"=>$Percentage_Infrastructure,
                "Audited_income_Expenditure"=>
                [
                    'Name' => $Audited_Infrastructure['name'],
                    'Type' => $Audited_Infrastructure['type'],
                    'Content' => new Binary(file_get_contents($Audited_Infrastructure['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],
            "Books_4_2_2"=>[
                "Amount_of_Expenditure_Infrastructure"=>$Expenditure_Books,
                "Percentage"=>$Percentage_Books,
                "Audited_Expenditure_statement"=>
                [
                    'Name' => $Audited_Books['name'],
                    'Type' => $Audited_Books['type'],
                    'Content' => new Binary(file_get_contents($Audited_Books['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],
            "Physical_Facilites_4_4_1"=>[
                "Expenditure_physical_facilities"=>$Expenditure_physical_facilities,
                "Expenditure_academic_facilities"=>$Expenditure_academic_facilities,
                "Audited_Expenditure_statement"=>
                [
                    'Name' => $Audited_Physical_Facilites['name'],
                    'Type' => $Audited_Physical_Facilites['type'],
                    'Content' => new Binary(file_get_contents($Audited_Physical_Facilites['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],
    
        ];


        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['office_412_422_441'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('office_412_422_441') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('office_412_422_441');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}
/**********************************************************************************/
// physical_facilities 
public function physical_facilities()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/physical_facilities");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_physical_facilities()
{
    if($this->request->getMethod()== 'post')
    {
        

        $document =
        [
            
    
        ];


        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['physical_facilities'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('physical_facilities') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('physical_facilities');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}

/*****************************************************************************/

//physical_facilities_environment
public function physical_facilities_environment()
{
    $session = \Config\Services::session();

    if ($session->has('committee_user')) 
    {
        //$data['documents']=$this->test->fetchData($key='HOD_1_1_1');

        //Save File
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Programme_Outcomes');
        //  $this->save->saveFile_HOD($key='HOD_1_1_1',$subkey='Course_Outcomes');

        return view("Committee/Office/physical_facilities_environment");
    } 
    else 
    {
        $url = base_url();
        echo "<script>
        alert('Your Session Is Close, Please Login !!!');
        window.location.href ='$url';
        </script>";
    }
}

public function save_physical_facilities_environment()
{
    if($this->request->getMethod()== 'post')
    {
        $Solar_Energy = $this->request->getPost('Solar_Energy');
        $Solar1 = $_FILES['Solar1'];
        $Solar2 = $_FILES['Solar2'];
        
        $Bio_gas = $this->request->getPost('Bio_gas');
        $Bio1 = $_FILES['Bio1'];
        $Bio2 = $_FILES['Bio2'];

        $Wheeling_to_the_grid = $this->request->getPost('Wheeling_to_the_grid');
        $Wheeling1 = $_FILES['Wheeling1'];
        $Wheeling2 = $_FILES['Wheeling2'];
        
        $Sensor_based_energy_conservation = $this->request->getPost('Sensor_based_energy_conservation');
        $Sensor1 = $_FILES['Sensor1'];
        $Sensor2 = $_FILES['Sensor2'];
        
        $Use_of_LED_bulbs = $this->request->getPost('Use_of_LED_bulbs');
        $LED1 = $_FILES['LED1'];
        $LED2 = $_FILES['LED2'];

        $Wind_mill = $this->request->getPost('Wind_mill');
        $Wind1 = $_FILES['Wind1'];
        $Wind2 = $_FILES['Wind2'];
        
        $Any_other = $this->request->getPost('Any_other');
        $other1 = $_FILES['other1'];
        $other2 = $_FILES['other2'];
        
        $document =
        [
            "Solar_Energy"=>[
                "Solar_Energy"=>$Solar_Energy,
                "Solar1"=>
                [
                    'Name' => $Solar1['name'],
                    'Type' => $Solar1['type'],
                    'Content' => new Binary(file_get_contents($Solar1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Solar2"=>
                [
                    'Name' => $Solar2['name'],
                    'Type' => $Solar2['type'],
                    'Content' => new Binary(file_get_contents($Solar2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],

            "Bio_gas"=>[
                "Bio_gas"=>$Bio_gas,
                "Bio1"=>
                [
                    'Name' => $Bio1['name'],
                    'Type' => $Bio1['type'],
                    'Content' => new Binary(file_get_contents($Bio1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Bio2"=>
                [
                    'Name' => $Bio2['name'],
                    'Type' => $Bio2['type'],
                    'Content' => new Binary(file_get_contents($Bio2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],

            "Wheeling_to_the_grid"=>[
                "Wheeling_to_the_grid"=>$Wheeling_to_the_grid,
                "Wheeling1"=>
                [
                    'Name' => $Wheeling1['name'],
                    'Type' => $Wheeling1['type'],
                    'Content' => new Binary(file_get_contents($Wheeling1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Wheeling2"=>
                [
                    'Name' => $Wheeling2['name'],
                    'Type' => $Wheeling2['type'],
                    'Content' => new Binary(file_get_contents($Wheeling2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],

            "Sensor_based_energy_conservation"=>[
                "Sensor_based_energy_conservation"=>$Sensor_based_energy_conservation,
                "Sensor1"=>
                [
                    'Name' => $Sensor1['name'],
                    'Type' => $Sensor1['type'],
                    'Content' => new Binary(file_get_contents($Sensor1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Sensor2"=>
                [
                    'Name' => $Sensor2['name'],
                    'Type' => $Sensor2['type'],
                    'Content' => new Binary(file_get_contents($Sensor2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],

            "Use_of_LED_bulbs_power_efficient_equipment"=>[
                "Use_of_LED_bulbs"=>$Use_of_LED_bulbs,
                "LED1"=>
                [
                    'Name' => $LED1['name'],
                    'Type' => $LED1['type'],
                    'Content' => new Binary(file_get_contents($LED1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "LED2"=>
                [
                    'Name' => $LED2['name'],
                    'Type' => $LED2['type'],
                    'Content' => new Binary(file_get_contents($LED2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],
            
            "Wind_mill"=>[
                "Wind_mill"=>$Wind_mill,
                "Wind1"=>
                [
                    'Name' => $Wind1['name'],
                    'Type' => $Wind1['type'],
                    'Content' => new Binary(file_get_contents($Wind1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "Wind2"=>
                [
                    'Name' => $Wind2['name'],
                    'Type' => $Wind2['type'],
                    'Content' => new Binary(file_get_contents($Wind2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],


            "Any_other"=>[
                "Any_other"=>$Any_other,
                "other1"=>
                [
                    'Name' => $other1['name'],
                    'Type' => $other1['type'],
                    'Content' => new Binary(file_get_contents($other1['tmp_name']), Binary::TYPE_GENERIC),
                ],
                "other2"=>
                [
                    'Name' => $other2['name'],
                    'Type' => $other2['type'],
                    'Content' => new Binary(file_get_contents($other2['tmp_name']), Binary::TYPE_GENERIC),
                ],
            ],

        ];


        if (isset($document) && !empty($document)) 
        {
            $committee = array('$set' =>['physical_facilities_environment'=>$document]);

            if ($this->test->saveData($committee)) 
            {
                $url = base_url('physical_facilities_environment') ;
                echo "<script>
                alert('Your Profile Is Updated Successfully...');
                window.location.href ='$url';
                </script>";
            } 
            else 
            {
                $url = base_url('physical_facilities_environment');
                echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>";
            }
        } 
        else 
        {
            $url = base_url('committeeProf') ;
            echo "<script>
                alert('Your Request Is Not Process, Please Refill The Form !!!');
                window.location.href ='$url';
            </script>";
        }
    }
    else
    {
        $url=base_url('committeeProf');
        echo "<script>
            alert('Unable To Process Your Request Please Try Again Some Time !!!');
            window.location.href ='$url';
        </script>";
    }
}




}
