<?php

namespace App\Controllers;
use App\Models\Extension_Model;
use MongoDB\BSON\Binary;
use App\Controllers\UniqueID;
 

class Extension extends BaseController
{
   public  $store,$id,$save;
    public function __construct() 
    {
         $this->store=new Extension_Model();
         $this->id = new UniqueID();
    }

/********************************************************************************************************/
    public function activitiesOfForum()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {

            $data['documents']=$this->store->fetchData($key='Activities_Of_Forum');
            return view('Externsion/activitiesOfForum_view',$data);
            //return redirect()->to(base_url());
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveActivitiesOfForum()
    {
        if($this->request->getMethod()=='post')
        {
            $activity= $this->request->getPost('activity');
            $Outcome=$this->request->getPost('Outcome');
            $noParticipants=$this->request->getPost('noParticipants');
            $forum=$this->request->getPost('forum');
            $other=$this->request->getPost('other');
            $conducte=$this->request->getPost('conducte');

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Upload_Attendance");

            $report=$this->request->getFile('report');
            $report_Name=$this->id->FileValidation_ManyDoc($report,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Upload_Report");

            $geotag1=$this->request->getFile('geotag1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Geotag_Photo1");  

            $geotag2=$this->request->getFile('geotag2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Geotag_Photo2");  

            $nongeotag1=$this->request->getFile('NonGeotag1');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="NonGeotag_Photo1");  

            $nongeotag2=$this->request->getFile('NonGeotag2');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="NonGeotag_Photo2");  

          
          
            $u_id = $this->id->generate();

            if($forum === "Other")
            {
                $forum=$other;
            }
            
            $document=
            [
                "Activities_Of_Forum_id"=>"$u_id", 
                "Name_Of_The_Extension_Activity_Orginised"=>$activity,
                "Outcome"=>$Outcome,
                "Number_Of_Participants"=>$noParticipants,
                "Forum"=>$forum,
                "Activity_Conducted"=>$conducte,
                "Upload_Attendance" =>$attendance_Name,
                "Upload_Report" =>$report_Name,
                "Geotag_Photo1"=>$geotag1_Name,
                "Geotag_Photo2"=>$geotag2_Name,
                "NonGeotag_Photo1"=>$nongeotag1_Name,
                "NonGeotag_Photo2"=>$nongeotag2_Name
            ];

            if(isset($document) && !empty($document))
            {
                $studyTour = array('$push' =>['Activities_Of_Forum'=>$document]);

                if($this->store->saveData($studyTour))
                {
                    $url=base_url('activitiesOfForum');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                }
                else
                {
                    $url=base_url('activitiesOfForum');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('activitiesOfForum');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }

    public function updateActivitiesOfForum()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber= $this->request->getPost('srnumber');
            $activity= $this->request->getPost('activity');
            $Outcome=$this->request->getPost('Outcome');
            $noParticipants=$this->request->getPost('noParticipants');
            $forum=$this->request->getPost('forum');
            $other=$this->request->getPost('other');
            $conducte=$this->request->getPost('conducte');

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Upload_Attendance");

            $report=$this->request->getFile('report');
            $report_Name=$this->id->FileValidation_ManyDoc($report,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Upload_Report");

            $geotag1=$this->request->getFile('geotag1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Geotag_Photo1");  

            $geotag2=$this->request->getFile('geotag2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="Geotag_Photo2");  

            $nongeotag1=$this->request->getFile('NonGeotag1');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="NonGeotag_Photo1");  

            $nongeotag2=$this->request->getFile('NonGeotag2');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Activities_Of_Forum",$subkey="NonGeotag_Photo2");  

            
            if($forum === "Other")
            {
                $forum=$other;
            }
            
            $document=
            [
            
                "Activities_Of_Forum_id"=>"$srnumber", 
                "Name_Of_The_Extension_Activity_Orginised"=>$activity,
                "Outcome"=>$Outcome,
                "Number_Of_Participants"=>$noParticipants,
                "Forum"=>$forum,
                "Activity_Conducted"=>$conducte,
                "Upload_Attendance" =>$attendance_Name,
                "Upload_Report" =>$report_Name,
                "Geotag_Photo1"=>$geotag1_Name,
                "Geotag_Photo2"=>$geotag2_Name,
                "NonGeotag_Photo1"=>$nongeotag1_Name,
                "NonGeotag_Photo2"=>$nongeotag2_Name
            ];

            if(isset($document) && !empty($document))
            {
                if($this->store->updateData_ActivitiesOfForum( $document, $srnumber))
                {
                    $url=base_url('activitiesOfForum');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                        </script>"; 
                }
                else
                {
                    $url=base_url('activitiesOfForum');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('activitiesOfForum');
                echo "<script>
                    alert('Your Request Is Not Process, Please Refill The Form !!!');
                    window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }

    public function deleteActivitiesOfForum()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='Activities_Of_Forum',$subkey='Activities_Of_Forum_id',$srnumber))
            {
                $url=base_url('activitiesOfForum');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('activitiesOfForum');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
                $url=base_url('teaProf');
                echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }

/********************************************************************************************************/
    public function sensitization()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents'] = $this->store->fetchData($key='Sensetization_Of_Student');
            return view('Externsion/sensitization_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveSensitization()
    {
        if($this->request->getMethod()=='post')
        {
            $details = $this->request->getPost('details');

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Attendance");

            $notice=$this->request->getFile('notice');
            $notice_Name=$this->id->FileValidation_ManyDoc($notice,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Notice");

            $geotag1=$this->request->getFile('geotagPhoto1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Geotag_Photo1");  

            $geotag2=$this->request->getFile('geotagPhoto2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Geotag_Photo2");  

            $nongeotag1=$this->request->getFile('nongeotagPhoto1');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="NonGeotag_Photo1");  

            $nongeotag2=$this->request->getFile('nongeotagPhoto2');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="NonGeotag_Photo2");  

         

            $u_id = $this->id->generate();
            $document=
            [
                
                "Sensetization_Of_Student_id"=>"$u_id",
                "Details" => $details,
                "Attendance" =>$attendance_Name,
                "Notice" =>$notice_Name,
                "Geotag_Photo1"=>$geotag1_Name,
                "Geotag_Photo2"=>$geotag2_Name,
                "NonGeotag_Photo1"=>$nongeotag1_Name,
                "NonGeotag_Photo2"=>$nongeotag2_Name
            ];
            
            if(isset($document) && !empty($document))
            {  
                $Sensetization_Of_Student = array('$push' =>['Sensetization_Of_Student'=>$document]);

                if($this->store->saveData($Sensetization_Of_Student))
                {
                    $url=base_url('sensitization');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('sensitization');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('sensitization');
                echo "<script>
                    alert('Your Request Is Not Process !!!);
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function updateSensitization()
    {
        if($this->request->getMethod()=='post')
        {

            $srnumber = $this->request->getPost('srnumber');
            $details = $this->request->getPost('details');

            $attendance=$this->request->getFile('attendance');
            $attendance_Name=$this->id->FileValidation_ManyDoc($attendance,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Attendance");

            $notice=$this->request->getFile('notice');
            $notice_Name=$this->id->FileValidation_ManyDoc($notice,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Notice");

            $geotag1=$this->request->getFile('geotagPhoto1');
            $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Geotag_Photo1");  

            $geotag2=$this->request->getFile('geotagPhoto2');
            $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="Geotag_Photo2");  

            $nongeotag1=$this->request->getFile('nongeotagPhoto1');
            $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="NonGeotag_Photo1");  

            $nongeotag2=$this->request->getFile('nongeotagPhoto2');
            $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Sensetization_Of_Student",$subkey="NonGeotag_Photo2");  

            $document=
            [
                
                "Sensetization_Of_Student_id"=>"$srnumber",
                "Details" => $details,
                "Attendance" =>$attendance_Name,
                "Notice" =>$notice_Name,
                "Geotag_Photo1"=>$geotag1_Name,
                "Geotag_Photo2"=>$geotag2_Name,
                "NonGeotag_Photo1"=>$nongeotag1_Name,
                "NonGeotag_Photo2"=>$nongeotag2_Name
            ];
            
            if(isset($document) && !empty($document))
            {  
                if($this->store->updateData_SensetizationOfStudent( $document, $srnumber))
                {
                    $url=base_url('sensitization');
                    echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                }
                else
                {
                    $url=base_url('sensitization');
                    echo "<script>
                        alert('Your Request Is Not Process, Please Refill The Form !!!');
                        window.location.href ='$url';
                    </script>"; 
                }
            }
            else
            {
                $url=base_url('sensitization');
                echo "<script>
                    alert('Your Request Is Not Process !!!);
                    window.location.href ='$url';
                </script>"; 
            }
            
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

    public function deleteSensitization()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='Sensetization_Of_Student',$subkey='Sensetization_Of_Student_id',$srnumber))
            {
                $url=base_url('sensitization');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('sensitization');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }
    }

/********************************************************************************************************/

    public function alumniEngagement()
    {
        $session = \Config\Services::session();
        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->store->fetchData($key='Alumni_Engagement');
            return view('Externsion/alumniEngagement_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }   
    }

    public function saveAlumniEngagement()
    {
        if($this->request->getMethod()=='post')
        {
             $activities= $this->request->getPost('activities');
             $Alumni=$this->request->getPost('Alumni');
             $mobile=$this->request->getPost('mobile');
             $designation=$this->request->getPost('designation');
             $oname=$this->request->getPost('oname');
             $other=$this->request->getPost('other');

             $rdocument=$this->request->getFile('rdocument');
             $rdocument_Name=$this->id->FileValidation_ManyDoc($rdocument,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Related_Documents");

             $geotag1=$this->request->getFile('photo1');
             $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Geotag_Photos1");  

             $geotag2=$this->request->getFile('photo2');
             $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Geotag_Photos2");  

             $nongeotag1=$this->request->getFile('photo3');
             $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Non_Geotag_Photos1");  

             $nongeotag2=$this->request->getFile('photo4');
             $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Non_Geotag_Photos2");  

             
             if($activities === "Other")
             {
                 $activities=$other;
             }

             $u_id = $this->id->generate();

             $document=
             [
                
                "Alumni_Engagement_id"=>"$u_id", 
                "Activities"=>$activities,
                "Name_Of_Alumni"=>$Alumni,
                "Mobile_Number"=>$mobile,
                "Designation"=>$designation,
                "Organization_Name"=>$oname,
                "Upload_Related_Documents"=>$rdocument_Name,
                "Upload_Geotag_Photos1" =>$geotag1_Name,
                "Upload_Geotag_Photos2" =>$geotag2_Name,
                "Upload_Non_Geotag_Photos1" => $nongeotag1_Name,
                "Upload_Non_Geotag_Photos2" => $nongeotag2_Name
             ];

             if(isset($document) && !empty($document))
             {
                $studyTour = array('$push' =>['Alumni_Engagement'=>$document]);

                 if($this->store->saveData($studyTour))
                 {
                     $url=base_url('alumniEngagement');
                     echo "<script>
                         alert('Your Profile Is Updated Successfully...');
                         window.location.href ='$url';
                         </script>"; 
                 }
                 else
                 {
                     $url=base_url('alumniEngagement');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('alumniEngagement');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }

    public function updateAlumniEngagement()
    {
        if($this->request->getMethod()=='post')
        {
            $srnumber= $this->request->getPost('srnumber');
             $activities= $this->request->getPost('activities');
             $Alumni=$this->request->getPost('Alumni');
             $yearofAward=$this->request->getPost('datepicker');
             $mobile=$this->request->getPost('mobile');
             $designation=$this->request->getPost('designation');
             $oname=$this->request->getPost('oname');
             $other=$this->request->getPost('other');
              
             $rdocument=$this->request->getFile('rdocument');
             $rdocument_Name=$this->id->FileValidation_ManyDoc($rdocument,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Related_Documents");

             $geotag1=$this->request->getFile('photo1');
             $geotag1_Name=$this->id->FileValidation_ManyDoc($geotag1,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Geotag_Photos1");  

             $geotag2=$this->request->getFile('photo2');
             $geotag2_Name=$this->id->FileValidation_ManyDoc($geotag2,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Geotag_Photos2");  

             $nongeotag1=$this->request->getFile('photo3');
             $nongeotag1_Name=$this->id->FileValidation_ManyDoc($nongeotag1,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Non_Geotag_Photos1");  

             $nongeotag2=$this->request->getFile('photo4');
             $nongeotag2_Name=$this->id->FileValidation_ManyDoc($nongeotag2,$path="./Userfiles/Teachers/Extension",$key="Alumni_Engagement",$subkey="Upload_Non_Geotag_Photos2");  

             if($activities === "Other")
             {
                 $activities=$other;
             }

             $document=
             [
                
                "Alumni_Engagement_id"=>"$srnumber", 
                "Activities"=>$activities,
                "Name_Of_Alumni"=>$Alumni,
                "Mobile_Number"=>$mobile,
                "Designation"=>$designation,
                "Organization_Name"=>$oname,
                "Upload_Related_Documents"=>$rdocument_Name,
                "Upload_Geotag_Photos1" =>$geotag1_Name,
                "Upload_Geotag_Photos2" =>$geotag2_Name,
                "Upload_Non_Geotag_Photos1" =>$nongeotag1_Name,
                "Upload_Non_Geotag_Photos2" =>$nongeotag2_Name

             ];

             if(isset($document) && !empty($document))
             {
                 if($this->store->updateData_AlumniEngagement( $document, $srnumber))
                 {
                     $url=base_url('alumniEngagement');
                     echo "<script>
                         alert('Your Profile Is Updated Successfully...');
                         window.location.href ='$url';
                         </script>"; 
                 }
                 else
                 {
                     $url=base_url('alumniEngagement');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('alumniEngagement');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }

    public function deleteAlumniEngagement()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->store->deleteData($key='Alumni_Engagement',$subkey='Alumni_Engagement_id',$srnumber))
            {
                $url=base_url('alumniEngagement');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('alumniEngagement');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }
}