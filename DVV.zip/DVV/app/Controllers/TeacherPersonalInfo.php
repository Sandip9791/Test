<?php

namespace App\Controllers;
use App\Models\TeacherPersonalInfo_Model;
use App\Libraries\DatabaseConnector;
use App\Controllers\CheckUserData;
 use App\Controllers\UniqueID;

use MongoDB\BSON\Binary;


class TeacherPersonalInfo extends BaseController
{
    private $test,$check,$save,$id;
    
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;

        $this->test=new TeacherPersonalInfo_Model();
        
         $this->id = new UniqueID();

 
    }

/********************************************************************************************************/
    // Teacher Personal Information Form View
    public function teacherForm()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fecthingData();
           return view('Teacher_Details/teacherForm_view',$data);   
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
      
    }
/********************************************************************************************************/
    // Teacher Personal Information Form Saving That Data Into Database
    public function personalData()
    {
        if($this->request->getMethod()=='post')
        {
                $title = $this->request->getPost('title');
                $fname = $this->request->getPost('fname');
                $lname = $this->request->getPost('lname');
                $mname = $this->request->getPost('mname');
        
                $gender = $this->request->getPost('gender');
                $dob = $this->request->getPost('dob');
                $email = $this->request->getPost('email');
                $mobile=$this->request->getPost('mobile');
                $adhar = $this->request->getPost('adhar');
                $category = $this->request->getPost('cat');
                $address= $this->request->getPost('address');
                $pan = $this->request->getPost('pan');

                $adocument = $this->request->getFile('adocument');
                $adocument_Name=$this->id->FileValidation($adocument,$path="./Userfiles/Teachers/Profile",$key="PID",$subkey="Adhar_Document");

                // Pan Card Validation
                $pdocument = $this->request->getFile('pdocument');
                $pdocument_Name=$this->id->FileValidation($pdocument,$path="./Userfiles/Teachers/Profile",$key="PID",$subkey="Pan_Document");

                // Cuurent Photo   Validation
                $cphoto=$this->request->getFile('cphoto');
                $cphoto_Name=$this->id->FileValidation($cphoto,$path="./Userfiles/Teachers/Profile",$key="PID",$subkey="Current_Image");

                $count= $this->collection->countDocuments();
                $id1= 110011;
                $pid= $id1 + $count;
                        
                $document = 
                [
                    '$set'=>[
                    'Title'=>$title,
                    'First_Name'=>ucwords($fname),
                    'Last_Name'=>ucwords($lname),
                    'Midd_Name'=>ucwords($mname),
                    "PID"=> array(
                    "PID"=>"PID".$pid,
                    'Gender' => $gender,
                    'DOB' => $dob,
                    'Mobile_Number' => $mobile,
                    'Email' =>$email,
                    'Category' => $category,
                    'Address' => ucwords($address),
                    'Adhar_Number' => $adhar,
                    "Adhar_Document" =>$adocument_Name ,
                    'Pan_Card_Number' => $pan,
                    "Pan_Document" =>$pdocument_Name,
                    "Current_Image" => $cphoto_Name 
                    )]
                ];

                if(isset($document) && !empty($document))
                {  
                    if($this->test->saveData($document))
                    {
                        $url=base_url('teaForm');
                        echo "<script>
                            alert('Your Profile Is Updated Successfully...');
                            window.location.href ='$url';
                            </script>"; 
                    }
                    else
                    {
                            $url=base_url('teaForm');
                            echo "<script>
                                alert('Your Request Is Not Process, Please Refill The Form !!!');
                                window.location.href ='$url';
                            </script>"; 
                    }
                }
                else
                {
                    $url=base_url();
                    echo "<script>
                        alert('Your Request Is Not Process !!!');
                        window.location.href ='$url';
                    </script>"; 
                }       
        }
        else
        {
            $url=base_url('teaForm');
            echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
            </script>";
        }   
    }

/********************************************************************************************************/
    // Teacher Profile All Data
    public function profileData()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fecthingData();
        }
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }
    
/********************************************************************************************************/
    // Teacher Awards Information Form View
    public function teacherAwards()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           $data['documents']=$this->test->fetchData($key="Teacher_Award");
            return view ('Teacher_Details/teaAwards_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
      
    }

    public function saveTeacherAwards()
    {
        if($this->request->getMethod()=='post')
        {
             $National= $this->request->getPost('National');
             $AwardNational=$this->request->getPost('AwardNational');
             $International=$this->request->getPost('International');
             $AwardInternational=$this->request->getPost('AwardInternational');


             if(isset($National) && !empty($National))
             {
                $nationaldocument=$this->request->getFile('nationaldocument');
                $nationaldocument_Name=$this->id->FileValidation_ManyDoc($nationaldocument,$path="./Userfiles/Teachers/Profile",$key="Teacher_Award",$subkey="National_Document");
             }
             else
             {
                $nationaldocument_Name="";
             }

             if(isset($International) && !empty($International))
             {
                $internationaldocument=$this->request->getFile('internationaldocument');
                $internationaldocument_Name=$this->id->FileValidation_ManyDoc($internationaldocument,$path="./Userfiles/Teachers/Profile",$key="Teacher_Award",$subkey="International_Document");
             }
             else
             {
                $internationaldocument_Name="";
             }
           

             $u_id = $this->id->generate();

             $document=
             [
                "Teacher_Award_id"=>"$u_id", 
                "National"=>$National,
                "International"=>$International,
                "National_Name_of_Award"=>$AwardNational,
                "National_Document"=>$nationaldocument_Name,
                "International_Name_of_Award"=>$AwardInternational,
                "International_Document"=>$internationaldocument_Name
             ];

             if(isset($document) && !empty($document))
             {
                $TeaAward = array('$push' =>['Teacher_Award'=>$document]);

                 if($this->test->saveData_Multi($TeaAward))
                 {
                     $url=base_url('teaAwards');
                     echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('teaAwards');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('teaAwards');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }

    public function updateTeacherAwards()
    {
        if($this->request->getMethod()=='post')
        {
             $srnumber= $this->request->getPost('srnumber');
             $National= $this->request->getPost('National');
             $AwardNational=$this->request->getPost('AwardNational');
             $International=$this->request->getPost('International');
             $AwardInternational=$this->request->getPost('AwardInternational');

             if(!empty($National) || !empty($International))
             {
                $nationaldocument=$this->request->getFile('nationaldocument');
                $nationaldocument_Name=$this->id->FileValidation_ManyDoc($nationaldocument,$path="./Userfiles/Teachers/Profile",$key="Teacher_Award",$subkey="National_Document");

                $internationaldocument=$this->request->getFile('internationaldocument');
                $internationaldocument_Name=$this->id->FileValidation_ManyDoc($internationaldocument,$path="./Userfiles/Teachers/Profile",$key="Teacher_Award",$subkey="International_Document");
             }
             else
             {
                $nationaldocument_Name="";
                $internationaldocument_Name="";
             }

             $document=
             [
                "Teacher_Award_id"=>"$srnumber", 
                "National"=>$National,
                "International"=>$International,
                "National_Name_of_Award"=>$AwardNational,
                "National_Document"=>$nationaldocument_Name,
                "International_Name_of_Award"=>$AwardInternational,
                "International_Document"=>$internationaldocument_Name
             ];

             if(isset($document) && !empty($document))
             {
                 if($this->test->updateData_TeacherAwards($document, $srnumber))
                 {
                     $url=base_url('teaAwards');
                     echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('teaAwards');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('teaAwards');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
            $url=base_url('teaProf');
                echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }

    public function deleteTeacherAwards()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Teacher_Award',$subkey='Teacher_Award_id',$srnumber))
            {
                $url=base_url('teaAwards');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('teaAwards');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
                echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }


/********************************************************************************************************/
    // Teacher Learning Information Form View
    public function teacherLearning()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
            $data['documents']=$this->test->fetchData($key="Teacher_Learning");
            return view ('Teacher_Details/teachingLearning_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }

    public function saveTeacherLearning()
    {
        if($this->request->getMethod()=='post')
        {
             $scode= $this->request->getPost('scode');
             $sname=$this->request->getPost('sname');

             $plan=$this->request->getFile('plan');
             $plan_Name=$this->id->FileValidation_ManyDoc($plan,$path="./Userfiles/Teachers/Profile",$key="Teacher_Learning",$subkey="Teaching_Plan");

             $u_id = $this->id->generate();

             $document=
             [
                "Teacher_Learning_id"=>"$u_id", 
                "Subject_Code"=>$scode,
                "Subject_Name"=>$sname,
                "Teaching_Plan"=>$plan_Name,

             ];

             if(isset($document) && !empty($document))
             {
                $TeaAward = array('$push' =>['Teacher_Learning'=>$document]);

                 if($this->test->saveData_Multi($TeaAward))
                 {
                     $url=base_url('teaLearning');
                     echo "<script>
                    alert('Your Profile Is Updated Successfully...');
                    window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('teaLearning');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('teaLearning');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }

    public function updateTeacherLearning()
    {
        if($this->request->getMethod()=='post')
        {
             $srnumber= $this->request->getPost('srnumber');
             $scode= $this->request->getPost('scode');
             $sname=$this->request->getPost('sname');

             $plan=$this->request->getFile('plan');
             $plan_Name=$this->id->FileValidation_ManyDoc($plan,$path="./Userfiles/Teachers/Profile",$key="Teacher_Learning",$subkey="Teaching_Plan");
            
             $document=
             [
                "Teacher_Learning_id"=>"$srnumber", 
                "Subject_Code"=>$scode,
                "Subject_Name"=>$sname,
                "Teaching_Plan"=>$plan_Name
             ];

             if(isset($document) && !empty($document))
             {
                 if($this->test->updateData_TeacherLearning($document, $srnumber))
                 {
                     $url=base_url('teaLearning');
                     echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('teaLearning');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('teaLearning');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                </script>";
        }
    }

    public function deleteTeacherLearning()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='Teacher_Learning',$subkey='Teacher_Learning_id',$srnumber))
            {
                $url=base_url('teaLearning');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('teaLearning');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                     alert('Unable To Process Your Request Please Try Again Some Time !!!');
                     window.location.href ='$url';
                 </script>";
        }
    }

/********************************************************************************************************/
    // Teacher Learning Information Form View
    public function fdp()
    {
        $session = \Config\Services::session();

        if ($session->has('loged_user')) 
        {
           
            $data['documents']=$this->test->fetchData($key="FDP");

            return view ('Teacher_Details/FDP_view',$data);
        } 
        else
        {
            $url=base_url();
            echo "<script>
            alert('Your Session Is Close, Please Login !!!');
            window.location.href ='$url';
            </script>"; 
        }
    }
    
    public function saveFDP()
    {
        if($this->request->getMethod()=='post')
        {
             $program= $this->request->getPost('program');
             $From= $this->request->getPost('From');
             $To=$this->request->getPost('To');
             $Institution=$this->request->getPost('Institution');

             $Certificate=$this->request->getFile('Certificate');
             $Certificate_Name=$this->id->FileValidation_ManyDoc($Certificate,$path="./Userfiles/Teachers/Profile",$key="FDP",$subkey="Certificate");


             $u_id = $this->id->generate();
            
             $document=
             [
                "FDP_id"=>"$u_id", 
                "Programs"=>$program,
                "From"=>$From,
                "To"=>$To,
                "Institution_Name_Offering_Programme"=>$Institution,
                "Certificate"=>$Certificate_Name
             ];

             if(isset($document) && !empty($document))
             {
                $fdp = array('$push' =>['FDP'=>$document]);

                 if($this->test->saveData_Multi($fdp))
                 {
                     $url=base_url('fdp');
                     echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('fdp');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('fdp');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                 </script>";
        }
    }

    public function updateFDP()
    {
        if($this->request->getMethod()=='post')
        {
             $srnumber= $this->request->getPost('srnumber');
             $program= $this->request->getPost('program');
             $From= $this->request->getPost('From');
             $To=$this->request->getPost('To');
             $Institution=$this->request->getPost('Institution');

             $Certificate=$this->request->getFile('Certificate');
             $Certificate_Name=$this->id->FileValidation_ManyDoc($Certificate,$path="./Userfiles/Teachers/Profile",$key="FDP",$subkey="Certificate");

                $document=
                [
                "FDP_id"=>"$srnumber", 
                "Programs"=>$program,
                "From"=>$From,
                "To"=>$To,
                "Institution_Name_Offering_Programme"=>$Institution,
                "Certificate"=>$Certificate_Name
                ];

             if(isset($document) && !empty($document))
             {
                 if($this->test->updateData_FDP( $document, $srnumber))
                 {
                     $url=base_url('fdp');
                     echo "<script>
                        alert('Your Profile Is Updated Successfully...');
                        window.location.href ='$url';
                    </script>"; 
                 }
                 else
                 {
                     $url=base_url('fdp');
                     echo "<script>
                         alert('Your Request Is Not Process, Please Refill The Form !!!');
                         window.location.href ='$url';
                     </script>"; 
                 }
             }
             else
             {
                 $url=base_url('fdp');
                 echo "<script>
                     alert('Your Request Is Not Process, Please Refill The Form !!!');
                     window.location.href ='$url';
                 </script>"; 
             }
        }
        else
        {
                $url=base_url('teaProf');
                 echo "<script>
                    alert('Unable To Process Your Request Please Try Again Some Time !!!');
                    window.location.href ='$url';
                 </script>";
        }
    }

    public function deleteFDP()
    {
        if($this->request->getMethod()=='post')
        { 
            $srnumber = $this->request->getPost('srnumber');
            
            if($this->test->deleteData($key='FDP',$subkey='FDP_id',$srnumber))
            {
                $url=base_url('fdp');
                echo "<script>
                alert('Data Is Deleted Successfully...');
                window.location.href ='$url';
                </script>"; 
            }
            else
            {
                $url=base_url('fdp');
                echo "<script>
                alert('Credential Not Found...');
                window.location.href ='$url';
                </script>"; 
            }
        }
        else
        {
            $url=base_url('teaProf');
                echo "<script>
                alert('Unable To Process Your Request Please Try Again Some Time !!!');
                window.location.href ='$url';
                </script>";
        }
    }

 
}
