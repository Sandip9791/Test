<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class TeacherPersonalInfo_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }

/********************************************************************************************************/    
    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result = $this->collection->updateOne($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
                return true;  
        } 
        else 
        {
            return false;
        }
    }
/**********************************************************************************************************/
    public function fecthingData()
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];
        
        $result= $this->collection->find($filter, ['projection' => ['_id'=>0,'PID'=>1,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Email'=>1,'Department'=>1,'Designation'=>1,'Teacher_Type'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

/***************************************************************************************************************/
    public function saveData_Multi($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');

        $filter = ['username' => $myusername];

        $result = $this->collection->updateMany($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;  
        } 
        else 
        {
            return false;
        }
    }

    public function fetchData($key)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result= $this->collection->find($filter, ['projection' => ['_id'=>0,"$key"=>1]]);

        $documents = [];

        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
              
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

/****************************************************************************************************************************/
    public function updateData_TeacherAwards( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Teacher_Award.Teacher_Award_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Teacher_Award.$.National"=> $document['National'],
                "Teacher_Award.$.International"=> $document['International'],
                "Teacher_Award.$.National_Name_of_Award"=> $document['National_Name_of_Award'],
                "Teacher_Award.$.National_Document"=> $document['National_Document'],
                "Teacher_Award.$.International_Name_of_Award"=> $document['International_Name_of_Award'],
               "Teacher_Award.$.International_Document"=> $document['International_Document'],
            ]
        ];
    
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }

/****************************************************************************************************************************/
    public function updateData_TeacherLearning( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Teacher_Learning.Teacher_Learning_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Teacher_Learning.$.Subject_Code"=> $document['Subject_Code'],
                "Teacher_Learning.$.Subject_Name"=> $document['Subject_Name'],
                "Teacher_Learning.$.Teaching_Plan"=> $document['Teaching_Plan'],
            ]
        ];

        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/****************************************************************************************************************************************************/

    public function updateData_FDP( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'FDP.FDP_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "FDP.$.Programs"=> $document['Programs'],
                "FDP.$.From"=> $document['From'],
                "FDP.$.To"=> $document['To'],
                "FDP.$.Institution_Name_Offering_Programme"=> $document['Institution_Name_Offering_Programme'],
                "FDP.$.Certificate"=> $document['Certificate'],
            ]
        ];

        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/****************************************************************************************************************************************************/

    // Deleting  Data Of Teacher
    public function deleteData($key,$subkey,$srnumber)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');

        $filter = ['username' => $myusername];

        // Use the $pull operator to remove the specific subdocument from the  array
        $updateQuery = ['$pull' => ["$key" => ["$subkey" => $srnumber]]];

        // Perform the update operation
        $result = $this->collection->updateOne($filter, $updateQuery);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }
}
 