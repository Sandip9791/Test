<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class ExcelReport_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
 
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }
    

    public function checkEnrollData_Report()
    {

        $result= $this->collection->find([], ['projection' => ['_id'=>0,'PID'=>1,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Email'=>1,'Department'=>1,'Designation'=>1,'Teacher_Type'=>1,'Joining_Date'=>1,'Nature_of_Appointment'=>1,'Experiance'=>1,'Leaving_Date'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************/
    public function checkReaserchProjectData_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'username'=>1,'RInfo'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************/
    public function checkReaserchGuide_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Leaving_Date'=>1,'RGuide1'=>1,'RGuide2'=>1,'RGuide3'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************/
    public function checkReaserchProject_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Department'=>1,'Leaving_Date'=>1,'Reaserch_Project_Info'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************/
    public function checkSeedMoney_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Department'=>1,'RMoneyInfo'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

/***************************************************************************************************************/
    public function checkFellowship_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'RFollow'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************/
    public function checkResearchPublication_Report()
    {
        $result= $this->collection->find([], ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Department'=>1,'Midd_Name'=>1,'ResearchPublication'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
}