<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class Admin_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->admin;
    }
      
/********************************************************************************************************/
   // Number of Documents in Teachers 
   public function numberOfDocument_Teacher()
   {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;

        $count= $this->collection->countDocuments();

        return $count;     
   }

/********************************************************************************************************/
   // Number of Documents in HOD 
   public function numberOfDocument_HOD()
   {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->HOD;

        $count= $this->collection->countDocuments();

        return $count;     
   }

/********************************************************************************************************/
   // Number of Documents in Committee 
   public function numberOfDocument_Committee()
   {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Committee;

        $count= $this->collection->countDocuments();

        return $count;     
   }

/********************************************************************************************************/
    // Cheking The user Admin
       public function checkUser($document)
       {        
            $result = $this->collection->findOne($document);

            if ($result) 
            {
                return true;
            } 
            else 
            {
                return false;
            }
       }

/********************************************************************************************************/
    // Saving The Teacher Enroll Data By Admin
       public function saveData($document)
       {
            if($document['Teacher_Type'] === 'IQAC') 
            {
                $this->connection = new DatabaseConnector();
                $database = $this->connection->getDatabase();
                $this->collection = $database->IQAC;
            }
            elseif($document['Teacher_Type'] === 'Committee') 
            {
                $this->connection = new DatabaseConnector();
                $database = $this->connection->getDatabase();
                $this->collection = $database->Committee;
            }
            else
            {
                $this->connection = new DatabaseConnector();
                $database = $this->connection->getDatabase();
                $this->collection = $database->Teacher;
            }
           
            $result= $this->collection->insertOne($document);

            if($result)
            {
                return true;
            }
            else
            {
                return false;
            }
       }

/********************************************************************************************************/
    // Displaying Enroll Data To Admin Of Teachers
       public function fetchData_Teacher()
       {
            $this->connection = new DatabaseConnector();
            $database = $this->connection->getDatabase();
            $this->collection = $database->Teacher;

            $result= $this->collection->find([], ['projection' => ['username'=>1,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Time'=>1,'Email'=>1,'Teacher_ID'=>1,'Teacher_Type'=>1,'Faculty'=>1,'Department'=>1,'Designation'=>1,'Nature_of_Appointment'=>1,'Joining_Date'=>1,'Leaving_Date'=>1,'Login_Time'=>1,'Logout_Time'=>1]]);

            $documents = [];
            if($result)
            {
                foreach ($result as $document) {
                    $documents[] = $document;
                }
                return $documents;
            }
            else
            {
                return false;
            }
       }

/********************************************************************************************************/
    // Displaying Enroll Data To Admin Of HOD
    public function fetchData_IQAC()
    {
         $this->connection = new DatabaseConnector();
         $database = $this->connection->getDatabase();
         $this->collection = $database->IQAC;

         $result= $this->collection->find([], ['projection' => ['username'=>1,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Time'=>1,'Email'=>1,'Teacher_ID'=>1,'Teacher_Type'=>1,'Faculty'=>1,'Department'=>1,'Designation'=>1,'Nature_of_Appointment'=>1,'Joining_Date'=>1,'Leaving_Date'=>1,'Login_Time'=>1,'Logout_Time'=>1]]);

         $documents = [];
         if($result)
         {
             foreach ($result as $document) {
                 $documents[] = $document;
             }
             return $documents;
         }
         else
         {
             return false;
         }
    }
/********************************************************************************************************/
    // Displaying Enroll Data To Admin Of Committee
    public function fetchData_Committee()
    {
         $this->connection = new DatabaseConnector();
         $database = $this->connection->getDatabase();
         $this->collection = $database->Committee;

         $result= $this->collection->find([], ['projection' => ['username'=>1,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Time'=>1,'Email'=>1,'Teacher_ID'=>1,'Teacher_Type'=>1,'Faculty'=>1,'Department'=>1,'Designation'=>1,'Nature_of_Appointment'=>1,'Joining_Date'=>1,'Leaving_Date'=>1,'Login_Time'=>1,'Logout_Time'=>1]]);

         $documents = [];
         if($result)
         {
             foreach ($result as $document) {
                 $documents[] = $document;
             }
             return $documents;
         }
         else
         {
             return false;
         }
    }
    
/********************************************************************************************************/
    // Deleting Enroll Data Of Teacher
    public function teaDeleteData($uname)
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;

        $result= $this->collection->deleteOne(['username'=>$uname]);

        // Check if any documents were deleted
        if ($result->getDeletedCount() > 0) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

/********************************************************************************************************/
    // Deleting Enroll Data Of IQAC
    public function iqacDeleteData($uname)
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->IQAC;

        $result= $this->collection->deleteOne(['username'=>$uname]);

        // Check if any documents were deleted
        if ($result->getDeletedCount() > 0) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }


//////////////////////////////////////////////////////////////////
    // Deleting Enroll Data Of Commitee
    public function committeeDeleteData($uname)   ///added by Victor
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Committee;

        $result= $this->collection->deleteOne(['username'=>$uname]);

        // Check if any documents were deleted
        if ($result->getDeletedCount() > 0) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }
  

       
}
 