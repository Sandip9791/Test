<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class ReaserchInfo_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }
     
/*********************************************************************************************************/
    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result = $this->collection->updateMany($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;  
        } 
        else 
        {
            return false;
        }
    }


/**************************************************************************************************************/
    public function fetchData($key)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result= $this->collection->find($filter, ['projection' => ['_id'=>0,"$key"=>1]]);

        $documents = [];

        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
              
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

/**************************************************************************************************************/
    // Deleting  Data Of Teacher
    public function deleteData($key,$subkey,$srnumber)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');

        $filter = ['username' => $myusername];

        // Use the $pull operator to remove the specific subdocument from the  array
        $updateQuery = ['$pull' => ["$key" => ["$subkey" => $srnumber]]];

        // Perform the update operation
        $result = $this->collection->updateOne($filter, $updateQuery);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

/**************************************************************************************************************/
   // Update Details Of BookAndChapter
   public function updateData_ReaserchGuideInfo1( $document, $srnumber)
   {
       $session = \Config\Services::session();
       $myusername = $session->get('loged_user');

       $filter = [
           'username' => $myusername,
           'RGuide1.RGuide1_id' => $srnumber
       ];

       $update = [
           '$set' => 
           [
               "RGuide1.$.Subject_Name"=> $document['Subject_Name'],
               "RGuide1.$.Current_Year"=> $document['Current_Year'],
               "RGuide1.$.Center_Name"=> $document['Center_Name'],
               "RGuide1.$.University"=> $document['University'],
               "RGuide1.$.Year_Of_Recognition"=> $document['Year_Of_Recognition'],
               "RGuide1.$.Recognition_Letter"=> $document['Recognition_Letter'],
           ]
       ];
     
       $result = $this->collection->updateOne($filter, $update);

       // Check if the update was successful
       if ($result->getModifiedCount() == 1) {
           return true;
       } else {
           return false;
       }
   }

   /**************************************************************************************************************/
   // Update Details Of BookAndChapter
   public function updateData_ReaserchGuideInfo2( $document, $srnumber)
   {
       $session = \Config\Services::session();
       $myusername = $session->get('loged_user');

       $filter = [
           'username' => $myusername,
           'RGuide2.RGuide2_id' => $srnumber
       ];

       $update = [
           '$set' => 
           [
               "RGuide2.$.Research_Title"=> $document['Research_Title'],
               "RGuide2.$.Current_Year"=> $document['Current_Year'],
               "RGuide2.$.Name_of_Researcher"=> $document['Name_of_Researcher'],
               "RGuide2.$.Year_of_Degree_Award"=> $document['Year_of_Degree_Award'],
               "RGuide2.$.Degree_Certificate"=> $document['Degree_Certificate'],
           ]
       ];
     
       $result = $this->collection->updateOne($filter, $update);

       // Check if the update was successful
       if ($result->getModifiedCount() == 1) {
           return true;
       } else {
           return false;
       }
   }

/**************************************************************************************************************/
    // Update Details Of BookAndChapter
    public function updateData_ReaserchGuideInfo3( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');
 
        $filter = [
            'username' => $myusername,
            'RGuide3.RGuide3_id' => $srnumber
        ];
 
        $update = [
            '$set' => 
            [
                "RGuide3.$.Research_Title"=> $document['Research_Title'],
                "RGuide3.$.Current_Year"=> $document['Current_Year'],
                "RGuide3.$.Name_of_Researcher"=> $document['Name_of_Researcher'],
                "RGuide3.$.Registration_Date"=> $document['Registration_Date'],
                "RGuide3.$.RR_Latter"=> $document['RR_Latter'],
            ]
        ];
      
        $result = $this->collection->updateOne($filter, $update);
 
        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/**************************************************************************************************************/
   // Update Details Of RGuide1
    public function updateData_BookAndChapter( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'BookAndChapter.BookAndChapter_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "BookAndChapter.$.Book_Published"=> $document['Book_Published'],
                "BookAndChapter.$.Title_Of_The_Chapter"=> $document['Title_Of_The_Chapter'],
                "BookAndChapter.$.Year_Of_Publication"=> $document['Year_Of_Publication'],
                "BookAndChapter.$.ISBN_Number"=> $document['ISBN_Number'],
                "BookAndChapter.$.Name_Of_The_Publisher"=> $document['Name_Of_The_Publisher'],
                "BookAndChapter.$.Time_Of_Publication"=> $document['Time_Of_Publication'],
                "BookAndChapter.$.Cover_Page"=> $document['Cover_Page'],
                "BookAndChapter.$.Content_Page"=> $document['Content_Page'],
                "BookAndChapter.$.First_Page"=> $document['First_Page'],
                "BookAndChapter.$.Back_Page"=> $document['Back_Page'],
 
            ]
        ];
      
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }

/**************************************************************************************************************/
   // Update Details Of  Research Project 
   public function updateData_ResearchProject ($document, $srnumber)
   {
       $session = \Config\Services::session();
       $myusername = $session->get('loged_user');

       $filter = [
           'username' => $myusername,
           'Reaserch_Project_Info.RInfo_id' => $srnumber
       ];

       $update = [
           '$set' => 
           [
               "Reaserch_Project_Info.$.Name_Of_Project"=> $document['Name_Of_Project'],
               "Reaserch_Project_Info.$.Current_Year"=> $document['Current_Year'],
               "Reaserch_Project_Info.$.Name_Of_Funding_Agency"=> $document['Name_Of_Funding_Agency'],
               "Reaserch_Project_Info.$.Year_Of_Award"=> $document['Year_Of_Award'],
               "Reaserch_Project_Info.$.Investigator_Type"=> $document['Investigator_Type'],
               "Reaserch_Project_Info.$.Type_Funding_Aggency"=> $document['Type_Funding_Aggency'],
               "Reaserch_Project_Info.$.Satus"=> $document['Satus'],
               "Reaserch_Project_Info.$.Funds_Provided"=> $document['Funds_Provided'],
               "Reaserch_Project_Info.$.Duration_Of_Project"=> $document['Duration_Of_Project'],
               "Reaserch_Project_Info.$.Sanction_Latter"=> $document['Sanction_Latter'],
           ]
       ];
     
       $result = $this->collection->updateOne($filter, $update);

       // Check if the update was successful
       if ($result->getModifiedCount() == 1) {
           return true;
       } else {
           return false;
       }
   }
/**************************************************************************************************************/
     // Update Details Of  Research Project 
     public function updateData_ResearchPublication ($document, $srnumber)
     {
         $session = \Config\Services::session();
         $myusername = $session->get('loged_user');
  
         $filter = [
             'username' => $myusername,
             'ResearchPublication.ResearchPublication_id' => $srnumber
         ];
  
         $update = [
             '$set' => 
             [
                 "ResearchPublication.$.Title_Of_Paper"=> $document['Title_Of_Paper'],
                 "ResearchPublication.$.Current_Year"=> $document['Current_Year'],
                 "ResearchPublication.$.Name_Of_Journal"=> $document['Name_Of_Journal'],
                 "ResearchPublication.$.Year_Of_Publication"=> $document['Year_Of_Publication'],
                 "ResearchPublication.$.Check"=> $document['Check'],
                 "ResearchPublication.$.Link_Of_Website"=> $document['Link_Of_Website'],
                 "ResearchPublication.$.Screenshot"=> $document['Screenshot'],

                 "ResearchPublication.$.Journal_Approved_By"=> $document['Journal_Approved_By'],
             ]
         ];
       
         $result = $this->collection->updateOne($filter, $update);
  
         // Check if the update was successful
         if ($result->getModifiedCount() == 1) {
             return true;
         } else {
             return false;
         }
     }
/**************************************************************************************************************/
      // Update Details Of  seed Money
      public function updateData_ProjectMoney($document, $srnumber)
      {
          $session = \Config\Services::session();
          $myusername = $session->get('loged_user');
   
          $filter = [
              'username' => $myusername,
              'RMoneyInfo.RMoneyInfo_id' => $srnumber
          ];
   
          $update = [
              '$set' => 
              [
                 
                  "RMoneyInfo.$.If_Send_Money_Received_For_Project"=> $document['If_Send_Money_Received_For_Project'],
                  "RMoneyInfo.$.Current_Year"=> $document['Current_Year'],
                  "RMoneyInfo.$.Amount"=> $document['Amount'],
                  "RMoneyInfo.$.Title_Of_Research_Project"=> $document['Title_Of_Research_Project'],
                  "RMoneyInfo.$.Duration"=> $document['Duration'],
                  "RMoneyInfo.$.Year_Of_Award"=> $document['Year_Of_Award'],
                  "RMoneyInfo.$.Sanction_Letter"=> $document['Sanction_Letter'],
              ]
          ];
        
          $result = $this->collection->updateOne($filter, $update);
   
          // Check if the update was successful
          if ($result->getModifiedCount() == 1) {
              return true;
          } else {
              return false;
          }
      }
/**************************************************************************************************************/
    // Update Details Of  seed Money
    public function updateData_Consultancy($document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');
    
        $filter = [
            'username' => $myusername,
            'Consultancy.Consultancy_id' => $srnumber
        ];
    
        $update = [
            '$set' => 
            [
                "Consultancy.$.Place"=> $document['Place'],
                "Consultancy.$.Name_Project"=> $document['Name_Project'],
                "Consultancy.$.Sponsoring_Agency"=> $document['Sponsoring_Agency'],
                "Consultancy.$.No_Trainings"=> $document['No_Trainings'],
                "Consultancy.$.Letter_Of_Beneficiary"=> $document['Letter_Of_Beneficiary'],
            ]
        ];
        
        $result = $this->collection->updateOne($filter, $update);
    
        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/***********************************************************************************************************/
public function updateData_Mou_Linkage($document, $srnumber)
{
    $session = \Config\Services::session();
    $myusername = $session->get('loged_user');

    $filter = [
        'username' => $myusername,
        'MOU_Linkage.MOU_Linkage_id' => $srnumber
    ];

    $update = [
        '$set' => 
        [
            "MOU_Linkage.$.Name_Organization"=> $document['Name_Organization'],
            "MOU_Linkage.$.Place"=> $document['Place'],
            "MOU_Linkage.$.Name_Colaborations"=> $document['Name_Colaborations'],
            "MOU_Linkage.$.From"=> $document['From'],
            "MOU_Linkage.$.To"=> $document['To'],
            "MOU_Linkage.$.No_Beneficiary"=> $document['No_Beneficiary'],
            "MOU_Linkage.$.Document_of_Activity"=> $document['Document_of_Activity'],
            "MOU_Linkage.$.Upload_Document1"=> $document['Upload_Document1'],
            "MOU_Linkage.$.Upload_Document2"=> $document['Upload_Document2'],
            "MOU_Linkage.$.Upload_Document3"=> $document['Upload_Document3'],
            "MOU_Linkage.$.Upload_Document4"=> $document['Upload_Document4'],
            "MOU_Linkage.$.Upload_Document5"=> $document['Upload_Document5'],
        ]
    ];
    
    $result = $this->collection->updateOne($filter, $update);

    // Check if the update was successful
    if ($result->getModifiedCount() == 1) {
        return true;
    } else {
        return false;
    }
}

/***********************************************************************************************************/
    public function updateData_ProjectFollowship($document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');
    
        $filter = [
            'username' => $myusername,
            'RFollow.RFollow_id' => $srnumber
        ];
    
        $update = [
            '$set' => 
            [
                "RFollow.$.Awarding_Agency"=> $document['Awarding_Agency'],
                "RFollow.$.Current_Year"=> $document['Current_Year'],
                "RFollow.$.Year_Of_Award"=> $document['Year_Of_Award'],
                "RFollow.$.Name_Of_Award_Fellowship"=> $document['Name_Of_Award_Fellowship'],
                "RFollow.$.Fellowship_Financial_Support_Status"=> $document['Fellowship_Financial_Support_Status'],
                "RFollow.$.Type1"=> $document['Type1'],
                "RFollow.$.Type2"=> $document['Type2'],
                "RFollow.$.Name_Of_Award_Fellowship"=> $document['Name_Of_Award_Fellowship'],
                "RFollow.$.Have_You_Received_Travel_Grant"=> $document['Have_You_Received_Travel_Grant'],
                "RFollow.$.Amount"=> $document['Amount'],
                "RFollow.$.Sanction_Latter"=> $document['Sanction_Latter'],
            ]
        ];
        
        $result = $this->collection->updateOne($filter, $update);
    
        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
}
 