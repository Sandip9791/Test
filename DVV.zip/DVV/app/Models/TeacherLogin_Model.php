<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;
use CodeIgniter\I18n\Time;


class TeacherLogin_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }
    
    public function checkUser($document)
    {        
        $result = $this->collection->findOne($document);

        if ($result) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    
    public function loginTime($myusername)
    {
        $filter = ['username' => $myusername];

        $myTime = new Time('now', 'GMT+5:30', 'en_US');

        $document=[
            '$set'=>
            [
                'Login_Time'=>"$myTime"
            ] 
        ];
        
        $currentTime = $this->collection->updateOne($filter,$document);
    }

    public function logoutTime($myusername)
    {
        $filter = ['username' => $myusername];

        $myTime = new Time('now', 'GMT+5:30', 'en_US');

        $document=[
         '$set'=>
            [
                'Logout_Time'=>"$myTime"
            ]
        ];
        
        $currentTime = $this->collection->updateOne($filter,$document);
    }

}
 