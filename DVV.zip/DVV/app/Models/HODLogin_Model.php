<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class HODLogin_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }

/********************************************************************************************************/
    // HOD Login
    public function checkUser($document)
    {        
        $result = $this->collection->findOne($document);

        if ($result) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

/********************************************************************************************************/
    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');

        $filter = ['username' => $myusername];

        $result = $this->collection->updateOne($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
                return true;  
        } 
        else 
        {
            return false;
        }
    }
/********************************************************************************************************/
public function fetchData($key)
{
    $session = \Config\Services::session();
    $myusername=$session->get('loged_user');

    $filter = ['username' => $myusername];

    $result= $this->collection->find($filter, ['projection' => ['_id'=>0,"$key"=>1]]);

    $documents = [];

    if($result)
    {
        foreach ($result as $document) 
        {
            $documents[] = $document;
          
        }
        return $documents;
    }
    else
    {
        return false;
    }
}

/********************************************************************************************************/
  // Deleting  Data Of HOD
  public function deleteData($key,$subkey,$srnumber)
  {
      $session = \Config\Services::session();
      $myusername=$session->get('loged_user');

      $filter = ['username' => $myusername];

      // Use the $pull operator to remove the specific subdocument from the  array
      $updateQuery = ['$pull' => ["$key" => ["$subkey" => $srnumber]]];

      // Perform the update operation
      $result = $this->collection->updateOne($filter, $updateQuery);

      // Check if the update was successful
      if ($result->getModifiedCount() == 1) 
      {
          return true;
      } 
      else 
      {
          return false;
      }
  }

/********************************************************************************************************/
  // update  Data Of HOD 1.3.2
  public function updateData_HOD_1_3_2($document, $srnumber)
  {
      $session = \Config\Services::session();
      $myusername = $session->get('loged_user');

      $filter = [
          'username' => $myusername,
          'HOD_1_3_2.HOD_id' => $srnumber
      ];

      $update = [
          '$set' => 
          [
              "HOD_1_3_2.$.Academic_year"=> $document['Academic_year'],
              "HOD_1_3_2.$.Course_name"=> $document['Course_name'],
              "HOD_1_3_2.$.Completed_course"=> $document['Completed_course'],
              "HOD_1_3_2.$.Course_code"=> $document['Course_code'],
              "HOD_1_3_2.$.Offering_year"=> $document['Offering_year'],
              "HOD_1_3_2.$.No_of_times"=> $document['No_of_times'],
              "HOD_1_3_2.$.Weeks_or_Hours"=> $document['Weeks_or_Hours'],
              "HOD_1_3_2.$.Duration"=> $document['Duration'],
              "HOD_1_3_2.$.Course_coordinator"=> $document['Course_coordinator'],
              "HOD_1_3_2.$.Students_enrolled"=> $document['Students_enrolled'],
              "HOD_1_3_2.$.Students_completed"=> $document['Students_completed'],
              "HOD_1_3_2.$.Related_Documents"=> $document['Related_Documents'],
              "HOD_1_3_2.$.Brochure"=> $document['Brochure'],
              "HOD_1_3_2.$.Module"=> $document['Module'],
              "HOD_1_3_2.$.Attendance"=> $document['Attendance'],
              "HOD_1_3_2.$.Certificate1"=> $document['Certificate1'],
              "HOD_1_3_2.$.Certificate2"=> $document['Certificate2'],
              "HOD_1_3_2.$.Certificate3"=> $document['Certificate3'],
              "HOD_1_3_2.$.Certificate4"=> $document['Certificate4'],
              "HOD_1_3_2.$.Certificate5"=> $document['Certificate5']
          ]
      ];
    
      $result = $this->collection->updateOne($filter, $update);

      // Check if the update was successful
      if ($result->getModifiedCount() == 1) 
      {
          return true;
      }
      else 
       {
          return false;
      }
  }

}
 