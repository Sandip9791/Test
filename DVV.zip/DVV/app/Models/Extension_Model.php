<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class Extension_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }
/***********************************************************************************************************************************/    
      
    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result = $this->collection->updateMany($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;  
        } 
        else 
        {
            return false;
        }
    }

/***************************************************************************************************************************************/ 
   // Fetching  Data
    public function fetchData($key)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];
        
        $result= $this->collection->find( $filter, ['projection' => ['_id'=>0,"$key"=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }
/***************************************************************************************************************************************/

  // Deleting  Data Of Teacher
  public function deleteData($key,$subkey,$srnumber)
  {
      $session = \Config\Services::session();
      $myusername=$session->get('loged_user');

      $filter = ['username' => $myusername];

      // Use the $pull operator to remove the specific subdocument from the  array
      $updateQuery = ['$pull' => ["$key" => ["$subkey" => $srnumber]]];

      // Perform the update operation
      $result = $this->collection->updateOne($filter, $updateQuery);

      // Check if the update was successful
      if ($result->getModifiedCount() == 1) 
      {
          return true;
      } 
      else 
      {
          return false;
      }
  }
/***************************************************************************************************************************************/
public function updateData_ActivitiesOfForum( $document, $srnumber)
{
    $session = \Config\Services::session();
    $myusername = $session->get('loged_user');

    $filter = [
        'username' => $myusername,
        'Activities_Of_Forum.Activities_Of_Forum_id' => $srnumber
    ];

    $update = [
        '$set' => 
        [
            "Activities_Of_Forum.$.Name_Of_The_Extension_Activity_Orginised"=> $document['Name_Of_The_Extension_Activity_Orginised'],
            "Activities_Of_Forum.$.Outcome"=> $document['Outcome'],
            "Activities_Of_Forum.$.Number_Of_Participants"=> $document['Number_Of_Participants'],
            "Activities_Of_Forum.$.Forum"=> $document['Forum'],
            "Activities_Of_Forum.$.Activity_Conducted"=> $document['Activity_Conducted'],
            "Activities_Of_Forum.$.Upload_Attendance"=> $document['Upload_Attendance'],
            "Activities_Of_Forum.$.Upload_Report"=> $document['Upload_Report'],
            "Activities_Of_Forum.$.Geotag_Photo1"=> $document['Geotag_Photo1'],
            "Activities_Of_Forum.$.Geotag_Photo2"=> $document['Geotag_Photo2'],
            "Activities_Of_Forum.$.NonGeotag_Photo1"=> $document['NonGeotag_Photo1'],
            "Activities_Of_Forum.$.NonGeotag_Photo2"=> $document['NonGeotag_Photo2'],
        ]
    ];
  
    $result = $this->collection->updateOne($filter, $update);

    // Check if the update was successful
    if ($result->getModifiedCount() == 1) {
        return true;
    } else {
        return false;
    }
}

/***************************************************************************************************************************************/
public function updateData_AlumniEngagement( $document, $srnumber)
{
    $session = \Config\Services::session();
    $myusername = $session->get('loged_user');

    $filter = [
        'username' => $myusername,
        'Alumni_Engagement.Alumni_Engagement_id' => $srnumber
    ];

    $update = [
        '$set' => 
        [
            "Alumni_Engagement.$.Activities"=> $document['Activities'],
            "Alumni_Engagement.$.Name_Of_Alumni"=> $document['Name_Of_Alumni'],
            "Alumni_Engagement.$.Mobile_Number"=> $document['Mobile_Number'],
            "Alumni_Engagement.$.Designation"=> $document['Designation'],
            "Alumni_Engagement.$.Organization_Name"=> $document['Organization_Name'],
            "Alumni_Engagement.$.Upload_Related_Documents"=> $document['Upload_Related_Documents'],
            "Alumni_Engagement.$.Upload_Geotag_Photos1"=> $document['Upload_Geotag_Photos1'],
            "Alumni_Engagement.$.Upload_Geotag_Photos2"=> $document['Upload_Geotag_Photos2'],
            "Alumni_Engagement.$.Upload_Non_Geotag_Photos1"=> $document['Upload_Non_Geotag_Photos1'],
            "Alumni_Engagement.$.Upload_Non_Geotag_Photos2"=> $document['Upload_Non_Geotag_Photos2'],

        ]
    ];
  
    $result = $this->collection->updateOne($filter, $update);

    // Check if the update was successful
    if ($result->getModifiedCount() == 1) {
        return true;
    } else {
        return false;
    }
}

/***************************************************************************************************************************************/
public function updateData_SensetizationOfStudent( $document, $srnumber)
{
    $session = \Config\Services::session();
    $myusername = $session->get('loged_user');

    $filter = [
        'username' => $myusername,
        'Sensetization_Of_Student.Sensetization_Of_Student_id' => $srnumber
    ];

    $update = [
        '$set' => 
        [
            "Sensetization_Of_Student.$.Details"=> $document['Details'],
            "Sensetization_Of_Student.$.Attendance"=> $document['Attendance'],
            "Sensetization_Of_Student.$.Notice"=> $document['Notice'],
            "Sensetization_Of_Student.$.Geotag_Photo1"=> $document['Geotag_Photo1'],
            "Sensetization_Of_Student.$.Geotag_Photo2"=> $document['Geotag_Photo2'],
            "Sensetization_Of_Student.$.NonGeotag_Photo1"=> $document['NonGeotag_Photo1'],
            "Sensetization_Of_Student.$.NonGeotag_Photo2"=> $document['NonGeotag_Photo2'],
        ]
    ];
  
    $result = $this->collection->updateOne($filter, $update);

    // Check if the update was successful
    if ($result->getModifiedCount() == 1) {
        return true;
    } else {
        return false;
    }
}

}
 