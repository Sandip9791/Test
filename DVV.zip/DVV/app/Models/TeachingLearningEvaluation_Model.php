<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class TeachingLearningEvaluation_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;
    }
    
/***********************************************************************************************************************************/    
      
    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];

        $result = $this->collection->updateMany($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
            return true;  
        } 
        else 
        {
            return false;
        }
    }

/***************************************************************************************************************************************/
    // Fetching  Data
    public function fetchData($key)
    {
        $session = \Config\Services::session();
        $myusername=$session->get('loged_user');
    
        $filter = ['username' => $myusername];
        
        $result= $this->collection->find( $filter, ['projection' => ['_id'=>0,"$key"=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

/***************************************************************************************************************************************/ 
  
     // Deleting  Data Of Teacher
     public function deleteData($key,$subkey,$srnumber)
     {
         $session = \Config\Services::session();
         $myusername=$session->get('loged_user');
 
         $filter = ['username' => $myusername];
 
         // Use the $pull operator to remove the specific subdocument from the "BookAndChapter" array
         $updateQuery = ['$pull' => ["$key" => ["$subkey" => $srnumber]]];
 
         // Perform the update operation
         $result = $this->collection->updateOne($filter, $updateQuery);
 
         // Check if the update was successful
         if ($result->getModifiedCount() == 1) 
         {
             return true;
         } 
         else 
         {
             return false;
         }
     }
/***************************************************************************************************************************************/
    public function updateData_ExperientialLearning( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Expetiential_Learning.Expetiential_Learning_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Expetiential_Learning.$.Field_of_Experiance"=> $document['Field_of_Experiance'],
                "Expetiential_Learning.$.Course_of_Experiance"=> $document['Course_of_Experiance'],
                "Expetiential_Learning.$.Program_Code"=> $document['Program_Code'],
                "Expetiential_Learning.$.Program_Name"=> $document['Program_Name'],
                "Expetiential_Learning.$.Syllabus_Link"=> $document['Syllabus_Link'],
                "Expetiential_Learning.$.Number_Students"=> $document['Number_Students'],
                "Expetiential_Learning.$.Documents_1"=> $document['Documents_1'],
                "Expetiential_Learning.$.Documents_2"=> $document['Documents_2'],
                "Expetiential_Learning.$.Documents_3"=> $document['Documents_3'],
                "Expetiential_Learning.$.Documents_4"=> $document['Documents_4'],
                "Expetiential_Learning.$.Documents_5"=> $document['Documents_5'],
            ]
        ];
      
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/*************************************************************************************************************/
    public function updateData_Mentee($document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Effective_Mentee_Mentor.Mentee_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Effective_Mentee_Mentor.$.Class_Of_Mentee"=> $document['Class_Of_Mentee'],
                "Effective_Mentee_Mentor.$.Number_Of_Mentee_Allocated"=> $document['Number_Of_Mentee_Allocated'],
                "Effective_Mentee_Mentor.$.Academic"=> $document['Academic'],
                "Effective_Mentee_Mentor.$.Pyschological"=> $document['Pyschological'],
                "Effective_Mentee_Mentor.$.Document"=> $document['Document'],
            ]
        ];
      
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }

/*************************************************************************************************************/
    public function updateData_StudyTour($document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Study_Tour.Study_Tour_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Study_Tour.$.Name_Program"=> $document['Name_Program'],
                "Study_Tour.$.Program_Code"=> $document['Program_Code'],
                "Study_Tour.$.Subject_Code"=> $document['Subject_Code'],
                "Study_Tour.$.Place"=> $document['Place'],
                "Study_Tour.$.Date"=> $document['Date'],
                "Study_Tour.$.Permission_Letter"=> $document['Permission_Letter'],
                "Study_Tour.$.Attendance_Sheet"=> $document['Attendance_Sheet'],
                "Study_Tour.$.Geotag_Photos_1"=> $document['Geotag_Photos_1'],
                "Study_Tour.$.Geotag_Photos_2"=> $document['Geotag_Photos_2'],
                "Study_Tour.$.Non_Geotag_Photos_1"=> $document['Non_Geotag_Photos_1'],
                "Study_Tour.$.Non_Geotag_Photos_2"=> $document['Non_Geotag_Photos_2'],
            ]
        ];
    
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }
/*************************************************************************************************************/

    public function updateData_FinancialSupportBy( $document, $srnumber)
    {
        $session = \Config\Services::session();
        $myusername = $session->get('loged_user');

        $filter = [
            'username' => $myusername,
            'Financial_Support_By.Financial_Support_By_id' => $srnumber
        ];

        $update = [
            '$set' => 
            [
                "Financial_Support_By.$.Financial_Support"=> $document['Financial_Support'],
                "Financial_Support_By.$.Financial_Support_to_Any_Student"=> $document['Financial_Support_to_Any_Student'],
                "Financial_Support_By.$.Amount"=> $document['Amount'],
                "Financial_Support_By.$.Student_Name"=> $document['Student_Name'],
                "Financial_Support_By.$.Class"=> $document['Class'],
                "Financial_Support_By.$.Roll_No"=> $document['Roll_No'],
                "Financial_Support_By.$.Purpose"=> $document['Purpose'],
                "Financial_Support_By.$.Student_Document"=> $document['Student_Document'],
                "Financial_Support_By.$.Photograph"=> $document['Photograph'],
                "Financial_Support_By.$.Sanction_Letter"=> $document['Sanction_Letter'],
            ]
        ];
      
        $result = $this->collection->updateOne($filter, $update);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) {
            return true;
        } else {
            return false;
        }
    }

}
 