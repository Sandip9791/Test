<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class Dashboard_Model extends Model 
{
      public $collection;
      public $session;

       public function __construct() 
       {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Teacher;

        $this->session = session();

       }
       
/********************************************************************************************************/
    // Checking User Valid Or Not
       public function checkUser($document)
       {        
            $result = $this->collection->findOne($document);

                if ($result) 
                {
                    return true;
                } 
                else 
                {
                    return false;
                }
       }

/********************************************************************************************************/
    // Updating The Password
       public function updatePass($confirmPassword)
       {
             $email= $this->session->get('setEmail');

             $filter = ['Email' => "$email"];

             $update = ['$set' => ['password' => md5($confirmPassword)]];

             $result= $this->collection->updateOne($filter,$update);
             
             if ($result->getModifiedCount() > 0) 
             {
                 return true;
             } 
            else 
            {
                 return false;
            }
       }
 }