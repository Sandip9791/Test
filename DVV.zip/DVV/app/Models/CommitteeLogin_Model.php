<?php
namespace App\Models;
use \CodeIgniter\Model;
use App\Libraries\DatabaseConnector;

class CommitteeLogin_Model extends Model 
{
    public $collection;
    public function __construct() 
    {
        $this->connection = new DatabaseConnector();
        $database = $this->connection->getDatabase();
        $this->collection = $database->Committee;
    }
      
    public function checkUser($document)
    {        
        $result = $this->collection->findOne($document);

        if ($result) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }


    public function fecthingData()
    {
        $session = \Config\Services::session();
        $myusername=$session->get('committee_user');
    
        $filter = ['username' => $myusername];
        
        $result= $this->collection->find($filter, ['projection' => ['_id'=>0,'Title'=>1,'First_Name'=>1,'Last_Name'=>1,'Midd_Name'=>1,'Email'=>1,'Department'=>1,'Designation'=>1,'Teacher_Type'=>1]]);

        $documents = [];
        if($result)
        {
            foreach ($result as $document) 
            {
                $documents[] = $document;
            }
            return $documents;
        }
        else
        {
            return false;
        }
    }

    public function saveData($document)
    {      
        $session = \Config\Services::session();
        $myusername=$session->get('committee_user');

        $filter = ['username' => $myusername];

        $result = $this->collection->updateOne($filter,$document);

        // Check if the update was successful
        if ($result->getModifiedCount() == 1) 
        {
                return true;  
        } 
        else 
        {
            return false;
        }
    }
}
 