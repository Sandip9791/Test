<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Dashboard');
$routes->setDefaultMethod('index1');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
//$routes->get('', 'HoDashboardme::index');

$routes->add('/', 'Dashboard::index1');
$routes->add('ALogin', 'Dashboard::index2');
$routes->add('PLogin', 'Dashboard::index3');
$routes->add('ILogin', 'Dashboard::iqacLogin_view');
$routes->add('CLogin', 'Dashboard::committeeLogin_View');

//Forgot Password
$routes->add('forgotPassword', 'Dashboard::index4');
$routes->add('enterOTP', 'Dashboard::index5');
$routes->add('teaForgotPass','Dashboard::teaForgotPass');
$routes->add('confirmPassword','Dashboard::confirmPassword');

//Test Email
$routes->add('testmail','TestEmail::testmail');
$routes->add('index','TestEmail::index');

// Admin
$routes->add('admin','Dashboard::admin');
$routes->add('adminLogin','Dashboard::adminLogin');
$routes->add('adminLogout','Dashboard::adminLogout');

$routes->add('teaFaculty','Admin::teaFacultyEnroll');
$routes->post('teaFacultyInsert','Admin::teaInsertData');

// Enroll Data Of Teachers and Delete Data
$routes->add('teaFacultyFecth','Admin::teaShowData');
$routes->post('teaFacultyDelete','Admin::teaDeleteData');

// Enroll Data Of IQAC
$routes->add('iqacFacultyFecth','Admin::iqacShowData');
$routes->post('iqacFacultyDelete','Admin::IQACDeleteData');


// Enroll Data Of Committee
$routes->add('commiteeFacultyFecth','Admin::commiteeShowData');
$routes->post('commiteeFacultyDelete','Admin::COMMITEEDeleteData');     //added this new by victor

// Teacher Login Page Routes
$routes->post('teaLogin','Dashboard::teaLogin');
$routes->post('teaLogout','Dashboard::teaLogout');

// IQAC Login Page Routes
$routes->post('iqacLogin','Dashboard::iqacLogin');
$routes->add('iqacProf','ModuleProfile::iqacProf');
$routes->post('iqacLogout','Dashboard::iqacLogout');


// Committee Login Page Routes
$routes->post('committeeLogin','Dashboard::committeeLogin');
$routes->add('committeeProf','ModuleProfile::committeeProf');     ///added by victorr
$routes->post('committeeLogout','Dashboard::committeeLogout');

// Teacher Profile 
$routes->add('teaProf','ModuleProfile::teacherProf');

// HOD Profile 
$routes->add('hodProf','ModuleProfile::hodProf');
$routes->post('hodLogout','Dashboard::hodLogout');

// Teacher Personal Info Form
$routes->add('teaForm','TeacherPersonalInfo::teacherForm');
$routes->post('personalData','TeacherPersonalInfo::personalData');
$routes->add('profileData','TeacherPersonalInfo::profileData');

// Teacher Awards 
$routes->add('teaAwards','TeacherPersonalInfo::teacherAwards');
$routes->post('saveTeacherAwards','TeacherPersonalInfo::saveTeacherAwards');
$routes->post('updateTeacherAwards','TeacherPersonalInfo::updateTeacherAwards');
$routes->post('deleteTeacherAwards','TeacherPersonalInfo::deleteTeacherAwards');


// Teacher Learning
$routes->add('teaLearning','TeacherPersonalInfo::teacherLearning');
$routes->post('saveTeacherLearning','TeacherPersonalInfo::saveTeacherLearning');
$routes->post('updateTeacherLearning','TeacherPersonalInfo::updateTeacherLearning');
$routes->post('deleteTeacherLearning','TeacherPersonalInfo::deleteTeacherLearning');

// FDP
$routes->add('fdp','TeacherPersonalInfo::fdp');
$routes->post('saveFDP','TeacherPersonalInfo::saveFDP');
$routes->post('updateFDP','TeacherPersonalInfo::updateFDP');
$routes->post('deleteFDP','TeacherPersonalInfo::deleteFDP');




//Reachers Details
$routes->add('reaserchProjectInfo','ReachersProjectInfo::reaserchProjectInfo');
$routes->post('saveProjectInfo','ReachersProjectInfo::saveProjectInfo');
$routes->post('updateProjectInfo','ReachersProjectInfo::updateProjectInfo');
$routes->post('deleteProjectInfo','ReachersProjectInfo::deleteProjectInfo');

// Research Guide part 1
$routes->add('reaserchGuideInfo1','ReachersProjectInfo::reaserchGuideInfo1');
$routes->post('saveReaserchGuideInfo1','ReachersProjectInfo::saveReaserchGuideInfo1');
$routes->post('updateReaserchGuideInfo1','ReachersProjectInfo::updateReaserchGuideInfo1');
$routes->post('deleteReaserchGuideInfo1','ReachersProjectInfo::deleteReaserchGuideInfo1');


// Research Guide part 2
$routes->add('reaserchGuideInfo2','ReachersProjectInfo::reaserchGuideInfo2');
$routes->post('saveReaserchGuideInfo2','ReachersProjectInfo::saveReaserchGuideInfo2');
$routes->post('updateReaserchGuideInfo2','ReachersProjectInfo::updateReaserchGuideInfo2');
$routes->post('deleteReaserchGuideInfo2','ReachersProjectInfo::deleteReaserchGuideInfo2');

// Research Guide part 3
$routes->add('reaserchGuideInfo3','ReachersProjectInfo::reaserchGuideInfo3');
$routes->post('saveReaserchGuideInfo3','ReachersProjectInfo::saveReaserchGuideInfo3');
$routes->post('updateReaserchGuideInfo3','ReachersProjectInfo::updateReaserchGuideInfo3');
$routes->post('deleteReaserchGuideInfo3','ReachersProjectInfo::deleteReaserchGuideInfo3');

// Fellowship/Financial Support
$routes->add('reaserchProjectFollowship','ReachersProjectInfo::reaserchProjectFollowship');
$routes->post('saveProjectFollowship','ReachersProjectInfo::saveProjectFollowship');
$routes->post('updateProjectFollowship','ReachersProjectInfo::updateProjectFollowship');
$routes->post('deleteProjectFollowship','ReachersProjectInfo::deleteProjectFollowship');

// Seed Money
$routes->add('reaserchProjectMoney','ReachersProjectInfo::reaserchProjectMoney');
$routes->post('saveProjectMoney','ReachersProjectInfo::saveProjectMoney');
$routes->post('updateProjectMoney','ReachersProjectInfo::updateProjectMoney');
$routes->post('deleteProjectMoney','ReachersProjectInfo::deleteProjectMoney');

// MOU Linkage
$routes->add('mou_Linkage','ReachersProjectInfo::mou_Linkage');
$routes->post('saveMou_Linkage','ReachersProjectInfo::saveMou_Linkage');
$routes->post('updateMou_Linkage','ReachersProjectInfo::updateMou_Linkage');
$routes->post('deleteMou_Linkage','ReachersProjectInfo::deleteMou_Linkage');


// consultancy
$routes->add('consultancy','ReachersProjectInfo::consultancy');
$routes->post('saveConsultancy','ReachersProjectInfo::saveConsultancy');
$routes->post('updateConsultancy','ReachersProjectInfo::updateConsultancy');

$routes->post('deleteConsultancy','ReachersProjectInfo::deleteConsultancy');

// Reaserch Publication
$routes->add('reaserchPublication','ReachersProjectInfo::reaserchPublication');
$routes->post('saveResearchPublication','ReachersProjectInfo::saveResearchPublication');
$routes->post('updateResearchPublication','ReachersProjectInfo::updateResearchPublication');
$routes->post('deleteResearchPublication','ReachersProjectInfo::deleteResearchPublication');

// Books and Chapter
$routes->add('booksAndChapter','ReachersProjectInfo::booksAndChapter');
$routes->post('saveBookAndChapter','ReachersProjectInfo::saveBookAndChapter');
$routes->post('updateBookAndChapter','ReachersProjectInfo::updateBookAndChapter');
$routes->post('deleteBookChapter','ReachersProjectInfo::deleteBookChapter');

//Activities Of Forum
$routes->add('activitiesOfForum','Extension::activitiesOfForum');
$routes->post('saveActivitiesOfForum','Extension::saveActivitiesOfForum');
$routes->post('updateActivitiesOfForum','Extension::updateActivitiesOfForum');
$routes->post('deleteActivitiesOfForum','Extension::deleteActivitiesOfForum');


// Sensetization Of Student
$routes->add('sensitization','Extension::sensitization');
$routes->post('saveSensitization','Extension::saveSensitization');
$routes->post('updateSensitization','Extension::updateSensitization');
$routes->post('deleteSensitization','Extension::deleteSensitization');


//Alumni Engagement
$routes->add('alumniEngagement','Extension::alumniEngagement');
$routes->add('saveAlumniEngagement','Extension::saveAlumniEngagement');
$routes->add('updateAlumniEngagement','Extension::updateAlumniEngagement');
$routes->add('deleteAlumniEngagement','Extension::deleteAlumniEngagement');


//Teaching Learning Evaluation
$routes->add('effectiveMentee','TeachingLearningEvaluation::effectiveMentee');
$routes->post('saveMentee','TeachingLearningEvaluation::saveMentee');
$routes->post('updateMentee','TeachingLearningEvaluation::updateMentee');
$routes->post('deleteMentee','TeachingLearningEvaluation::deleteMentee');

$routes->add('studentcentric','TeachingLearningEvaluation::studentCentricMethods');
$routes->post('saveStudentCentric','TeachingLearningEvaluation::saveStudentCentric');

$routes->add('financialSupport','TeachingLearningEvaluation::financialSupport');
$routes->post('saveFinancialSupport','TeachingLearningEvaluation::saveFinancialSupport');
$routes->post('updateFinancialSupport','TeachingLearningEvaluation::updateFinancialSupport');
$routes->post('deleteFinancialSupport','TeachingLearningEvaluation::deleteFinancialSupport');

// Study Tour
$routes->add('studyTour','TeachingLearningEvaluation::studyTour');
$routes->post('saveStudyTour','TeachingLearningEvaluation::saveStudyTour');
$routes->post('updateStudyTour','TeachingLearningEvaluation::updateStudyTour');
$routes->post('deleteStudyTour','TeachingLearningEvaluation::deleteStudyTour');

// Experiential Learning
$routes->add('experientialLearning','TeachingLearningEvaluation::experientialLearning');
$routes->post('saveExperientialLearning','TeachingLearningEvaluation::saveExperientialLearning');
$routes->post('updateExperientialLearning','TeachingLearningEvaluation::updateExperientialLearning');
$routes->post('deleteExperientialLearning','TeachingLearningEvaluation::deleteExperientialLearning');

// Message Box
$routes->add('errorMessage','ErrorMessage::errorMessage');


// Teacher Enroll  Reports
$routes->add('teachingExperiance_Report','GenerateExcel_Report::teachingExperiance_Report');
$routes->add('teachingPeriod_Report','GenerateExcel_Report::teachingPeriod_Report');

// Reaserch Project Info Report
$routes->add('researchProject_Report','GenerateExcel_Report_Resaerch::researchProject_Report');
$routes->add('researchGuide_Report','GenerateExcel_Report_Resaerch::researchGuide_Report');
$routes->add('seedMoney_Report','GenerateExcel_Report_Resaerch::seedMoney_Report');
$routes->add('fellowshipFinancial_Report','GenerateExcel_Report_Resaerch::fellowshipFinancial_Report');
$routes->add('researchPublication_Report','GenerateExcel_Report_Resaerch::researchPublication_Report');

 


//HOD 
$routes->add('hod_1_1_1','HOD::hod_1_1_1');
$routes->post('save_1_1_1','HOD::save_1_1_1');
$routes->post('delete_1_1_1','HOD::delete_1_1_1');


$routes->add('hod_1_1_2','HOD::hod_1_1_2');
$routes->post('save_1_1_2','HOD::save_1_1_2');

$routes->add('hod_1_2_1','HOD::hod_1_2_1');
$routes->post('save_1_2_1','HOD::save_1_2_1');

$routes->add('hod_1_3_1','HOD::hod_1_3_1');
$routes->post('save_1_3_1','HOD::save_1_3_1');

$routes->add('hod_1_3_2','HOD::hod_1_3_2');
$routes->post('save_1_3_2','HOD::save_1_3_2');
$routes->post('update_1_3_2','HOD::update_1_3_2');
$routes->post('delete_1_3_2','HOD::delete_1_3_2');


$routes->add('hod_2_2_1','HOD::hod_2_2_1');
$routes->post('save_2_2_1','HOD::save_2_2_1');

$routes->add('hod_2_3_3','HOD::hod_2_3_3');
$routes->post('save_2_3_3','HOD::save_2_3_3');

$routes->add('hod_2_6_1','HOD::hod_2_6_1');
$routes->post('save_2_6_1','HOD::save_2_6_1');

$routes->add('hod_3_1_1','HOD::hod_3_1_1');
$routes->post('save_3_1_1','HOD::save_3_1_1');

$routes->add('hod_3_3_1','HOD::hod_3_3_1');
$routes->post('save_3_3_1','HOD::save_3_3_1');

$routes->add('hod_3_6_1','HOD::hod_3_6_1');
$routes->post('save_3_6_1','HOD::save_3_6_1');

$routes->add('hod_5_1_2','HOD::hod_5_1_2');
$routes->post('save_5_1_2','HOD::save_5_1_2');

$routes->add('hod_5_1_3','HOD::hod_5_1_3');
$routes->post('save_5_1_3','HOD::save_5_1_3');

$routes->add('hod_5_2_1','HOD::hod_5_2_1');
$routes->post('save_5_2_1','HOD::save_5_2_1');

$routes->add('hod_5_2_3','HOD::hod_5_2_3');
$routes->post('save_5_2_3','HOD::save_5_2_3');

$routes->add('hod_7_1_1','HOD::hod_7_1_1');
$routes->post('save_7_1_1','HOD::save_7_1_1');

$routes->add('hod_7_1_8','HOD::hod_7_1_8');
$routes->post('save_7_1_8','HOD::save_7_1_8');

$routes->add('hod_7_2_1','HOD::hod_7_2_1');
$routes->post('save_7_2_1','HOD::save_7_2_1');

// IQAC
$routes->add('iqac_2_3_3','IQAC::iqac_2_3_3');
$routes->post('save_IQAC_2_3_3','IQAC::save_IQAC_2_3_3');

$routes->add('iqac_4_1_1','IQAC::iqac_4_1_1');
$routes->post('save_IQAC_4_1_1','IQAC::save_IQAC_4_1_1');

$routes->add('iqac_4_4_2','IQAC::iqac_4_4_2');
$routes->post('save_IQAC_4_4_2','IQAC::save_IQAC_4_4_2');

$routes->add('iqac_6_1_1','IQAC::iqac_6_1_1');
$routes->post('save_IQAC_6_1_1','IQAC::save_IQAC_6_1_1');

$routes->add('iqac_6_2_1','IQAC::iqac_6_2_1');
$routes->post('save_IQAC_6_2_1','IQAC::save_IQAC_6_2_1');

$routes->add('iqac_6_2_2','IQAC::iqac_6_2_2');
$routes->post('save_IQAC_6_2_2','IQAC::save_IQAC_6_2_2');

$routes->add('iqac_6_3_1','IQAC::iqac_6_3_1');
$routes->post('save_IQAC_6_3_1','IQAC::save_IQAC_6_3_1');

$routes->add('iqac_6_3_2','IQAC::iqac_6_3_2');
$routes->post('save_IQAC_6_3_2','IQAC::save_IQAC_6_3_2');

$routes->add('iqac_6_4_1','IQAC::iqac_6_4_1');
$routes->post('save_IQAC_6_4_1','IQAC::save_IQAC_6_4_1');

$routes->add('iqac_6_4_3','IQAC::iqac_6_4_3');
$routes->post('save_IQAC_6_4_3','IQAC::save_IQAC_6_4_3');

$routes->add('iqac_6_5_1','IQAC::iqac_6_5_1');
$routes->post('save_IQAC_6_5_1','IQAC::save_IQAC_6_5_1');

$routes->add('iqac_6_5_2','IQAC::iqac_6_5_2');
$routes->post('save_IQAC_6_5_2','IQAC::save_IQAC_6_5_2');

$routes->add('iqac_6_5_3','IQAC::iqac_6_5_3');
$routes->post('save_IQAC_6_5_3','IQAC::save_IQAC_6_5_3');

$routes->add('iqac_7_1_1','IQAC::iqac_7_1_1');
$routes->post('save_IQAC_7_1_1','IQAC::save_IQAC_7_1_1');

$routes->add('iqac_7_1_6','IQAC::iqac_7_1_6');
$routes->post('save_IQAC_7_1_6','IQAC::save_IQAC_7_1_6');

$routes->add('iqac_7_1_10','IQAC::iqac_7_1_10');
$routes->post('save_IQAC_7_1_10','IQAC::save_IQAC_7_1_10');

$routes->add('iqac_7_3_1','IQAC::iqac_7_3_1');
$routes->post('save_IQAC_7_3_1','IQAC::save_IQAC_7_3_1');


//-----------Committee-----------------------------------//

//Exam
$routes->add('exam_2_5_1','Committee::exam_2_5_1');
$routes->post('save_exam_2_5_1','Committee::save_exam_2_5_1');

$routes->add('exam_2_5_2','Committee::exam_2_5_2');
$routes->post('save_exam_2_5_2','Committee::save_exam_2_5_2');

$routes->add('exam_2_5_3','Committee::exam_2_5_3');
$routes->post('save_exam_2_5_3','Committee::save_exam_2_5_3');

$routes->add('exam_2_6_2','Committee::exam_2_6_2');
$routes->post('save_exam_2_6_2','Committee::save_exam_2_6_2');

//Library
$routes->add('library_3_4_5','Committee::library_3_4_5');
$routes->post('save_library_3_4_5','Committee::save_library_3_4_5');

$routes->add('library_3_4_6','Committee::library_3_4_6');
$routes->post('save_library_3_4_6','Committee::save_library_3_4_6');

$routes->add('library_4_2_1','Committee::library_4_2_1');
$routes->post('save_library_4_2_1','Committee::save_library_4_2_1');

$routes->add('library_4_2_2','Committee::library_4_2_2');
$routes->post('save_library_4_2_2','Committee::save_library_4_2_2');

//Office
$routes->add('office_2_1__2_2','Committee::office_2_1__2_2');
$routes->post('save_office_2_1__2_2','Committee::save_office_2_1__2_2');

$routes->add('office_2_1_1','Committee::office_2_1_1');
$routes->post('save_office_2_1_1','Committee::save_office_2_1_1');

$routes->add('office_2_1_2','Committee::office_2_1_2');
$routes->post('save_office_2_1_2','Committee::save_office_2_1_2');

$routes->add('office_2_2_2','Committee::office_2_2_2');
$routes->post('save_office_2_2_2','Committee::save_office_2_2_2');

$routes->add('office_6_4_2','Committee::office_6_4_2');
$routes->post('save_office_6_4_2','Committee::save_office_6_4_2');

$routes->add('office_412_422_441','Committee::office_412_422_441');
$routes->post('save_office_412_422_441','Committee::save_office_412_422_441');

$routes->add('physical_facilities_environment','Committee::physical_facilities_environment');
$routes->post('save_physical_facilities_environment','Committee::save_physical_facilities_environment');

$routes->add('physical_facilities','Committee::physical_facilities');              //incomplete
$routes->post('save_physical_facilities','Committee::save_physical_facilities');   //incomplete
















/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
